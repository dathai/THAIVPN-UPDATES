// ============================================================================
// 🎨 UNIVERSAL MODERN GLASSMORPHISM ALERT, CONFIRM & PROMPT MANAGER
// Automatically intercepts all alert(), confirm(), prompt() calls across the entire app
// ============================================================================
(function() {
    let alertResolve = null;

    function showModernDialog({ message, title = null, type = 'info', isConfirm = false, isPrompt = false, defaultValue = '' }) {
        return new Promise((resolve) => {
            alertResolve = resolve;

            const modal = document.getElementById('global-alert-modal');
            const card = document.getElementById('global-alert-card');
            const iconWrap = document.getElementById('global-alert-icon-wrap');
            const icon = document.getElementById('global-alert-icon');
            const titleEl = document.getElementById('global-alert-title');
            const msgEl = document.getElementById('global-alert-message');
            const inputWrap = document.getElementById('global-alert-input-wrap');
            const inputEl = document.getElementById('global-alert-input');
            const btnCancel = document.getElementById('btn-global-alert-cancel');
            const btnOk = document.getElementById('btn-global-alert-ok');
            const strip = document.getElementById('global-alert-strip');

            if (!modal) {
                // If DOM not loaded yet, fallback to native console
                console.warn('[ALERT FALLBACK]', message);
                return resolve(true);
            }

            // Detect type automatically from text content if not explicitly specified
            const lower = String(message || '').toLowerCase();
            if (type === 'info') {
                if (lower.includes('error') || lower.includes('failed') || lower.includes('fail') || lower.includes('404') || lower.includes('ไม่สำเร็จ') || lower.includes('ล้มเหลว') || lower.includes('ผิดพลาด')) {
                    type = 'error';
                } else if (lower.includes('warning') || lower.includes('เตือน') || lower.includes('ระวัง') || lower.includes('ลบ') || lower.includes('reset') || isConfirm) {
                    type = 'warning';
                } else if (lower.includes('สำเร็จ') || lower.includes('success') || lower.includes('ok') || lower.includes('เรียบร้อย') || lower.includes('ล่าสุด')) {
                    type = 'success';
                }
            }

            // Apply modern theme per type
            if (type === 'error') {
                if (!title) title = 'เกิดข้อผิดพลาด';
                if (iconWrap) {
                    iconWrap.style.background = 'rgba(239, 68, 68, 0.15)';
                    iconWrap.style.borderColor = 'rgba(239, 68, 68, 0.35)';
                    iconWrap.style.color = '#f87171';
                    iconWrap.style.boxShadow = '0 0 20px rgba(239, 68, 68, 0.3)';
                }
                if (icon) icon.className = 'fas fa-exclamation-circle';
                if (strip) strip.style.background = 'linear-gradient(90deg, #ef4444, #f87171)';
                if (btnOk) {
                    btnOk.style.background = 'linear-gradient(135deg, #dc2626, #ef4444)';
                    btnOk.style.boxShadow = '0 4px 15px rgba(239, 68, 68, 0.35)';
                }
            } else if (type === 'warning') {
                if (!title) title = isConfirm ? 'ยืนยันการทำรายการ' : 'ข้อควรระวัง';
                if (iconWrap) {
                    iconWrap.style.background = 'rgba(245, 158, 11, 0.15)';
                    iconWrap.style.borderColor = 'rgba(245, 158, 11, 0.35)';
                    iconWrap.style.color = '#fbbf24';
                    iconWrap.style.boxShadow = '0 0 20px rgba(245, 158, 11, 0.3)';
                }
                if (icon) icon.className = 'fas fa-exclamation-triangle';
                if (strip) strip.style.background = 'linear-gradient(90deg, #f59e0b, #fbbf24)';
                if (btnOk) {
                    btnOk.style.background = 'linear-gradient(135deg, #d97706, #f59e0b)';
                    btnOk.style.boxShadow = '0 4px 15px rgba(245, 158, 11, 0.35)';
                }
            } else if (type === 'success') {
                if (!title) title = 'ดำเนินการสำเร็จ';
                if (iconWrap) {
                    iconWrap.style.background = 'rgba(34, 197, 94, 0.15)';
                    iconWrap.style.borderColor = 'rgba(34, 197, 94, 0.35)';
                    iconWrap.style.color = '#4ade80';
                    iconWrap.style.boxShadow = '0 0 20px rgba(34, 197, 94, 0.3)';
                }
                if (icon) icon.className = 'fas fa-check-circle';
                if (strip) strip.style.background = 'linear-gradient(90deg, #22c55e, #4ade80)';
                if (btnOk) {
                    btnOk.style.background = 'linear-gradient(135deg, #16a34a, #22c55e)';
                    btnOk.style.boxShadow = '0 4px 15px rgba(34, 197, 94, 0.35)';
                }
            } else {
                if (!title) title = 'แจ้งเตือนระบบ';
                if (iconWrap) {
                    iconWrap.style.background = 'rgba(56, 189, 248, 0.15)';
                    iconWrap.style.borderColor = 'rgba(56, 189, 248, 0.35)';
                    iconWrap.style.color = '#38bdf8';
                    iconWrap.style.boxShadow = '0 0 20px rgba(56, 189, 248, 0.3)';
                }
                if (icon) icon.className = 'fas fa-info-circle';
                if (strip) strip.style.background = 'linear-gradient(90deg, #38bdf8, #818cf8)';
                if (btnOk) {
                    btnOk.style.background = 'linear-gradient(135deg, #0284c7, #38bdf8)';
                    btnOk.style.boxShadow = '0 4px 15px rgba(56, 189, 248, 0.35)';
                }
            }

            if (titleEl) titleEl.textContent = title;
            if (msgEl) msgEl.textContent = String(message || '');

            if (isPrompt) {
                if (inputWrap) inputWrap.style.display = 'block';
                if (inputEl) {
                    inputEl.value = defaultValue || '';
                    setTimeout(() => { inputEl.focus(); inputEl.select(); }, 60);
                }
            } else {
                if (inputWrap) inputWrap.style.display = 'none';
            }

            if (isConfirm || isPrompt) {
                if (btnCancel) btnCancel.style.display = 'block';
                if (btnOk) {
                    btnOk.style.flex = '1';
                    btnOk.textContent = 'ยืนยัน';
                }
            } else {
                if (btnCancel) btnCancel.style.display = 'none';
                if (btnOk) {
                    btnOk.style.flex = '2';
                    btnOk.textContent = 'ตกลง';
                }
            }

            modal.style.display = 'flex';
            setTimeout(() => {
                if (card) card.style.transform = 'scale(1)';
                if (btnOk && !isPrompt) btnOk.focus();
            }, 10);

            function closeModal(result) {
                if (card) card.style.transform = 'scale(0.95)';
                setTimeout(() => {
                    if (modal) modal.style.display = 'none';
                }, 140);
                window.removeEventListener('keydown', onKey);
                if (alertResolve) {
                    alertResolve(result);
                    alertResolve = null;
                }
            }

            if (btnOk) {
                btnOk.onclick = () => {
                    if (isPrompt && inputEl) {
                        closeModal(inputEl.value);
                    } else {
                        closeModal(true);
                    }
                };
            }

            if (btnCancel) {
                btnCancel.onclick = () => {
                    closeModal(isPrompt ? null : false);
                };
            }

            function onKey(e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    if (btnOk) btnOk.click();
                } else if (e.key === 'Escape') {
                    e.preventDefault();
                    if (isConfirm || isPrompt) {
                        if (btnCancel) btnCancel.click();
                    } else {
                        if (btnOk) btnOk.click();
                    }
                }
            }
            window.addEventListener('keydown', onKey);
        });
    }

    // 1. OVERRIDE GLOBAL alert()
    window.alert = function(msg) {
        return showModernDialog({ message: msg });
    };

    // 2. OVERRIDE GLOBAL confirm()
    window.confirm = function(msg) {
        return showModernDialog({ message: msg, isConfirm: true });
    };

    // 3. OVERRIDE GLOBAL prompt()
    window.prompt = function(msg, def) {
        return showModernDialog({ message: msg, isPrompt: true, defaultValue: def });
    };

    // 4. EXPLICIT HELPER APIs
    window.showCustomAlert = function(msg, type = 'info', title = null) {
        return showModernDialog({ message: msg, type, title });
    };

    window.showCustomConfirm = function(msg, title = null) {
        return showModernDialog({ message: msg, isConfirm: true, title });
    };

    window.showCustomPrompt = function(msg, def = '', title = null) {
        return showModernDialog({ message: msg, isPrompt: true, defaultValue: def, title });
    };
})();

// Translations
const translations = {
    en: {
        nav_sys: "System Tools",
        nav_clean: "PC Cleanup",
        nav_test: "Test Mode",
                header_sys_title: "System Tools",
        header_sys_desc: "Manage your device and network settings.",
        card_dev_title: "Device Manager",
        card_dev_desc: "Open Windows Device Manager",
        card_dev_btn: "Launch",
        card_reg_title: "Network Registry",
        card_reg_desc: "Open Registry for Network Reset",
        card_reg_btn: "Launch",
        card_store_title: "Reserved Storage",
        card_store_desc: "Disable Windows Reserved Storage",
        card_store_btn: "Disable (Admin)",
        // Network Tools
        hdr_net_tools: "🌐 Network Tools",
        hdr_drv_tools: "📱 Driver Tools",
        hdr_maint_tools: "🔧 Maintenance",
        hdr_quick_launch: "⚡ Quick Launch",
        btn_net_reset: "Network Reset",
        btn_flush_dns: "Flush DNS",
        btn_show_ip: "Show IP Info",
        btn_ping_test: "Ping Test",
        btn_proxy: "Proxy Settings",
        // Driver Tools
        btn_drv_adb: "ADB Driver",
        btn_drv_mtk: "MTK (VCOM)",
        btn_drv_qcom: "Qualcomm 9008",
        btn_drv_spd: "SPD Driver",
        btn_drv_samsung: "Samsung USB",
        btn_drv_zadig: "Zadig",
        // Maintenance
        btn_chkdsk: "CHKDSK (C:)",
        btn_sfc: "SFC /scannow",
        btn_dism: "DISM Repair",
        btn_startup: "Startup Apps",
        btn_msinfo: "System Info",
        btn_services: "Services",
        // Quick Launch
        btn_taskmgr: "Task Manager",
        btn_calc: "Calculator",
        btn_notepad: "Notepad",
        btn_snip: "Snipping Tool",
        btn_paint: "Paint",
        btn_diskmgmt: "Disk Management",
        card_def_title: "Windows Defender",
        card_def_desc: "Turn Real-time Protection On/Off",
        btn_def_off: "Disable (Admin)",
        btn_def_on: "Enable (Admin)",
        card_hosts_title: "Hosts Editor",
        card_hosts_desc: "Edit Windows hosts file to block servers",
        btn_hosts: "Edit Hosts (Admin)",
        card_ncpa_title: "Network Adapters",
        card_ncpa_desc: "Open Network Connections (ncpa.cpl)",
        btn_ncpa: "Open Network",
        header_clean_title: "PC Cleanup Tool",
        header_clean_desc: "Free up disk space by clearing caches and temporary files.",
        drive_c_title: "C: Drive (Windows System)",
        drive_free_text: "Free:",
        drive_total_text: "Total:",
        drive_used_text: "Used",
        drive_usage_pct: "Disk Usage",
        btn_smart_clean: "⚡ 1-Click Smart Clean",
        smart_clean_hint: "Instantly clean safe high-impact caches and temp files",
        preset_safe: "Recommended (Safe)",
        preset_all: "Select All (Deep)",
        preset_none: "Deselect All",
        chk_temp_title: "Windows Temp Files",
        chk_temp_desc: "User Temp, Windows Temp, Prefetch, Thumbnails, Delivery Opt.",
        chk_trash_title: "Recycle Bin & Crash Dumps",
        chk_trash_desc: "Empty Recycle Bin, Minidumps, BSOD Dumps, WER Reports",
        chk_shader_title: "DirectX & GPU Shader Caches",
        chk_shader_desc: "DirectX, NVIDIA, AMD, Intel Shader Caches",
        chk_browser_title: "Browser Caches",
        chk_browser_desc: "Chrome, Edge, Firefox, Brave, Opera",
        chk_game_title: "Game Launchers Caches",
        chk_game_desc: "Steam, Epic Games, Riot, EA Desktop",
        chk_dev_title: "Developer Caches",
        chk_dev_desc: "Gradle, npm, pip, NuGet, Pub, Yarn",
        chk_app_title: "App Caches",
        chk_app_desc: "Discord, Spotify, LINE, Telegram, TikTok LIVE Studio",
        chk_win_title: "Deep Windows Cleanup",
        chk_win_desc: "Windows Update Download Cache, System Disk Cleanup, DISM",
        btn_run_clean: "Run Selected Cleanup",
        btn_scan_junk: "Scan Junk Files",
        scan_results: "Junk Analysis Results",
        scan_total_junk: "Total Junk:",
        scan_progress: "Scanning...",
        scan_no_junk: "No junk files found!",
        header_test_title: "Test Mode Configuration",
        header_test_desc: "Toggle Windows TestSigning mode for driver testing.",
        test_status: "Checking status...",
        test_status_on: "Test Mode is ON",
        test_status_off: "Test Mode is OFF",
        btn_test_on: "Enable Test Mode (ON)",
        btn_test_on_desc: "For Flashing Tools",
        btn_test_off: "Disable Test Mode (OFF)",
        btn_test_off_desc: "For Gaming / Anti-Cheat",
        test_note_strong: "Note:",
        test_note: "Changing Test Mode requires Administrator privileges and a system restart to take effect.",
        modal_title: "Running Task...",
        modal_title_storage: "Disabling Reserved Storage (Admin)",
        modal_title_cleanup: "Running PC Cleanup...",
        modal_title_test_on: "Enabling Test Mode (Admin)",
        modal_title_test_off: "Disabling Test Mode (Admin)",
        modal_close: "Close",
        
        // Mobile Tools EN
        nav_mobile: "Mobile Tools",
        nav_root: "ROOT Tool",
        nav_pico: "Raspberry Pi Flasher",
        header_mobile_title: "Mobile Tools",
        header_mobile_desc: "Manage your Android device using ADB & Fastboot.",
        mobile_adb_devices: "ADB Devices",
        mobile_adb_desc: "Check connected devices in normal/recovery mode.",
        mobile_reboot_fastboot: "Reboot to Fastboot",
        mobile_reboot_fastboot_desc: "Reboot phone into Bootloader/Fastboot mode.",
        mobile_fastboot_devices: "Fastboot Devices",
        mobile_fastboot_desc: "Check devices in Fastboot mode.",
        mobile_fastboot_reboot: "Fastboot Reboot",
        mobile_fastboot_reboot_desc: "Normal restart from Fastboot mode.",
        mobile_cmd: "Open Terminal Here",
        mobile_cmd_desc: "Open CMD in the platform-tools folder for manual commands.",
        mobile_cmd_btn: "Open CMD",
        mobile_flash_title: "Image Flasher",
        mobile_flash_desc: "Flash an image (.img) file to a specific partition via Fastboot.",
        mobile_flash_browse: "Browse File...",
        mobile_flash_now: "Flash Now",
        no_file_selected: "No file selected",
        
        
          mob_qcom_service: "Service (Unlock)",
          mob_btn_readinfo: "Read Info",
          mob_btn_readgpt: "Read GPT (Root)",
          mob_btn_dump: "Dump Firmware",
          mob_btn_erasefrp: "Erase FRP",
          mob_btn_factory: "Factory Reset",
          mob_btn_micloud: "Mi Cloud Bypass",
          mob_qcom_security: "Security (IMEI/EFS)",
          mob_btn_backupefs: "Backup EFS",
          mob_btn_restoreefs: "Restore EFS",
          mob_btn_eraseefs: "Erase EFS",
          mob_qcom_port: "Select Device Port (EDL 9008):",
          mob_no_devices: "No devices found",
          mob_btn_scanports: "Scan Ports",
          mob_qcom_flasher: "Qualcomm Flasher",
          mob_qcom_flasher_desc: "Load rawprogram0.xml or .map (UnlockTool Dump) to flash.",
          mob_qcom_load_fw: "1. Load Firmware / Map",
          mob_qcom_load_prog: "2. Load Programmer",
          mob_qcom_load_patch: "3. Load Patch",
          mob_no_file: "No file selected",
          mob_qcom_prog_desc: "Optional: prog_emmc_firehose.mbn",
          mob_qcom_patch_desc: "Optional: patch0.xml",
          mob_qcom_flash: "Flash QCOM Firmware",
          mob_mtk_unlockbl: "Unlock Bootloader",
          mob_mtk_security: "Security (NVRAM)",
          mob_mtk_backupnv: "Backup NVRAM/NVDATA",
          mob_mtk_restorenv: "Restore NVRAM",
          mob_mtk_erasenv: "Erase NVRAM",
          mob_mtk_conn: "Connection / Boot Settings",
          mob_mtk_brom: "BROM Mode (Bypass SLA)",
          mob_mtk_preloader: "Preloader Mode",
          mob_mtk_da: "Custom DA",
          mob_mtk_emi: "Preloader / EMI",
          mob_mtk_auth: "Auth File",
          mob_btn_browse: "Browse",
          mob_mtk_modeldb: "Select Model Database",
          mob_mtk_flasher: "MediaTek Flasher",
          mob_mtk_flasher_desc: "Load Scatter (.txt) or .map (UnlockTool Dump) to flash.",
          mob_mtk_load_scatter: "Load Scatter / Map",
          mob_mtk_flash: "Flash MTK Firmware",
          mob_adb_tools: "ADB Tools (USB Debugging)",
          mob_adb_reboot_rec: "Reboot Recovery",
          mob_adb_reboot_bl: "Reboot Bootloader",
          mob_adb_reboot_edl: "Reboot EDL",
          mob_fb_tools: "Fastboot Tools",
          mob_btn_scandevices: "Scan Devices",
          mob_fb_reboot_normal: "Reboot Normal",
          mob_adb_dump_title: "Firmware Dump (ADB Root)",
          mob_adb_dump_desc: "Dump device partitions directly via ADB (Requires Root / su access). Ensure device has sufficient free space.",
          mob_adb_dump_scan: "1. Scan Partitions",
          mob_adb_dump_scatter: "Generate MTK Scatter File (MTK Only)",
          mob_adb_dump_avail: "Available Partitions:",
          mob_adb_dump_now: "2. Dump Selected Partitions",
          mob_adb_app_title: "App Remover (ADB)",
          mob_adb_app_desc: "Scan and forcibly remove stubborn apps or viruses via ADB.",
          mob_adb_app_load: "Load Installed Apps",

          mob_spd_service: "Service (Unlock)",
          mob_spd_port: "Select Device Port (SPRD U2S):",
          mob_spd_flasher: "Unisoc / SPD Flasher",
          mob_spd_flasher_desc: "Load .pac firmware file to flash.",
          mob_spd_load_pac: "1. Load .pac File",
          mob_spd_flash: "Flash SPD Firmware",
// Advanced Firmware Flasher EN
        mobile_adv_flash_title: "Advanced Firmware Flasher (MTK & Qualcomm)",
        mobile_adv_flash_desc: "Load Scatter (.txt) or RawProgram (.xml) to flash multiple partitions automatically.",
        mobile_browse_fw: "1. Load Firmware File",
        mobile_browse_prog: "2. Load Programmer (QCOM)",
        mobile_browse_patch: "3. Load Patch (QCOM)",
        mobile_partitions_title: "Partitions to Flash:",
        mobile_select_all: "Select All",
        mobile_select_none: "Select None",
        mobile_flash_fw_now: "Flash Selected Partitions",
        
        card_rm_title: "Rainmeter Skins",
        card_rm_desc: "Manage custom Rainmeter skins and layouts",
        btn_dl_rm: "Download Rainmeter",
        btn_apply_rm_net: "Apply Skins (Net/Sys)",
        btn_apply_rm_full: "Apply Full Setup (Current)",
        card_wifi_title: "WiFi Passwords",
        card_wifi_desc: "View saved WiFi passwords",
        dropdown_scan: "Scan to load...",
        btn_scan: "Scan",
        btn_show: "Show",
        card_usb_title: "Fix USB Virus",
        card_usb_desc: "Unhide files and remove shortcut virus",
        btn_usb_fix: "Fix Drive Now",
        root_title: '⚡ One-Click ROOT Tool',
        root_subtitle: 'Scan device → auto-detect brand/model → root with Magisk in one click.',
        root_no_device: 'No device detected',
        root_scan_btn: 'Scan Device',
        root_device_info: 'Device Info',
        root_brand: 'Brand',
        root_model: 'Model',
        root_method: 'Root Method',
        root_device_details: '📋 Device Details',
        root_det_model: 'Model',
        root_det_android: 'Android',
        root_det_serial: 'Serial',
        root_det_cpu: 'CPU',
        root_det_bootloader: 'Bootloader',
        root_det_root: 'Root Status',
        root_start_btn: 'One-Click ROOT',
        root_progress_title: '⚙️ Root Progress',
        root_status_idle: 'Idle',
        root_waiting: 'Waiting...',
        root_log_title: '📟 Root Log',
        root_log_placeholder: '[ Root process log will appear here... ]',
        nav_settings: 'Settings',
        set_title: 'App Settings',
        set_width: 'Window Width',
        set_height: 'Window Height',
        set_cancel: 'Cancel',
        set_save: 'Save',
        
        // Odin
        
        nav_rom: "ROM Download",
        header_rom_title: "ROM & Firmware Workstation",
        header_rom_desc: "Official Android Stock ROMs, Apple IPSW Direct CDN, MTK/Qualcomm Service Files & Hasher Tools",
        rom_tab_android: "Android Firmware Hub",
        rom_tab_apple: "Apple iOS / iPadOS Live IPSW",
        rom_tab_service: "Service & Unlock Files (FRP / DA)",
        rom_tab_tools: "Firmware Verifier & Hasher",
        rom_tab_downloader: "Download Manager",
        rom_android_picker: "Select Device",
        rom_brand_label: "Brand:",
        rom_model_label: "Models:",
        rom_save_dest: "Download Destination Folder:",
        nav_odin: 'Odin Flasher',
        odin_title: 'Odin Flasher (Samsung)',
        odin_subtitle: 'Flash Samsung firmware files (.tar / .md5) in Download Mode.',
        odin_options: 'Options',
        odin_log: 'Log',
        odin_files: 'Firmware Files',
        nav_apple_flasher: 'Apple iOS Flasher',
        apple_flasher_title: 'Apple iOS Flasher',
        apple_flasher_subtitle: 'Restore, Clean Flash & Update iOS for iPhone and iPad'
    },
    th: {
        nav_sys: "เครื่องมือระบบ",
        nav_clean: "ล้างขยะในเครื่อง",
        nav_test: "โหมดทดสอบ",
                header_sys_title: "เครื่องมือระบบ",
        header_sys_desc: "จัดการตั้งค่าอุปกรณ์และเครือข่ายของคุณ",
        card_dev_title: "ตัวจัดการอุปกรณ์",
        card_dev_desc: "เปิดหน้าจอ Device Manager ของ Windows",
        card_dev_btn: "เปิดใช้งาน",
        card_reg_title: "รีเซ็ต Registry เครือข่าย",
        card_reg_desc: "เปิด Registry สำหรับแก้ไขหรือรีเซ็ตเครือข่าย",
        card_reg_btn: "เปิดใช้งาน",
        card_store_title: "ปิด Reserved Storage",
        card_store_desc: "ปิดพื้นที่สำรองอัปเดตของ Windows",
        card_store_btn: "ปิดการใช้งาน (Admin)",
        card_def_title: "เปิด-ปิด แอนตี้ไวรัส",
        card_def_desc: "ปิด Windows Defender ชั่วคราว (กันลบไฟล์แฟลช)",
        btn_def_off: "ปิดการป้องกัน (Admin)",
        btn_def_on: "เปิดการป้องกัน (Admin)",
        card_hosts_title: "แก้ไขไฟล์ Hosts",
        card_hosts_desc: "บล็อกเซิร์ฟเวอร์ผ่านไฟล์ Hosts",
        btn_hosts: "เปิด Notepad (Admin)",
        card_ncpa_title: "ตั้งค่าเน็ตเวิร์ค",
        card_ncpa_desc: "เปิดหน้าตั้งค่าวงแลน / แชร์เน็ต",
        btn_ncpa: "เปิด Network Settings",
        // Network Tools Headers & Buttons
        hdr_net_tools: "🌐 เครื่องมือเน็ตเวิร์ค",
        btn_net_reset: "รีเซ็ตเน็ตเวิร์ค",
        btn_flush_dns: "ล้าง DNS Cache",
        btn_show_ip: "ดูข้อมูล IP",
        btn_ping_test: "ทดสอบ Ping",
        btn_proxy: "ตั้งค่า Proxy",
        // Driver Tools
        hdr_drv_tools: "📱 โหลดไดรเวอร์มือถือ",
        btn_drv_adb: "โหลด ADB Driver",
        btn_drv_mtk: "โหลด MTK (VCOM)",
        btn_drv_qcom: "โหลด Qualcomm 9008",
        btn_drv_spd: "โหลด SPD Driver",
        btn_drv_samsung: "โหลด Samsung USB",
        btn_drv_zadig: "เปิด Zadig",
        // Maintenance
        hdr_maint_tools: "🔧 ซ่อมบำรุงระบบ",
        btn_chkdsk: "ตรวจ HDD (C:)",
        btn_sfc: "ซ่อมไฟล์ระบบ",
        btn_dism: "ซ่อม Windows Image",
        btn_startup: "โปรแกรมตอนเปิด",
        btn_msinfo: "ข้อมูลระบบ",
        btn_services: "จัดการ Services",
        // Quick Launch
        hdr_quick_launch: "⚡ เปิดโปรแกรมด่วน",
        btn_taskmgr: "Task Manager",
        btn_calc: "เครื่องคิดเลข",
        btn_notepad: "Notepad",
        btn_snip: "จับภาพหน้าจอ",
        btn_paint: "Paint",
        btn_diskmgmt: "จัดการดิสก์",
        header_clean_title: "เครื่องมือล้างขยะระบบ (PC Cleanup)",
        header_clean_desc: "เพิ่มพื้นที่ว่างไดรฟ์ C: โดยการลบไฟล์แคช ไฟล์ขยะ และไฟล์ตกค้างในระบบ",
        drive_c_title: "ไดรฟ์ C: (ระบบ Windows)",
        drive_free_text: "พื้นที่ว่าง:",
        drive_total_text: "ทั้งหมด:",
        drive_used_text: "ใช้ไป",
        drive_usage_pct: "การใช้งานดิสก์",
        btn_smart_clean: "⚡ 1-Click ล้างด่วนอัจฉริยะ",
        smart_clean_hint: "ล้างไฟล์ขยะและแคชปลอดภัยที่กินพื้นที่เยอะที่สุดทันที",
        preset_safe: "แนะนำ (Safe)",
        preset_all: "เลือกทั้งหมด (All)",
        preset_none: "ยกเลิกทั้งหมด (None)",
        chk_temp_title: "ไฟล์ขยะระบบ Windows",
        chk_temp_desc: "User Temp, Windows Temp, Prefetch, Thumbnails, Delivery Opt.",
        chk_trash_title: "ถังขยะและไฟล์ดัมพ์ข้อผิดพลาด",
        chk_trash_desc: "ล้างถังขยะทุกไดรฟ์, Minidumps, BSOD Dumps, WER Reports",
        chk_shader_title: "แคชการ์ดจอ DirectX & GPU Shaders",
        chk_shader_desc: "แคชสำหรับเล่นเกมและตัดต่อ DirectX, NVIDIA, AMD, Intel",
        chk_browser_title: "ไฟล์แคชเว็บบราวเซอร์",
        chk_browser_desc: "Chrome, Edge, Firefox, Brave, Opera",
        chk_game_title: "แคชโปรแกรมเปิดเกม (Game Launchers)",
        chk_game_desc: "Steam, Epic Games, Riot, EA Desktop",
        chk_dev_title: "แคชสำหรับโปรแกรมเมอร์",
        chk_dev_desc: "Gradle, npm, pip, NuGet, Pub, Yarn",
        chk_app_title: "แคชแอปพลิเคชันและโปรแกรมแชท",
        chk_app_desc: "Discord, Spotify, LINE, Telegram, TikTok LIVE Studio",
        chk_win_title: "ล้างลึกระดับระบบ (Admin)",
        chk_win_desc: "Windows Update Download, Disk Cleanup System, DISM",
        btn_run_clean: "เริ่มการล้างขยะที่เลือก",
        btn_scan_junk: "สแกนวิเคราะห์ไฟล์ขยะ",
        scan_results: "ผลการวิเคราะห์ไฟล์ขยะ",
        scan_total_junk: "รวมขยะทั้งหมด:",
        scan_progress: "กำลังสแกน...",
        scan_no_junk: "ไม่พบไฟล์ขยะ!",
        header_test_title: "ตั้งค่าโหมดทดสอบ",
        header_test_desc: "เปิด-ปิด Windows TestSigning mode สำหรับทดสอบไดรเวอร์",
        test_status: "กำลังตรวจสอบ...",
        test_status_on: "โหมดทดสอบ: เปิด",
        test_status_off: "โหมดทดสอบ: ปิด",
        btn_test_on: "เปิดโหมดทดสอบ (ON)",
        btn_test_on_desc: "สำหรับเครื่องมือแฟลชรอม",
        btn_test_off: "ปิดโหมดทดสอบ (OFF)",
        btn_test_off_desc: "สำหรับเล่นเกม / ป้องกันแบน",
        test_note_strong: "หมายเหตุ:",
        test_note: "การสลับโหมดต้องใช้สิทธิ์ Administrator และต้องรีสตาร์ทคอมพิวเตอร์เพื่อแสดงผล",
        modal_title: "กำลังทำงาน...",
        modal_title_storage: "กำลังปิด Reserved Storage (Admin)",
        modal_title_cleanup: "กำลังล้างขยะ...",
        modal_title_test_on: "กำลังเปิดโหมดทดสอบ (Admin)",
        modal_title_test_off: "กำลังปิดโหมดทดสอบ (Admin)",
        modal_close: "ปิด",
        
        // Mobile Tools TH
        nav_mobile: "เครื่องมือมือถือ",
        nav_root: "เครื่องมือรูท (ROOT)",
        nav_pico: "แฟลช Raspberry Pi",
        header_mobile_title: "เครื่องมือมือถือ (Mobile Tools)",
        header_mobile_desc: "จัดการโทรศัพท์ Android ของคุณผ่าน ADB และ Fastboot",
        mobile_adb_devices: "เช็คอุปกรณ์ ADB",
        mobile_adb_desc: "ตรวจสอบอุปกรณ์ที่ต่อผ่านโหมดปกติหรือ Recovery",
        mobile_reboot_fastboot: "รีบูตเข้า Fastboot",
        mobile_fastboot_desc: "ตรวจสอบมือถือที่เชื่อมต่อในโหมด Fastboot",
        mobile_fastboot_reboot: "รีบูตเครื่องปกติ",
        mobile_fastboot_reboot_desc: "สั่งให้มือถือรีสตาร์ทจาก Fastboot กลับเข้าโหมดปกติ",
        mobile_cmd: "เปิดหน้าต่าง Terminal",
        mobile_cmd_desc: "เปิด CMD ตรงไปที่โฟลเดอร์ platform-tools ทันที",
        mobile_cmd_btn: "เปิด CMD",
        mobile_flash_title: "ระบบแฟลชไฟล์ (Image Flasher)",
        mobile_flash_desc: "เลือกไฟล์ (.img) เพื่อแฟลชลงพาร์ติชันที่ต้องการผ่าน Fastboot",
        mobile_flash_browse: "เลือกไฟล์...",
        mobile_flash_now: "เริ่มแฟลชไฟล์",
        no_file_selected: "ยังไม่ได้เลือกไฟล์",
        
        
          mob_qcom_service: "บริการปลดล็อค (Service)",
          mob_btn_readinfo: "อ่านข้อมูล (Read Info)",
          mob_btn_readgpt: "อ่านตาราง GPT (Root)",
          mob_btn_dump: "ดูดรอม (Dump Firmware)",
          mob_btn_erasefrp: "ปลดล็อค Gmail (FRP)",
          mob_btn_factory: "ล้างเครื่อง (Factory Reset)",
          mob_btn_micloud: "ปลดล็อค Mi Cloud",
          mob_qcom_security: "ความปลอดภัย (IMEI/EFS)",
          mob_btn_backupefs: "สำรองข้อมูล EFS",
          mob_btn_restoreefs: "คืนค่า EFS",
          mob_btn_eraseefs: "ล้าง EFS",
          mob_qcom_port: "เลือกพอร์ตอุปกรณ์ (EDL 9008):",
          mob_no_devices: "ไม่พบอุปกรณ์",
          mob_btn_scanports: "ค้นหาพอร์ต",
          mob_qcom_flasher: "โปรแกรมแฟลช Qualcomm",
          mob_qcom_flasher_desc: "โหลดไฟล์ rawprogram0.xml หรือ .map (UnlockTool Dump) เพื่อแฟลช",
          mob_qcom_load_fw: "1. โหลดไฟล์ Firmware / Map",
          mob_qcom_load_prog: "2. โหลดไฟล์ Programmer",
          mob_qcom_load_patch: "3. โหลดไฟล์ Patch",
          mob_no_file: "ยังไม่ได้เลือกไฟล์",
          mob_qcom_prog_desc: "ตัวเลือก: prog_emmc_firehose.mbn",
          mob_qcom_patch_desc: "ตัวเลือก: patch0.xml",
          mob_qcom_flash: "เริ่มแฟลช Qualcomm",
          mob_mtk_unlockbl: "ปลดล็อค Bootloader",
          mob_mtk_security: "ความปลอดภัย (NVRAM)",
          mob_mtk_backupnv: "สำรองข้อมูล NVRAM/NVDATA",
          mob_mtk_restorenv: "คืนค่า NVRAM",
          mob_mtk_erasenv: "ล้าง NVRAM",
          mob_mtk_conn: "การเชื่อมต่อ / ตั้งค่าบูต",
          mob_mtk_brom: "โหมด BROM (Bypass SLA)",
          mob_mtk_preloader: "โหมด Preloader",
          mob_mtk_da: "ไฟล์ DA",
          mob_mtk_emi: "ไฟล์ Preloader / EMI",
          mob_mtk_auth: "ไฟล์ Auth",
          mob_btn_browse: "เปิดไฟล์",
          mob_mtk_modeldb: "เลือกฐานข้อมูลรุ่น",
          mob_mtk_flasher: "โปรแกรมแฟลช MediaTek",
          mob_mtk_flasher_desc: "โหลดไฟล์ Scatter (.txt) หรือ .map (UnlockTool Dump) เพื่อแฟลช",
          mob_mtk_load_scatter: "โหลดไฟล์ Scatter / Map",
          mob_mtk_flash: "เริ่มแฟลช MediaTek",
          mob_adb_tools: "เครื่องมือ ADB (USB Debugging)",
          mob_adb_reboot_rec: "รีบูตเข้า Recovery",
          mob_adb_reboot_bl: "รีบูตเข้า Bootloader",
          mob_adb_reboot_edl: "รีบูตเข้า EDL",
          mob_fb_tools: "เครื่องมือ Fastboot",
          mob_btn_scandevices: "ค้นหาอุปกรณ์",
          mob_fb_reboot_normal: "รีบูตเข้าหน้าปกติ",
          mob_adb_dump_title: "ดูดรอมผ่าน ADB (Root)",
          mob_adb_dump_desc: "ดูดพาร์ติชั่นต่างๆ ของเครื่องผ่าน ADB (ต้อง Root และให้สิทธิ์ su) ต้องมีพื้นที่ว่างพอ",
          mob_adb_dump_scan: "1. ค้นหาพาร์ติชั่น",
          mob_adb_dump_scatter: "สร้างไฟล์ MTK Scatter ด้วย (เฉพาะ MTK)",
          mob_adb_dump_avail: "พาร์ติชั่นที่พบ:",
          mob_adb_dump_now: "2. ดูดไฟล์พาร์ติชั่นที่เลือก",
          mob_adb_app_title: "เครื่องมือลบแอป (ADB)",
          mob_adb_app_desc: "ค้นหาและลบแอปขยะหรือไวรัสที่ฝังตัวแน่นผ่าน ADB",
          mob_adb_app_load: "โหลดแอปในเครื่อง",

          mob_spd_service: "บริการปลดล็อค (Service)",
          mob_spd_port: "เลือกพอร์ตอุปกรณ์ (SPRD U2S):",
          mob_spd_flasher: "โปรแกรมแฟลช Unisoc / SPD",
          mob_spd_flasher_desc: "โหลดไฟล์เฟิร์มแวร์ .pac เพื่อแฟลช",
          mob_spd_load_pac: "1. โหลดไฟล์ .pac",
          mob_spd_flash: "เริ่มแฟลช Unisoc / SPD",
// Advanced Firmware Flasher TH
        mobile_adv_flash_title: "ระบบแฟลชขั้นสูง (MTK & Qualcomm)",
        mobile_adv_flash_desc: "เลือกไฟล์ Scatter (.txt) หรือ RawProgram (.xml) เพื่อเตรียมแฟลชหลายพาร์ติชันอัตโนมัติ",
        mobile_browse_fw: "1. เลือกไฟล์เฟิร์มแวร์",
        mobile_browse_prog: "2. เลือกไฟล์ Programmer (QCOM)",
        mobile_browse_patch: "3. เลือกไฟล์ Patch (QCOM)",
        mobile_partitions_title: "รายการพาร์ติชันที่จะแฟลช:",
        mobile_select_all: "เลือกทั้งหมด",
        mobile_select_none: "ไม่เลือกเลย",
        mobile_flash_fw_now: "เริ่มแฟลชรายการที่เลือก",
        
        card_rm_title: "เรนมิเตอร์ สกิน (Rainmeter)",
        card_rm_desc: "จัดการสกินเรนมิเตอร์ และเลย์เอาต์บนหน้าจอ",
        btn_dl_rm: "ดาวน์โหลดโปรแกรม Rainmeter",
        btn_apply_rm_net: "ติดตั้งสกิน (เน็ตเวิร์ก/ระบบ)",
        btn_apply_rm_full: "คัดลอกตั้งค่าปัจจุบันไปใช้ (เต็มรูปแบบ)",
        card_wifi_title: "รหัสผ่านไวไฟ",
        card_wifi_desc: "ดูรหัสผ่าน WiFi ที่เคยเชื่อมต่อในเครื่อง",
        dropdown_scan: "กดสแกนเพื่อค้นหา...",
        btn_scan: "สแกน",
        btn_show: "ดูรหัส",
        card_usb_title: "แก้ไวรัสซ่อนไฟล์แฟลชไดรฟ์",
        card_usb_desc: "ยกเลิกซ่อนไฟล์และลบไวรัสโฟลเดอร์ Shortcut",
        btn_usb_fix: "กำจัดไวรัสทันที",
        root_title: '⚡ รูทมือถือ (One-Click ROOT)',
        root_subtitle: 'สแกนเครื่อง → ตรวจสอบรุ่นอัตโนมัติ → รูทด้วย Magisk ในคลิกเดียว',
        root_no_device: 'ยังไม่ได้เชื่อมต่ออุปกรณ์',
        root_scan_btn: 'สแกนอุปกรณ์',
        root_device_info: 'ข้อมูลอุปกรณ์',
        root_brand: 'ยี่ห้อ (Brand)',
        root_model: 'รุ่น (Model)',
        root_method: 'วิธีการรูท (Root Method)',
        root_device_details: '📋 รายละเอียดเครื่อง',
        root_det_model: 'รุ่น',
        root_det_android: 'แอนดรอยด์',
        root_det_serial: 'ซีเรียล',
        root_det_cpu: 'ซีพียู',
        root_det_bootloader: 'บูตโหลดเดอร์',
        root_det_root: 'สถานะรูท',
        root_start_btn: 'รูทเครื่องทันที (One-Click ROOT)',
        root_progress_title: '⚙️ สถานะการทำงาน',
        root_status_idle: 'รอคำสั่ง',
        root_waiting: 'รอคำสั่ง...',
        root_log_title: '📟 ประวัติการทำงาน (Root Log)',
        root_log_placeholder: '[ ประวัติการทำงานจะแสดงที่นี่... ]',
        nav_settings: 'ตั้งค่า',
        set_title: 'ตั้งค่าหน้าจอ',
        set_width: 'ความกว้าง (Width)',
        set_height: 'ความสูง (Height)',
        set_cancel: 'ยกเลิก',
        set_save: 'บันทึก',

        // Odin
        
        // ROM & Firmware Workstation
        nav_rom: "ดาวน์โหลดรอม (ROM)",
        header_rom_title: "ศูนย์ดาวน์โหลดรอมและเฟิร์มแวร์ครบวงจร",
        header_rom_desc: "ศูนย์ดาวน์โหลดรอมศูนย์ Android, Apple IPSW Direct CDN, ไฟล์ช่าง MTK/Qualcomm และระบบตรวจเช็คไฟล์ครบวงจร",
        rom_tab_android: "รอมศูนย์ Android",
        rom_tab_apple: "เฟิร์มแวร์ Apple IPSW (CDN แท้)",
        rom_tab_service: "ไฟล์ช่าง & ปลดล็อค (FRP / DA)",
        rom_tab_tools: "ตรวจสอบ Hash & เครื่องมือช่าง",
        rom_tab_downloader: "ตัวจัดการดาวน์โหลด",
        rom_android_picker: "เลือกรุ่นอุปกรณ์",
        rom_brand_label: "ยี่ห้อ (Brand):",
        rom_model_label: "รายการรุ่น (Models):",
        rom_save_dest: "โฟลเดอร์จัดเก็บไฟล์ดาวน์โหลด:",
        nav_odin: 'แฟลชรอม Samsung (Odin)',
        odin_title: 'โปรแกรมแฟลชรอม (Odin Flasher)',
        odin_subtitle: 'แฟลชไฟล์รอมศูนย์ Samsung (.tar / .md5) ในโหมด Download Mode',
        odin_options: 'ตัวเลือก (Options)',
        odin_log: 'ประวัติการทำงาน (Log)',
        odin_files: 'ไฟล์เฟิร์มแวร์ (Firmware Files)',
        nav_apple_flasher: 'แฟลชเครื่อง Apple iOS',
        apple_flasher_title: 'โปรแกรมแฟลชเครื่อง Apple iOS',
        apple_flasher_subtitle: 'ระบบรีสโตร์ แฟลชล้างเครื่องแก้ติดรหัส/ค้างโลโก้ และอัพเดท iOS แบบเก็บข้อมูลเดิม'
    }
};

let currentLang = 'en';

// Universal dialog result resolver (supports both string and { canceled, filePaths } forms)
function resolveDialogPath(res) {
    if (!res) return null;
    if (typeof res === 'string') return res;
    if (res.canceled) return null;
    if (Array.isArray(res.filePaths) && res.filePaths.length > 0) return res.filePaths[0];
    if (res.filePath) return res.filePath;
    return null;
}

function getBasename(filePath) {
    if (!filePath || typeof filePath !== 'string') return '';
    return filePath.replace(/\\/g, '/').split('/').filter(Boolean).pop() || filePath;
}

// Universal Magisk Boot Patching Runner
async function executeMagiskPatch(bootImgPath, statusElement, logCallback) {
    if (!bootImgPath) return;
    const log = (msg, col) => {
        if (typeof logCallback === 'function') logCallback(msg, col);
    };

    if (statusElement) {
        statusElement.innerHTML = `
            <div style="background: rgba(255,78,0,0.12); border: 1px solid rgba(255,78,0,0.3); border-radius: 8px; padding: 12px; color: #ff8a65;">
                <div style="display:flex; align-items:center; gap:8px; font-weight:600; font-size:12px;">
                    <i class="fas fa-spinner fa-spin"></i> กำลังส่งเครื่องมือและแพตช์ Magisk Root บนโทรศัพท์...
                </div>
                <div style="color: #cbd5e1; font-size: 11px; margin-top: 4px;">
                    ไฟล์ Boot: <b>${getBasename(bootImgPath)}</b> (กรุณารอสักครู่ ~5-10 วินาที)
                </div>
            </div>
        `;
        statusElement.style.display = 'block';
    }

    log('⚡ กำลังเริ่มแพตช์ไฟล์ Boot ด้วย Magisk Root...', '#ff8a65');
    log('> ตรวจสอบการเชื่อมต่อ ADB และรันสคริปต์ Magisk บนมือถือ...', '#aaa');

    try {
        const pRes = await window.api.patchBootWithMagisk({ bootPath: bootImgPath });
        if (pRes && pRes.success) {
            log(`🎉 แพตช์ Magisk Root สำเร็จเรียบร้อย! (ใช้เวลา ${pRes.elapsedSeconds}s)`, '#69f0ae');
            if (pRes.patchedTar) {
                log(`📁 ไฟล์แฟลชสำหรับ Samsung Odin: ${pRes.patchedTar}`, '#ffd740');
            }
            if (pRes.patchedImg) {
                log(`📁 ไฟล์แฟลช Boot ดิบ: ${pRes.patchedImg}`, '#ffd740');
            }

            if (statusElement) {
                statusElement.innerHTML = `
                    <div style="background: rgba(34,197,94,0.15); border: 1px solid rgba(34,197,94,0.35); border-radius: 8px; padding: 12px; color: #4ade80;">
                        <div style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:8px; margin-bottom:6px;">
                            <div style="font-weight:700; font-size: 12px; display:flex; align-items:center; gap:6px;">
                                <i class="fas fa-check-circle"></i> แพตช์ Magisk Root สำเร็จ! (${pRes.elapsedSeconds}s)
                            </div>
                            <div style="display:flex; gap:6px; flex-wrap: wrap;">
                                <button type="button" class="btn-open-patch-folder" style="background: rgba(34,197,94,0.25); border: 1px solid rgba(34,197,94,0.4); color: #fff; padding: 3px 9px; border-radius: 5px; font-size: 11px; cursor: pointer;">
                                    <i class="fas fa-folder-open"></i> เปิดโฟลเดอร์
                                </button>
                                <button type="button" class="btn-goto-odin" style="background: linear-gradient(135deg, #0284c7, #0369a1); border: none; color: #fff; padding: 3px 10px; border-radius: 5px; font-size: 11px; font-weight: 600; cursor: pointer;">
                                    <i class="fas fa-bolt"></i> แฟลชผ่าน Odin
                                </button>
                            </div>
                        </div>
                        <div style="color: #f1f5f9; font-size: 11px; margin-bottom: 2px;">
                            📦 สำหรับ Samsung Odin: <b>${getBasename(pRes.patchedTar || pRes.patchedImg)}</b>
                        </div>
                        <div style="color: #94a3b8; font-size: 10px; word-break: break-all;">
                            ${pRes.patchedTar || pRes.patchedImg}
                        </div>
                    </div>
                `;

                const openBtn = statusElement.querySelector('.btn-open-patch-folder');
                if (openBtn) {
                    openBtn.addEventListener('click', async () => {
                        if (window.api && window.api.openFileLocation) {
                            await window.api.openFileLocation(pRes.patchedTar || pRes.patchedImg);
                        }
                    });
                }
                const odinBtn = statusElement.querySelector('.btn-goto-odin');
                if (odinBtn) {
                    odinBtn.addEventListener('click', () => {
                        const odinNav = document.querySelector('[data-target="odin-section"]') || document.getElementById('nav-odin');
                        if (odinNav) odinNav.click();
                        const odinApInput = document.getElementById('odin-path-ap');
                        const odinApChk = document.getElementById('odin-chk-ap');
                        if (odinApInput && pRes.patchedTar) {
                            odinApInput.value = pRes.patchedTar;
                            if (odinApChk) odinApChk.checked = true;
                        }
                    });
                }
            }
            return pRes;
        } else {
            const errMsg = pRes ? pRes.error : 'Unknown error';
            log(`❌ การแพตช์ล้มเหลว: ${errMsg}`, '#ff5252');
            if (statusElement) {
                statusElement.innerHTML = `
                    <div style="background: rgba(239,68,68,0.12); border: 1px solid rgba(239,68,68,0.3); border-radius: 8px; padding: 12px; color: #f87171;">
                        <div style="font-weight:600;"><i class="fas fa-times-circle"></i> แพตช์ไม่สำเร็จ: ${errMsg}</div>
                        ${pRes && pRes.needDevice ? '<div style="color:#cbd5e1; font-size:11px; margin-top:6px;">💡 กรุณาเสียบสาย USB เปิดโหมดแก้จุดบกพร่อง (USB Debugging) บนโทรศัพท์</div>' : ''}
                        <div style="margin-top:8px;">
                            <button type="button" class="btn-retry-patch action-btn safe-btn" style="padding:4px 10px; font-size:11px;">
                                <i class="fas fa-rotate-right"></i> ลองแพตช์ใหม่อีกครั้ง
                            </button>
                        </div>
                    </div>
                `;
                const retryBtn = statusElement.querySelector('.btn-retry-patch');
                if (retryBtn) {
                    retryBtn.addEventListener('click', () => executeMagiskPatch(bootImgPath, statusElement, logCallback));
                }
            }
            return pRes;
        }
    } catch (err) {
        log(`❌ เกิดข้อผิดพลาด: ${err.message}`, '#ff5252');
        if (statusElement) {
            statusElement.innerHTML = `<div style="color: #f87171; padding: 10px;">❌ เกิดข้อผิดพลาด: ${err.message}</div>`;
        }
    }
}

function applyTranslations(lang) {
    currentLang = lang;
    try { localStorage.setItem('preferred_language', lang); } catch (e) {}
    const t = translations[lang];
    if (!t) return;
    
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (t[key]) {
            if (key === 'chk_win_title') {
                el.innerHTML = t[key] + ' <span class="badge warning">Admin</span>';
            } else {
                const icon = el.querySelector('i, svg');
                if (icon) {
                    const iconHtml = icon.outerHTML;
                    const span = el.querySelector('span[data-i18n]');
                    if (span) {
                        span.textContent = t[key];
                    } else {
                        el.innerHTML = iconHtml + ' ' + t[key];
                    }
                } else {
                    el.textContent = t[key];
                }
            }
        }
    });

    const btnEn = document.getElementById('btn-lang-en');
    const btnTh = document.getElementById('btn-lang-th');
    if (btnEn && btnTh) {
        if (lang === 'th') {
            btnTh.style.opacity = '1';
            btnTh.style.boxShadow = '0 0 10px rgba(255,152,0,0.5)';
            btnEn.style.opacity = '0.6';
            btnEn.style.boxShadow = 'none';
        } else {
            btnEn.style.opacity = '1';
            btnEn.style.boxShadow = '0 0 10px rgba(76,175,80,0.5)';
            btnTh.style.opacity = '0.6';
            btnTh.style.boxShadow = 'none';
        }
    }

    // Force re-render of test status
    if (window.api && window.api.getTestModeStatus) {
        window.api.getTestModeStatus();
    }
    if (typeof refreshCDriveSpace === 'function') {
        refreshCDriveSpace();
    }
}

document.addEventListener('DOMContentLoaded', () => {

    // --- RTC Tool Global Device Selection Logic ---
    const deviceDb = {
        xiaomi: [
            { name: "Redmi Note 9 (Merlin)", cpu: "MTK MT6769V", type: "mtk", auth: true },
            { name: "Redmi Note 10 (Sunny)", cpu: "QCOM Snapdragon 678", type: "qcom", firehose: "prog_firehose_sm6150.mbn" },
            { name: "Poco X3 Pro (Vayu)", cpu: "QCOM Snapdragon 860", type: "qcom", firehose: "prog_firehose_sm8150.mbn" }
        ],
        oppo: [
            { name: "Oppo A15 (CPH2185)", cpu: "MTK MT6765", type: "mtk", auth: false },
            { name: "Oppo A53 (CPH2127)", cpu: "QCOM Snapdragon 460", type: "qcom", firehose: "prog_firehose_sm4250.mbn" }
        ],
        vivo: [
            { name: "Vivo Y11 (1906)", cpu: "QCOM Snapdragon 439", type: "qcom", firehose: "prog_firehose_sdm439.mbn" },
            { name: "Vivo Y12 (1904)", cpu: "MTK MT6762", type: "mtk", auth: true }
        ],
        samsung: [
            { name: "Galaxy A03 Core", cpu: "SPD SC9863A", type: "spd" },
            { name: "Galaxy A12", cpu: "MTK MT6765", type: "mtk", auth: false },
            { name: "Galaxy A32 5G", cpu: "MTK MT6853", type: "mtk", auth: true }
        ]
    };

    let selectedDevice = null;
    const brandSelect = document.getElementById('global-brand-select');
    const modelSelect = document.getElementById('global-model-select');
    const cpuDisplay = document.getElementById('global-cpu-display');

    if (brandSelect && modelSelect) {
        brandSelect.addEventListener('change', (e) => {
            const brand = e.target.value;
            modelSelect.innerHTML = '<option value="" disabled selected>-- Choose Model --</option>';
            if (deviceDb[brand]) {
                deviceDb[brand].forEach((device, index) => {
                    modelSelect.innerHTML += `<option value="${index}">${device.name}</option>`;
                });
                modelSelect.disabled = false;
            } else {
                modelSelect.disabled = true;
            }
            cpuDisplay.textContent = "NONE";
            cpuDisplay.style.color = "#4ade80";
            selectedDevice = null;
        });

        modelSelect.addEventListener('change', (e) => {
            const brand = brandSelect.value;
            const idx = e.target.value;
            if (brand && deviceDb[brand] && deviceDb[brand][idx]) {
                selectedDevice = deviceDb[brand][idx];
                cpuDisplay.textContent = selectedDevice.cpu;
                
                // Switch tab automatically based on CPU type
                const tabId = `tab-${selectedDevice.type}`;
                const tabBtn = document.querySelector(`.tab-btn[data-target="${tabId}"]`);
                if (tabBtn) tabBtn.click();
            }
        });
    }

    // --- Specialized One-Click Operations ---
    function doOneClick(id, handler) {
        const btn = document.getElementById(id);
        if (btn) {
            btn.addEventListener('click', () => {
                handler();
            });
        }
    }

    doOneClick('btn-sp-mi-account', () => {
        openModal('Bypass Mi Account (Xiaomi / Redmi / POCO)');
        logToModal('> Starting Bypass Mi Account...\n');
        logToModal('> 🔌 กรุณาปิดเครื่องให้ดับสนิท -> กดปุ่ม Vol Up (+) และ Vol Down (-) ค้างไว้ -> เสียบสาย USB\n');
        if (selectedDevice && selectedDevice.type === 'qcom') {
            const loaderArg = selectedDevice.firehose ? [`--loader=${selectedDevice.firehose}`] : [];
            window.api.runFlasherTool({ tool: 'edl', args: ['e', 'persist'].concat(loaderArg) });
        } else {
            window.api.runFlasherTool({ tool: 'mtk', args: ['e', 'persist'] });
        }
    });

    doOneClick('btn-sp-oppo-demo', () => {
        openModal('Remove Demo Mode (Oppo / Vivo / Realme)');
        logToModal('> Starting Remove Demo Mode...\n');
        logToModal('> 🔌 กรุณาปิดเครื่องให้ดับสนิท -> กดปุ่ม Vol Up (+) และ Vol Down (-) ค้างไว้ -> เสียบสาย USB\n');
        window.api.runFlasherTool({ tool: 'mtk', args: ['e', 'userdata,metadata,reserve2'] });
    });

    doOneClick('btn-sp-sam-frp', async () => {
        openModal('Samsung MTP FRP (*#0*# Mode)');
        logToModal('> Starting Samsung MTP FRP (*#0*# Mode)...\n');
        logToModal('> 💡 ในโทรศัพท์: เข้าหน้าโทรออก/โทรฉุกเฉิน -> กดรหัส *#0*# (หรือ *#0808# เลือก DM+MODEM+ADB)\n');
        logToModal('> เสียบสาย USB เข้าคอมรอไว้...\n');
        try {
            const res = await window.api.samsungMtpFrp();
            if (res && res.success) {
                logToModal('\n[SUCCESS] Samsung MTP FRP command sequence sent successfully!\n', 'success');
                finishModal(true);
            } else {
                logToModal(`\n[FAILED] ${res ? res.error : 'Failed'}\n`, 'error');
                finishModal(false);
            }
        } catch (e) {
            logToModal(`\n[ERROR] ${e.message}\n`, 'error');
            finishModal(false);
        }
    });

    doOneClick('btn-sp-sam-download', async () => {
        openModal('Samsung 350K: Enter Download Mode');
        logToModal('> Sending AT Download Mode trigger to Samsung phone...\n');
        try {
            const res = await window.api.samsung350kAction({ action: 'download' });
            if (res && res.success) {
                logToModal('\n[SUCCESS] Phone is entering Download Mode!\n', 'success');
                finishModal(true);
            } else {
                logToModal(`\n[NOTICE] ${res ? res.error : 'Not detected'}\n`, 'warning');
                logToModal('💡 หากเครื่องไม่เข้าโหมด: ปิดเครื่อง -> กด Vol Up (+) และ Vol Down (-) ค้างไว้ -> เสียบสาย USB\n');
                finishModal(false);
            }
        } catch (e) {
            logToModal(`\n[ERROR] ${e.message}\n`, 'error');
            finishModal(false);
        }
    });

    doOneClick('btn-sp-sam-reboot', async () => {
        openModal('Samsung 350K: Reboot Phone');
        logToModal('> Sending reboot trigger to Samsung phone...\n');
        try {
            const res = await window.api.samsung350kAction({ action: 'reboot' });
            if (res && res.success) {
                logToModal('\n[SUCCESS] Phone reboot command sent successfully!\n', 'success');
                finishModal(true);
            } else {
                logToModal(`\n[NOTICE] ${res ? res.error : 'Not detected'}\n`, 'warning');
                finishModal(false);
            }
        } catch (e) {
            logToModal(`\n[ERROR] ${e.message}\n`, 'error');
            finishModal(false);
        }
    });

    doOneClick('btn-sp-auth-bypass', () => {
        openModal('MTK SLA/DA Auth Bypass');
        logToModal('> Starting MTK SLA/DA Auth Bypass (BROM Exploit)...\n');
        logToModal('> 🔌 กรุณาปิดเครื่องให้ดับสนิท -> กดปุ่ม Vol Up (+) และ Vol Down (-) ค้างไว้ -> เสียบสาย USB\n');
        window.api.runFlasherTool({ tool: 'mtk', args: ['payload'] });
    });

    doOneClick('btn-sp-unlock-bl', () => {
        openModal('Unlock Bootloader');
        logToModal('> Starting Bootloader Unlock Sequence...\n');
        logToModal('> 🔌 เสียบสาย USB ในโหมด BROM / Fastboot / EDL...\n');
        if (selectedDevice && selectedDevice.type === 'qcom') {
            window.api.runFlasherTool({ tool: 'edl', args: ['modules', 'oemunlock', 'enable'] });
        } else {
            window.api.runFlasherTool({ tool: 'mtk', args: ['da', 'seccfg', 'unlock'] });
        }
    });


// --- Live Device Hardware Monitor ---
async function refreshLiveMonitor() {
    const adbBadge = document.getElementById('mon-adb-status');
    const edlBadge = document.getElementById('mon-edl-status');
    const mtkBadge = document.getElementById('mon-mtk-status');
    const samBadge = document.getElementById('mon-sam-status');
    const scanBtn = document.getElementById('btn-mon-scan-all');

    if (scanBtn) {
        scanBtn.disabled = true;
        scanBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Scanning...';
    }

    // 1. Check ADB
    try {
        if (window.api && window.api.runAdbCommand) {
            const adbOut = await window.api.runAdbCommand('devices');
            const lines = (adbOut || '').split(/\r?\n/).filter(l => l.trim() && !l.includes('List of devices attached'));
            const devLine = lines.find(l => l.includes('\tdevice'));
            if (devLine && adbBadge) {
                const devId = devLine.split('\t')[0].trim();
                adbBadge.textContent = `🟢 ${devId}`;
                adbBadge.style.background = 'rgba(34, 197, 94, 0.2)';
                adbBadge.style.color = '#4ade80';
                adbBadge.style.border = '1px solid rgba(34, 197, 94, 0.4)';
            } else if (adbBadge) {
                const unauth = lines.find(l => l.includes('\tunauthorized'));
                if (unauth) {
                    adbBadge.textContent = '🟡 Unauthorized';
                    adbBadge.style.background = 'rgba(234, 179, 8, 0.2)';
                    adbBadge.style.color = '#facc15';
                    adbBadge.style.border = '1px solid rgba(234, 179, 8, 0.4)';
                } else {
                    adbBadge.textContent = '⚪ No device';
                    adbBadge.style.background = 'rgba(255,255,255,0.06)';
                    adbBadge.style.color = '#94a3b8';
                    adbBadge.style.border = 'none';
                }
            }
        }
    } catch (e) {
        if (adbBadge) {
            adbBadge.textContent = '⚪ No device';
            adbBadge.style.background = 'rgba(255,255,255,0.06)';
            adbBadge.style.color = '#94a3b8';
            adbBadge.style.border = 'none';
        }
    }

    // 2. Check COM Ports for EDL, MTK, Samsung
    try {
        if (window.api && window.api.scanComPorts) {
            const ports = await window.api.scanComPorts();
            let foundEdl = null;
            let foundMtk = null;
            let foundSam = null;

            if (Array.isArray(ports)) {
                for (const p of ports) {
                    const portName = typeof p === 'object' ? p.port : p;
                    const desc = typeof p === 'object' ? (p.description || '') : '';
                    const isEdl = typeof p === 'object' ? (p.isEdl || /9008|QDLOADER|QUALCOMM/i.test(desc)) : /9008/i.test(p);
                    const isMtk = typeof p === 'object' ? (p.isMtk || /VCOM|MTK|MEDIATEK/i.test(desc)) : /MTK|VCOM/i.test(p);
                    const isSam = typeof p === 'object' ? (p.isSamsung || /SAMSUNG|SSUDMDM/i.test(desc)) : /SAMSUNG/i.test(p);

                    if (isEdl && !foundEdl) foundEdl = portName;
                    if (isMtk && !foundMtk) foundMtk = portName;
                    if (isSam && !foundSam) foundSam = portName;
                }
            }

            if (edlBadge) {
                if (foundEdl) {
                    edlBadge.textContent = `🟢 ${foundEdl} (EDL 9008)`;
                    edlBadge.style.background = 'rgba(34, 197, 94, 0.2)';
                    edlBadge.style.color = '#4ade80';
                    edlBadge.style.border = '1px solid rgba(34, 197, 94, 0.4)';
                } else {
                    edlBadge.textContent = '⚪ No port';
                    edlBadge.style.background = 'rgba(255,255,255,0.06)';
                    edlBadge.style.color = '#94a3b8';
                    edlBadge.style.border = 'none';
                }
            }

            if (mtkBadge) {
                if (foundMtk) {
                    mtkBadge.textContent = `🟢 ${foundMtk} (MTK VCOM)`;
                    mtkBadge.style.background = 'rgba(34, 197, 94, 0.2)';
                    mtkBadge.style.color = '#4ade80';
                    mtkBadge.style.border = '1px solid rgba(34, 197, 94, 0.4)';
                } else {
                    mtkBadge.textContent = '⚪ No port';
                    mtkBadge.style.background = 'rgba(255,255,255,0.06)';
                    mtkBadge.style.color = '#94a3b8';
                    mtkBadge.style.border = 'none';
                }
            }

            if (samBadge) {
                if (foundSam) {
                    samBadge.textContent = `🟢 ${foundSam} (Modem)`;
                    samBadge.style.background = 'rgba(34, 197, 94, 0.2)';
                    samBadge.style.color = '#4ade80';
                    samBadge.style.border = '1px solid rgba(34, 197, 94, 0.4)';
                } else {
                    samBadge.textContent = '⚪ No modem';
                    samBadge.style.background = 'rgba(255,255,255,0.06)';
                    samBadge.style.color = '#94a3b8';
                    samBadge.style.border = 'none';
                }
            }
        }
    } catch (e) {
        console.error('Error scanning COM ports for monitor:', e);
    }

    if (scanBtn) {
        scanBtn.disabled = false;
        scanBtn.innerHTML = '<i class="fas fa-sync-alt"></i> Scan Devices';
    }
}

const btnMonScanAll = document.getElementById('btn-mon-scan-all');
if (btnMonScanAll) {
    btnMonScanAll.addEventListener('click', () => refreshLiveMonitor());
}

// --- Console & Modal Panel Logic ---
const consoleTerminal = document.getElementById('console-terminal');
const consoleActionText = document.getElementById('console-action-text');
const consoleProgress1 = document.getElementById('console-progress-1');
const consoleProgressText1 = document.getElementById('console-progress-text-1');
const consoleProgress2 = document.getElementById('console-progress-2');
const consoleProgressText2 = document.getElementById('console-progress-text-2');

let activeProgressTimer1 = null;

function logToConsole(text, type = 'info') {
    logToModal(text, type);
}

function showRightPanelTab(tab) {
    const logTab = document.getElementById('btn-panel-tab-log');
    const screenTab = document.getElementById('btn-panel-tab-screen');
    const logView = document.getElementById('mobile-panel-log-view');
    const screenView = document.getElementById('mobile-panel-screen-view');
    if (!logView) return;

    if (tab === 'log') {
        logTab.classList.add('active');
        logTab.style.background = 'var(--accent-color)';
        logTab.style.color = '#fff';
        screenTab.classList.remove('active');
        screenTab.style.background = 'transparent';
        screenTab.style.color = '#94a3b8';
        logView.style.display = 'flex';
        screenView.style.display = 'none';
    } else {
        screenTab.classList.add('active');
        screenTab.style.background = 'var(--accent-color)';
        screenTab.style.color = '#fff';
        logTab.classList.remove('active');
        logTab.style.background = 'transparent';
        logTab.style.color = '#94a3b8';
        screenView.style.display = 'flex';
        logView.style.display = 'none';
    }
}

function openModal(titleText) {
    const mobileSec = document.getElementById('mobile-section');
    const isMobileActive = mobileSec && mobileSec.classList.contains('active');

    // 1. Update Mobile Right Panel Header & Progress
    const panelTitle = document.getElementById('mobile-panel-action-title');
    const panelBadge = document.getElementById('mobile-panel-badge');
    const panelProgress = document.getElementById('mobile-panel-progress-bar');
    const panelProgressTxt = document.getElementById('mobile-panel-progress-text');
    const panelTerminal = document.getElementById('mobile-panel-terminal');

    if (panelTitle) panelTitle.textContent = titleText;
    if (panelBadge) {
        panelBadge.textContent = 'RUNNING';
        panelBadge.style.background = 'rgba(56, 189, 248, 0.2)';
        panelBadge.style.color = '#38bdf8';
        panelBadge.style.borderColor = 'rgba(56, 189, 248, 0.4)';
    }
    if (panelProgress) {
        panelProgress.style.width = '35%';
        panelProgress.style.background = 'linear-gradient(90deg, #38bdf8, #818cf8)';
    }
    if (panelProgressTxt) panelProgressTxt.textContent = 'Running...';
    
    // Auto-switch right panel to Log tab so user sees operation logs live!
    showRightPanelTab('log');

    // เคลียร์ Log ของคำสั่งเก่าออกทันทีเมื่อกดคำสั่งใหม่ ตามคำขอของผู้ใช้!
    if (panelTerminal) {
        panelTerminal.innerHTML = '';
        const headerSpan = document.createElement('span');
        headerSpan.style.color = '#38bdf8';
        headerSpan.style.fontWeight = 'bold';
        headerSpan.textContent = `================================================\n [ACTION] ${titleText}\n Started at: ${new Date().toLocaleTimeString()}\n================================================\n`;
        panelTerminal.appendChild(headerSpan);
        panelTerminal.scrollTop = 0;
    }
    const panelLines = document.getElementById('mobile-panel-terminal-lines');
    if (panelLines) {
        panelLines.textContent = '4 lines';
    }

    // 2. Standard modal update for non-mobile tools or background tracking
    const modal = document.getElementById('status-modal');
    const modalTitle = document.getElementById('modal-title');
    const modalLoader = document.getElementById('modal-loader');
    const btnModalClose = document.getElementById('btn-modal-close');
    const statusBadge = document.getElementById('modal-status-badge');
    
    if (modalTitle) modalTitle.textContent = titleText;
    if (statusBadge) {
        statusBadge.textContent = 'RUNNING';
        statusBadge.style.background = '#0284c7';
    }
    const out = document.getElementById('modal-output');
    if (out) out.innerHTML = '';
    if (modalLoader) modalLoader.classList.remove('hidden');
    if (btnModalClose) btnModalClose.classList.add('hidden');

    // ONLY show blocking popup modal if user is NOT on Mobile Tools!
    if (!isMobileActive && modal) {
        modal.classList.remove('hidden');
    }
}

function finishModal(success = true) {
    const modalLoader = document.getElementById('modal-loader');
    const btnModalClose = document.getElementById('btn-modal-close');
    const statusBadge = document.getElementById('modal-status-badge');
    if (modalLoader) modalLoader.classList.add('hidden');
    if (btnModalClose) btnModalClose.classList.remove('hidden');
    if (statusBadge) {
        statusBadge.textContent = success ? 'COMPLETED' : 'FAILED';
        statusBadge.style.background = success ? '#16a34a' : '#dc2626';
    }

    // Update Mobile Right Panel
    const panelBadge = document.getElementById('mobile-panel-badge');
    const panelProgress = document.getElementById('mobile-panel-progress-bar');
    const panelProgressTxt = document.getElementById('mobile-panel-progress-text');
    const panelTerminal = document.getElementById('mobile-panel-terminal');

    if (panelBadge) {
        panelBadge.textContent = success ? 'COMPLETED' : 'FAILED';
        panelBadge.style.background = success ? 'rgba(34, 197, 94, 0.2)' : 'rgba(239, 68, 68, 0.2)';
        panelBadge.style.color = success ? '#4ade80' : '#f87171';
        panelBadge.style.borderColor = success ? 'rgba(34, 197, 94, 0.4)' : 'rgba(239, 68, 68, 0.4)';
    }
    if (panelProgress) {
        panelProgress.style.width = '100%';
        panelProgress.style.background = success ? 'linear-gradient(90deg, #38bdf8, #22c55e)' : '#ef4444';
    }
    if (panelProgressTxt) {
        panelProgressTxt.textContent = success ? '100% (Done)' : 'Failed';
    }
    if (panelTerminal) {
        const finishSpan = document.createElement('span');
        finishSpan.style.color = success ? '#4ade80' : '#f87171';
        finishSpan.style.fontWeight = 'bold';
        finishSpan.textContent = `\n[RESULT] ${success ? '✅ Operation completed successfully!' : '❌ Operation failed or stopped.'}\n`;
        panelTerminal.appendChild(finishSpan);
        panelTerminal.scrollTop = panelTerminal.scrollHeight;
    }
}

function closeModal() {
    const modal = document.getElementById('status-modal');
    if (modal) modal.classList.add('hidden');
}

function logToModal(text, type = 'info') {
    function formatSpan(spanEl, txt, t) {
        if (t === 'error' || txt.includes('[ERROR]') || txt.includes('failed') || txt.includes('FAIL') || txt.includes('[FAILED]')) {
            spanEl.style.color = '#ff5252';
        } else if (t === 'success' || txt.includes('Completed!') || txt.includes('OK') || txt.includes('✅') || txt.includes('[SUCCESS]')) {
            spanEl.style.color = '#69f0ae';
        } else if (t === 'warning' || txt.includes('⚠️') || txt.includes('Warning') || txt.includes('💡') || txt.includes('[NOTICE]')) {
            spanEl.style.color = '#ffd740';
        } else if (txt.startsWith('>') || txt.startsWith('📱') || txt.startsWith('🔋') || txt.startsWith('⚡')) {
            spanEl.style.color = '#38bdf8';
        } else {
            spanEl.style.color = '#cbd5e1';
        }
        spanEl.textContent = txt;
    }

    // 1. Output to standard modal output
    const modalOutput = document.getElementById('modal-output');
    if (modalOutput) {
        const span = document.createElement('span');
        formatSpan(span, text, type);
        modalOutput.appendChild(span);
        modalOutput.scrollTop = modalOutput.scrollHeight;
    }

    // 2. Output directly to Mobile Right Panel Terminal!
    const panelTerminal = document.getElementById('mobile-panel-terminal');
    if (panelTerminal) {
        const span = document.createElement('span');
        formatSpan(span, text, type);
        panelTerminal.appendChild(span);
        
        const autoScroll = document.getElementById('chk-panel-autoscroll');
        if (!autoScroll || autoScroll.checked) {
            panelTerminal.scrollTop = panelTerminal.scrollHeight;
        }
        
        const linesEl = document.getElementById('mobile-panel-terminal-lines');
        if (linesEl) {
            const lineCount = panelTerminal.innerText.split('\n').length;
            linesEl.textContent = `${lineCount} lines`;
        }
    }
}
function clearConsole() {
    openModal('Running Task...');
}

function setConsoleStatus(actionName) {
    if (consoleActionText) consoleActionText.textContent = actionName;
}

// Hook up live terminal listeners
if (window.api && window.api.onTerminalOutput) {
    window.api.onTerminalOutput((data) => {
        logToModal(data);
    });
}

if (window.api && window.api.onOperationComplete) {
    window.api.onOperationComplete((res) => {
        finishModal(res.success);
    });
}

const btnModalKill = document.getElementById('btn-modal-kill');
if (btnModalKill) {
    btnModalKill.addEventListener('click', () => {
        if (window.api && window.api.killFlasherTool) window.api.killFlasherTool();
        logToModal('\n[STOPPED] Command cancelled by user.\n', 'error');
        finishModal(false);
    });
}

const btnModalCopy = document.getElementById('btn-modal-copy');
if (btnModalCopy) {
    btnModalCopy.addEventListener('click', () => {
        const modalOutput = document.getElementById('modal-output');
        if (modalOutput) {
            navigator.clipboard.writeText(modalOutput.innerText).then(() => {
                const originalHtml = btnModalCopy.innerHTML;
                btnModalCopy.innerHTML = '<i class="fas fa-check"></i> คัดลอกแล้ว! (Copied)';
                btnModalCopy.style.color = '#69f0ae';
                setTimeout(() => {
                    btnModalCopy.innerHTML = originalHtml;
                    btnModalCopy.style.color = '#ccc';
                }, 2000);
            }).catch(err => {
                console.error('Failed to copy: ', err);
            });
        }
    });
}

const btnModalX = document.getElementById('btn-modal-x');
if (btnModalX) btnModalX.addEventListener('click', closeModal);

const btnModalClose = document.getElementById('btn-modal-close');
if (btnModalClose) btnModalClose.addEventListener('click', closeModal);

function simulateProgress(durationMs = 5000) {
    if(!consoleProgress1) return;
    consoleProgress1.style.width = '0%';
    if(consoleProgress2) consoleProgress2.style.width = '0%';
    consoleProgress1.style.transition = 'none';
    if(consoleProgress2) consoleProgress2.style.transition = 'none';
    
    void consoleProgress1.offsetWidth; // Reflow
    
    consoleProgress1.style.transition = `width ${durationMs}ms ease-out`;
    if(consoleProgress2) consoleProgress2.style.transition = `width ${durationMs * 1.5}ms ease-out`;
    consoleProgress1.style.width = '95%';
    if(consoleProgress2) consoleProgress2.style.width = '80%';
    
    let curProgress = 0;
    clearInterval(activeProgressTimer1);
    activeProgressTimer1 = setInterval(() => {
        if(curProgress < 95) {
            curProgress += 1;
            consoleProgressText1.textContent = `${curProgress}%`;
            consoleProgressText2.textContent = `${Math.floor(curProgress * 0.84)}%`;
        }
    }, durationMs / 95);
}

function finishProgress() {
    if(!consoleProgress1) return;
    clearInterval(activeProgressTimer1);
    consoleProgress1.style.transition = 'width 0.2s linear';
    if(consoleProgress2) consoleProgress2.style.transition = 'width 0.2s linear';
    consoleProgress1.style.width = '100%';
    if(consoleProgress2) consoleProgress2.style.width = '100%';
    consoleProgressText1.textContent = '100%';
    if(consoleProgressText2) consoleProgressText2.textContent = '100%';
    setConsoleStatus('Operation Completed!');
    
    const modalLoader = document.getElementById('modal-loader');
    const btnModalClose = document.getElementById('btn-modal-close');
    if (modalLoader) modalLoader.classList.add('hidden'); // Stop loader
    if (btnModalClose) btnModalClose.classList.remove('hidden'); // Show close button
}

function stopProgress() {
    if(!consoleProgress1) return;
    clearInterval(activeProgressTimer1);
    setConsoleStatus('Operation stopped by user!');
    consoleProgress1.style.transition = 'none';
    if(consoleProgress2) consoleProgress2.style.transition = 'none';
}

    
if(document.getElementById('btn-console-stop')) {
        document.getElementById('btn-console-stop').addEventListener('click', () => {
            logToConsole('\n[USER] Stop command issued.\n', 'error');
            stopProgress();
            if (window.api && window.api.send) {
                window.api.send('kill-flasher-tool');
            }
        });
    }
    // Language Toggle
    const savedLang = (() => {
        try { return localStorage.getItem('preferred_language') || 'en'; } catch(e) { return 'en'; }
    })();
    applyTranslations(savedLang);

    document.getElementById('btn-lang-en').addEventListener('click', () => {
        applyTranslations('en');
    });
    document.getElementById('btn-lang-th').addEventListener('click', () => {
        applyTranslations('th');
    });

    // --- Fullscreen Toggle (F11) Logic ---
    const btnFullscreen = document.getElementById('btn-fullscreen');
    const iconFullscreen = document.getElementById('icon-fullscreen');
    const txtFullscreen = document.getElementById('txt-fullscreen');

    function updateFullscreenUI(isFull) {
        if (!btnFullscreen) return;
        if (isFull) {
            if (iconFullscreen) iconFullscreen.className = 'fas fa-compress';
            if (txtFullscreen) txtFullscreen.textContent = currentLang === 'th' ? 'ย่อหน้าจอ (F11 / Esc)' : 'Exit Fullscreen (F11 / Esc)';
            btnFullscreen.style.background = 'rgba(234, 179, 8, 0.15)';
            btnFullscreen.style.borderColor = 'rgba(234, 179, 8, 0.4)';
            btnFullscreen.style.color = '#facc15';
            btnFullscreen.title = currentLang === 'th' ? 'กดย่อหน้าต่างกลับสู่ขนาดปกติ (F11 / Esc)' : 'Restore window (F11 / Esc)';
        } else {
            if (iconFullscreen) iconFullscreen.className = 'fas fa-expand';
            if (txtFullscreen) txtFullscreen.textContent = currentLang === 'th' ? 'ขยายเต็มจอ (F11)' : 'Fullscreen (F11)';
            btnFullscreen.style.background = 'rgba(56, 189, 248, 0.1)';
            btnFullscreen.style.borderColor = 'rgba(56, 189, 248, 0.25)';
            btnFullscreen.style.color = '#38bdf8';
            btnFullscreen.title = currentLang === 'th' ? 'สลับโหมดขยายเต็มจอ (F11)' : 'Toggle Fullscreen mode (F11)';
        }
    }

    if (btnFullscreen && window.api && window.api.toggleFullScreen) {
        btnFullscreen.addEventListener('click', async () => {
            const isFull = await window.api.toggleFullScreen();
            updateFullscreenUI(isFull);
        });

        if (window.api.onFullScreenChange) {
            window.api.onFullScreenChange((isFull) => {
                updateFullscreenUI(isFull);
            });
        }

        if (window.api.isFullScreen) {
            window.api.isFullScreen().then(isFull => updateFullscreenUI(isFull)).catch(() => {});
        }
    }

    // Navigation
    const navBtns = document.querySelectorAll('.nav-btn');
    const sections = document.querySelectorAll('.content-section');

    navBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            navBtns.forEach(b => b.classList.remove('active'));
            sections.forEach(s => s.classList.remove('active'));
            
            btn.classList.add('active');
            document.getElementById(btn.dataset.target).classList.add('active');

            // Show Console Panel only on Mobile Tools
            const cp = document.getElementById('console-panel');
            if (cp) {
                cp.style.display = btn.dataset.target === 'mobile-section' ? 'flex' : 'none';
            }

            if (btn.dataset.target === 'mobile-section') {
                refreshLiveMonitor();
            }
            if (btn.dataset.target === 'tools-section') {
                if (typeof updateDefenderBadge === 'function') updateDefenderBadge();
                if (typeof updateWin11MenuBadge === 'function') updateWin11MenuBadge();
            }
            if (btn.dataset.target === 'cleanup-section') {
                if (typeof refreshCDriveSpace === 'function') refreshCDriveSpace();
            }
        });
    });

    // Hide console panel on initial load (System Tools is default)
    const cpInit = document.getElementById('console-panel');
    if (cpInit) cpInit.style.display = 'none';
    setTimeout(() => {
        if (typeof updateDefenderBadge === 'function') updateDefenderBadge();
        if (typeof updateWin11MenuBadge === 'function') updateWin11MenuBadge();
        if (typeof refreshCDriveSpace === 'function') refreshCDriveSpace();
    }, 1000);


    // Custom Confirm Dialog
    function showCustomConfirm(message) {
        return new Promise((resolve) => {
            const confirmModal = document.getElementById('confirm-modal');
            const confirmMessage = document.getElementById('confirm-message');
            const btnOk = document.getElementById('btn-confirm-ok');
            const btnCancel = document.getElementById('btn-confirm-cancel');
            
            confirmMessage.textContent = message;
            confirmModal.classList.remove('hidden');
            
            const cleanup = () => {
                btnOk.removeEventListener('click', onOk);
                btnCancel.removeEventListener('click', onCancel);
                confirmModal.classList.add('hidden');
            };
            
            const onOk = () => { cleanup(); resolve(true); };
            const onCancel = () => { cleanup(); resolve(false); };
            
            btnOk.addEventListener('click', onOk);
            btnCancel.addEventListener('click', onCancel);
        });
    }
    window.showCustomConfirm = showCustomConfirm;

    // IPC Listeners
    window.api.onCommandOutput((output) => {
        if (isCleaning) {
            const text = document.getElementById('cleanup-progress-text');
            // Show only the last line of output if it's a path
            const lines = output.trim().split('\n');
            const lastLine = lines[lines.length - 1];
            if (lastLine && lastLine.length > 5) {
                // Keep it short
                let shortPath = lastLine;
                if (shortPath.length > 50) shortPath = "..." + shortPath.substring(shortPath.length - 47);
                text.textContent = 'กำลังลบ: ' + shortPath;
            }
        } else {
            const modal = document.getElementById('status-modal');
            if (modal && !modal.classList.contains('hidden')) {
                logToModal(output);
            } else {
                logToConsole(output);
            }
        }
    });

    window.api.onCommandDone((success) => {
        finishProgress();
        
        // Handle PC Cleanup completion
        if (isCleaning) {
            clearInterval(cleanupInterval);
            const bar = document.getElementById('cleanup-progress-bar');
            const pct = document.getElementById('cleanup-progress-percent');
            const text = document.getElementById('cleanup-progress-text');
            
            bar.style.width = '100%';
            pct.textContent = '100%';
            text.textContent = 'เสร็จสมบูรณ์! (Cleanup Complete!)';
            text.style.color = '#00e676';
            
            setTimeout(() => {
                isCleaning = false;
                const runBtn = document.getElementById('btn-run-cleanup');
                if (runBtn) runBtn.disabled = false;
                const smartBtn = document.getElementById('btn-smart-clean');
                if (smartBtn) smartBtn.disabled = false;
                
                document.getElementById('cleanup-progress-container').classList.add('hidden');
                text.style.color = 'var(--text-light)';

                const alertEl = document.getElementById('cleanup-summary-alert');
                if (alertEl) alertEl.classList.remove('hidden');

                if (typeof refreshCDriveSpace === 'function') {
                    refreshCDriveSpace();
                }
            }, 2000);
        }
        
        // Refresh test mode status if we were toggling it
        window.api.getTestModeStatus();
    });

    // System Tools
    document.getElementById('btn-devmgmt').addEventListener('click', () => {
        window.api.runCmd('devmgmt', false);
    });
    document.getElementById('btn-regedit').addEventListener('click', () => {
        window.api.runCmd('regedit', false);
    });
    
    
    // ---- PROGRESS MODAL SYSTEM ----
    const progressModal = document.getElementById('tool-progress-modal');
    const progressTitle = document.getElementById('tool-progress-title');
    const progressSubtitle = document.getElementById('tool-progress-subtitle');
    const progressBar = document.getElementById('tool-progress-bar');
    const progressStatus = document.getElementById('tool-progress-status');
    const progressPct = document.getElementById('tool-progress-pct');
    const progressLog = document.getElementById('tool-progress-log');
    const progressClose = document.getElementById('tool-progress-close');
    // Add close button event listener
    if (progressClose) {
        progressClose.addEventListener('click', () => {
            if (progressModal) progressModal.style.display = 'none';
        });
    }

    const progressIcon = document.getElementById('tool-progress-icon');
    
    let progressInterval = null;
    
    function showProgressModal(title, subtitle, icon = '⚙️') {
        if (!progressModal) return;
        progressTitle.textContent = title;
        progressSubtitle.textContent = subtitle;
        progressIcon.textContent = icon;
        progressBar.style.width = '0%';
        progressBar.style.background = 'var(--primary)';
        progressPct.textContent = '0%';
        progressStatus.textContent = 'เริ่มต้น...';
        progressLog.textContent = '';
        progressClose.disabled = true;
        progressModal.style.display = 'flex';
        
        // Simulate progress animation
        let pct = 0;
        clearInterval(progressInterval);
        progressInterval = setInterval(() => {
            pct += Math.random() * 8;
            if (pct > 90) pct = 90; // Hold at 90% until done
            progressBar.style.width = pct + '%';
            progressPct.textContent = Math.floor(pct) + '%';
        }, 400);
    }
    
    function finishProgressModal(success, msg) {
        clearInterval(progressInterval);
        progressBar.style.width = '100%';
        progressPct.textContent = '100%';
        if (success) {
            progressBar.style.background = '#10b981';
            progressStatus.textContent = '✅ เสร็จสมบูรณ์!';
            progressIcon.textContent = '✅';
        } else {
            progressBar.style.background = '#ef4444';
            progressStatus.textContent = '❌ เกิดข้อผิดพลาด';
            progressIcon.textContent = '❌';
        }
        if (msg) progressLog.textContent += msg;
        progressClose.disabled = false;
    }
    
    // Listen for command output to update log
    if (window.api && window.api.onCommandOutput) {
        window.api.onCommandOutput((output) => {
            if (progressModal && progressModal.style.display === 'flex') {
                progressLog.textContent += output + '\n';
                progressLog.scrollTop = progressLog.scrollHeight;
            }
        });
        window.api.onCommandDone((success) => {
            if (progressModal && progressModal.style.display === 'flex') {
                finishProgressModal(success, success ? '' : '\n❌ คำสั่งล้มเหลว');
            }
        });
    }

    // ---- NETWORK TOOLS ----
    function showNetOutput(msg) {
        // legacy - now using modal
    }
    const btnNetReset = document.getElementById('btn-net-reset');
    if (btnNetReset) btnNetReset.addEventListener('click', () => {
        if (confirm('รีเซ็ตเน็ตเวิร์คทั้งหมด? (ต้องการสิทธิ์ Admin)')) {
            showProgressModal('กำลังรีเซ็ตเน็ตเวิร์ค', 'รีเซ็ต TCP/IP, Winsock, DNS Cache...', '🔄');
            window.api.runCmd('net-reset', true);
        }
    });
    const btnFlushDns = document.getElementById('btn-flush-dns');
    if (btnFlushDns) btnFlushDns.addEventListener('click', () => {
        showProgressModal('กำลังล้าง DNS Cache', 'ipconfig /flushdns...', '🧹');
        window.api.runCmd('flush-dns', false);
    });
    const btnShowIp = document.getElementById('btn-show-ip');
    if (btnShowIp) btnShowIp.addEventListener('click', () => {
        showProgressModal('ข้อมูล IP Address', 'กำลังดึงข้อมูลเครือข่าย...', '🖥️');
        window.api.runCmd('show-ip', false);
    });
    const btnPingTest = document.getElementById('btn-ping-test');
    if (btnPingTest) btnPingTest.addEventListener('click', () => {
        showProgressModal('ทดสอบการเชื่อมต่ออินเตอร์เน็ต', 'กำลัง Ping 8.8.8.8 (4 ครั้ง)...', '📡');
        window.api.runCmd('ping-test', false);
    });
    const btnProxy = document.getElementById('btn-proxy');
    if (btnProxy) btnProxy.addEventListener('click', () => window.api.runCmd('proxy', false));

    // ---- DRIVER TOOLS ----
    const driverUrls = {
        'btn-drv-adb': 'https://adb.clockworkmod.com/',
        'btn-drv-mtk': 'https://androidsupported.com/mtk-usb-vcom-driver/',
        'btn-drv-qcom': 'https://qualcomm-hs-usb-qdloader9008.en.lo4d.com/',
        'btn-drv-spd': 'https://spreadtrum-drivers.en.lo4d.com/',
        'btn-drv-samsung': 'https://developer.samsung.com/mobile/android-usb-driver.html',
    };
    Object.entries(driverUrls).forEach(([id, url]) => {
        const btn = document.getElementById(id);
        if (btn) btn.addEventListener('click', async () => {
            if (window.api && window.api.openExternalUrl) await window.api.openExternalUrl(url);
        });
    });
    const btnDrvZadig = document.getElementById('btn-drv-zadig');
    if (btnDrvZadig) btnDrvZadig.addEventListener('click', () => window.api.openZadig());

    // ---- MAINTENANCE ----
    function showMaintOutput(msg) {
        // legacy - now using modal
    }
    const maintCmds = {
        'btn-chkdsk': { id: 'chkdsk', elevated: true, title: 'ตรวจสอบ HDD (CHKDSK)', subtitle: 'ตรวจสอบและซ่อม Bad Sector บน C: ...', icon: '💾', confirm: 'CHKDSK จะทำงานตอน Restart ใช่ไหม?' },
        'btn-sfc': { id: 'sfc', elevated: true, title: 'ซ่อมไฟล์ระบบ (SFC)', subtitle: 'กำลังสแกนและซ่อม Windows System Files...', icon: '🛡️' },
        'btn-dism': { id: 'dism', elevated: true, title: 'ซ่อม Windows Image (DISM)', subtitle: 'กำลัง Restore Health... (อาจใช้เวลา 15-30 นาที)', icon: '🔩' },
        'btn-startup': { id: 'startup', elevated: false, open: true },
        'btn-msinfo': { id: 'msinfo', elevated: false, open: true },
        'btn-services': { id: 'services', elevated: false, open: true },
    };
    Object.entries(maintCmds).forEach(([btnId, opt]) => {
        const btn = document.getElementById(btnId);
        if (btn) btn.addEventListener('click', () => {
            if (opt.confirm && !confirm(opt.confirm)) return;
            if (!opt.open && opt.title) {
                showProgressModal(opt.title, opt.subtitle, opt.icon);
            }
            window.api.runCmd(opt.id, opt.elevated);
        });
    });

    // ---- QUICK LAUNCH ----
    const quickCmds = {
        'btn-taskmgr': 'taskmgr',
        'btn-calc': 'calc',
        'btn-notepad': 'notepad-blank',
        'btn-snip': 'snip',
        'btn-paint': 'paint',
        'btn-diskmgmt': 'diskmgmt',
    };
    Object.entries(quickCmds).forEach(([btnId, cmdId]) => {
        const btn = document.getElementById(btnId);
        if (btn) btn.addEventListener('click', () => window.api.runCmd(cmdId, false));
    });

    // ========================================================
    // ADVANCED SYSTEM TOOLS HANDLERS & LOGIC (10 PRO FEATURES)
    // ========================================================

    // 1. Quick Utilities (Admin Shortcuts)
    const btnCompMgmt = document.getElementById('btn-compmgmt');
    if (btnCompMgmt) btnCompMgmt.addEventListener('click', () => window.api.runCmd('compmgmt', false));

    const btnGpEdit = document.getElementById('btn-gpedit');
    if (btnGpEdit) btnGpEdit.addEventListener('click', () => window.api.runCmd('gpedit', false));

    const btnGodMode = document.getElementById('btn-create-godmode');
    if (btnGodMode) {
        btnGodMode.addEventListener('click', async () => {
            try {
                const res = await window.api.createGodMode();
                if (res.success) {
                    alert('👑 ' + res.message);
                } else {
                    alert('❌ ' + (res.error || 'Failed to create God Mode'));
                }
            } catch (e) {
                alert('❌ ' + e.message);
            }
        });
    }

    // 2. Windows Activation & License Checker
    const btnCheckActivation = document.getElementById('btn-check-activation');
    const winActivationBadge = document.getElementById('win-activation-badge');
    const winActivationDetails = document.getElementById('win-activation-details');
    if (btnCheckActivation) {
        btnCheckActivation.addEventListener('click', async () => {
            btnCheckActivation.disabled = true;
            btnCheckActivation.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังตรวจสอบ...';
            if (winActivationBadge) {
                winActivationBadge.textContent = 'Checking...';
                winActivationBadge.style.background = 'rgba(234, 179, 8, 0.2)';
                winActivationBadge.style.color = '#facc15';
            }
            try {
                const res = await window.api.winCheckActivation();
                if (res.success) {
                    if (res.isActivated) {
                        winActivationBadge.textContent = '🟢 เปิดใช้งานถาวร (Activated)';
                        winActivationBadge.style.background = 'rgba(34, 197, 94, 0.2)';
                        winActivationBadge.style.color = '#4ade80';
                    } else {
                        winActivationBadge.textContent = '🔴 ยังไม่ Activate';
                        winActivationBadge.style.background = 'rgba(239, 68, 68, 0.2)';
                        winActivationBadge.style.color = '#f87171';
                    }
                    if (winActivationDetails) {
                        winActivationDetails.style.display = 'block';
                        winActivationDetails.innerHTML = `<strong>Edition:</strong> ${res.edition}<br><strong>Channel:</strong> ${res.channel}<br><strong>License Status:</strong> ${res.licenseStatus}`;
                    }
                } else {
                    if (winActivationBadge) winActivationBadge.textContent = '❌ ผิดพลาด';
                }
            } catch (e) {
                if (winActivationBadge) winActivationBadge.textContent = '❌ ผิดพลาด';
            } finally {
                btnCheckActivation.disabled = false;
                btnCheckActivation.innerHTML = '<i class="fas fa-search"></i> ตรวจสอบสถานะลิขสิทธิ์ Windows';
            }
        });
    }

    // 3. Ultimate Performance Mode
    const btnUnlockUltimatePerf = document.getElementById('btn-unlock-ultimate-perf');
    const ultimatePerfStatus = document.getElementById('ultimate-perf-status');
    if (btnUnlockUltimatePerf) {
        btnUnlockUltimatePerf.addEventListener('click', async () => {
            btnUnlockUltimatePerf.disabled = true;
            btnUnlockUltimatePerf.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังปลดล็อก...';
            try {
                const res = await window.api.unlockUltimatePerformance();
                if (ultimatePerfStatus) {
                    ultimatePerfStatus.style.display = 'block';
                    if (res.success) {
                        ultimatePerfStatus.style.background = 'rgba(34, 197, 94, 0.2)';
                        ultimatePerfStatus.style.color = '#4ade80';
                        ultimatePerfStatus.textContent = '✅ ' + res.message;
                    } else {
                        ultimatePerfStatus.style.background = 'rgba(239, 68, 68, 0.2)';
                        ultimatePerfStatus.style.color = '#f87171';
                        ultimatePerfStatus.textContent = '❌ ' + res.error;
                    }
                }
            } catch (e) {
                if (ultimatePerfStatus) {
                    ultimatePerfStatus.style.display = 'block';
                    ultimatePerfStatus.style.background = 'rgba(239, 68, 68, 0.2)';
                    ultimatePerfStatus.style.color = '#f87171';
                    ultimatePerfStatus.textContent = '❌ ' + e.message;
                }
            } finally {
                btnUnlockUltimatePerf.disabled = false;
                btnUnlockUltimatePerf.innerHTML = '<i class="fas fa-bolt"></i> ปลดล็อก & เปิดใช้ Ultimate Performance';
            }
        });
    }

    // 4. Battery Health Report
    const btnBatteryReport = document.getElementById('btn-battery-report');
    const batteryReportStatus = document.getElementById('battery-report-status');
    if (btnBatteryReport) {
        btnBatteryReport.addEventListener('click', async () => {
            btnBatteryReport.disabled = true;
            btnBatteryReport.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังสร้างรายงาน...';
            try {
                const res = await window.api.getBatteryReport();
                if (batteryReportStatus) {
                    batteryReportStatus.style.display = 'block';
                    if (res.success) {
                        batteryReportStatus.style.background = 'rgba(34, 197, 94, 0.2)';
                        batteryReportStatus.style.color = '#4ade80';
                        batteryReportStatus.textContent = '✅ สร้างและเปิดรายงานในเบราว์เซอร์แล้ว (' + (res.reportPath || '') + ')';
                    } else {
                        batteryReportStatus.style.background = 'rgba(234, 179, 8, 0.2)';
                        batteryReportStatus.style.color = '#facc15';
                        batteryReportStatus.textContent = res.error || 'ไม่พบแบตเตอรี่ในอุปกรณ์นี้';
                    }
                }
            } catch (e) {
                if (batteryReportStatus) {
                    batteryReportStatus.style.display = 'block';
                    batteryReportStatus.style.background = 'rgba(239, 68, 68, 0.2)';
                    batteryReportStatus.style.color = '#f87171';
                    batteryReportStatus.textContent = '❌ ' + e.message;
                }
            } finally {
                btnBatteryReport.disabled = false;
                btnBatteryReport.innerHTML = '<i class="fas fa-file-medical-alt"></i> สร้างและเปิดรายงานแบตเตอรี่';
            }
        });
    }

    // 5. Windows Defender Live Status & Control
    async function updateDefenderBadge() {
        const badge = document.getElementById('defender-live-badge');
        if (!badge || !window.api || !window.api.getDefenderStatus) return;
        try {
            const res = await window.api.getDefenderStatus();
            if (res.success) {
                if (res.realTimeEnabled) {
                    badge.textContent = '🟢 ปกป้องอยู่ (Active)';
                    badge.style.background = 'rgba(34, 197, 94, 0.2)';
                    badge.style.color = '#4ade80';
                    badge.style.border = '1px solid rgba(34, 197, 94, 0.4)';
                } else {
                    badge.textContent = '🔴 ปิดอยู่ (Disabled)';
                    badge.style.background = 'rgba(239, 68, 68, 0.2)';
                    badge.style.color = '#f87171';
                    badge.style.border = '1px solid rgba(239, 68, 68, 0.4)';
                }
            }
        } catch (e) {
            console.error('Defender status error:', e);
        }
    }

    const btnDefOff = document.getElementById('btn-def-off');
    if (btnDefOff) {
        btnDefOff.addEventListener('click', () => {
            showProgressModal('กำลังปิด Windows Defender', 'ปิด Real-time Protection...', '🛡️');
            window.api.runCmd('def-off', true);
            setTimeout(updateDefenderBadge, 3500);
        });
    }
    const btnDefOn = document.getElementById('btn-def-on');
    if (btnDefOn) {
        btnDefOn.addEventListener('click', () => {
            showProgressModal('กำลังเปิด Windows Defender', 'เปิด Real-time Protection...', '🛡️');
            window.api.runCmd('def-on', true);
            setTimeout(updateDefenderBadge, 3500);
        });
    }

    // 6. Windows Update Manager
    const winUpdateStatus = document.getElementById('win-update-status');
    function handleWinUpdate(action, btn, title) {
        if (!btn) return;
        btn.addEventListener('click', async () => {
            btn.disabled = true;
            const origHtml = btn.innerHTML;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>...';
            if (winUpdateStatus) {
                winUpdateStatus.style.display = 'block';
                winUpdateStatus.style.background = 'rgba(234, 179, 8, 0.2)';
                winUpdateStatus.style.color = '#facc15';
                winUpdateStatus.textContent = 'กำลังดำเนินการ ' + title + '...';
            }
            try {
                const res = await window.api.winUpdateAction(action);
                if (winUpdateStatus) {
                    if (res.success) {
                        winUpdateStatus.style.background = 'rgba(34, 197, 94, 0.2)';
                        winUpdateStatus.style.color = '#4ade80';
                        winUpdateStatus.textContent = '✅ ' + res.message;
                    } else {
                        winUpdateStatus.style.background = 'rgba(239, 68, 68, 0.2)';
                        winUpdateStatus.style.color = '#f87171';
                        winUpdateStatus.textContent = '❌ ' + (res.error || 'เกิดข้อผิดพลาด');
                    }
                }
            } catch (e) {
                if (winUpdateStatus) {
                    winUpdateStatus.style.background = 'rgba(239, 68, 68, 0.2)';
                    winUpdateStatus.style.color = '#f87171';
                    winUpdateStatus.textContent = '❌ ' + e.message;
                }
            } finally {
                btn.disabled = false;
                btn.innerHTML = origHtml;
            }
        });
    }
    handleWinUpdate('pause', document.getElementById('btn-pause-updates'), 'หยุดอัปเดต');
    handleWinUpdate('resume', document.getElementById('btn-resume-updates'), 'เปิดรับอัปเดต');
    handleWinUpdate('fix', document.getElementById('btn-fix-updates'), 'ซ่อมแซมแคชอัปเดต');

    // 7. BSOD Minidump Crash Analyzer
    const btnAnalyzeBsod = document.getElementById('btn-analyze-bsod');
    const bsodResultBox = document.getElementById('bsod-result-box');
    if (btnAnalyzeBsod) {
        btnAnalyzeBsod.addEventListener('click', async () => {
            btnAnalyzeBsod.disabled = true;
            btnAnalyzeBsod.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังสแกน Minidump...';
            if (bsodResultBox) {
                bsodResultBox.style.display = 'block';
                bsodResultBox.textContent = 'กำลังตรวจสอบโฟลเดอร์ C:\Windows\Minidump...';
            }
            try {
                const res = await window.api.analyzeBsod();
                if (bsodResultBox) {
                    if (res.success) {
                        if (res.dumps && res.dumps.length > 0) {
                            let html = `<div style="color: #4ade80; font-weight: bold; margin-bottom: 6px;">พบ ${res.dumps.length} Minidump ล่าสุด:</div>`;
                            res.dumps.forEach((d, idx) => {
                                html += `<div style="border-top: 1px solid rgba(255,255,255,0.1); padding-top: 4px; margin-top: 4px;">
                                    <strong>[${idx + 1}] ${d.fileName}</strong> (${d.date})<br>
                                    <span style="color: #f87171;">BugCheck: ${d.bugCheck}</span> | ไดรเวอร์ที่เกี่ยวข้อง: <span style="color: #fbbf24;">${d.probableCause || 'N/A'}</span>
                                </div>`;
                            });
                            bsodResultBox.innerHTML = html;
                        } else {
                            bsodResultBox.innerHTML = `<div style="color: #4ade80;">✅ ไม่พบไฟล์ Minidump (ระบบไม่เคยจอฟ้า หรือเพิ่งล้างแคชไป)</div>`;
                        }
                    } else {
                        bsodResultBox.innerHTML = `<div style="color: #fbbf24;">ℹ️ ${res.message || res.error}</div>`;
                    }
                }
            } catch (e) {
                if (bsodResultBox) bsodResultBox.innerHTML = `<div style="color: #f87171;">❌ ${e.message}</div>`;
            } finally {
                btnAnalyzeBsod.disabled = false;
                btnAnalyzeBsod.innerHTML = '<i class="fas fa-search-plus"></i> สแกนวิเคราะห์จอฟ้า (Minidump)';
            }
        });
    }

    // 8. Win 11 Classic Menu & Take Ownership
    async function updateWin11MenuBadge() {
        const badge = document.getElementById('win11-menu-badge');
        if (!badge || !window.api || !window.api.getWin11MenuStatus) return;
        try {
            const res = await window.api.getWin11MenuStatus();
            if (res.success) {
                if (res.isClassic) {
                    badge.textContent = 'Classic Menu';
                    badge.style.background = 'rgba(34, 197, 94, 0.2)';
                    badge.style.color = '#4ade80';
                } else {
                    badge.textContent = 'Win 11 Default';
                    badge.style.background = 'rgba(255, 255, 255, 0.08)';
                    badge.style.color = '#94a3b8';
                }
            }
        } catch (e) {}
    }

    const btnToggleWin11Menu = document.getElementById('btn-toggle-win11-menu');
    const win11MenuStatus = document.getElementById('win11-menu-status');
    if (btnToggleWin11Menu) {
        btnToggleWin11Menu.addEventListener('click', async () => {
            btnToggleWin11Menu.disabled = true;
            try {
                const res = await window.api.toggleWin11ClassicMenu();
                if (win11MenuStatus) {
                    win11MenuStatus.style.display = 'block';
                    if (res.success) {
                        win11MenuStatus.style.background = 'rgba(34, 197, 94, 0.2)';
                        win11MenuStatus.style.color = '#4ade80';
                        win11MenuStatus.textContent = '✅ ' + res.message;
                    } else {
                        win11MenuStatus.style.background = 'rgba(239, 68, 68, 0.2)';
                        win11MenuStatus.style.color = '#f87171';
                        win11MenuStatus.textContent = '❌ ' + (res.error || 'ล้มเหลว');
                    }
                }
                updateWin11MenuBadge();
            } catch (e) {
                if (win11MenuStatus) {
                    win11MenuStatus.style.display = 'block';
                    win11MenuStatus.style.background = 'rgba(239, 68, 68, 0.2)';
                    win11MenuStatus.style.color = '#f87171';
                    win11MenuStatus.textContent = '❌ ' + e.message;
                }
            } finally {
                btnToggleWin11Menu.disabled = false;
            }
        });
    }

    const btnAddTakeOwnership = document.getElementById('btn-add-take-ownership');
    if (btnAddTakeOwnership) {
        btnAddTakeOwnership.addEventListener('click', async () => {
            btnAddTakeOwnership.disabled = true;
            try {
                const res = await window.api.addTakeOwnership();
                if (win11MenuStatus) {
                    win11MenuStatus.style.display = 'block';
                    if (res.success) {
                        win11MenuStatus.style.background = 'rgba(34, 197, 94, 0.2)';
                        win11MenuStatus.style.color = '#4ade80';
                        win11MenuStatus.textContent = '✅ ' + res.message;
                    } else {
                        win11MenuStatus.style.background = 'rgba(239, 68, 68, 0.2)';
                        win11MenuStatus.style.color = '#f87171';
                        win11MenuStatus.textContent = '❌ ' + res.error;
                    }
                }
            } catch (e) {
                alert('Error: ' + e.message);
            } finally {
                btnAddTakeOwnership.disabled = false;
            }
        });
    }

    // 9. Driver Export & Restore
    const btnDriverExport = document.getElementById('btn-driver-export');
    const btnDriverRestore = document.getElementById('btn-driver-restore');
    if (btnDriverExport) {
        btnDriverExport.addEventListener('click', async () => {
            showProgressModal('กำลังสำรองไดรเวอร์ทั้งหมด', 'DISM กำลัง Export 3rd-party drivers ไปที่ C:\\DriverBackup...', '💾');
            try {
                const res = await window.api.driverExportAll();
                finishProgressModal(res.success, res.success ? `\n✅ สำรองไดรเวอร์เรียบร้อยแล้วที่:\n${res.path}` : `\n❌ เกิดข้อผิดพลาด: ${res.error}`);
            } catch (e) {
                finishProgressModal(false, `\n❌ ${e.message}`);
            }
        });
    }
    if (btnDriverRestore) {
        btnDriverRestore.addEventListener('click', async () => {
            const ok = await showCustomConfirm('ต้องการติดตั้งไดรเวอร์คืนจาก C:\\DriverBackup ใช่หรือไม่?\n\n(pnputil จะทำการติดตั้งไดรเวอร์ .inf ทั้งหมดในโฟลเดอร์)');
            if (!ok) return;
            showProgressModal('กำลังติดตั้งไดรเวอร์คืน', 'pnputil กำลังติดตั้งไดรเวอร์จาก C:\\DriverBackup...', '💾');
            try {
                const res = await window.api.driverRestoreAll();
                finishProgressModal(res.success, res.success ? `\n✅ ติดตั้งไดรเวอร์คืนเรียบร้อยแล้ว!` : `\n❌ เกิดข้อผิดพลาด: ${res.error}`);
            } catch (e) {
                finishProgressModal(false, `\n❌ ${e.message}`);
            }
        });
    }

    // 10. Port Scanner & Process Killer
    const inputKillerPort = document.getElementById('input-killer-port');
    const btnPortCheck = document.getElementById('btn-port-check');
    const btnPortKill = document.getElementById('btn-port-kill');
    const portKillerResult = document.getElementById('port-killer-result');
    let currentKillerPid = null;

    if (btnPortCheck) {
        btnPortCheck.addEventListener('click', async () => {
            const port = inputKillerPort.value.trim();
            if (!port) {
                alert('กรุณากรอกหมายเลขพอร์ต');
                return;
            }
            btnPortCheck.disabled = true;
            btnPortCheck.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
            if (portKillerResult) {
                portKillerResult.style.display = 'block';
                portKillerResult.textContent = `กำลังตรวจสอบพอร์ต :${port}...`;
            }
            try {
                const res = await window.api.checkPortKiller(port);
                if (res.success) {
                    if (res.found) {
                        currentKillerPid = res.pid;
                        portKillerResult.innerHTML = `<span style="color: #f87171; font-weight: bold;">🔴 พอร์ตถูกใช้งานอยู่!</span><br><strong>Process:</strong> ${res.procName} (PID: ${res.pid})<br><strong>Line:</strong> ${res.line}`;
                        if (btnPortKill) {
                            btnPortKill.style.display = 'block';
                            btnPortKill.innerHTML = `<i class="fas fa-skull"></i> ปิด ${res.procName} (PID: ${res.pid})`;
                        }
                    } else {
                        currentKillerPid = null;
                        portKillerResult.innerHTML = `<span style="color: #4ade80;">🟢 พอร์ต ${port} ว่าง (ไม่มีโปรแกรมใดบล็อกอยู่)</span>`;
                        if (btnPortKill) btnPortKill.style.display = 'none';
                    }
                } else {
                    portKillerResult.textContent = '❌ ' + res.error;
                }
            } catch (e) {
                portKillerResult.textContent = '❌ ' + e.message;
            } finally {
                btnPortCheck.disabled = false;
                btnPortCheck.innerHTML = '<i class="fas fa-search"></i> ตรวจ';
            }
        });
    }

    if (btnPortKill) {
        btnPortKill.addEventListener('click', async () => {
            if (!currentKillerPid) return;
            const ok = await showCustomConfirm(`ยืนยันการบังคับปิด Process PID ${currentKillerPid} หรือไม่?`);
            if (!ok) return;
            btnPortKill.disabled = true;
            try {
                const res = await window.api.killProcessPid(currentKillerPid);
                if (res.success) {
                    alert('✅ สั่งปิดกระบวนการเรียบร้อยแล้ว!');
                    btnPortKill.style.display = 'none';
                    currentKillerPid = null;
                    if (btnPortCheck) btnPortCheck.click();
                } else {
                    alert('❌ ไม่สามารถปิดได้: ' + res.error);
                }
            } catch (e) {
                alert('❌ ' + e.message);
            } finally {
                btnPortKill.disabled = false;
            }
        });
    }

    // 11. Visual C++ & DirectX Runtime Installer
    const btnInstallVcRedist = document.getElementById('btn-install-vcredist');
    if (btnInstallVcRedist) {
        btnInstallVcRedist.addEventListener('click', async () => {
            const ok = await showCustomConfirm('ต้องการเริ่มติดตั้งชุด Visual C++ 2005-2022 และ DirectX หรือไม่?\n\n(ระบบจะเรียก winget ติดตั้ง Runtimes ทั้งหมดแบบอัตโนมัติ)');
            if (!ok) return;
            showProgressModal('กำลังติดตั้ง VC++ & DirectX', 'กำลังดาวน์โหลดและติดตั้งชุดรันไทม์ทั้งหมด...', '⚙️');
            try {
                const res = await window.api.installVcRedist();
                finishProgressModal(res.success, res.success ? `\n✅ ติดตั้งชุด Runtime สำเร็จเรียบร้อยแล้ว!` : `\n${res.error || res.message}`);
            } catch (e) {
                finishProgressModal(false, `\n❌ ${e.message}`);
            }
        });
    }

    // 12. Hosts File Editor & Reset Default
    const btnHosts = document.getElementById('btn-hosts');
    if (btnHosts) {
        btnHosts.addEventListener('click', () => {
            window.api.runCmd('hosts', true);
        });
    }

    const btnResetHosts = document.getElementById('btn-reset-hosts');
    const hostsResetStatus = document.getElementById('hosts-reset-status');
    if (btnResetHosts) {
        btnResetHosts.addEventListener('click', async () => {
            const ok = await showCustomConfirm('คุณแน่ใจหรือไม่ที่จะรีเซ็ตไฟล์ Hosts กลับเป็นค่าเริ่มต้นแท้ของ Windows?\n\n(การบล็อกโดเมนทั้งหมดจะถูกล้าง)');
            if (!ok) return;
            btnResetHosts.disabled = true;
            try {
                const res = await window.api.resetDefaultHosts();
                if (hostsResetStatus) {
                    hostsResetStatus.style.display = 'block';
                    if (res.success) {
                        hostsResetStatus.style.background = 'rgba(34, 197, 94, 0.2)';
                        hostsResetStatus.style.color = '#4ade80';
                        hostsResetStatus.textContent = '✅ ' + res.message;
                    } else {
                        hostsResetStatus.style.background = 'rgba(239, 68, 68, 0.2)';
                        hostsResetStatus.style.color = '#f87171';
                        hostsResetStatus.textContent = '❌ ' + res.error;
                    }
                }
            } catch (e) {
                alert('Error: ' + e.message);
            } finally {
                btnResetHosts.disabled = false;
            }
        });
    }

    // 13. Network Adapters
    const btnNcpa = document.getElementById('btn-ncpa');
    if (btnNcpa) {
        btnNcpa.addEventListener('click', () => {
            window.api.runCmd('ncpa', false);
        });
    }

    // 14. Reserved Storage
    const btnStorage = document.getElementById('btn-storage');
    if (btnStorage) {
        btnStorage.addEventListener('click', () => {
            showProgressModal('ปิด Reserved Storage', 'กำลังคืนพื้นที่ฮาร์ดดิสก์ 7GB (Admin)...', '💾');
            window.api.runCmd('storage', true);
        });
    }

    // 15. WiFi Passwords with Copy Feature
    let lastRetrievedWifiPw = '';
    const wifiPwResult = document.getElementById('wifi-pw-result');
    const btnWifiCopy = document.getElementById('btn-wifi-copy');

    document.getElementById('btn-wifi-scan').addEventListener('click', async () => {
        const select = document.getElementById('wifi-profiles');
        select.innerHTML = '<option value="">Scanning...</option>';
        if (wifiPwResult) wifiPwResult.style.display = 'none';
        lastRetrievedWifiPw = '';
        try {
            const profiles = await window.api.getWifiProfiles();
            select.innerHTML = '';
            if (profiles.length === 0) {
                select.innerHTML = '<option value="">No profiles found</option>';
            } else {
                profiles.forEach(p => {
                    const opt = document.createElement('option');
                    opt.value = p;
                    opt.textContent = p;
                    select.appendChild(opt);
                });
            }
        } catch (err) {
            select.innerHTML = '<option value="">Error scanning</option>';
            alert("Error: " + err);
        }
    });

    document.getElementById('btn-wifi-show').addEventListener('click', async () => {
        const select = document.getElementById('wifi-profiles');
        const profileName = select.value;
        if (!profileName) {
            alert("กรุณาเลือกชื่อ WiFi ก่อน");
            return;
        }
        try {
            const result = await window.api.getWifiPassword(profileName);
            const match = result.match(/(?:Key Content|เนื้อหาของคีย์)\s*:\s*(.+)/i);
            const cleanPw = match ? match[1].trim() : '(ไม่มีรหัสผ่าน หรือเปิดเป็น Open)';
            lastRetrievedWifiPw = cleanPw;
            if (wifiPwResult) {
                wifiPwResult.style.display = 'block';
                wifiPwResult.innerHTML = `🔑 รหัสผ่าน <strong>${profileName}</strong>: <span style="color:#fbbf24; font-size:14px; font-weight:bold;">${cleanPw}</span>`;
            }
            openModal('WiFi Password: ' + profileName);
            logToModal(result);
            finishProgress();
        } catch (err) {
            alert("Error: " + err);
        }
    });

    if (btnWifiCopy) {
        btnWifiCopy.addEventListener('click', async () => {
            const select = document.getElementById('wifi-profiles');
            const profileName = select.value;
            if (!profileName) {
                alert('กรุณาเลือกชื่อ WiFi ก่อน');
                return;
            }
            try {
                let pwToCopy = lastRetrievedWifiPw;
                if (!pwToCopy) {
                    const res = await window.api.getWifiPassword(profileName);
                    const match = res.match(/(?:Key Content|เนื้อหาของคีย์)\s*:\s*(.+)/i);
                    pwToCopy = match ? match[1].trim() : res.trim();
                }
                await navigator.clipboard.writeText(pwToCopy);
                if (wifiPwResult) {
                    wifiPwResult.style.display = 'block';
                    wifiPwResult.innerHTML = `📋 คัดลอกรหัสผ่าน <strong>${profileName}</strong> ใส่คลิปบอร์ดแล้ว!`;
                }
                alert(`✅ คัดลอกรหัสผ่าน WiFi (${profileName}) สำเร็จแล้ว:\n${pwToCopy}`);
            } catch (e) {
                alert('Error copying password: ' + e.message);
            }
        });
    }

    // 16. Rainmeter Skins Integration
    const btnDlRm = document.getElementById('btn-dl-rm');
    if (btnDlRm) btnDlRm.addEventListener('click', () => window.api.downloadRainmeter());
    const btnApplyRm = document.getElementById('btn-apply-rm');
    if (btnApplyRm) btnApplyRm.addEventListener('click', () => window.api.applyRainmeterSkins());
    const btnApplyRmFull = document.getElementById('btn-apply-rm-full');
    if (btnApplyRmFull) btnApplyRmFull.addEventListener('click', () => window.api.applyRainmeterFull());

    document.getElementById('btn-usb-scan').addEventListener('click', async () => {
        const select = document.getElementById('usb-drive-select');
        select.innerHTML = '<option value="">Scanning...</option>';
        try {
            const drives = await window.api.getDrives();
            select.innerHTML = '';
            if (drives.length === 0) {
                select.innerHTML = '<option value="">No drives found</option>';
            } else {
                drives.forEach(d => {
                    const opt = document.createElement('option');
                    opt.value = d.name;
                    opt.textContent = `${d.name} (${d.label})`;
                    select.appendChild(opt);
                });
            }
        } catch (err) {
            select.innerHTML = '<option value="">Error scanning</option>';
            alert("Error: " + err);
        }
    });

    document.getElementById('btn-usb-fix').addEventListener('click', async () => {
        const select = document.getElementById('usb-drive-select');
        const drive = select.value;
        if (!drive) {
            alert("Please select a drive first.");
            return;
        }
        const userConfirmed = await showCustomConfirm(`คุณแน่ใจหรือไม่ที่จะแก้ไวรัสซ่อนไฟล์ในไดรฟ์ ${drive}?\n\nการทำงานนี้จะทำการยกเลิกการซ่อนไฟล์ทั้งหมด และลบไฟล์ทางลัด (.lnk) ที่เกิดจากไวรัสออกจากไดรฟ์ทันที`);
        if (!userConfirmed) return;

        openModal('Fixing USB Virus on ' + drive);
        
        try {
            const result = await window.api.fixUsbVirus(drive);
            logToModal(result);
        } catch (err) {
            logToModal("Error: " + err);
        }
        finishProgress();
    });

    // PC Cleanup
    // Function to refresh C: Drive Capacity
    async function refreshCDriveSpace() {
        try {
            const info = await window.api.getCDriveSpace();
            if (!info || !info.success) return;
            
            const freeEl = document.getElementById('drive-c-free');
            const totalEl = document.getElementById('drive-c-total');
            const usedEl = document.getElementById('drive-c-used');
            const pctEl = document.getElementById('drive-c-pct-text');
            const barEl = document.getElementById('drive-c-bar');
            const badgeEl = document.getElementById('drive-c-badge');
            
            if (freeEl) freeEl.textContent = `${info.freeGB} GB`;
            if (totalEl) totalEl.textContent = `${info.totalGB} GB`;
            if (usedEl) usedEl.textContent = `${info.usedGB} GB`;
            if (pctEl) pctEl.textContent = `${info.percent}%`;
            
            if (barEl) {
                barEl.style.width = `${Math.min(100, Math.max(0, info.percent))}%`;
                if (info.percent > 90) {
                    barEl.style.background = 'linear-gradient(90deg, #ff9800, #ff1744)';
                } else if (info.percent > 75) {
                    barEl.style.background = 'linear-gradient(90deg, #26c6da, #ff9800)';
                } else {
                    barEl.style.background = 'linear-gradient(90deg, #26c6da, #00e676)';
                }
            }
            
            if (badgeEl) {
                if (info.percent > 90) {
                    badgeEl.className = 'badge danger';
                    badgeEl.textContent = currentLang === 'th' ? 'พื้นที่เหลือน้อยวิกฤต' : 'Critical Low';
                } else if (info.percent > 75) {
                    badgeEl.className = 'badge warning';
                    badgeEl.textContent = currentLang === 'th' ? 'พื้นที่เริ่มเหลือน้อย' : 'Warning Low';
                } else {
                    badgeEl.className = 'badge success';
                    badgeEl.textContent = currentLang === 'th' ? 'ปกติ (Healthy)' : 'Healthy';
                }
            }
        } catch (e) {
            console.error('Failed to get C: drive space:', e);
        }
    }

    // Refresh Drive Space button
    const btnRefreshDrive = document.getElementById('btn-refresh-drive');
    if (btnRefreshDrive) {
        btnRefreshDrive.addEventListener('click', async () => {
            const icon = btnRefreshDrive.querySelector('i');
            if (icon) icon.classList.add('fa-spin');
            await refreshCDriveSpace();
            setTimeout(() => {
                if (icon) icon.classList.remove('fa-spin');
            }, 600);
        });
    }

    // Close cleanup alert
    const btnCloseAlert = document.getElementById('btn-close-cleanup-alert');
    if (btnCloseAlert) {
        btnCloseAlert.addEventListener('click', () => {
            document.getElementById('cleanup-summary-alert').classList.add('hidden');
        });
    }

    // Parent checkbox toggles all sub-checkboxes & sub toggles parent
    function bindCleanupGroup(parentId, subClass) {
        const parent = document.getElementById(parentId);
        const subs = document.querySelectorAll('.' + subClass);
        if (!parent || !subs.length) return;
        
        parent.addEventListener('change', () => {
            subs.forEach(c => c.checked = parent.checked);
        });
        
        subs.forEach(s => {
            s.addEventListener('change', () => {
                const anyChecked = Array.from(subs).some(sub => sub.checked);
                parent.checked = anyChecked;
            });
        });
    }

    bindCleanupGroup('chk-temp', 'sub-chk-temp');
    bindCleanupGroup('chk-trash', 'sub-chk-trash');
    bindCleanupGroup('chk-shader', 'sub-chk-shader');
    bindCleanupGroup('chk-browser', 'sub-chk-browser');
    bindCleanupGroup('chk-game', 'sub-chk-game');
    bindCleanupGroup('chk-app', 'sub-chk-app');
    bindCleanupGroup('chk-dev', 'sub-chk-dev');
    bindCleanupGroup('chk-win', 'sub-chk-win');

    // Presets
    const btnPresetAll = document.getElementById('btn-preset-all');
    if (btnPresetAll) {
        btnPresetAll.addEventListener('click', () => {
            document.querySelectorAll('#cleanup-section input[type="checkbox"]').forEach(c => c.checked = true);
        });
    }

    const btnPresetNone = document.getElementById('btn-preset-none');
    if (btnPresetNone) {
        btnPresetNone.addEventListener('click', () => {
            document.querySelectorAll('#cleanup-section input[type="checkbox"]').forEach(c => c.checked = false);
        });
    }

    const btnPresetSafe = document.getElementById('btn-preset-safe');
    if (btnPresetSafe) {
        btnPresetSafe.addEventListener('click', () => {
            const safeGroups = ['chk-temp', 'chk-trash', 'chk-shader', 'chk-browser', 'chk-game', 'chk-app'];
            const unsafeGroups = ['chk-dev', 'chk-win'];
            
            safeGroups.forEach(id => {
                const el = document.getElementById(id);
                if (el) {
                    el.checked = true;
                    el.dispatchEvent(new Event('change'));
                }
            });
            unsafeGroups.forEach(id => {
                const el = document.getElementById(id);
                if (el) {
                    el.checked = false;
                    el.dispatchEvent(new Event('change'));
                }
            });
            const elEvt = document.getElementById('chk-temp-eventlogs');
            if (elEvt) elEvt.checked = false;
            const elLogs = document.getElementById('chk-trash-logs');
            if (elLogs) elLogs.checked = false;
        });
    }

    let cleanupInterval = null;
    let isCleaning = false;
    let scanInterval = null;
    let isScanning = false;

    function executeCleanup(options) {
        if (isCleaning) return;
        isCleaning = true;
        
        const runBtn = document.getElementById('btn-run-cleanup');
        const smartBtn = document.getElementById('btn-smart-clean');
        if (runBtn) runBtn.disabled = true;
        if (smartBtn) smartBtn.disabled = true;
        
        const alertEl = document.getElementById('cleanup-summary-alert');
        if (alertEl) alertEl.classList.add('hidden');
        
        const container = document.getElementById('cleanup-progress-container');
        const text = document.getElementById('cleanup-progress-text');
        const bar = document.getElementById('cleanup-progress-bar');
        const pct = document.getElementById('cleanup-progress-percent');
        
        container.classList.remove('hidden');
        text.textContent = currentLang === 'th' ? 'กำลังเริ่มลบไฟล์ขยะและแคชระบบ...' : 'Starting cleanup...';
        bar.style.width = '0%';
        pct.textContent = '0%';
        
        let progress = 0;
        clearInterval(cleanupInterval);
        cleanupInterval = setInterval(() => {
            if (progress < 90) {
                progress += options.hasWin ? 2 : 5;
                if (progress > 90) progress = 90;
                bar.style.width = progress + '%';
                pct.textContent = progress + '%';
            }
        }, 400);

        window.api.runCleanup(options);
    }

    // 1-Click Smart Clean
    const btnSmartClean = document.getElementById('btn-smart-clean');
    if (btnSmartClean) {
        btnSmartClean.addEventListener('click', () => {
            const options = {
                temp: { user: true, win: true, prefetch: true, recent: true, thumb: true, delivery: true, eventlogs: false },
                trash: { recycle: true, dumps: true, wer: true, logs: false },
                shader: { d3d: true, nvidia: true, amd: true, intel: true },
                browser: { chrome: true, edge: true, firefox: true, brave: true, opera: true },
                game: { steam: true, epic: true, riot: true, ea: true },
                app: { discord: true, spotify: true, line: true, telegram: true, apple: true, tiktok: true },
                dev: { gradle: false, npm: false, pip: false, nuget: false, pub: false, yarn: false },
                win: { update: true, cleanmgr: false, dism: false },
                hasWin: true
            };
            executeCleanup(options);
        });
    }

    // Scan Junk Files
    document.getElementById('btn-scan-junk').addEventListener('click', async () => {
        if (isScanning || isCleaning) return;
        isScanning = true;
        
        const scanBtn = document.getElementById('btn-scan-junk');
        const originalText = scanBtn.innerHTML;
        scanBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> ' + (translations[currentLang]?.scan_progress || 'Scanning...');
        scanBtn.disabled = true;
        
        const progContainer = document.getElementById('scan-progress-container');
        const resultsContainer = document.getElementById('scan-results-container');
        const bar = document.getElementById('scan-progress-bar');
        const pct = document.getElementById('scan-progress-percent');
        const resultsList = document.getElementById('scan-results-list');
        const totalSize = document.getElementById('scan-total-size');
        
        resultsContainer.classList.add('hidden');
        progContainer.classList.remove('hidden');
        bar.style.width = '0%';
        pct.textContent = '0%';
        resultsList.innerHTML = '';
        totalSize.textContent = '';
        
        let progress = 0;
        scanInterval = setInterval(() => {
            if (progress < 95) {
                progress += 3;
                if (progress > 95) progress = 95;
                bar.style.width = progress + '%';
                pct.textContent = progress + '%';
            }
        }, 300);

        try {
            const result = await window.api.scanJunk();
            clearInterval(scanInterval);
            bar.style.width = '100%';
            pct.textContent = '100%';
            
            setTimeout(() => {
                progContainer.classList.add('hidden');
                resultsContainer.classList.remove('hidden');
                
                const mbTotal = (result.totalBytes / (1024 * 1024)).toFixed(2);
                const gbTotal = (result.totalBytes / (1024 * 1024 * 1024)).toFixed(2);
                totalSize.textContent = result.totalBytes > 1024 * 1024 * 1024 ? `${gbTotal} GB` : `${mbTotal} MB`;
                
                const entries = Object.entries(result.results);
                entries.forEach(([name, size]) => {
                    if (size > 0) {
                        const sizeMB = (size / (1024 * 1024)).toFixed(2);
                        const item = document.createElement('div');
                        item.style = 'font-size: 13px; color: var(--text-light); display: flex; justify-content: space-between; align-items: center; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.06); border-radius: 6px; padding: 6px 12px;';
                        item.innerHTML = `<span><i class="fas fa-folder" style="color: #26c6da; margin-right: 6px; font-size: 11px;"></i>${name}</span><span style="color: #00e676; font-weight: 600; font-family: monospace;">${sizeMB} MB</span>`;
                        resultsList.appendChild(item);
                    }
                });
                if (resultsList.children.length === 0) {
                    resultsList.innerHTML = '<span style="color: var(--text-light); font-size: 13px;">' + (translations[currentLang]?.scan_no_junk || 'No junk files found!') + '</span>';
                }
                
                scanBtn.innerHTML = originalText;
                scanBtn.disabled = false;
                isScanning = false;
            }, 400);
            
        } catch (error) {
            console.error('Scan error:', error);
            clearInterval(scanInterval);
            scanBtn.innerHTML = originalText;
            scanBtn.disabled = false;
            isScanning = false;
            progContainer.classList.add('hidden');
        }
    });

    // Run Selected Cleanup
    document.getElementById('btn-run-cleanup').addEventListener('click', () => {
        if (isCleaning) return;
        const getChk = (id) => {
            const el = document.getElementById(id);
            return el ? el.checked : false;
        };
        
        const options = {
            temp: {
                user: getChk('chk-temp-user'),
                win: getChk('chk-temp-win'),
                prefetch: getChk('chk-temp-prefetch'),
                recent: getChk('chk-temp-recent'),
                thumb: getChk('chk-temp-thumb'),
                delivery: getChk('chk-temp-delivery'),
                eventlogs: getChk('chk-temp-eventlogs')
            },
            trash: {
                recycle: getChk('chk-trash-recycle'),
                dumps: getChk('chk-trash-dumps'),
                wer: getChk('chk-trash-wer'),
                logs: getChk('chk-trash-logs')
            },
            shader: {
                d3d: getChk('chk-shader-d3d'),
                nvidia: getChk('chk-shader-nvidia'),
                amd: getChk('chk-shader-amd'),
                intel: getChk('chk-shader-intel')
            },
            browser: {
                chrome: getChk('chk-browser-chrome'),
                edge: getChk('chk-browser-edge'),
                firefox: getChk('chk-browser-firefox'),
                brave: getChk('chk-browser-brave'),
                opera: getChk('chk-browser-opera')
            },
            game: {
                steam: getChk('chk-game-steam'),
                epic: getChk('chk-game-epic'),
                riot: getChk('chk-game-riot'),
                ea: getChk('chk-game-ea')
            },
            app: {
                discord: getChk('chk-app-discord'),
                spotify: getChk('chk-app-spotify'),
                line: getChk('chk-app-line'),
                apple: getChk('chk-app-apple'),
                telegram: getChk('chk-app-telegram'),
                tiktok: getChk('chk-app-tiktok')
            },
            dev: {
                gradle: getChk('chk-dev-gradle'),
                npm: getChk('chk-dev-npm'),
                pip: getChk('chk-dev-pip'),
                nuget: getChk('chk-dev-nuget'),
                pub: getChk('chk-dev-pub'),
                yarn: getChk('chk-dev-yarn')
            },
            win: {
                update: getChk('chk-win-update'),
                cleanmgr: getChk('chk-win-cleanmgr'),
                dism: getChk('chk-win-dism')
            },
            hasWin: getChk('chk-win-update') || getChk('chk-win-cleanmgr') || getChk('chk-win-dism')
        };
        
        executeCleanup(options);
    });

    // Test Mode
    const testmodeStatusText = document.getElementById('testmode-status-text');
    const testmodeDot = document.getElementById('testmode-dot');

    window.api.onTestModeStatusReply((status) => {
        if (status === 'ON') {
            testmodeStatusText.textContent = translations[currentLang]['test_status_on'];
            testmodeDot.classList.remove('off');
            testmodeDot.classList.add('on');
        } else {
            testmodeStatusText.textContent = translations[currentLang]['test_status_off'];
            testmodeDot.classList.remove('on');
            testmodeDot.classList.add('off');
        }
    });

    // Initial check
    window.api.getTestModeStatus();

    document.getElementById('btn-testmode-on').addEventListener('click', () => {
        openModal('modal_title_test_on');
        window.api.runCmd('testmode-on', true);
    });

    document.getElementById('btn-testmode-off').addEventListener('click', () => {
        openModal('modal_title_test_off');
        window.api.runCmd('testmode-off', true);
    });

    // Mobile Tools
    async function runMobileTool(titleKey, apiMethod, ...args) {
        openModal(titleKey);
        try {
            const result = await apiMethod(...args);
            logToConsole(result || "Done.");
        } catch (err) {
            logToConsole(err.toString());
        }
        finishProgress();
    }

    // --- Mobile Section UI Logic (Redesigned) ---

    // Tab Switching
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            tabBtns.forEach(b => {
                b.classList.remove('active');
                b.style.background = 'rgba(0,0,0,0.3)';
                b.style.color = '#cbd5e1';
            });
            tabContents.forEach(c => c.style.display = 'none');
            
            btn.classList.add('active');
            btn.style.background = 'var(--accent-color)';
            btn.style.color = '#ffffff';
            const targetId = btn.getAttribute('data-target');
            document.getElementById(targetId).style.display = 'block';
        });
    });

    // Helper: update checkboxes status
    function updateFlashBtnStatus(listId, btnId) {
        const fwPartitionsList = document.getElementById(listId);
        const btnFlashFwNow = document.getElementById(btnId);
        if (!fwPartitionsList || !btnFlashFwNow) return;
        const checked = fwPartitionsList.querySelectorAll('input[type="checkbox"]:checked');
        btnFlashFwNow.disabled = checked.length === 0;
    }

    function renderPartitions(parsedPartitions, listId, btnId) {
        const fwPartitionsList = document.getElementById(listId);
        fwPartitionsList.innerHTML = '';
        let hasValidPartition = false;
        
        parsedPartitions.forEach((p, idx) => {
            const id = `chk-${listId}-${idx}`;
            const div = document.createElement('div');
            div.style.display = 'flex';
            div.style.alignItems = 'center';
            div.style.gap = '8px';
            div.style.opacity = p.exists ? '1' : '0.5';
            
            const cb = document.createElement('input');
            cb.type = 'checkbox';
            cb.id = id;
            cb.value = idx;
            cb.checked = p.defaultChecked;
            cb.disabled = !p.exists;
            
            if (p.defaultChecked) hasValidPartition = true;
            
            cb.addEventListener('change', () => updateFlashBtnStatus(listId, btnId));
            
            const lbl = document.createElement('label');
            lbl.htmlFor = id;
            lbl.style.cursor = 'pointer';
            lbl.style.fontSize = '12px';
            lbl.style.color = p.exists ? 'var(--text-color)' : 'var(--text-muted)';
            lbl.style.overflow = 'hidden';
            lbl.style.textOverflow = 'ellipsis';
            lbl.style.whiteSpace = 'nowrap';
            lbl.style.flex = '1';
            lbl.innerHTML = `<strong>${p.partition}</strong> <span style="opacity:0.7">(${p.fileName})</span>`;
            if (!p.exists) lbl.innerHTML += ' <span style="color:var(--danger-color);">(Missing)</span>';
            
            const btnChange = document.createElement('button');
            btnChange.textContent = "Change File";
            btnChange.style.fontSize = '10px';
            btnChange.style.padding = '2px 6px';
            btnChange.style.marginLeft = 'auto';
            btnChange.style.borderRadius = '4px';
            btnChange.style.border = '1px solid var(--border-color)';
            btnChange.style.background = 'var(--bg-secondary)';
            btnChange.style.color = 'var(--text-color)';
            btnChange.style.cursor = 'pointer';
            
            btnChange.onclick = async () => {
                const newPath = await window.api.browseSingleFile();
                if (newPath) {
                    p.fullPath = newPath;
                    p.fileName = newPath.substring(newPath.lastIndexOf('\\') + 1);
                    p.exists = true;
                    
                    div.style.opacity = '1';
                    cb.disabled = false;
                    cb.checked = true;
                    lbl.style.color = 'var(--text-color)';
                    lbl.innerHTML = `<strong>${p.partition}</strong> <span style="opacity:0.7">(${p.fileName})</span> <span style="color:var(--accent-color);">(Mod)</span>`;
                    updateFlashBtnStatus(listId, btnId);
                }
            };

            div.appendChild(cb);
            div.appendChild(lbl);
            div.appendChild(btnChange);
            fwPartitionsList.appendChild(div);
        });
        
        updateFlashBtnStatus(listId, btnId);
    }

    // --- QUALCOMM SECTION ---
    let qcomParsedPartitions = [];
    let qcomSelectedProgrammer = null;
    let qcomSelectedPatch = null;
    let qcomSelectedComPort = null;
    let qcomFwDir = null;

    const btnQcomScanPorts = document.getElementById('btn-qcom-scan-ports');
    const qcomPortSelect = document.getElementById('qcom-port-select');
    
    btnQcomScanPorts.addEventListener('click', async () => {
        btnQcomScanPorts.disabled = true;
        btnQcomScanPorts.textContent = "Scanning...";
        const ports = await window.api.scanComPorts();
        
        qcomPortSelect.innerHTML = '';
        if (ports && ports.length > 0) {
            let bestPort = null;
            ports.forEach(port => {
                const opt = document.createElement('option');
                const portVal = typeof port === 'object' ? port.port : port;
                const portDesc = typeof port === 'object' ? (port.description || '') : '';
                const isEdl = typeof port === 'object' ? (port.isEdl || /9008|QUALCOMM/i.test(portDesc)) : /9008/i.test(port);
                opt.value = portVal;
                opt.textContent = portDesc ? `${portVal} (${portDesc})` : portVal;
                if (isEdl && !bestPort) {
                    opt.selected = true;
                    bestPort = portVal;
                }
                qcomPortSelect.appendChild(opt);
            });
            qcomSelectedComPort = bestPort || (typeof ports[0] === 'object' ? ports[0].port : ports[0]);
        } else {
            const opt = document.createElement('option');
            opt.value = "";
            opt.textContent = "No devices found";
            qcomPortSelect.appendChild(opt);
            qcomSelectedComPort = null;
        }
        btnQcomScanPorts.disabled = false;
        btnQcomScanPorts.textContent = "Scan Ports";
    });

    qcomPortSelect.addEventListener('change', (e) => {
        qcomSelectedComPort = e.target.value;
    });

    document.getElementById('btn-qcom-browse-fw').addEventListener('click', async () => {
        const filePath = await window.api.browseAdvFirmwareFile();
        if (filePath) {
            document.getElementById('qcom-fw-file-path').textContent = filePath;
            document.getElementById('qcom-fw-file-path').title = filePath;
            
            const result = await window.api.parseFirmwareFile(filePath);
            if (result.error) {
                alert("Error reading file: " + result.error);
                return;
            }
            
            if (result.type !== 'QCOM' && !filePath.toLowerCase().endsWith('.map')) {
                alert("Please select a valid QCOM XML or .map file.");
                return;
            }
            
            qcomParsedPartitions = result.partitions;
            qcomFwDir = filePath.substring(0, filePath.lastIndexOf('\\'));
            
            if (result.autoPatch) {
                qcomSelectedPatch = result.autoPatch;
                document.getElementById('qcom-patch-file-path').textContent = result.autoPatch;
                document.getElementById('qcom-patch-file-path').title = result.autoPatch;
            }

            btnQcomScanPorts.click();
            document.getElementById('qcom-partitions-container').style.display = 'block';
            renderPartitions(qcomParsedPartitions, 'qcom-partitions-list', 'btn-qcom-flash-now');
        }
    });

    // Qualcomm Firehose loaders and brand/model database initialized via initFlasherSuiteDatabase()

    document.getElementById('btn-qcom-select-all').addEventListener('click', () => {
        const cbs = document.getElementById('qcom-partitions-list').querySelectorAll('input[type="checkbox"]:not(:disabled)');
        cbs.forEach(cb => cb.checked = true);
        updateFlashBtnStatus('qcom-partitions-list', 'btn-qcom-flash-now');
    });

    document.getElementById('btn-qcom-select-none').addEventListener('click', () => {
        const cbs = document.getElementById('qcom-partitions-list').querySelectorAll('input[type="checkbox"]');
        cbs.forEach(cb => cb.checked = false);
        updateFlashBtnStatus('qcom-partitions-list', 'btn-qcom-flash-now');
    });

    document.getElementById('btn-qcom-flash-now').addEventListener('click', async () => {
        const checkedBoxes = document.getElementById('qcom-partitions-list').querySelectorAll('input[type="checkbox"]:checked');
        if (checkedBoxes.length === 0) return;
        
        const selectedParts = [];
        for (const cb of checkedBoxes) {
            selectedParts.push(qcomParsedPartitions[cb.value]);
        }
        
        
        
        
        if (!qcomSelectedComPort) {
            logToConsole(`\n[ERROR] Please select a COM port first.\n`);
            finishProgress();
            return;
        }
        if (!qcomSelectedProgrammer) {
            logToConsole(`\n[ERROR] Please select a Programmer file (.mbn/.elf) for QCOM flashing.\n`);
            finishProgress();
            return;
        }

        logToConsole(`\n> [QCOM EDL] Port: ${qcomSelectedComPort}\n`);
        logToConsole(`> [QCOM EDL] Programmer: ${qcomSelectedProgrammer}\n`);
        logToConsole(`> [QCOM EDL] Selected Partitions: ${selectedParts.length}\n`);
        

        try {
            const res = await window.api.runQcomFlash(qcomSelectedComPort, qcomSelectedProgrammer, qcomSelectedPatch, qcomFwDir, selectedParts);
            logToConsole(`\n[QCOM EDL] Flash Completed!\nOutput:\n${res}\n`);
        } catch (err) {
            logToConsole(`\n[ERROR] QCOM Flashing failed:\n${err.message || err}\n`);
        }
        finishProgress();
    });

    // --- MEDIATEK SECTION ---
    let mtkParsedPartitions = [];
    let mtkSelectedDa = null;
    let mtkMode = 'brom'; // 'brom' or 'preloader'
    let mtkFwDir = null;

    const mtkModeRadios = document.querySelectorAll('input[name="mtk-mode"]');
    mtkModeRadios.forEach(r => {
        r.addEventListener('change', (e) => {
            mtkMode = e.target.value;
            if (mtkMode === 'preloader') {
                document.getElementById('mtk-da-container').style.display = 'flex';
            } else {
                document.getElementById('mtk-da-container').style.display = 'none';
            }
        });
    });

    let mtkSelectedPreloader = null;
    let mtkSelectedAuth = null;
    
    // Checkbox toggles
    document.getElementById('chk-custom-da').addEventListener('change', (e) => {
        document.getElementById('btn-mtk-browse-da').disabled = !e.target.checked;
        if (!e.target.checked) mtkSelectedDa = null;
    });
    document.getElementById('chk-custom-preloader').addEventListener('change', (e) => {
        document.getElementById('btn-mtk-browse-preloader').disabled = !e.target.checked;
        if (!e.target.checked) mtkSelectedPreloader = null;
    });
    document.getElementById('chk-custom-auth').addEventListener('change', (e) => {
        document.getElementById('btn-mtk-browse-auth').disabled = !e.target.checked;
        if (!e.target.checked) mtkSelectedAuth = null;
    });

    document.getElementById('btn-mtk-browse-da').addEventListener('click', async () => {
        const filePath = await window.api.browseSingleFile();
        if (filePath) {
            mtkSelectedDa = filePath;
            document.getElementById('mtk-da-file-path').textContent = filePath.split('\\').pop();
            document.getElementById('mtk-da-file-path').title = filePath;
        }
    });
    
    document.getElementById('btn-mtk-browse-preloader').addEventListener('click', async () => {
        const filePath = await window.api.browseSingleFile();
        if (filePath) {
            mtkSelectedPreloader = filePath;
            document.getElementById('mtk-preloader-file-path').textContent = filePath.split('\\').pop();
            document.getElementById('mtk-preloader-file-path').title = filePath;
        }
    });
    
    document.getElementById('btn-mtk-browse-auth').addEventListener('click', async () => {
        const filePath = await window.api.browseSingleFile();
        if (filePath) {
            mtkSelectedAuth = filePath;
            document.getElementById('mtk-auth-file-path').textContent = filePath.split('\\').pop();
            document.getElementById('mtk-auth-file-path').title = filePath;
        }
    });

    document.getElementById('btn-mtk-browse-fw').addEventListener('click', async () => {
        const filePath = await window.api.browseAdvFirmwareFile();
        if (filePath) {
            document.getElementById('mtk-fw-file-path').textContent = filePath;
            document.getElementById('mtk-fw-file-path').title = filePath;
            
            const result = await window.api.parseFirmwareFile(filePath);
            if (result.error) {
                alert("Error reading file: " + result.error);
                return;
            }
            
            if (result.type !== 'MTK' && result.type !== 'MTK_MAP' && result.type !== 'MTK_ZIP') {
                alert("Please select a valid MTK Scatter, .map, or .zip NV backup file.");
                return;
            }
            
            // Validate model if ZIP has proinfo
            if (result.type === 'MTK_ZIP' && result.hasProinfo) {
                const model = result.proinfoModel || "Unknown";
                const usbText = document.getElementById('console-usb-status') ? document.getElementById('console-usb-status').textContent : '';
                let warning = `ไฟล์ NV Backup นี้มาจากเครื่องรุ่น: ${model}\n\n`;
                if (usbText && usbText !== '- Waiting for devices -') {
                    warning += `เครื่องที่กำลังเชื่อมต่ออยู่: ${usbText}\n\n`;
                    if (model !== "Unknown" && !usbText.toUpperCase().includes(model.toUpperCase())) {
                        warning += `ข้อควรระวัง: เครื่องที่เชื่อมต่ออยู่ดูเหมือนจะไม่ตรงกับรุ่น ${model}!\nการแฟลชข้อมูล NV ผิดรุ่นอาจทำให้เลข IMEI หรือ Baseband สูญหายได้\n\n`;
                    }
                }
                warning += `คุณต้องการดำเนินการต่อและโหลดพาร์ติชันเหล่านี้หรือไม่?`;
                const userConfirmed = await showCustomConfirm(warning);
                if (!userConfirmed) {
                    document.getElementById('mtk-fw-file-path').textContent = 'No file selected';
                    return;
                }
            }
            
            mtkParsedPartitions = result.partitions;
            mtkFwDir = filePath.substring(0, filePath.lastIndexOf('\\'));
            
            document.getElementById('mtk-partitions-container').style.display = 'block';
            renderPartitions(mtkParsedPartitions, 'mtk-partitions-list', 'btn-mtk-flash-now');
        }
    });

    document.getElementById('btn-mtk-select-all').addEventListener('click', () => {
        const cbs = document.getElementById('mtk-partitions-list').querySelectorAll('input[type="checkbox"]:not(:disabled)');
        cbs.forEach(cb => cb.checked = true);
        updateFlashBtnStatus('mtk-partitions-list', 'btn-mtk-flash-now');
    });

    document.getElementById('btn-mtk-select-none').addEventListener('click', () => {
        const cbs = document.getElementById('mtk-partitions-list').querySelectorAll('input[type="checkbox"]');
        cbs.forEach(cb => cb.checked = false);
        updateFlashBtnStatus('mtk-partitions-list', 'btn-mtk-flash-now');
    });

    document.getElementById('btn-mtk-flash-now').addEventListener('click', async () => {
        const checkedBoxes = document.getElementById('mtk-partitions-list').querySelectorAll('input[type="checkbox"]:checked');
        if (checkedBoxes.length === 0) return;
        
        const selectedParts = [];
        for (const cb of checkedBoxes) {
            selectedParts.push(mtkParsedPartitions[cb.value]);
        }
        
        
        
        
        logToConsole(`\n> [MTK] Preparing to flash ${selectedParts.length} partitions...\n`);
        

        let cmdStr = "";
        for (const p of selectedParts) {
            cmdStr += `w ${p.partition} "${p.fullPath}"; `;
        }
        
        try {
            // Use the new partition extractor/flasher for MTK
            const res = await window.api.flashMtkPartitions(selectedParts, mtkMode, mtkSelectedDa, mtkSelectedPreloader);
            logToConsole(`\n[MTK] Flash Completed!\nOutput:\n${res}\n`);
        } catch (err) {
            logToConsole(`\n[ERROR] MTK Flashing failed:\n${err.message || err}\n`);
        }

        finishProgress();
    });

    // --- ADB & FASTBOOT SECTION ---
    const btnAdbGpt = document.getElementById('btn-adb-gpt');
    if (btnAdbGpt) {
        btnAdbGpt.addEventListener('click', async () => {
        openModal('ADB: Read GPT Table');
        logToModal('> Requesting GPT Table via ADB...\n');
        
        try {
            let rootCheck = '';
            try {
                rootCheck = await window.api.runAdbCommand('shell su -c "id"');
            } catch(e) {
                rootCheck = '';
            }
            if (!rootCheck || (!rootCheck.includes('uid=0') && !rootCheck.includes('root'))) {
                logToModal('[ERROR] Root access denied. Device is not rooted (su not found) or permission was denied.\n', 'error');
                finishModal(false);
                return;
            }
            window.api.send('adb-read-gpt', {});
        } catch(err) {
            logToModal(`[ERROR] ${err.message || err}\n`, 'error');
            finishModal(false);
        }
        });
    }

    document.getElementById('btn-adb-info').addEventListener('click', async () => {
        openModal('ADB: Read Device Info');
        logToModal('> Reading Device Info via ADB...\n');
        
        try {
            const getProp = async (prop) => {
                try {
                    const res = await window.api.runAdbCommand('shell getprop ' + prop);
                    return (res && res.trim() !== '') ? res.trim() : 'Unknown';
                } catch(e) { return 'Unknown'; }
            };
            
            const getKernel = async () => {
                try {
                    const res = await window.api.runAdbCommand('shell uname -a');
                    return (res && res.trim() !== '') ? res.trim() : 'Unknown';
                } catch(e) { return 'Unknown'; }
            };

            const info = {
                'Patch Level': await getProp('ro.build.version.security_patch'),
                'Ver. CodeName': await getProp('ro.build.version.codename'),
                'Ver. Release': await getProp('ro.build.version.release'),
                'Sec. Patch': await getProp('ro.build.version.security_patch'),
                'Product Manfct': await getProp('ro.product.manufacturer'),
                'Build Time': await getProp('ro.build.date'),
                'Product Brand': await getProp('ro.product.brand'),
                'Product Model': await getProp('ro.product.model'),

                'Product Device': await getProp('ro.product.device'),
                'Product Name': await getProp('ro.product.name'),
                'SW OTA Version': await getProp('ro.build.version.incremental'),

                'Kernel Info': await getKernel(),
                'Android Version': await getProp('ro.build.version.release'),
                'Platform/Chipset': await getProp('ro.board.platform'),

                'CPU Arch': await getProp('ro.product.cpu.abi'),
                'Build ID': await getProp('ro.build.display.id'),
                'SIM State': await getProp('gsm.sim.state'),
                'SIM Operator': await getProp('gsm.sim.operator.alpha'),
            };
            
            let csc = await getProp('ro.csc.sales_code');
            if (csc === 'Unknown' || csc === '') csc = await getProp('ril.sales_code');
            info['Sales Code / CSC'] = csc;

            logToModal('--------------------------------\n');
            for (const [key, value] of Object.entries(info)) {
                logToModal(`${key.padEnd(16, ' ')}: ${value}\n`);
            }
            logToModal('--------------------------------\n');
            
            const simState = info['SIM State'];
            const operator = info['SIM Operator'];
            if (simState.includes('NETWORK_LOCKED') || simState.includes('PIN_REQUIRED') || simState.includes('PUK_REQUIRED')) {
                let lockSource = operator !== 'Unknown' ? operator : (csc !== 'Unknown' ? csc : 'Unknown Carrier');
                logToModal(`📌 ข้อสรุป: 🔒 เครื่องนี้ติดล็อกซิม (Locked to: ${lockSource})\n`, 'warning');
            } else if (simState.includes('LOADED') || simState.includes('READY')) {
                logToModal(`📌 ข้อสรุป: ✅ เครื่องเปล่า ไม่ล็อกซิม (Unlocked)\n`, 'success');
            } else if (simState.includes('ABSENT')) {
                logToModal(`📌 ข้อสรุป: ⚠️ ไม่ได้ใส่ซิมการ์ด (Please insert SIM to check lock status)\n`, 'warning');
            } else {
                logToModal(`📌 ข้อสรุป: ⚠️ ไม่สามารถระบุสถานะล็อกซิมได้จาก ADB (Unknown)\n`, 'warning');
            }
            logToModal('--------------------------------\n');
            finishModal(true);
        } catch (err) {
            logToModal(`\n[ERROR] ${err.message || err}\n`, 'error');
            finishModal(false);
        }
    });

    document.getElementById('btn-adb-reboot-rec').addEventListener('click', () => runAdbSimple('reboot recovery'));
    document.getElementById('btn-adb-reboot-bl').addEventListener('click', () => runAdbSimple('reboot bootloader'));
    document.getElementById('btn-adb-reboot-edl').addEventListener('click', () => runAdbSimple('reboot edl'));
    
    // Fastboot Buttons
    document.getElementById('btn-fb-scan')?.addEventListener('click', () => runFbSimple('devices'));
    document.getElementById('btn-fb-info')?.addEventListener('click', () => runFbSimple('getvar all'));
    document.getElementById('btn-fb-erasefrp')?.addEventListener('click', () => runFbSimple('erase frp'));
    document.getElementById('btn-fb-unlock')?.addEventListener('click', async () => {
        const confirmUnlock = confirm('⚠️ คำเตือน: การปลดล็อค Bootloader จะล้างข้อมูลในเครื่องทั้งหมด (Factory Reset)\n\nคุณต้องการส่งคำสั่งปลดล็อคใช่หรือไม่?');
        if (!confirmUnlock) return;
        openModal('Fastboot: UNLOCK BOOTLOADER');
        logToModal('> กำลังส่งคำสั่งปลดล็อค Bootloader...\n');
        try {
            logToModal('> fastboot flashing unlock...\n');
            const res1 = await window.api.runFastbootCommand('flashing unlock');
            logToModal(`\n${res1}\n`, 'info');
        } catch(e1) {
            logToModal(`> flashing unlock ไม่สำเร็จ (${e1.message || e1}), กำลังลอง fastboot oem unlock...\n`);
            try {
                const res2 = await window.api.runFastbootCommand('oem unlock');
                logToModal(`\n${res2}\n`, 'info');
            } catch(e2) {
                logToModal(`\n[ERROR] ${e2.message || e2}\n`, 'error');
            }
        }
        logToModal('\n💡 หากบนหน้าจอมือถือมีข้อความขึ้นเตือน ให้กดปุ่ม Vol Up บนเครื่องเพื่อยืนยันการปลดล็อค\n', 'warning');
        finishModal(true);
    });
    document.getElementById('btn-fb-reboot')?.addEventListener('click', () => runFbSimple('reboot'));
    document.getElementById('btn-fb-reboot-rec')?.addEventListener('click', () => runFbSimple('reboot recovery'));
    document.getElementById('btn-fb-reboot-bl')?.addEventListener('click', () => runFbSimple('reboot bootloader'));
    document.getElementById('btn-fb-reboot-edl')?.addEventListener('click', async () => {
        openModal('Fastboot: REBOOT EDL (9008)');
        logToModal('> กำลังส่งคำสั่งรีบูตเข้าโหมด EDL 9008...\n');
        try {
            logToModal('> fastboot oem edl...\n');
            const res = await window.api.runFastbootCommand('oem edl');
            logToModal(`\n${res}\n`, 'success');
            finishModal(true);
        } catch(e) {
            logToModal(`> oem edl ไม่สำเร็จ, กำลังลอง fastboot reboot-edl...\n`);
            try {
                const res2 = await window.api.runFastbootCommand('reboot-edl');
                logToModal(`\n${res2}\n`, 'success');
                finishModal(true);
            } catch(e2) {
                logToModal(`\n[ERROR] ${e2.message || e2}\n`, 'error');
                finishModal(false);
            }
        }
    });

    async function runAdbSimple(cmd) {
        openModal(`ADB: ${cmd.toUpperCase()}`);
        logToModal(`> adb ${cmd}...\n`);
        try {
            const res = await window.api.runAdbCommand(cmd);
            logToModal(`\n${res}\n`, 'success');
            finishModal(true);
        } catch (err) {
            logToModal(`\n[ERROR] ${err.message || err}\n`, 'error');
            finishModal(false);
        }
    }

    async function runFbSimple(cmd) {
        openModal(`Fastboot: ${cmd.toUpperCase()}`);
        logToModal(`> fastboot ${cmd}...\n`);
        try {
            const res = await window.api.runFastbootCommand(cmd);
            logToModal(`\n${res}\n`, 'success');
            finishModal(true);
        } catch (err) {
            logToModal(`\n[ERROR] ${err.message || err}\n`, 'error');
            finishModal(false);
        }
    }

    // ADB App Remover Logic
    let installedApps = [];
    
    // ADB Dump Logic (Legacy / Root)
    let adbDiscoveredPartitions = [];
    const btnAdbScanParts = document.getElementById('btn-adb-scan-parts');
    if (btnAdbScanParts) {
        btnAdbScanParts.addEventListener('click', async () => {
            const listDiv = document.getElementById('adb-partitions-list');
            listDiv.innerHTML = `<div style="grid-column: 1 / -1; text-align: center; color: var(--text-muted); padding: 10px;">${currentLang === 'th' ? 'กำลังค้นหาพาร์ติชั่น (ต้อง Root)...' : 'Scanning partitions (requires Root)...'}</div>`;
            document.getElementById('adb-dump-partitions-container').style.display = 'block';
            adbDiscoveredPartitions = [];
            
            try {
                // Check Root
                let rootCheck = '';
                try {
                    rootCheck = await window.api.runAdbCommand('shell su -c "id"');
                } catch(e) {
                    rootCheck = '';
                }
                if (!rootCheck || (!rootCheck.includes('uid=0') && !rootCheck.includes('root'))) {
                    const text = currentLang === 'th' ? 'การเข้าถึง Root ไม่สำเร็จ (เครื่องยังไม่ได้รูท หรือ su: not found)' : 'Root access denied. Device must be rooted and grant su permissions to ADB.';
                    listDiv.innerHTML = `<div style="grid-column: 1 / -1; text-align: center; color: var(--danger-color); padding: 10px;">${text}</div>`;
                    return;
                }

                // Get partition list
                const lsOutput = await window.api.runAdbCommand('shell su -c "ls -la /dev/block/by-name/"');
                
                if (!lsOutput || lsOutput.includes('No such file or directory')) {
                    const text = currentLang === 'th' ? 'ไม่พบ /dev/block/by-name/ โครงสร้างพาร์ติชั่นของรุ่นนี้อาจจะแตกต่างออกไป' : 'Could not find /dev/block/by-name/. Device might have a different partition layout.';
                    listDiv.innerHTML = `<div style="grid-column: 1 / -1; text-align: center; color: var(--danger-color); padding: 10px;">${text}</div>`;
                    return;
                }

                const lines = lsOutput.split('\n');
                for (const line of lines) {
                    // Parse symlinks: lrwxrwxrwx ... boot -> /dev/block/mmcblk0p24
                    const match = line.match(/([^\s]+)\s*->\s*(.+)$/);
                    if (match) {
                        const name = match[1].trim();
                        const path = match[2].trim();
                        // exclude '.' and '..'
                        if (name !== '.' && name !== '..') {
                            adbDiscoveredPartitions.push({ name, path });
                        }
                    }
                }
                
                if (adbDiscoveredPartitions.length === 0) {
                    const text = currentLang === 'th' ? 'ไม่พบพาร์ติชั่นในไดเรกทอรี by-name' : 'No partitions found in by-name directory.';
                    listDiv.innerHTML = `<div style="grid-column: 1 / -1; text-align: center; color: var(--warning-color); padding: 10px;">${text}</div>`;
                    return;
                }

                // Render
                listDiv.innerHTML = '';
                adbDiscoveredPartitions.forEach((p, i) => {
                    const id = 'chk-adb-part-' + i;
                    listDiv.innerHTML += `
                        <label style="display: flex; align-items: center; gap: 8px; font-size: 13px; color: var(--text-light); cursor: pointer;">
                            <input type="checkbox" id="${id}" data-name="${p.name}" data-path="${p.path}" class="adb-part-chk"> 
                            ${p.name}
                        </label>
                    `;
                });
                
            } catch (err) {
                let errMsg = err.message || err;
                if (errMsg.includes('su: inaccessible or not found') || errMsg.includes('not found')) {
                    const text = currentLang === 'th' ? 'ข้อผิดพลาด: เครื่องยังไม่ได้ Root หรือไม่มีคำสั่ง su (su: inaccessible or not found)' : 'Error: Device is not Rooted or su binary is missing.';
                    listDiv.innerHTML = `<div style="grid-column: 1 / -1; text-align: center; color: var(--danger-color); padding: 10px;">${text}</div>`;
                } else {
                    listDiv.innerHTML = `<div style="grid-column: 1 / -1; text-align: center; color: var(--danger-color); padding: 10px;">Error: ${errMsg}</div>`;
                }
            }
        });

        document.getElementById('btn-adb-sel-all')?.addEventListener('click', () => {
            document.querySelectorAll('.adb-part-chk').forEach(c => c.checked = true);
        });
        document.getElementById('btn-adb-sel-none')?.addEventListener('click', () => {
            document.querySelectorAll('.adb-part-chk').forEach(c => c.checked = false);
        });

        document.getElementById('btn-adb-dump-now')?.addEventListener('click', async () => {
            const selected = [];
            document.querySelectorAll('.adb-part-chk:checked').forEach(c => {
                selected.push({ name: c.getAttribute('data-name'), path: c.getAttribute('data-path') });
            });
            
            if (selected.length === 0) {
                alert('Please select at least one partition to dump.');
                return;
            }
            
            const generateScatter = document.getElementById('chk-adb-scatter')?.checked;
            
            const saveDir = await window.api.showOpenDialog({ properties: ['openDirectory'], title: 'Select folder to save dump' });
            if (!saveDir) return;
            
            clearConsole();
            setConsoleStatus('Dumping Firmware via ADB...');
            window.api.send('adb-dump-partitions', { partitions: selected, saveDir, generateScatter });
        });
    }

    document.getElementById('btn-adb-list-apps').addEventListener('click', async () => {
        const tbody = document.getElementById('adb-apps-table-body');
        tbody.innerHTML = '<tr><td colspan="2" style="padding: 20px; text-align: center;">Scanning devices...</td></tr>';
        
        try {
            // Check if device is connected first
            const devices = await window.api.runAdbCommand("devices");
            if (!devices.includes("\tdevice")) {
                tbody.innerHTML = '<tr><td colspan="2" style="padding: 20px; text-align: center; color: var(--danger-color);">No ADB device connected. Make sure USB Debugging is ON.</td></tr>';
                return;
            }
            
            // Get third party apps or all apps
            const appsStr = await window.api.runAdbCommand("shell pm list packages -3"); // -3 for 3rd party
            if (appsStr) {
                installedApps = appsStr.split('\n').filter(line => line.includes('package:')).map(line => line.replace('package:', '').trim());
                installedApps.sort();
                renderAppsTable(installedApps);
            }
        } catch(err) {
            tbody.innerHTML = `<tr><td colspan="2" style="padding: 20px; text-align: center; color: var(--danger-color);">Error: ${err.message}</td></tr>`;
        }
    });

    function getFriendlyAppInfo(pkg) {
        const known = {
            'com.facebook.katana': { name: 'Facebook', icon: 'fab fa-facebook' },
            'com.facebook.orca': { name: 'Messenger', icon: 'fab fa-facebook-messenger' },
            'com.zhiliaoapp.musically': { name: 'TikTok', icon: 'fab fa-tiktok' },
            'com.google.android.youtube': { name: 'YouTube', icon: 'fab fa-youtube' },
            'com.android.vending': { name: 'Google Play Store', icon: 'fab fa-google-play' },
            'com.whatsapp': { name: 'WhatsApp', icon: 'fab fa-whatsapp' },
            'com.instagram.android': { name: 'Instagram', icon: 'fab fa-instagram' },
            'org.telegram.messenger': { name: 'Telegram', icon: 'fab fa-telegram' },
            'com.twitter.android': { name: 'Twitter / X', icon: 'fab fa-twitter' },
            'com.netflix.mediaclient': { name: 'Netflix', icon: 'fas fa-film' },
            'com.spotify.music': { name: 'Spotify', icon: 'fab fa-spotify' },
            'com.shopee.th': { name: 'Shopee', icon: 'fas fa-shopping-bag' },
            'com.lazada.android': { name: 'Lazada', icon: 'fas fa-shopping-cart' },
            'com.google.android.gm': { name: 'Gmail', icon: 'fas fa-envelope' },
            'com.google.android.apps.maps': { name: 'Google Maps', icon: 'fas fa-map-marker-alt' },
            'com.google.android.chrome': { name: 'Chrome Browser', icon: 'fab fa-chrome' }
        };
        
        if (known[pkg]) return known[pkg];
        
        let icon = 'fas fa-box';
        let name = pkg;
        
        if (pkg.includes('google')) icon = 'fab fa-google';
        else if (pkg.includes('samsung') || pkg.includes('sec')) icon = 'fas fa-mobile-alt';
        else if (pkg.includes('game')) icon = 'fas fa-gamepad';
        else if (pkg.includes('video') || pkg.includes('player') || pkg.includes('camera')) icon = 'fas fa-play-circle';
        
        const parts = pkg.split('.');
        if (parts.length >= 2) {
            let n = parts[parts.length - 1];
            if (n.length < 3 && parts.length > 2) n = parts[parts.length - 2] + ' ' + n;
            name = n.charAt(0).toUpperCase() + n.slice(1);
        }
        
        return { name, icon };
    }

    function renderAppsTable(apps) {
        const tbody = document.getElementById('adb-apps-table-body');
        tbody.innerHTML = '';
        if (apps.length === 0) {
            tbody.innerHTML = '<tr><td colspan="2" style="padding: 20px; text-align: center;">No third-party apps found.</td></tr>';
            return;
        }

        apps.forEach(pkg => {
            const tr = document.createElement('tr');
            tr.style.borderBottom = '1px solid rgba(255,255,255,0.1)';
            
            const tdName = document.createElement('td');
            tdName.style.padding = '10px';
            const info = getFriendlyAppInfo(pkg);
            tdName.innerHTML = `<i class="${info.icon}" style="margin-right:8px; color:var(--primary-color);"></i> <b>${info.name}</b> <br><small style="color:gray; font-size:10px;">${pkg}</small>`;
            
            const tdAction = document.createElement('td');
            tdAction.style.padding = '10px';
            tdAction.style.textAlign = 'center';
            
            const btnDel = document.createElement('button');
            btnDel.textContent = 'Delete';
            btnDel.className = 'action-btn warning-btn';
            btnDel.style.padding = '4px 8px';
            btnDel.style.fontSize = '11px';
            btnDel.onclick = async () => {
                const confirmed = await showCustomConfirm(`คุณต้องการบังคับลบแอปพลิเคชัน ${pkg} ใช่หรือไม่?\n\nการลบแอประบบอาจทำให้เครื่องทำงานผิดปกติได้`);
                if (confirmed) {
                    btnDel.disabled = true;
                    btnDel.textContent = '...';
                    try {
                        const res = await window.api.runAdbCommand(`shell pm uninstall -k --user 0 ${pkg}`);
                        if (res.includes('Success')) {
                            tr.style.opacity = '0.3';
                            btnDel.textContent = 'Done';
                        } else {
                            alert("Failed: " + res);
                            btnDel.disabled = false;
                            btnDel.textContent = 'Delete';
                        }
                    } catch(e) {
                        alert("Error: " + e.message);
                        btnDel.disabled = false;
                        btnDel.textContent = 'Delete';
                    }
                }
            };
            
            tdAction.appendChild(btnDel);
            tr.appendChild(tdName);
            tr.appendChild(tdAction);
            tbody.appendChild(tr);
        });
    }

    document.getElementById('adb-search-app').addEventListener('input', (e) => {
        const q = e.target.value.toLowerCase();
        if (!installedApps || installedApps.length === 0) return;
        const filtered = installedApps.filter(pkg => pkg.toLowerCase().includes(q));
        renderAppsTable(filtered);
    });

    // ========================================================
    // 📱 Enhanced Mobile Workstation Controllers
    // ========================================================
    function initEnhancedMobileTools() {
        // 1. Battery & Hardware Diagnostics
        const btnBatteryInfo = document.getElementById('btn-adb-battery-info');
        if (btnBatteryInfo) {
            btnBatteryInfo.addEventListener('click', async () => {
                btnBatteryInfo.disabled = true;
                btnBatteryInfo.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังตรวจสภาพแบตเตอรี่...';
                try {
                    const res = await window.api.getAndroidBatteryInfo();
                    const d = (res && res.data) ? res.data : (res && res.battery ? { ...res.battery, ...(res.device || {}) } : null);
                    
                    if (res && res.success && d) {
                        const levelEl = document.getElementById('adb-battery-level-val');
                        const barEl = document.getElementById('adb-battery-bar');
                        const healthEl = document.getElementById('adb-battery-health-val');
                        const tempEl = document.getElementById('adb-battery-temp-val');
                        const voltEl = document.getElementById('adb-battery-volt-val');
                        const sourceEl = document.getElementById('adb-battery-source-val');
                        const devEl = document.getElementById('adb-battery-dev-val');

                        if (levelEl) levelEl.textContent = `${d.level}%`;
                        if (barEl) barEl.style.width = `${Math.min(100, Math.max(0, d.level))}%`;
                        
                        if (healthEl) {
                            healthEl.textContent = d.health;
                            if (d.health && d.health.toLowerCase().includes('good')) {
                                healthEl.style.background = 'rgba(34, 197, 94, 0.2)';
                                healthEl.style.color = '#4ade80';
                            } else {
                                healthEl.style.background = 'rgba(239, 68, 68, 0.2)';
                                healthEl.style.color = '#f87171';
                            }
                        }
                        if (tempEl) tempEl.textContent = `${d.temperature} °C`;
                        if (voltEl) voltEl.textContent = `${d.voltage} V`;
                        if (sourceEl) sourceEl.textContent = d.source;
                        if (devEl) devEl.textContent = `${d.brand} ${d.model}`;

                        openModal('รายงานผลการตรวจแบตเตอรี่ & ฮาร์ดแวร์');
                        logToModal(`📱 อุปกรณ์: ${d.brand} ${d.model} (Android ${d.version})\n`);
                        logToModal(`🔋 ระดับแบตเตอรี่: ${d.level}%\n`);
                        logToModal(`🩺 สถานะความสมบูรณ์ (Health): ${d.health}\n`);
                        logToModal(`⚡ สถานะการทำงาน (Status): ${d.status}\n`);
                        logToModal(`🌡️ อุณหภูมิ: ${d.temperature} °C\n`);
                        logToModal(`⚡ แรงดันไฟ: ${d.voltage} V\n`);
                        logToModal(`🔌 แหล่งจ่ายไฟ: ${d.source}\n`);
                        logToModal(`🧪 เทคโนโลยีเซลล์: ${d.technology}\n`);
                        finishModal(true);
                    } else {
                        const errMsg = (res && res.error) ? res.error : 'ไม่พบอุปกรณ์ ADB หรืออุปกรณ์ยังไม่ได้เปิดโหมด USB Debugging';
                        openModal('รายงานผลการตรวจแบตเตอรี่ & ฮาร์ดแวร์');
                        logToModal(`[ERROR] ไม่สามารถตรวจค่าแบตเตอรี่ได้\n\n`, 'error');
                        logToModal(`รายละเอียดข้อผิดพลาด: ${errMsg}\n\n`);
                        logToModal(`💡 ขั้นตอนตรวจสอบ:\n`);
                        logToModal(`1. ตรวจสอบว่าเปิดโหมด "แก้จุดบกพร่อง USB" (USB Debugging) บนโทรศัพท์แล้วหรือยัง\n`);
                        logToModal(`2. ปลดล็อกหน้าจอโทรศัพท์ และกดยอมรับ "อนุญาตการดีบัก USB จากคอมพิวเตอร์เครื่องนี้เสมอ"\n`);
                        logToModal(`3. ลองถอดสาย USB แล้วเสียบใหม่ หรือเปลี่ยนพอร์ต USB\n`);
                        finishModal(false);
                    }
                } catch (e) {
                    openModal('รายงานผลการตรวจแบตเตอรี่ & ฮาร์ดแวร์');
                    logToModal(`[EXCEPTION] ${e.message}\n`, 'error');
                    finishModal(false);
                } finally {
                    btnBatteryInfo.disabled = false;
                    btnBatteryInfo.innerHTML = '<i class="fas fa-stethoscope"></i> ตรวจสุขภาพแบตเตอรี่ & ฮาร์ดแวร์';
                }
            });
        }

        // 2. 1-Click Screen Capture to PC
        const btnScreenshot = document.getElementById('btn-adb-screenshot');
        const resScreenshot = document.getElementById('adb-screenshot-result');
        if (btnScreenshot) {
            btnScreenshot.addEventListener('click', async () => {
                btnScreenshot.disabled = true;
                btnScreenshot.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังจับภาพหน้าจอ...';
                if (resScreenshot) resScreenshot.style.display = 'none';
                try {
                    const res = await window.api.captureAndroidScreenshot();
                    if (res && res.success) {
                        if (resScreenshot) {
                            resScreenshot.style.display = 'block';
                            resScreenshot.innerHTML = `
                                <span>📸 บันทึกภาพแล้ว: <b>${res.fileName}</b> (${(res.fileSize / 1024).toFixed(1)} KB)</span>
                                <button id="btn-open-sc-dir" style="margin-left: 8px; padding: 2px 8px; font-size: 11px; background: rgba(56, 189, 248, 0.2); border: 1px solid #38bdf8; color: #38bdf8; border-radius: 4px; cursor: pointer;">เปิดโฟลเดอร์รูป</button>
                            `;
                            const btnOpenDir = document.getElementById('btn-open-sc-dir');
                            if (btnOpenDir) {
                                btnOpenDir.addEventListener('click', () => {
                                    window.api.openFileLocation(res.filePath);
                                });
                            }
                        }
                    } else {
                        alert(`ไม่สามารถถ่ายภาพหน้าจอได้: ${res ? res.error : 'ADB Connection Error'}`);
                    }
                } catch (e) {
                    alert(`เกิดข้อผิดพลาด: ${e.message}`);
                } finally {
                    btnScreenshot.disabled = false;
                    btnScreenshot.innerHTML = '<i class="fas fa-camera"></i> ถ่ายภาพหน้าจอบันทึกลง PC';
                }
            });
        }

        // 3. Wireless ADB & TCP/IP
        const btnWireless = document.getElementById('btn-adb-wireless');
        const inputWirelessIp = document.getElementById('adb-wireless-ip');
        const statusWireless = document.getElementById('adb-wireless-status');
        if (btnWireless) {
            btnWireless.addEventListener('click', async () => {
                btnWireless.disabled = true;
                btnWireless.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังเปิดโหมดไร้สาย...';
                if (statusWireless) statusWireless.style.display = 'none';
                try {
                    const customIp = inputWirelessIp ? inputWirelessIp.value.trim() : null;
                    const res = await window.api.enableWirelessAdb(customIp || null);
                    if (statusWireless) {
                        statusWireless.style.display = 'block';
                        if (res && res.success) {
                            statusWireless.style.background = 'rgba(34, 197, 94, 0.15)';
                            statusWireless.style.color = '#4ade80';
                            statusWireless.innerHTML = `<i class="fas fa-check-circle"></i> ${res.message} (IP: ${res.deviceIp}:5555)`;
                        } else {
                            statusWireless.style.background = 'rgba(239, 68, 68, 0.15)';
                            statusWireless.style.color = '#f87171';
                            statusWireless.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${res ? (res.error || res.message) : 'เกิดข้อผิดพลาด'}`;
                        }
                    }
                } catch (e) {
                    if (statusWireless) {
                        statusWireless.style.display = 'block';
                        statusWireless.style.background = 'rgba(239, 68, 68, 0.15)';
                        statusWireless.style.color = '#f87171';
                        statusWireless.innerHTML = `<i class="fas fa-exclamation-circle"></i> Error: ${e.message}`;
                    }
                } finally {
                    btnWireless.disabled = false;
                    btnWireless.innerHTML = '<i class="fas fa-network-wired"></i> เปิดโหมดไร้สาย & เชื่อมต่อ IP';
                }
            });
        }

        // 4. Reboot Modes (Samsung Download, Sideload, Normal)
        const btnRebootSam = document.getElementById('btn-adb-reboot-sam');
        if (btnRebootSam) {
            btnRebootSam.addEventListener('click', async () => {
                openModal('ADB: Reboot Samsung Odin Mode');
                logToModal('> กำลังส่งคำสั่งรีบูตเข้า Samsung Download / Odin Mode...\n');
                try {
                    const res = await window.api.rebootAndroidMode('download');
                    if (res && res.success) {
                        logToModal(`\n[SUCCESS] ${res.output || 'รีบูตเข้า Samsung Odin Mode สำเร็จ'}\n`, 'success');
                        finishModal(true);
                    } else {
                        logToModal(`\n[ERROR] ${res ? (res.error || res.output) : 'ล้มเหลว'}\n`, 'error');
                        finishModal(false);
                    }
                } catch (e) {
                    logToModal(`\n[ERROR] ${e.message}\n`, 'error');
                    finishModal(false);
                }
            });
        }

        const btnRebootSideload = document.getElementById('btn-adb-reboot-sideload');
        if (btnRebootSideload) {
            btnRebootSideload.addEventListener('click', async () => {
                openModal('ADB: Reboot Sideload Mode');
                logToModal('> กำลังส่งคำสั่งรีบูตเข้า Recovery Sideload Mode...\n');
                try {
                    const res = await window.api.rebootAndroidMode('sideload');
                    if (res && res.success) {
                        logToModal(`\n[SUCCESS] ${res.output || 'รีบูตเข้า Sideload สำเร็จ'}\n`, 'success');
                        finishModal(true);
                    } else {
                        logToModal(`\n[ERROR] ${res ? (res.error || res.output) : 'ล้มเหลว'}\n`, 'error');
                        finishModal(false);
                    }
                } catch (e) {
                    logToModal(`\n[ERROR] ${e.message}\n`, 'error');
                    finishModal(false);
                }
            });
        }

        const btnRebootNormal = document.getElementById('btn-adb-reboot-normal');
        if (btnRebootNormal) {
            btnRebootNormal.addEventListener('click', async () => {
                openModal('ADB: Reboot Normal System');
                logToModal('> กำลังส่งคำสั่งรีบูตเข้าระบบปกติ (System)...\n');
                try {
                    const res = await window.api.rebootAndroidMode('normal');
                    if (res && res.success) {
                        logToModal(`\n[SUCCESS] ${res.output || 'รีบูตระบบสำเร็จ'}\n`, 'success');
                        finishModal(true);
                    } else {
                        logToModal(`\n[ERROR] ${res ? (res.error || res.output) : 'ล้มเหลว'}\n`, 'error');
                        finishModal(false);
                    }
                } catch (e) {
                    logToModal(`\n[ERROR] ${e.message}\n`, 'error');
                    finishModal(false);
                }
            });
        }

        // 5. Proxy Manager
        const btnSetProxy = document.getElementById('btn-adb-set-proxy');
        const btnClearProxy = document.getElementById('btn-adb-clear-proxy');
        const inputProxyHost = document.getElementById('adb-proxy-host');
        const inputProxyPort = document.getElementById('adb-proxy-port');
        const statusProxy = document.getElementById('adb-proxy-status');

        if (btnSetProxy) {
            btnSetProxy.addEventListener('click', async () => {
                const host = inputProxyHost ? inputProxyHost.value.trim() : '';
                const port = inputProxyPort ? inputProxyPort.value.trim() : '8080';
                if (!host) {
                    alert('กรุณากรอก Proxy Host หรือ IP');
                    return;
                }
                btnSetProxy.disabled = true;
                try {
                    const res = await window.api.setAndroidProxy(host, port);
                    if (statusProxy) {
                        statusProxy.style.display = 'block';
                        if (res && res.success) {
                            statusProxy.style.background = 'rgba(34, 197, 94, 0.15)';
                            statusProxy.style.color = '#4ade80';
                            statusProxy.innerHTML = `<i class="fas fa-check-circle"></i> ตั้ง Proxy สำเร็จ: ${host}:${port}`;
                        } else {
                            statusProxy.style.background = 'rgba(239, 68, 68, 0.15)';
                            statusProxy.style.color = '#f87171';
                            statusProxy.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${res ? res.error : 'ล้มเหลว'}`;
                        }
                    }
                } catch (e) {
                    alert(`Error: ${e.message}`);
                } finally {
                    btnSetProxy.disabled = false;
                }
            });
        }

        if (btnClearProxy) {
            btnClearProxy.addEventListener('click', async () => {
                btnClearProxy.disabled = true;
                try {
                    const res = await window.api.clearAndroidProxy();
                    if (statusProxy) {
                        statusProxy.style.display = 'block';
                        if (res && res.success) {
                            if (inputProxyHost) inputProxyHost.value = '';
                            if (inputProxyPort) inputProxyPort.value = '';
                            statusProxy.style.background = 'rgba(56, 189, 248, 0.15)';
                            statusProxy.style.color = '#38bdf8';
                            statusProxy.innerHTML = `<i class="fas fa-info-circle"></i> ล้างค่า Proxy เรียบร้อย (Direct Connection)`;
                        } else {
                            statusProxy.style.background = 'rgba(239, 68, 68, 0.15)';
                            statusProxy.style.color = '#f87171';
                            statusProxy.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${res ? res.error : 'ล้มเหลว'}`;
                        }
                    }
                } catch (e) {
                    alert(`Error: ${e.message}`);
                } finally {
                    btnClearProxy.disabled = false;
                }
            });
        }

        // 6. Quick ADB Terminal & Preset Chips
        const inputQuickCmd = document.getElementById('adb-quick-cmd');
        const btnRunQuick = document.getElementById('btn-adb-run-quick');
        const outQuick = document.getElementById('adb-quick-output');
        const presetChips = document.querySelectorAll('.adb-preset-chip');

        presetChips.forEach(chip => {
            chip.addEventListener('click', () => {
                const cmd = chip.getAttribute('data-cmd');
                if (inputQuickCmd) {
                    inputQuickCmd.value = cmd;
                    if (btnRunQuick) btnRunQuick.click();
                }
            });
        });

        if (btnRunQuick) {
            btnRunQuick.addEventListener('click', async () => {
                const rawCmd = inputQuickCmd ? inputQuickCmd.value.trim() : '';
                if (!rawCmd) {
                    alert('กรุณาพิมพ์คำสั่ง ADB');
                    return;
                }
                btnRunQuick.disabled = true;
                if (outQuick) {
                    outQuick.style.display = 'block';
                    outQuick.textContent = `> adb ${rawCmd}\n[Running...]`;
                }
                try {
                    const cleanCmd = rawCmd.startsWith('adb ') ? rawCmd.slice(4).trim() : rawCmd;
                    const res = await window.api.runAdbCommand(cleanCmd);
                    if (outQuick) {
                        outQuick.textContent = `> adb ${cleanCmd}\n\n${res || '(No output returned)'}`;
                    }
                } catch (e) {
                    if (outQuick) {
                        outQuick.textContent = `> adb ${rawCmd}\n\n[ERROR] ${e.message || e}`;
                    }
                } finally {
                    btnRunQuick.disabled = false;
                }
            });
        }

        // 7. Zadig & Platform Tools Launchers
        const btnZadig = document.getElementById('btn-open-zadig');
        if (btnZadig) {
            btnZadig.addEventListener('click', () => {
                window.api.openZadig();
            });
        }

        const btnPtCmd = document.getElementById('btn-open-pt-cmd');
        if (btnPtCmd) {
            btnPtCmd.addEventListener('click', async () => {
                try {
                    await window.api.openPlatformToolsCmd();
                } catch(e) {
                    alert(`ไม่สามารถเปิด CMD ได้: ${e.message}`);
                }
            });
        }
    }

    initEnhancedMobileTools();

    // Helper functions for Service and Security buttons
    let spdSelectedComPort = null;
    let spdSelectedPacPath = null;

    function bindQcomAction(id, cmdName) {
        const btn = document.getElementById(id);
        if (!btn) return;
        btn.addEventListener('click', async () => {
            openModal(`Qualcomm (EDL): ${cmdName.toUpperCase()}`);
            logToModal(`> Running QCOM EDL: ${cmdName}...\n`);
            if (qcomSelectedComPort) {
                logToModal(`> Selected Port: ${qcomSelectedComPort}\n`);
            } else {
                logToModal(`> 🔌 Auto-detecting Qualcomm HS-USB QDLoader 9008...\n`);
            }
            logToModal('> 💡 วิธีเข้า EDL 9008: ปิดเครื่องให้ดับสนิท -> กดปุ่ม Vol Up (+) และ Vol Down (-) ค้างไว้ -> เสียบสาย USB\n\n');
            
            try {
                const res = await window.api.runQcomService(cmdName, qcomSelectedComPort, qcomSelectedProgrammer);
                logToModal(`\n${res}\n`, 'success');
                finishModal(true);
            } catch (err) {
                logToModal(`\n[ERROR] ${err.message || err}\n`, 'error');
                finishModal(false);
            }
        });
    }

    function bindMtkAction(id, cmdName) {
        const btn = document.getElementById(id);
        if (!btn) return;
        btn.addEventListener('click', async () => {
            openModal(`MediaTek (MTK): ${cmdName.toUpperCase()}`);
            logToModal(`> Running MTK Service: ${cmdName}...\n`);
            logToModal('> 💡 วิธีเชื่อมต่อ MTK: ปิดเครื่องให้ดับสนิท -> กดปุ่ม Vol Up (+) และ Vol Down (-) ค้างไว้ -> เสียบสาย USB\n\n');
            
            try {
                const res = await window.api.runMtkService(cmdName, mtkMode, mtkSelectedDa, mtkSelectedPreloader);
                logToModal(`\n${res}\n`, 'success');
                finishModal(true);
            } catch (err) {
                logToModal(`\n[ERROR] ${err.message || err}\n`, 'error');
                finishModal(false);
            }
        });
    }

    function bindSpdAction(id, cmdName) {
        const btn = document.getElementById(id);
        if (!btn) return;
        btn.addEventListener('click', async () => {
            openModal(`Unisoc (SPD): ${cmdName.toUpperCase()}`);
            logToModal(`> Running Unisoc / SPD Service: ${cmdName}...\n`);
            logToModal('> 💡 วิธีเชื่อมต่อ Unisoc: ปิดเครื่องให้ดับสนิท -> กด Boot Key (Vol Down หรือ Vol Up) -> เสียบสาย USB\n\n');
            
            try {
                const res = await window.api.runSpdService(cmdName, spdSelectedComPort, spdSelectedPacPath);
                logToModal(`\n${res}\n`, 'success');
                finishModal(true);
            } catch (err) {
                logToModal(`\n[ERROR] ${err.message || err}\n`, 'error');
                finishModal(false);
            }
        });
    }

    // Bind Qualcomm buttons
    bindQcomAction('btn-qcom-readinfo', 'readinfo');
    bindQcomAction('btn-qcom-dump', 'dump');
    bindQcomAction('btn-qcom-erasefrp', 'erasefrp');
    bindQcomAction('btn-qcom-factory', 'factory');
    bindQcomAction('btn-qcom-micloud', 'micloud');
    bindQcomAction('btn-qcom-backupefs', 'backupefs');
    bindQcomAction('btn-qcom-restoreefs', 'restoreefs');
    bindQcomAction('btn-qcom-eraseefs', 'eraseefs');

    // Bind MediaTek buttons
    bindMtkAction('btn-mtk-readinfo', 'readinfo');
    bindMtkAction('btn-mtk-wipedata', 'wipedata');
    bindMtkAction('btn-mtk-format', 'format');
    bindMtkAction('btn-mtk-dump', 'dump');
    bindMtkAction('btn-mtk-erasefrp', 'erasefrp');
    bindMtkAction('btn-mtk-factory', 'factory');
    bindMtkAction('btn-mtk-unlockbl', 'unlockbl');
    bindMtkAction('btn-mtk-backupnv', 'backupnv');
    bindMtkAction('btn-mtk-restorenv', 'restorenv');
    bindMtkAction('btn-mtk-erasenv', 'erasenv');

    // Bind Unisoc/Spreadtrum buttons
    bindSpdAction('btn-spd-readinfo', 'readinfo');
    bindSpdAction('btn-spd-format', 'format');
    bindSpdAction('btn-spd-factory', 'factory');
    bindSpdAction('btn-spd-erasefrp', 'erasefrp');

    // SPD PAC Browser
    document.getElementById('btn-spd-browse-pac').addEventListener('click', async () => {
        const filePath = await window.api.showOpenDialog({ filters: [{ name: 'PAC Files', extensions: ['pac'] }] });
        if (filePath) {
            spdSelectedPacPath = filePath;
            document.getElementById('spd-pac-file-path').textContent = filePath;
            
            // Trigger PAC Parsing
            const container = document.getElementById('spd-partitions-container');
            const list = document.getElementById('spd-partitions-list');
            if (container && list) {
                list.innerHTML = '<div style="color:#aaa; font-size:12px; text-align:center;">Parsing PAC file...</div>';
                container.style.display = 'block';
                
                try {
                    const res = await window.api.parsePacFile(filePath);
                    if (res && res.success && res.partitions && res.partitions.length > 0) {
                        let html = '';
                        res.partitions.forEach(p => {
                            const isCore = ['fdl1','fdl2','nvitem','prodnv','uboot','bootloader','sml','smlboot','fdl'].includes(p.name.toLowerCase());
                            const sizeMb = p.size > 0
                                ? (p.size >= 1048576 ? (p.size / 1048576).toFixed(2) + ' MB'
                                    : (p.size >= 1024 ? (p.size / 1024).toFixed(1) + ' KB' : p.size + ' B'))
                                : (p.has_file ? '🗑 Erase' : 'Op only');
                            const color = isCore ? '#ff8a80' : (p.has_file ? '#e0e0e0' : '#888');
                            const bg = isCore ? 'background:rgba(255,100,100,0.1);' : '';
                            html += `
                                <label style="display:flex;justify-content:space-between;align-items:center;padding:5px 6px;border-radius:4px;cursor:pointer;${bg}">
                                    <div style="display:flex;gap:8px;align-items:center;">
                                        <input type="checkbox" class="spd-part-cb" value="${p.name}" ${isCore ? 'checked disabled' : (p.has_file ? 'checked' : '')} style="accent-color:var(--primary-color);">
                                        <span style="font-size:12px;color:${color};font-weight:${isCore?'600':'400'};">${p.name}</span>
                                    </div>
                                    <span style="font-size:10px;color:var(--text-muted);max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${p.file}">${p.file} (${sizeMb})</span>
                                </label>
                            `;
                        });
                        list.innerHTML = `<div style="font-size:10px;color:#aaa;margin-bottom:8px;padding-bottom:6px;border-bottom:1px solid rgba(255,255,255,0.08);">📦 ${res.firmware || res.product || 'PAC Firmware'} — ${res.partitions.length} partitions</div>` + html;

                        const checkAll = document.getElementById('spd-check-all');
                        if (checkAll) {
                            checkAll.onchange = (e) => {
                                document.querySelectorAll('.spd-part-cb:not(:disabled)').forEach(cb => cb.checked = e.target.checked);
                            };
                        }
                    } else {
                        const errMsg = (res && res.error) ? res.error : 'Unknown error or empty partition list';
                        list.innerHTML = `<div style="color:#ff8a80;font-size:12px;text-align:center;">❌ Failed to parse PAC:<br><small style="color:#aaa;">${errMsg}</small></div>`;
                    }
                } catch(e) {
                    list.innerHTML = `<div style="color:#ff8a80;font-size:12px;text-align:center;">❌ Error: ${e.message || e}</div>`;
                }
            }
        }
    });

    const spdFlashBtn = document.getElementById('btn-spd-flash');
    if (spdFlashBtn) {
        spdFlashBtn.addEventListener('click', async () => {
            const pacPath = document.getElementById('spd-pac-file-path')?.textContent;
            if (!pacPath || pacPath === 'No file selected') {
                alert("Please select a .pac file first.");
                return;
            }
            
            openModal('Unisoc / SPD: Flash Firmware (PAC)');
            logToModal(`> Starting SPD Firmware Flash: ${pacPath}\n`);
            if (spdSelectedComPort) {
                logToModal(`> Selected Port: ${spdSelectedComPort}\n`);
            }
            logToModal('> 💡 วิธีเชื่อมต่อ: ปิดเครื่องให้ดับสนิท -> กดปุ่ม Boot Key (Vol Down หรือ Vol Up) -> เสียบสาย USB\n\n');
            
            try {
                const res = await window.api.runSpdService('flash', spdSelectedComPort, pacPath);
                logToModal(`\n${res}\n`, 'success');
                finishModal(true);
            } catch (err) {
                logToModal(`\n[ERROR] ${err.message || err}\n`, 'error');
                finishModal(false);
            }
        });
    }

    // SPD Scan Ports listener
    const btnSpdScanPorts = document.getElementById('btn-spd-scan-ports');
    const spdPortSelect = document.getElementById('spd-port-select');
    if (btnSpdScanPorts && spdPortSelect) {
        btnSpdScanPorts.addEventListener('click', async () => {
            btnSpdScanPorts.disabled = true;
            btnSpdScanPorts.textContent = "Scanning...";
            spdPortSelect.innerHTML = '<option value="" disabled selected>Scanning...</option>';
            try {
                const ports = await window.api.scanComPorts();
                spdPortSelect.innerHTML = '';
                if (ports && ports.length > 0) {
                    let bestPort = null;
                    ports.forEach(port => {
                        const opt = document.createElement('option');
                        const portVal = typeof port === 'object' ? port.port : port;
                        const portDesc = typeof port === 'object' ? (port.description || '') : '';
                        const isSpd = typeof port === 'object' ? (/SPRD|Sci|Unisoc/i.test(portDesc)) : /SPRD|Sci|Unisoc/i.test(port);
                        opt.value = portVal;
                        opt.textContent = portDesc ? `${portVal} (${portDesc})` : portVal;
                        if (isSpd && !bestPort) {
                            opt.selected = true;
                            bestPort = portVal;
                        }
                        spdPortSelect.appendChild(opt);
                    });
                    spdSelectedComPort = bestPort || (typeof ports[0] === 'object' ? ports[0].port : ports[0]);
                } else {
                    spdPortSelect.innerHTML = '<option value="" disabled selected>No devices found</option>';
                    spdSelectedComPort = null;
                }
            } catch (e) {
                spdPortSelect.innerHTML = '<option value="" disabled selected>No devices found</option>';
                spdSelectedComPort = null;
            } finally {
                btnSpdScanPorts.disabled = false;
                btnSpdScanPorts.textContent = "Scan Ports";
            }
        });

        spdPortSelect.addEventListener('change', (e) => {
            spdSelectedComPort = e.target.value;
        });
    }

    // ==========================================
    // FLASHER SUITE DATABASE INITIALIZATION
    // Categorized by Brand, Model, & Chipset (CS-Tool Suite)
    // ==========================================
    async function initFlasherSuiteDatabase() {
        if (!window.api || !window.api.getFlasherDatabase) return;
        try {
            const db = await window.api.getFlasherDatabase();
            if (!db) return;

            // --- 1. Qualcomm Brand & Model Cascading Selectors ---
            const qcomBrandSelect = document.getElementById('qcom-brand-select');
            const qcomModelSelect = document.getElementById('qcom-model-select');
            const qcomBadge = document.getElementById('qcom-selected-prog-badge');

            if (qcomBrandSelect && qcomModelSelect && db.qualcomm) {
                qcomBrandSelect.innerHTML = '';
                db.qualcomm.brands.forEach(b => {
                    const opt = document.createElement('option');
                    opt.value = b.id;
                    opt.textContent = b.name;
                    qcomBrandSelect.appendChild(opt);
                });

                function updateQcomModels(brandId) {
                    qcomModelSelect.innerHTML = '';
                    const models = (db.qualcomm.models && db.qualcomm.models[brandId]) || [];
                    models.forEach(m => {
                        const opt = document.createElement('option');
                        opt.value = m.fullPath || '';
                        opt.textContent = m.name;
                        qcomModelSelect.appendChild(opt);
                    });

                    const selectedPath = qcomModelSelect.value;
                    qcomSelectedProgrammer = selectedPath || null;
                    if (qcomBadge) {
                        if (selectedPath) {
                            const selText = qcomModelSelect.options[qcomModelSelect.selectedIndex]?.text || '';
                            qcomBadge.textContent = `✓ ${selText}`;
                        } else {
                            qcomBadge.textContent = '⚡ ตรวจจับชิปอัตโนมัติ';
                        }
                    }
                }

                qcomBrandSelect.addEventListener('change', () => {
                    updateQcomModels(qcomBrandSelect.value);
                });

                qcomModelSelect.addEventListener('change', () => {
                    const selectedPath = qcomModelSelect.value;
                    qcomSelectedProgrammer = selectedPath || null;
                    if (qcomBadge) {
                        if (selectedPath) {
                            const selText = qcomModelSelect.options[qcomModelSelect.selectedIndex]?.text || '';
                            qcomBadge.textContent = `✓ ${selText}`;
                        } else {
                            qcomBadge.textContent = '⚡ ตรวจจับชิปอัตโนมัติ';
                        }
                    }
                });

                // Initialize with Auto
                updateQcomModels('auto');
            }

            // External Browse button for Qualcomm Programmer
            const btnQcomBrowseProg = document.getElementById('btn-qcom-browse-prog');
            if (btnQcomBrowseProg) {
                btnQcomBrowseProg.addEventListener('click', async () => {
                    const filePath = await window.api.browseProgrammerFile();
                    if (filePath) {
                        qcomSelectedProgrammer = filePath;
                        const baseName = filePath.split(/[/\\]/).pop();
                        if (qcomBadge) {
                            qcomBadge.textContent = `📁 กำหนดเอง: ${baseName}`;
                        }
                        if (qcomModelSelect) {
                            let customOpt = document.getElementById('qcom-custom-loader-opt');
                            if (!customOpt) {
                                customOpt = document.createElement('option');
                                customOpt.id = 'qcom-custom-loader-opt';
                                qcomModelSelect.insertBefore(customOpt, qcomModelSelect.firstChild);
                            }
                            customOpt.value = filePath;
                            customOpt.textContent = `📁 กำหนดเอง: ${baseName}`;
                            customOpt.selected = true;
                        }
                    }
                });
            }

            // --- 2. MediaTek Brand & CPU/Tools Selectors ---
            const mtkBrandSelect = document.getElementById('mtk-brand-select');
            const mtkCpuSelect = document.getElementById('mtk-cpu-select');
            const chkMtkPreloader = document.getElementById('chk-custom-preloader');
            const mtkPreloaderPathLabel = document.getElementById('mtk-preloader-file-path');
            const btnMtkBrowsePreloader = document.getElementById('btn-mtk-browse-preloader');

            if (mtkBrandSelect && db.mediatek && db.mediatek.brands) {
                mtkBrandSelect.innerHTML = '';
                db.mediatek.brands.forEach(b => {
                    const opt = document.createElement('option');
                    opt.value = b.id;
                    opt.textContent = b.name;
                    mtkBrandSelect.appendChild(opt);
                });
            }

            if (mtkCpuSelect && db.mediatek && db.mediatek.cpus) {
                mtkCpuSelect.innerHTML = '';
                db.mediatek.cpus.forEach(c => {
                    const opt = document.createElement('option');
                    opt.value = c.id;
                    opt.textContent = c.name;
                    if (c.emiPath) opt.dataset.emiPath = c.emiPath;
                    if (c.emi) opt.dataset.emi = c.emi;
                    mtkCpuSelect.appendChild(opt);
                });

                mtkCpuSelect.addEventListener('change', () => {
                    const selectedOpt = mtkCpuSelect.options[mtkCpuSelect.selectedIndex];
                    const emiPath = selectedOpt ? selectedOpt.dataset.emiPath : null;
                    const emiName = selectedOpt ? selectedOpt.dataset.emi : null;

                    if (emiPath) {
                        mtkSelectedPreloader = emiPath;
                        if (chkMtkPreloader) chkMtkPreloader.checked = true;
                        if (mtkPreloaderPathLabel) {
                            mtkPreloaderPathLabel.textContent = `✓ EMI: ${emiName}`;
                            mtkPreloaderPathLabel.title = emiName;
                        }
                        if (btnMtkBrowsePreloader) btnMtkBrowsePreloader.disabled = false;
                    } else if (chkMtkPreloader && !chkMtkPreloader.checked) {
                        mtkSelectedPreloader = null;
                        if (mtkPreloaderPathLabel) mtkPreloaderPathLabel.textContent = 'Not Selected';
                    }
                });
            }

            // --- 3. Unisoc / Spreadtrum Boots Selector ---
            const spdBootsSelect = document.getElementById('spd-boots-select');
            const spdBootStatus = document.getElementById('spd-boot-status');
            if (spdBootsSelect && db.unisoc && db.unisoc.boots) {
                spdBootsSelect.innerHTML = '';
                db.unisoc.boots.forEach(b => {
                    const opt = document.createElement('option');
                    opt.value = b.id;
                    opt.textContent = b.name;
                    spdBootsSelect.appendChild(opt);
                });

                spdBootsSelect.addEventListener('change', () => {
                    const selId = spdBootsSelect.value;
                    if (spdBootStatus) {
                        if (selId === 'auto') {
                            spdBootStatus.innerHTML = '<i class="fas fa-microchip"></i> FDL Bootloader: ตรวจจับอัตโนมัติ (92 ตัวในคลัง)';
                        } else {
                            const selText = spdBootsSelect.options[spdBootsSelect.selectedIndex]?.text || selId;
                            spdBootStatus.innerHTML = `<i class="fas fa-check-circle" style="color:#4caf50;"></i> พร้อมเชื่อมต่อ: ${selText}`;
                        }
                    }
                });
            }
        } catch (err) {
            console.warn('Failed to load flasher database:', err);
        }
    }

    initFlasherSuiteDatabase();


// Custom Dropdown Logic (ROOT section)
(function initCustomDropdowns() {
    function setupDropdown(triggerId, dropdownId, hiddenId) {
        const trigger = document.getElementById(triggerId);
        const dropdown = document.getElementById(dropdownId);
        const hidden = document.getElementById(hiddenId);
        if (!trigger || !dropdown || !hidden) return;

        trigger.addEventListener('click', (e) => {
            e.stopPropagation();
            const isOpen = dropdown.style.display !== 'none';
            // Close all dropdowns first
            document.querySelectorAll('.custom-select-dropdown').forEach(d => d.style.display = 'none');
            dropdown.style.display = isOpen ? 'none' : 'block';
        });

        dropdown.querySelectorAll('.csd-option').forEach(opt => {
            opt.addEventListener('click', () => {
                const val = opt.dataset.value;
                const label = opt.textContent.trim();
                trigger.childNodes[0].textContent = label + ' ';
                trigger.dataset.value = val;
                hidden.value = val;
                dropdown.style.display = 'none';
                // Highlight selected
                dropdown.querySelectorAll('.csd-option').forEach(o => o.classList.remove('selected'));
                opt.classList.add('selected');
            });
        });
    }

    setupDropdown('root-brand-trigger', 'root-brand-dropdown', 'root-brand-select');
    setupDropdown('root-method-trigger', 'root-method-dropdown', 'root-method-select');

    // Close dropdowns when clicking outside
    document.addEventListener('click', () => {
        document.querySelectorAll('.custom-select-dropdown').forEach(d => d.style.display = 'none');
    });
})();


// ============================================================
// ROOT TOOL LOGIC
// ============================================================
(function() {

    // --- helpers ---
    function rootLog(msg, color) {
        if (currentLang === 'th') {
            const thLogs = {
                '> Scanning ADB devices...': '> กำลังค้นหาอุปกรณ์ ADB...',
                'No device found. Enable USB debugging.': 'ไม่พบอุปกรณ์ กรุณาเปิดโหมดแก้จุดบกพร่อง USB',
                '⚡ Starting One-Click ROOT process...': '⚡ เริ่มกระบวนการรูท (One-Click ROOT)...',
                '✅ ADB connected': '✅ เชื่อมต่อ ADB สำเร็จ',
                '⚠️ Bootloader is LOCKED. Attempting Auto-Unlock...': '⚠️ บูตโหลดเดอร์ล็อคอยู่ กำลังพยายามปลดล็อคอัตโนมัติ...',
                '⚠️ Samsung devices cannot be unlocked automatically via Fastboot.': '⚠️ อุปกรณ์ Samsung ไม่สามารถปลดล็อคอัตโนมัติผ่าน Fastboot ได้',
                'Please power off, hold Vol UP + Vol DOWN, plug in USB, and long-press Vol UP to unlock.': 'กรุณาปิดเครื่อง กดปุ่มเพิ่มเสียง+ลดเสียงค้างไว้ แล้วเสียบสาย USB จากนั้นกดปุ่มเพิ่มเสียงค้างเพื่อปลดล็อค',
                '> Sending unlock command...': '> กำลังส่งคำสั่งปลดล็อค...',
                '❌ Bootloader unlock cancelled by user.': '❌ ยกเลิกการปลดล็อคบูตโหลดเดอร์โดยผู้ใช้',
                '> Waiting for device to boot up and reconnect to ADB...': '> กำลังรอเครื่องเปิดและเชื่อมต่อ ADB กลับมาอีกครั้ง...',
                '❌ Device did not reconnect to ADB after unlock.': '❌ เครื่องไม่เชื่อมต่อ ADB กลับมาหลังจากปลดล็อค',
                '✅ Bootloader Unlocked & Device Reconnected': '✅ ปลดล็อคบูตโหลดเดอร์และเชื่อมต่อกลับสำเร็จ',
                '✅ Bootloader: Already Unlocked': '✅ บูตโหลดเดอร์: ปลดล็อคอยู่แล้ว',
                '✅ Magisk pushed to /data/local/tmp/': '✅ ส่งไฟล์ Magisk ไปที่ /data/local/tmp/ สำเร็จ',
                '   Make sure Magisk.apk is in bin\\magisk\\ folder': '   ตรวจสอบให้แน่ใจว่ามีไฟล์ Magisk.apk ในโฟลเดอร์ bin\\magisk\\',
                '✅ boot.img pulled successfully': '✅ ดึงไฟล์ boot.img สำเร็จ',
                '   Device may not be rooted yet - manual step needed': '   เครื่องอาจจะยังไม่รูท - ต้องทำบางขั้นตอนด้วยตนเอง',
                '✅ boot.img patched': '✅ แพตช์ไฟล์ boot.img สำเร็จ',
                '⚠️ Patching via device skipped - using local magiskboot': '⚠️ ข้ามการแพตช์ผ่านมือถือ - ใช้ magiskboot ในคอมแทน',
                '✅ Patched boot flashed!': '✅ แฟลชไฟล์ Boot ที่แพตช์แล้วสำเร็จ!',
                '🎉 Device successfully ROOTED with Magisk!': '🎉 รูทเครื่องด้วย Magisk สำเร็จแล้ว!',
                '   Open Magisk app on your device to verify.': '   เปิดแอป Magisk ในมือถือเพื่อตรวจสอบความเรียบร้อย',
                'Device rebooting - check Magisk app to verify root.': 'เครื่องกำลังรีบูต - ตรวจสอบแอป Magisk เพื่อยืนยันการรูท'
            };
            
            if (msg.startsWith('📱 Device:')) msg = msg.replace('📱 Device:', '📱 อุปกรณ์:');
            else if (msg.startsWith('Error:')) msg = msg.replace('Error:', '❌ ข้อผิดพลาด:');
            else if (msg.startsWith('❌ Error:')) msg = msg.replace('❌ Error:', '❌ ข้อผิดพลาด:');
            else if (msg.startsWith('⚠️ Could not verify bootloader state:')) msg = msg.replace('⚠️ Could not verify bootloader state:', '⚠️ ไม่สามารถตรวจสอบสถานะบูตโหลดเดอร์ได้:');
            else if (thLogs[msg]) msg = thLogs[msg];
            
            // Also handle any string with emoji already mapped if they were missing emoji in mapping
            let cleanMsg = msg;
            // The logs in code use emojis directly like '✅ ADB connected' so the mapping above has them.
        }
        
        const log = document.getElementById('root-log');
        if (!log) return;
        const d = document.createElement('div');
        d.style.cssText = `color:${color || '#ccc'};margin-bottom:2px;`;
        d.textContent = msg;
        log.appendChild(d);
        log.scrollTop = log.scrollHeight;
    }

    function setProgress(pct, stepLabel) {
        const bar = document.getElementById('root-progress-bar');
        const pctEl = document.getElementById('root-progress-pct');
        const stepEl = document.getElementById('root-step-label');
        if (bar) bar.style.width = pct + '%';
        if (pctEl) pctEl.textContent = pct + '%';
        if (stepEl && stepLabel) stepEl.textContent = stepLabel;
    }

    function setStep(num, status) {
        // status: 'done'|'active'|'error'
        const el = document.querySelector(`.root-step[data-step="${num}"]`);
        if (!el) return;
        const icons = { done: '✅', active: '🔄', error: '❌', pending: '⬜' };
        el.querySelector('.step-icon').textContent = icons[status] || '⬜';
        el.style.color = { done: '#69f0ae', active: '#fff', error: '#ff5252', pending: '#777' }[status] || '#777';
        el.style.background = { done: 'rgba(105,240,174,0.08)', active: 'rgba(255,255,255,0.08)', error: 'rgba(255,82,82,0.08)' }[status] || 'rgba(255,255,255,0.03)';
    }

    function setBadge(text, color) {
        const b = document.getElementById('root-status-badge');
        if (!b) return;
        b.textContent = text;
        b.style.background = color || 'rgba(255,255,255,0.1)';
        b.style.color = '#fff';
    }

    function resetSteps() {
        for (let i = 1; i <= 7; i++) setStep(i, 'pending');
        setProgress(0, 'Waiting...');
        setBadge('Idle', 'rgba(255,255,255,0.1)');
        const log = document.getElementById('root-log');
        if (log) log.innerHTML = '';
    }

    // --- Scan Device ---
    const scanBtn = document.getElementById('btn-root-scan');
    if (scanBtn) {
        scanBtn.addEventListener('click', async () => {
            const label = document.getElementById('root-device-label');
            const icon = document.getElementById('root-device-icon');
            if (label) label.textContent = 'Scanning...';
            if (icon) { icon.textContent = '🔍'; icon.style.filter = 'none'; }
            scanBtn.disabled = true;

            // Clear log on new scan
                const log = document.getElementById('root-log');
                if (log) log.innerHTML = '';
                rootLog('> Scanning ADB devices...', '#aaa');

            try {
                // Get device list safely
                const toStr = (v) => typeof v === 'string' ? v : (v && v.message ? v.message : (v && v.output ? v.output : String(v || '')));
                const res = await window.api.invoke('run-adb-devices');
                const rawRes = toStr(res);
                const lines = rawRes.split('\n').filter(l => l.includes('\t'));
                
                if (lines.length === 0 || rawRes.startsWith('[ERROR]')) {
                    const errHint = rawRes.startsWith('[ERROR]') ? ' (' + rawRes.split('\n')[0] + ')' : '';
                    rootLog('No device found. Enable USB debugging.' + errHint, '#ff5252');
                    if (label) label.textContent = 'No device found';
                    if (icon) { icon.textContent = '❌'; }
                    scanBtn.disabled = false;
                    return;
                }

                // Get device info via ADB
                const model = await window.api.invoke('run-adb-command', 'shell getprop ro.product.model');
                const brand = await window.api.invoke('run-adb-command', 'shell getprop ro.product.brand');
                const android = await window.api.invoke('run-adb-command', 'shell getprop ro.build.version.release');
                const serial = await window.api.invoke('run-adb-command', 'shell getprop ro.serialno');
                const cpu = await window.api.invoke('run-adb-command', 'shell getprop ro.product.cpu.abi');
                const blState = await window.api.invoke('run-adb-command', 'shell getprop ro.boot.verifiedbootstate');

                const cleanModel = toStr(model).trim();
                const cleanBrand = toStr(brand).trim();
                const cleanAndroid = toStr(android).trim();
                const cleanSerial = toStr(serial).trim();
                const cleanCpu = toStr(cpu).trim();
                const cleanBL = toStr(blState).trim();

                // Update device card
                if (icon) { icon.textContent = '📱'; icon.style.filter = 'none'; }
                if (label) label.textContent = `${cleanBrand} ${cleanModel}`;

                // Update info grid
                document.getElementById('info-model').textContent = cleanModel || '-';
                document.getElementById('info-android').textContent = 'Android ' + (cleanAndroid || '-');
                document.getElementById('info-serial').textContent = cleanSerial || '-';
                document.getElementById('info-cpu').textContent = cleanCpu || '-';
                
                const flashLocked = await window.api.invoke('run-adb-command', 'shell getprop ro.boot.flash.locked');
                const cleanFL = (flashLocked || '').trim();
                const isUnlocked = cleanBL === 'orange' || cleanFL === '0';
                const blEl = document.getElementById('info-bootloader');
                if (blEl) {
                    blEl.textContent = isUnlocked ? '🔓 Unlocked' : '🔒 Locked';
                    blEl.style.color = isUnlocked ? '#69f0ae' : '#ff5252';
                }

                // Check root status safely
                let isRooted = false;
                try {
                    const suCheck = await window.api.invoke('run-adb-command', 'shell su -c "id"');
                    isRooted = (suCheck || '').includes('uid=0') || (suCheck || '').includes('root');
                } catch(e) {
                    isRooted = false;
                }
                const rootEl = document.getElementById('info-root');
                if (rootEl) {
                    rootEl.textContent = isRooted ? '✅ Rooted' : '❌ Not Rooted';
                    rootEl.style.color = isRooted ? '#69f0ae' : '#888';
                }

                // Auto-fill brand select
                const brandSelect = document.getElementById('root-brand-select');
                if (brandSelect && cleanBrand) {
                    const bl = cleanBrand.toLowerCase();
                    let setVal = 'generic';
                    if (bl.includes('samsung')) setVal = 'samsung';
                    else if (bl.includes('xiaomi') || bl.includes('redmi') || bl.includes('poco')) setVal = 'xiaomi';
                    else if (bl.includes('realme') || bl.includes('oppo') || bl.includes('oneplus')) setVal = 'realme';
                    else if (bl.includes('vivo')) setVal = 'vivo';
                    else if (bl.includes('huawei') || bl.includes('honor')) setVal = 'huawei';
                    else if (bl.includes('motorola') || bl.includes('moto')) setVal = 'motorola';
                    
                    brandSelect.value = setVal;
                    
                    // Update custom dropdown UI
                    const trigger = document.getElementById('root-brand-trigger');
                    const dropdown = document.getElementById('root-brand-dropdown');
                    if (trigger && dropdown) {
                        const opt = dropdown.querySelector(`.csd-option[data-value="${setVal}"]`);
                        if (opt) {
                            const label = opt.textContent.trim();
                            trigger.childNodes[0].textContent = label + ' ';
                            trigger.dataset.value = setVal;
                            dropdown.querySelectorAll('.csd-option').forEach(o => o.classList.remove('selected'));
                            opt.classList.add('selected');
                        }
                    }
                }

                // Auto-fill model
                const modelInput = document.getElementById('root-model-input');
                if (modelInput && cleanModel) modelInput.value = cleanModel;

                rootLog(`✅ Device: ${cleanBrand} ${cleanModel} (Android ${cleanAndroid})`, '#69f0ae');
                rootLog(`   CPU: ${cleanCpu} | Bootloader: ${cleanBL}`, '#aaa');

                // Check Samsung Knox 7-day Security Policy
                if (cleanBrand.toLowerCase().includes('samsung') || cleanModel.toUpperCase().startsWith('SM-')) {
                    await refreshSamsungKnoxPolicy(false);
                } else {
                    const knoxCard = document.getElementById('samsung-knox-policy-card');
                    if (knoxCard) knoxCard.style.display = 'none';
                    const devDetailsCard = document.getElementById('card-root-device-details');
                    if (devDetailsCard) devDetailsCard.style.gridColumn = '1 / -1';
                }

            } catch (e) {
                rootLog('Error: ' + e.message, '#ff5252');
                if (label) label.textContent = 'Error - check ADB';
            }

            scanBtn.disabled = false;
        });
    }

    // --- Samsung Knox 7-Day Security Policy Controller ---
    async function refreshSamsungKnoxPolicy(silent = false) {
        const card = document.getElementById('samsung-knox-policy-card');
        if (!card) return;

        try {
            const data = await window.api.checkSamsungKnoxPolicy();
            if (!data || !data.success || !data.isSamsung) {
                card.style.display = 'none';
                const devDetailsCard = document.getElementById('card-root-device-details');
                if (devDetailsCard) devDetailsCard.style.gridColumn = '1 / -1';
                return;
            }

            // Show card side-by-side with Device Details
            card.style.display = 'flex';
            const devDetailsCard = document.getElementById('card-root-device-details');
            if (devDetailsCard) devDetailsCard.style.gridColumn = 'auto';

            // Populate Elements
            const badge = document.getElementById('knox-policy-badge');
            const oemStatus = document.getElementById('knox-oem-status');
            const setupTime = document.getElementById('knox-setup-time');
            const elapsedTime = document.getElementById('knox-elapsed-time');
            const remainingTime = document.getElementById('knox-remaining-time');
            const estUnlock = document.getElementById('knox-estimated-unlock');
            const kgState = document.getElementById('knox-kg-state');
            const progLabel = document.getElementById('knox-progress-label');
            const progBar = document.getElementById('knox-progress-bar');
            const alertBox = document.getElementById('knox-policy-alert');

            if (setupTime) setupTime.textContent = data.setupTimeStr || '-';
            if (elapsedTime) {
                const hoursTxt = data.elapsedHours < 24 ? `${data.elapsedHours} ชม. (ยังไม่ถึง 24 ชม.)` : `${data.elapsedHours} ชม.`;
                elapsedTime.textContent = hoursTxt;
            }
            if (remainingTime) {
                const daysLeft = (data.remainingHours / 24).toFixed(1);
                remainingTime.textContent = data.remainingHours > 0 ? `~${data.remainingHours} ชม. (${daysLeft} วัน)` : '0 ชม. (ครบกำหนดแล้ว)';
            }
            if (estUnlock) estUnlock.textContent = data.estimatedUnlockStr || '-';
            if (kgState) kgState.textContent = `${data.kgState} (${data.flashLocked ? 'Flash Locked' : 'Unlocked'})`;

            if (progLabel) progLabel.textContent = `${data.percentage}% (${data.elapsedHours}/${data.totalHours} ชม.)`;
            if (progBar) {
                progBar.style.width = `${Math.max(5, data.percentage)}%`;
                progBar.style.background = data.isPolicyActive 
                    ? 'linear-gradient(90deg, #f59e0b, #ef4444)' 
                    : 'linear-gradient(90deg, #10b981, #059669)';
            }

            if (data.isPolicyActive) {
                card.style.borderColor = 'rgba(239,68,68,0.4)';
                card.style.background = 'rgba(239,68,68,0.06)';
                if (badge) {
                    badge.textContent = '🔒 168h Lock Active';
                    badge.style.background = 'rgba(239,68,68,0.2)';
                    badge.style.color = '#f87171';
                    badge.style.borderColor = 'rgba(239,68,68,0.4)';
                }
                if (oemStatus) {
                    oemStatus.textContent = '🔒 ซ่อนเมนู (Locked)';
                    oemStatus.style.color = '#f87171';
                }
                if (alertBox) {
                    alertBox.innerHTML = `⚠️ <b>ตรวจพบนโยบายความปลอดภัย Samsung Knox:</b> ตัวเครื่องเพิ่งเปิดใช้งานมา ${data.elapsedHours} ชม. (${data.elapsedHours < 24 ? 'ยังไม่ถึง 24 ชั่วโมง' : data.elapsedHours + ' ชม.'}) ระบบความปลอดภัย VaultKeeper จึงซ่อนเมนู <b>"การปลดล็อก OEM"</b> ไว้อย่างเข้มงวดเป็นเวลา 168 ชั่วโมง (7 วันเต็ม) เพื่อความปลอดภัยของข้อมูล`;
                }
                if (!silent) {
                    rootLog('🛡️ ตรวจพบเครื่อง Samsung ติดนโยบายความปลอดภัย 7 วัน (168 ชม.)', '#f59e0b');
                    rootLog(`   ใช้งานมาแล้ว: ${data.elapsedHours} ชม. | เหลืออีก: ${data.remainingHours} ชม. | คาดการณ์ปลดล็อก: ${data.estimatedUnlockStr}`, '#aaa');
                }
            } else {
                card.style.borderColor = 'rgba(74,222,128,0.4)';
                card.style.background = 'rgba(74,222,128,0.06)';
                if (badge) {
                    badge.textContent = '✅ OEM Unlock Ready';
                    badge.style.background = 'rgba(74,222,128,0.2)';
                    badge.style.color = '#4ade80';
                    badge.style.borderColor = 'rgba(74,222,128,0.4)';
                }
                if (oemStatus) {
                    oemStatus.textContent = '✅ เมนูพร้อมเปิด (Available)';
                    oemStatus.style.color = '#4ade80';
                }
                if (alertBox) {
                    alertBox.innerHTML = '✅ <b>ผ่านเกณฑ์ความปลอดภัยแล้ว:</b> ตัวเครื่องเปิดใช้งานครบ 168 ชั่วโมงแล้ว เมนู "การปลดล็อก OEM" ในทางเลือกผู้พัฒนาสามารถเปิดใช้งานได้ตามปกติ';
                }
                if (!silent) {
                    rootLog('✅ ตรวจสอบ Samsung Knox Policy: ผ่านเกณฑ์ 168 ชั่วโมงแล้ว', '#4ade80');
                }
            }
        } catch (err) {
            console.error('Samsung Knox Policy error:', err);
        }
    }

    const knoxRefreshBtn = document.getElementById('btn-knox-refresh');
    if (knoxRefreshBtn) {
        knoxRefreshBtn.addEventListener('click', async () => {
            knoxRefreshBtn.disabled = true;
            knoxRefreshBtn.textContent = '⏳ กำลังตรวจ...';
            await refreshSamsungKnoxPolicy(false);
            knoxRefreshBtn.disabled = false;
            knoxRefreshBtn.textContent = '🔄 รีเฟรชสถานะ';
        });
    }

    const knoxGuideBtn = document.getElementById('btn-knox-guide');
    if (knoxGuideBtn) {
        knoxGuideBtn.addEventListener('click', () => {
            alert(
                "📖 คำแนะนำนโยบายความปลอดภัย 7 วัน (168 ชั่วโมง) ของ Samsung Knox\n\n" +
                "1. นโยบายนี้ถูกบังคับใช้กับมือถือ Samsung รุ่นใหม่ทุกเครื่องที่เพิ่งแกะกล่องหรือเพิ่งคืนค่าโรงงาน (Factory Reset)\n" +
                "2. ระบบจะซ่อนเมนู 'การปลดล็อก OEM' ไว้เป็นเวลา 168 ชั่วโมงเต็ม โดยต้องเปิดเครื่อง ใส่ซิม และเชื่อมต่อ Wi-Fi ไว้\n" +
                "3. เมื่อครบกำหนด 168 ชั่วโมง เมนูปลดล็อก OEM จะโผล่ขึ้นมาให้เปิดได้เองโดยอัตโนมัติ\n" +
                "4. เทคนิคย้อนเวลา (Date Trick): บางรุ่นสามารถหลอกระบบได้โดย ปิดเวลาอัตโนมัติ -> ตั้งเวลาย้อนหลัง 10-15 วัน -> กดเช็คอัปเดตซอฟต์แวร์ 1 ครั้ง -> รีสตาร์ทเครื่อง"
            );
        });
    }

    // --- Boot File Selector & Reboot buttons ---
    const browseBootBtn = document.getElementById('btn-root-browse-boot');
    const bootPathInput = document.getElementById('root-boot-path');
    const bootClearBtn = document.getElementById('btn-root-clear-boot');
    const bootStatusBadge = document.getElementById('root-boot-status-badge');

    async function handleBootFileSelection(filePath) {
        if (!filePath) return;
        if (bootPathInput) bootPathInput.value = filePath;
        if (bootClearBtn) bootClearBtn.style.display = 'inline-block';

        const baseName = getBasename(filePath);
        const lowerPath = filePath.toLowerCase();
        const isAp = lowerPath.endsWith('.tar') || lowerPath.endsWith('.tar.md5') || lowerPath.includes('ap_');
        const isZip = lowerPath.endsWith('.zip');

        if (isAp) {
            if (bootStatusBadge) {
                bootStatusBadge.innerHTML = `
                    <div style="background: rgba(56,189,248,0.12); border: 1px solid rgba(56,189,248,0.3); border-radius: 8px; padding: 8px 10px; color: #38bdf8;">
                        <div style="display:flex; align-items:center; gap:8px; font-weight:600; margin-bottom:3px;">
                            <i class="fas fa-spinner fa-spin"></i> ตรวจพบรอมศูนย์ Samsung AP! กำลังสกัด boot.img อัตโนมัติ...
                        </div>
                        <div style="color: #94a3b8; font-size: 11px; word-break: break-all;">ไฟล์: <b>${baseName}</b></div>
                    </div>
                `;
                bootStatusBadge.style.display = 'block';
            }
            rootLog('📦 ตรวจพบรอมศูนย์ Samsung AP: ' + baseName, '#38bdf8');
            rootLog('> กำลังสกัด boot.img อัตโนมัติด้วยเอนจินความเร็วสูง...', '#aaa');

            try {
                const apRes = await window.api.extractBootFromAp(filePath);
                if (apRes && apRes.success) {
                    const lz4Note = apRes.hasDecompressed ? ' (แตก LZ4 &rarr; .img ดิบ)' : '';
                    const initNote = apRes.isInitBoot ? ' [Android 13+ init_boot]' : '';
                    const timeNote = apRes.elapsedSeconds ? `(${apRes.elapsedSeconds}s)` : '';

                    const autoPatchChk = document.getElementById('chk-auto-patch-magisk');
                    const shouldAutoPatch = autoPatchChk && autoPatchChk.checked;

                    if (shouldAutoPatch) {
                        rootLog(`✅ สกัดสำเร็จ: ${apRes.targetFile} ${lz4Note} ${timeNote}`, '#69f0ae');
                        rootLog(`⚡ ตรวจพบการตั้งค่าแพตช์อัตโนมัติ: กำลังเริ่มแพตช์ Magisk Root ทันที...`, '#ff8a65');
                        await executeMagiskPatch(apRes.outPath, bootStatusBadge, rootLog);
                    } else {
                        if (bootStatusBadge) {
                            bootStatusBadge.innerHTML = `
                                <div style="background: rgba(34,197,94,0.12); border: 1px solid rgba(34,197,94,0.3); border-radius: 8px; padding: 10px; color: #4ade80;">
                                    <div style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:6px; margin-bottom:4px;">
                                        <div style="font-weight:600; display:flex; align-items:center; gap:6px;">
                                            <i class="fas fa-check-circle"></i> สกัด Boot Image สำเร็จ! ${timeNote}
                                        </div>
                                        <div style="display:flex; gap:6px; flex-wrap: wrap;">
                                            <button type="button" class="btn-root-patch-now" style="background: linear-gradient(135deg, #ff4e00, #ec9f05); border: none; color: #fff; padding: 3px 10px; border-radius: 4px; font-size: 11px; font-weight: 600; cursor: pointer;">
                                                <i class="fas fa-bolt"></i> แพตช์ Magisk Root ทันที
                                            </button>
                                            <button type="button" class="btn-open-root-extracted" style="background: rgba(34,197,94,0.25); border: 1px solid rgba(34,197,94,0.4); color: #fff; padding: 3px 8px; border-radius: 4px; font-size: 11px; cursor: pointer;">
                                                <i class="fas fa-folder-open"></i> เปิดโฟลเดอร์
                                            </button>
                                        </div>
                                    </div>
                                    <div style="color: #cbd5e1; font-size: 11px; word-break: break-all;">
                                        สกัดได้: <b>${apRes.targetFile}</b> ${lz4Note} ${initNote}
                                    </div>
                                    <div style="color: #94a3b8; font-size: 10px; margin-top: 3px; word-break: break-all;">
                                        ตำแหน่ง: ${apRes.outPath}
                                    </div>
                                </div>
                            `;
                            const patchBtn = bootStatusBadge.querySelector('.btn-root-patch-now');
                            if (patchBtn) {
                                patchBtn.addEventListener('click', () => {
                                    executeMagiskPatch(apRes.outPath, bootStatusBadge, rootLog);
                                });
                            }
                            const openBtn = bootStatusBadge.querySelector('.btn-open-root-extracted');
                            if (openBtn) {
                                openBtn.addEventListener('click', async () => {
                                    if (window.api && window.api.openFileLocation) {
                                        await window.api.openFileLocation(apRes.outPath);
                                    }
                                });
                            }
                        }
                        rootLog(`✅ สกัดสำเร็จ: ${apRes.targetFile} ${lz4Note} ${timeNote}`, '#69f0ae');
                        rootLog(`💡 คุณสามารถคลิกปุ่ม [แพตช์ Magisk Root ทันที] เพื่อแปลงเป็นไฟล์รูทได้เลย`, '#38bdf8');
                    }
                } else {
                    if (bootStatusBadge) {
                        bootStatusBadge.innerHTML = `
                            <div style="background: rgba(239,68,68,0.12); border: 1px solid rgba(239,68,68,0.3); border-radius: 8px; padding: 10px; color: #f87171;">
                                <div style="font-weight:600;"><i class="fas fa-times-circle"></i> สกัดไฟล์ boot ไม่สำเร็จ: ${apRes ? apRes.error : 'Unknown error'}</div>
                            </div>
                        `;
                    }
                    rootLog(`❌ สกัดไฟล์ boot ไม่สำเร็จ: ${apRes ? apRes.error : 'Unknown error'}`, '#ff5252');
                }
            } catch (err) {
                if (bootStatusBadge) {
                    bootStatusBadge.innerHTML = `<div style="color: #f87171; padding: 6px;">❌ เกิดข้อผิดพลาด: ${err.message}</div>`;
                }
                rootLog(`❌ เกิดข้อผิดพลาดในการสกัดไฟล์: ${err.message}`, '#ff5252');
            }
        } else if (isZip) {
            if (bootStatusBadge) {
                bootStatusBadge.innerHTML = `
                    <div style="background: rgba(245,158,11,0.12); border: 1px solid rgba(245,158,11,0.3); border-radius: 8px; padding: 10px; color: #fbbf24;">
                        <div style="font-weight:600; display:flex; align-items:center; gap:6px;">
                            <i class="fas fa-file-archive"></i> ไฟล์ ZIP เฟิร์มแวร์
                        </div>
                        <div style="color: #e2e8f0; font-size: 11px; margin-top: 3px;">
                            กรุณาเลือกไฟล์ <b>AP_*.tar.md5</b> ที่อยู่ภายใน หรือแตกไฟล์ ZIP ออกมาก่อน
                        </div>
                    </div>
                `;
                bootStatusBadge.style.display = 'block';
            }
            rootLog('ℹ️ ตรวจพบไฟล์ ZIP: กรุณาเลือกไฟล์ AP_*.tar.md5 ภายใน', '#fbbf24');
        } else {
            // raw img or other
            if (bootStatusBadge) {
                bootStatusBadge.innerHTML = `
                    <div style="background: rgba(34,197,94,0.12); border: 1px solid rgba(34,197,94,0.3); border-radius: 8px; padding: 10px; color: #4ade80;">
                        <div style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:6px; margin-bottom:4px;">
                            <div style="font-weight:600; display:flex; align-items:center; gap:6px;">
                                <i class="fas fa-check-circle"></i> พร้อมใช้งาน: ${baseName}
                            </div>
                            <div style="display:flex; gap:6px; flex-wrap:wrap;">
                                <button type="button" class="btn-root-pack-tar" style="background: linear-gradient(135deg, #0284c7, #0369a1); border: none; color: #fff; padding: 3px 10px; border-radius: 4px; font-size: 11px; font-weight: 600; cursor: pointer;">
                                    <i class="fas fa-file-archive"></i> รวมเป็นไฟล์ .tar สำหรับ Odin
                                </button>
                                <button type="button" class="btn-root-patch-now" style="background: linear-gradient(135deg, #ff4e00, #ec9f05); border: none; color: #fff; padding: 3px 10px; border-radius: 4px; font-size: 11px; font-weight: 600; cursor: pointer;">
                                    <i class="fas fa-bolt"></i> แพตช์ Magisk Root ทันที
                                </button>
                            </div>
                        </div>
                        <div style="color: #94a3b8; font-size: 10px; margin-top: 3px; word-break: break-all;">
                            ${filePath}
                        </div>
                    </div>
                `;
                bootStatusBadge.style.display = 'block';
                const patchBtn = bootStatusBadge.querySelector('.btn-root-patch-now');
                if (patchBtn) {
                    patchBtn.addEventListener('click', () => {
                        executeMagiskPatch(filePath, bootStatusBadge, rootLog);
                    });
                }
                const packTarBtn = bootStatusBadge.querySelector('.btn-root-pack-tar');
                if (packTarBtn) {
                    packTarBtn.addEventListener('click', async () => {
                        rootLog(`📦 กำลังแปลงไฟล์ ${baseName} เป็น .tar สำหรับ Samsung Odin...`, '#38bdf8');
                        try {
                            const res = await window.api.convertImgToOdinTar(filePath);
                            if (res && res.success) {
                                rootLog(`🎉 แปลงไฟล์เป็น .tar สำเร็จแล้ว!`, '#69f0ae');
                                rootLog(`📁 ที่อยู่ไฟล์: ${res.tarPath}`, '#ffd740');
                                if (window.api.openFileLocation) {
                                    await window.api.openFileLocation(res.tarPath);
                                }
                            } else {
                                rootLog(`❌ แปลงไฟล์ไม่สำเร็จ: ${res ? res.error : 'Unknown error'}`, '#ff5252');
                            }
                        } catch (err) {
                            rootLog(`❌ เกิดข้อผิดพลาด: ${err.message}`, '#ff5252');
                        }
                    });
                }
            }
            rootLog('📁 เลือกไฟล์ Boot Image: ' + baseName, '#69f0ae');
        }
    }

    async function triggerBootFileDialog() {
        try {
            const res = await window.api.showOpenDialog({
                title: 'เลือกไฟล์ boot.img หรือ Samsung AP tar file',
                filters: [
                    { name: 'Boot / Firmware Files', extensions: ['img', 'lz4', 'tar', 'md5', 'bin', 'zip'] },
                    { name: 'Samsung AP Files (*.tar.md5, *.tar)', extensions: ['tar.md5', 'tar'] },
                    { name: 'Boot Images (*.img, *.img.lz4)', extensions: ['img', 'lz4'] },
                    { name: 'All Files', extensions: ['*'] }
                ],
                properties: ['openFile']
            });
            const filePath = resolveDialogPath(res);
            if (filePath) {
                await handleBootFileSelection(filePath);
            }
        } catch(e) {
            rootLog('Error selecting file: ' + e.message, '#ff5252');
        }
    }

    if (browseBootBtn) {
        browseBootBtn.addEventListener('click', triggerBootFileDialog);
    }
    if (bootPathInput) {
        bootPathInput.addEventListener('click', triggerBootFileDialog);
    }
    if (bootClearBtn) {
        bootClearBtn.addEventListener('click', () => {
            if (bootPathInput) bootPathInput.value = '';
            if (bootStatusBadge) {
                bootStatusBadge.innerHTML = '';
                bootStatusBadge.style.display = 'none';
            }
            bootClearBtn.style.display = 'none';
            rootLog('ℹ️ ล้างการเลือกไฟล์ Boot Image แล้ว', '#aaa');
        });
    }

    const rebootDlBtn = document.getElementById('btn-root-reboot-dl');
    if (rebootDlBtn) {
        rebootDlBtn.addEventListener('click', async () => {
            try {
                rootLog('> Rebooting device to Download Mode...', '#aaa');
                await window.api.invoke('run-adb-command', 'reboot download');
                rootLog('✅ Sent reboot download command.', '#69f0ae');
            } catch (e) {
                rootLog('❌ Error: ' + e.message, '#ff5252');
            }
        });
    }

    const rebootFbBtn = document.getElementById('btn-root-reboot-fb');
    if (rebootFbBtn) {
        rebootFbBtn.addEventListener('click', async () => {
            try {
                rootLog('> Rebooting device to Fastboot...', '#aaa');
                await window.api.invoke('run-adb-command', 'reboot bootloader');
                rootLog('✅ Sent reboot bootloader command.', '#69f0ae');
            } catch (e) {
                rootLog('❌ Error: ' + e.message, '#ff5252');
            }
        });
    }

    // --- One-Click ROOT ---
    const rootBtn = document.getElementById('btn-root-oneclick');
    if (rootBtn) {
        rootBtn.addEventListener('click', async () => {
            const model = document.getElementById('root-model-input')?.value?.trim();
            if (!model) {
                alert('Please scan your device or enter model manually first.');
                return;
            }

            resetSteps();
            rootBtn.disabled = true;
            setBadge('Rooting...', 'rgba(255,78,0,0.6)');
            const log = document.getElementById('root-log');
            if (log) log.innerHTML = '';

            rootLog('⚡ Starting One-Click ROOT process...', '#fff');

            // Step 1: Check ADB
            setStep(1, 'active');
            setProgress(5, 'Checking ADB connection...');
            await new Promise(r => setTimeout(r, 400));
            try {
                const rawDevs = await window.api.invoke('run-adb-devices');
                const toStr = (v) => typeof v === 'string' ? v : (v && v.message ? v.message : (v && v.output ? v.output : String(v || '')));
                const devs = toStr(rawDevs);
                if (!devs || !devs.includes('\t')) throw new Error('No device in ADB mode. Make sure USB Debugging is ON.');
                setStep(1, 'done');
                rootLog('✅ ADB connected', '#69f0ae');
                setProgress(14, 'Checking bootloader...');
            } catch(e) {
                setStep(1, 'error');
                setBadge('Failed', 'rgba(255,82,82,0.6)');
                rootLog('❌ ' + e.message, '#ff5252');
                rootBtn.disabled = false;
                return;
            }

            // Step 2 & 3: Check / Unlock Bootloader
            setStep(2, 'active');
            await new Promise(r => setTimeout(r, 400));

            const skipBL = document.getElementById('root-skip-bl-check')?.checked;
            if (skipBL) {
                rootLog('⏩ ข้ามขั้นตอนตรวจ Bootloader (Force Skip / Already Unlocked)', '#69f0ae');
                setStep(2, 'done');
                setStep(3, 'done');
            } else {
                try {
                    const blState = await window.api.invoke('run-adb-command', 'shell getprop ro.boot.verifiedbootstate');
                    const flashLocked = await window.api.invoke('run-adb-command', 'shell getprop ro.boot.flash.locked');
                    const cleanBL = (blState || '').trim().toLowerCase();
                    const cleanFL = (flashLocked || '').trim();
                    const isBLUnlocked = cleanBL === 'orange' || cleanFL === '0';

                    if (isBLUnlocked) {
                        setStep(2, 'done');
                        rootLog('✅ Bootloader: Already Unlocked', '#69f0ae');
                        setStep(3, 'done');
                    } else {
                        rootLog('⚠️ Bootloader is LOCKED.', '#ffa726');
                        setStep(2, 'done');
                        setStep(3, 'active');

                        const currentBrand = (document.getElementById('root-brand-select')?.value || document.getElementById('root-device-label')?.textContent || '').toLowerCase();
                        if (currentBrand.includes('samsung')) {
                            rootLog('⚠️ Samsung devices cannot be unlocked automatically via Fastboot.', '#ffd740');
                            rootLog('Samsung requires manual unlock in Device Unlock Mode.', '#aaa');
                            
                            const msgTh = 'เครื่อง Samsung ต้องทำการปลดล็อค Bootloader บนตัวเครื่องโดยตรง\n\n' +
                                '📌 ขั้นตอนการปลดล็อค (ข้อมูลจะถูกล้าง Factory Reset):\n' +
                                '1. เข้า ตั้งค่า > ข้อมูลซอฟต์แวร์ > กด Build number 7 ครั้ง\n' +
                                '2. เข้า ทางเลือกผู้พัฒนา > เปิด "การปลดล็อค OEM" (OEM Unlock)\n' +
                                '3. ปิดเครื่องโทรศัพท์ให้สนิท\n' +
                                '4. กดปุ่ม [เพิ่มเสียง + ลดเสียง] ค้างไว้ แล้วเสียบสาย USB ต่อเข้าคอม\n' +
                                '5. เมื่อหน้าจอสีฟ้า (Warning) เด้งขึ้นมา ให้ "กดปุ่มเพิ่มเสียงค้างไว้" (Long-press Vol Up)\n' +
                                '6. กดปุ่มเพิ่มเสียงอีก 1 ครั้งเพื่อยืนยัน\n\n' +
                                '💡 หากปลดล็อคเรียบร้อยแล้ว ให้ติ๊กช่อง "ข้ามการตรวจ Bootloader" ด้านล่าง แล้วกด One-Click ROOT อีกครั้ง';
                            
                            await showCustomConfirm(msgTh);
                            setStep(3, 'error');
                            setBadge('Action Needed', 'rgba(255,167,38,0.6)');
                            rootBtn.disabled = false;
                            return;
                        }

                        // Fastboot auto-unlock for non-Samsung
                        setProgress(20, 'Rebooting to Fastboot for Unlock...');
                        await window.api.invoke('run-adb-command', 'reboot bootloader');
                        await new Promise(r => setTimeout(r, 6000));
                        rootLog('> Sending unlock command...', '#aaa');
                        await window.api.invoke('run-fastboot-command', 'flashing unlock');
                        await window.api.invoke('run-fastboot-command', 'oem unlock');
                        
                        const confirmRes = await showCustomConfirm('Please confirm the unlock on your phone screen by pressing Volume Up.');
                        if (!confirmRes) {
                            rootLog('❌ Bootloader unlock cancelled by user.', '#ff5252');
                            setStep(3, 'error');
                            rootBtn.disabled = false;
                            return;
                        }

                        rootLog('> Waiting for device to boot up and reconnect to ADB...', '#aaa');
                        let adbConnected = false;
                        for (let i = 0; i < 40; i++) {
                            await new Promise(r => setTimeout(r, 3000));
                            const d = await window.api.invoke('run-adb-devices');
                            if (d && d.includes('\t')) { adbConnected = true; break; }
                        }
                        if (!adbConnected) {
                            rootLog('❌ Device did not reconnect to ADB after unlock.', '#ff5252');
                            setStep(3, 'error');
                            rootBtn.disabled = false;
                            return;
                        }
                        setStep(3, 'done');
                        rootLog('✅ Bootloader Unlocked & Device Reconnected', '#69f0ae');
                    }
                } catch(e) {
                    setStep(2, 'error');
                    setStep(3, 'error');
                    rootLog('⚠️ Bootloader check error: ' + e.message, '#ff5252');
                    rootBtn.disabled = false;
                    return;
                }
            }

            // Step 4: Push Magisk & Tools
            setStep(4, 'active');
            setProgress(35, 'Pushing Magisk & patching engine to device...');
            try {
                const magiskApk = 'bin\\magisk\\Magisk.apk';
                rootLog('> Installing Magisk app...', '#aaa');
                try {
                    await window.api.invoke('run-adb-command', `install -r -d -g "${magiskApk}"`);
                } catch(installErr) {
                    rootLog('ℹ️ Magisk app push/install note: ' + (installErr.message || ''), '#aaa');
                }
                await window.api.invoke('run-adb-command', `push "${magiskApk}" /data/local/tmp/Magisk.apk`);

                // Push magiskboot engine
                const tools = ['magiskboot', 'magiskinit', 'boot_patch.sh', 'util_functions.sh', 'stub.apk'];
                for (const t of tools) {
                    await window.api.invoke('run-adb-command', `push "bin\\magisk\\${t}" /data/local/tmp/${t}`);
                }
                await window.api.invoke('run-adb-command', 'shell "chmod 755 /data/local/tmp/magiskboot /data/local/tmp/magiskinit /data/local/tmp/boot_patch.sh"');

                setStep(4, 'done');
                rootLog('✅ Magisk engine deployed to /data/local/tmp/', '#69f0ae');
                setProgress(45, 'Preparing boot image...');
            } catch(e) {
                setStep(4, 'error');
                rootLog('❌ ' + e.message, '#ff5252');
                setBadge('Failed', 'rgba(255,82,82,0.6)');
                rootBtn.disabled = false;
                return;
            }

            // Step 5: Pull or Obtain boot.img
            setStep(5, 'active');
            setProgress(50, 'Obtaining boot image...');
            let customBootPath = document.getElementById('root-boot-path')?.value?.trim();

            try {
                if (customBootPath) {
                    rootLog(`> Using provided boot file: ${customBootPath}`, '#aaa');
                } else {
                    // Try pulling via root dd (if already rooted)
                    rootLog('> Checking if boot partition can be dumped via ADB...', '#aaa');
                    let hasBootDump = false;
                    try {
                        await window.api.invoke('run-adb-command', 'shell su -c "dd if=/dev/block/by-name/boot of=/data/local/tmp/boot.img bs=4M"');
                        const checkImg = await window.api.invoke('run-adb-command', 'shell ls -la /data/local/tmp/boot.img');
                        if (checkImg && !checkImg.includes('No such file') && !checkImg.includes('0 bytes')) {
                            hasBootDump = true;
                        }
                    } catch(suErr) {
                        hasBootDump = false;
                    }
                    
                    if (!hasBootDump) {
                        rootLog('⚠️ Cannot dump boot partition directly (device is not rooted yet).', '#ffa726');
                        rootLog('👉 กรุณาเลือกไฟล์ AP (รอมศูนย์ Samsung .tar / .tar.md5) หรือไฟล์ boot.img / boot.img.lz4', '#69f0ae');
                        
                        const filePick = await window.api.showOpenDialog({
                            title: 'เลือกไฟล์รอม Samsung AP (.tar.md5) หรือไฟล์ boot.img',
                            filters: [
                                { name: 'Samsung AP / Boot Image Files', extensions: ['tar.md5', 'tar', 'img', 'lz4', 'bin'] },
                                { name: 'All Files', extensions: ['*'] }
                            ],
                            properties: ['openFile']
                        });

                        const pickedPath = resolveDialogPath(filePick);
                        if (!pickedPath) {
                            throw new Error('จำเป็นต้องใช้ไฟล์ boot.img หรือไฟล์ AP tar ของเครื่องเพื่อทำการรูท');
                        }

                        customBootPath = pickedPath;
                        const bootInp = document.getElementById('root-boot-path');
                        if (bootInp) bootInp.value = customBootPath;
                    }
                }

                // If user selected Samsung AP tar file, extract boot.img from it on PC!
                if (customBootPath && (customBootPath.toLowerCase().endsWith('.tar') || customBootPath.toLowerCase().endsWith('.tar.md5') || customBootPath.toLowerCase().includes('ap_'))) {
                    rootLog('> ตรวจพบไฟล์รอม Samsung AP! กำลังแตกไฟล์ boot.img ออกจาก TAR...', '#60a5fa');
                    const apRes = await window.api.extractBootFromAp(customBootPath);
                    if (!apRes.success) {
                        throw new Error('ไม่สามารถแตกไฟล์ boot จาก AP ได้: ' + apRes.error);
                    }
                    rootLog(`✅ แตกไฟล์สำเร็จ: ${apRes.targetFile}`, '#69f0ae');
                    rootLog(`> กำลังส่ง ${apRes.targetFile} ไปยังมือถือ...`, '#aaa');
                    
                    if (apRes.hasDecompressed) {
                        await window.api.invoke('run-adb-command', `push "${apRes.outPath}" /data/local/tmp/boot.img`);
                    } else if (apRes.isLz4) {
                        await window.api.invoke('run-adb-command', `push "${apRes.outPath}" /data/local/tmp/boot.img.tmp`);
                        rootLog('> กำลังคลายบีบอัด LZ4 บนมือถือ...', '#aaa');
                        await window.api.invoke('run-adb-command', 'shell "/data/local/tmp/magiskboot decompress /data/local/tmp/boot.img.tmp /data/local/tmp/boot.img"');
                    } else {
                        await window.api.invoke('run-adb-command', `push "${apRes.outPath}" /data/local/tmp/boot.img`);
                    }
                } else if (customBootPath) {
                    rootLog(`> Pushing ${customBootPath} to device...`, '#aaa');
                    await window.api.invoke('run-adb-command', `push "${customBootPath}" /data/local/tmp/boot.img.tmp`);
                    if (customBootPath.toLowerCase().endsWith('.lz4')) {
                        await window.api.invoke('run-adb-command', 'shell "/data/local/tmp/magiskboot decompress /data/local/tmp/boot.img.tmp /data/local/tmp/boot.img"');
                    } else {
                        await window.api.invoke('run-adb-command', 'shell "mv /data/local/tmp/boot.img.tmp /data/local/tmp/boot.img"');
                    }
                }

                setStep(5, 'done');
                rootLog('✅ boot.img ready for patching', '#69f0ae');
                setProgress(65, 'Patching boot.img with Magisk...');
            } catch(e) {
                setStep(5, 'error');
                rootLog('❌ ' + e.message, '#ff5252');
                setBadge('Failed', 'rgba(255,82,82,0.6)');
                rootBtn.disabled = false;
                return;
            }

            // Step 6: Patch boot.img
            setStep(6, 'active');
            setProgress(70, 'Patching boot.img with Magisk engine...');
            try {
                const patchCmd = 'shell "cd /data/local/tmp && KEEPVERITY=true KEEPFORCEENCRYPT=true sh boot_patch.sh boot.img 2>&1"';
                const patchOut = await window.api.invoke('run-adb-command', patchCmd);
                rootLog(patchOut || '', '#888');

                // Pull output
                await window.api.invoke('run-adb-command', 'pull /data/local/tmp/new-boot.img bin\\magisk\\magisk_patched.img');
                
                setStep(6, 'done');
                rootLog('✅ boot.img successfully patched with Magisk!', '#69f0ae');
                setProgress(80, 'Preparing flash...');
            } catch(e) {
                setStep(6, 'error');
                rootLog('❌ Patch error: ' + e.message, '#ff5252');
                setBadge('Failed', 'rgba(255,82,82,0.6)');
                rootBtn.disabled = false;
                return;
            }

            // Step 7: Flash patched boot
            setStep(7, 'active');
            const currentBrand = (document.getElementById('root-brand-select')?.value || document.getElementById('root-device-label')?.textContent || '').toLowerCase();

            if (currentBrand.includes('samsung') || (document.getElementById('root-device-label')?.textContent || '').toLowerCase().includes('sm-')) {
                // Samsung uses Odin / Download mode
                setProgress(88, 'Packaging Samsung Odin tar file...');
                try {
                    // Create magisk_patched.tar
                    await window.api.invoke('run-cmd', { id: 'create-patched-tar', elevated: false });
                } catch(e) {}

                setStep(7, 'done');
                rootLog('🎉 รวมไฟล์ magisk_patched.tar สำหรับ Samsung เรียบร้อยแล้ว!', '#69f0ae');
                rootLog('📁 ไฟล์ที่พร้อมแฟลชอยู่ที่: bin\\magisk\\magisk_patched.tar', '#ffd740');
                rootLog('==================================================', '#555');
                rootLog('📱 ขั้นตอนแฟลชสำหรับ Samsung ให้ ROOT สำเร็จ 100%:', '#38bdf8');
                rootLog('1. ปิดเครื่องโทรศัพท์ให้สนิท', '#fff');
                rootLog('2. กดปุ่ม [เพิ่มเสียง + ลดเสียง] ค้างไว้ แล้วเสียบสาย USB ต่อเข้าคอม (เข้า Download Mode)', '#fff');
                rootLog('3. หน้าจอโทรศัพท์จะขึ้นสีฟ้า ให้กดปุ่ม [เพิ่มเสียง 1 ครั้ง] เพื่อยืนยัน', '#fff');
                rootLog('4. ไปที่แท็บ Odin Flasher ในโปรแกรมนี้ ใส่ไฟล์ bin\\magisk\\magisk_patched.tar ในช่อง AP', '#69f0ae');
                rootLog('5. กดปุ่ม Start ใน Odin เพื่อแฟลชรูทเข้าเครื่อง', '#fff');
                rootLog('6. เมื่อเครื่องบูตขึ้นมา เปิดแอป Magisk แล้วกด Reboot 1 ครั้ง -> สำเร็จ 100%!', '#69f0ae');
                rootLog('==================================================', '#555');
                
                setProgress(100, '✅ Magisk Patched Ready for Odin Flash!');
                setBadge('Ready for Odin', 'rgba(105,240,174,0.4)');
            } else {
                // Fastboot flash
                setProgress(88, 'Rebooting to Fastboot and flashing...');
                try {
                    await window.api.invoke('run-adb-command', 'reboot bootloader');
                    await new Promise(r => setTimeout(r, 4000));
                    const flashRes = await window.api.invoke('run-fastboot-command', 'flash boot bin\\magisk\\magisk_patched.img');
                    if ((flashRes || '').includes('OKAY')) {
                        setStep(7, 'done');
                        rootLog('✅ Patched boot flashed via Fastboot!', '#69f0ae');
                    } else {
                        throw new Error('Flash output: ' + flashRes);
                    }
                } catch(e) {
                    setStep(7, 'error');
                    rootLog('❌ ' + e.message, '#ff5252');
                    setBadge('Failed', 'rgba(255,82,82,0.6)');
                    rootBtn.disabled = false;
                    return;
                }

                // Step 8: Reboot
                setStep(8, 'active');
                setProgress(95, 'Rebooting device...');
                try {
                    await window.api.invoke('run-fastboot-command', 'reboot');
                    setStep(8, 'done');
                    setProgress(100, 'Root Complete!');
                    setBadge('Rooted!', 'rgba(105,240,174,0.4)');
                    rootLog('🎉 Root completed! Open Magisk app on device to complete setup.', '#69f0ae');
                } catch(e) {
                    rootLog('⚠️ Reboot warning: ' + e.message, '#ffa726');
                }
            }

            rootBtn.disabled = false;
        });
    }

})();
// ============================================================

});

// (Cloud Loaders DB removed)


// --- Device Status Polling Loop ---
let _lastUsbText = '';
setInterval(async () => {
    try {
        const adbRes = await window.api.runAdbCommand('devices');
        const adbLines = adbRes.split('\n').filter(line => line.trim() !== '' && !line.includes('List of devices'));
        const usbStatus = document.getElementById('console-usb-status');
        if (usbStatus) {
            if (adbLines.length > 0) {
                const parts = adbLines[0].split('\t');
                const devId = parts[0];
                const devMode = parts[1] ? parts[1].trim() : '';
                let modeLabel = 'ADB Interface';
                if (devMode === 'recovery') modeLabel = 'Recovery Mode';
                else if (devMode === 'sideload') modeLabel = 'Sideload Mode';
                else if (devMode === 'unauthorized') modeLabel = 'Unauthorized';
                if (_lastUsbText === '' || !_lastUsbText.includes(devId)) {
                    try {
                        const brand = await window.api.runAdbCommand('shell getprop ro.product.brand');
                        const model = await window.api.runAdbCommand('shell getprop ro.product.model');
                        const b = (brand && brand.trim()) ? brand.trim().toUpperCase() : '';
                        const m = (model && model.trim()) ? model.trim() : '';
                        _lastUsbText = b ? (b + ' ' + m + ' ' + modeLabel + ' [' + devId + ']') : ('Android ' + modeLabel + ' [' + devId + ']');
                    } catch(e2) {
                        _lastUsbText = 'Android ' + modeLabel + ' [' + devId + ']';
                    }
                }
                usbStatus.textContent = _lastUsbText;
                usbStatus.style.color = '#69f0ae';
            } else {
                _lastUsbText = '';
                usbStatus.textContent = '- Waiting for devices -';
                usbStatus.style.color = '#ffa726';
            }
        }
        const comStatus = document.getElementById('console-com-status');
        if (comStatus) {
            const ports = await window.api.scanComPorts();
            if (ports && ports.length > 0) {
                const p = ports[0];
                comStatus.textContent = (p && p.name) ? p.name : (typeof p === 'string' ? p : '');
                comStatus.style.color = '#69f0ae';
            } else {
                comStatus.textContent = '- Waiting for COM ports -';
                comStatus.style.color = '#ffa726';
            }
        }
    } catch(e) {}
}, 3000);

    // Settings logic
    const btnSettings = document.getElementById('btn-settings');
    const settingsModal = document.getElementById('settings-modal');
    const btnSettingsX = document.getElementById('btn-settings-x');
    const btnSettingsCancel = document.getElementById('btn-settings-cancel');
    const btnSettingsSave = document.getElementById('btn-settings-save');
    const inputWinWidth = document.getElementById('input-win-width');
    const inputWinHeight = document.getElementById('input-win-height');

    if (btnSettings && settingsModal) {
        btnSettings.addEventListener('click', () => {
            inputWinWidth.value = window.outerWidth;
            inputWinHeight.value = window.outerHeight;
            settingsModal.classList.remove('hidden');
        });

        // Update values in real-time if user resizes while modal is open
        window.addEventListener('resize', () => {
            if (!settingsModal.classList.contains('hidden')) {
                inputWinWidth.value = window.outerWidth;
                inputWinHeight.value = window.outerHeight;
            }
        });

        const closeSettings = () => settingsModal.classList.add('hidden');
        if (btnSettingsX) btnSettingsX.addEventListener('click', closeSettings);
        if (btnSettingsCancel) btnSettingsCancel.addEventListener('click', closeSettings);

        if (btnSettingsSave) {
            btnSettingsSave.addEventListener('click', async () => {
                const w = parseInt(inputWinWidth.value);
                const h = parseInt(inputWinHeight.value);
                if (w >= 400 && h >= 400) {
                    btnSettingsSave.textContent = currentLang === 'th' ? 'กำลังบันทึก...' : 'Saving...';
                    await window.api.saveSettings({ width: w, height: h });
                    btnSettingsSave.textContent = currentLang === 'th' ? 'บันทึกแล้ว!' : 'Saved!';
                    setTimeout(() => {
                        btnSettingsSave.textContent = currentLang === 'th' ? 'บันทึก' : 'Save';
                        closeSettings();
                    }, 500);
                } else {
                    alert(currentLang === 'th' ? 'ขนาดเล็กเกินไป (ขั้นต่ำ 400)' : 'Size too small (Min 400)');
                }
            });
        }
    }
    // --- Odin Flasher Logic ---
    const odinBtnBl = document.getElementById('odin-btn-bl');
    const odinBtnAp = document.getElementById('odin-btn-ap');
    const odinBtnCp = document.getElementById('odin-btn-cp');
    const odinBtnCsc = document.getElementById('odin-btn-csc');
    const odinBtnUserdata = document.getElementById('odin-btn-userdata');

    const odinPathBl = document.getElementById('odin-path-bl');
    const odinPathAp = document.getElementById('odin-path-ap');
    const odinPathCp = document.getElementById('odin-path-cp');
    const odinPathCsc = document.getElementById('odin-path-csc');
    const odinPathUserdata = document.getElementById('odin-path-userdata');

    const odinChkBl = document.getElementById('odin-chk-bl');
    const odinChkAp = document.getElementById('odin-chk-ap');
    const odinChkCp = document.getElementById('odin-chk-cp');
    const odinChkCsc = document.getElementById('odin-chk-csc');
    const odinChkUserdata = document.getElementById('odin-chk-userdata');

    const odinLog = document.getElementById('odin-log');
    const odinProgressPct = document.getElementById('odin-progress-pct');
    const odinProgressLabel = document.getElementById('odin-progress-label');
    const odinProgressBar = document.getElementById('odin-progress-bar');
    const odinBtnStart = document.getElementById('odin-btn-start');
    const odinBtnReset = document.getElementById('odin-btn-reset');

    function writeOdinLog(msg, color = '#ccc') {
        if (!odinLog) return;
        const d = document.createElement('div');
        d.style.color = color;
        d.textContent = msg;
        odinLog.appendChild(d);
        odinLog.scrollTop = odinLog.scrollHeight;
    }

    async function handleOdinBrowse(type, pathInput, chkInput) {
        try {
            const filePath = await window.api.browseOdinFile(type);
            if (filePath) {
                pathInput.value = filePath;
                chkInput.checked = true;
                writeOdinLog(`<OSM> Added ${type.toUpperCase()} file: ${filePath.split('\\').pop()}`, '#aaa');
            }
        } catch (e) {
            console.error(e);
        }
    }

    if (odinBtnBl) odinBtnBl.addEventListener('click', () => handleOdinBrowse('bl', odinPathBl, odinChkBl));
    if (odinBtnAp) odinBtnAp.addEventListener('click', () => handleOdinBrowse('ap', odinPathAp, odinChkAp));
    if (odinBtnCp) odinBtnCp.addEventListener('click', () => handleOdinBrowse('cp', odinPathCp, odinChkCp));
    if (odinBtnCsc) odinBtnCsc.addEventListener('click', () => handleOdinBrowse('csc', odinPathCsc, odinChkCsc));
    if (odinBtnUserdata) odinBtnUserdata.addEventListener('click', () => handleOdinBrowse('userdata', odinPathUserdata, odinChkUserdata));

    if (odinBtnReset) {
        odinBtnReset.addEventListener('click', () => {
            [odinPathBl, odinPathAp, odinPathCp, odinPathCsc, odinPathUserdata].forEach(i => i.value = '');
            [odinChkBl, odinChkAp, odinChkCp, odinChkCsc, odinChkUserdata].forEach(i => i.checked = false);
            odinLog.innerHTML = '';
            odinProgressBar.style.width = '0%';
            odinProgressPct.textContent = '0%';
            odinProgressLabel.textContent = 'Idle';
            document.getElementById('odin-com-status').textContent = '[ ]';
            document.getElementById('odin-com-status').style.color = '#fff';
        });
    }

    if (odinBtnStart) {
        odinBtnStart.addEventListener('click', async () => {
            let filesToFlash = [];
            if (odinChkBl.checked && odinPathBl.value) filesToFlash.push('BL');
            if (odinChkAp.checked && odinPathAp.value) filesToFlash.push('AP');
            if (odinChkCp.checked && odinPathCp.value) filesToFlash.push('CP');
            if (odinChkCsc.checked && odinPathCsc.value) filesToFlash.push('CSC');
            if (odinChkUserdata.checked && odinPathUserdata.value) filesToFlash.push('USERDATA');

            if (filesToFlash.length === 0) {
                alert(currentLang === 'th' ? 'กรุณาเลือกไฟล์อย่างน้อย 1 ไฟล์ (AP, BL, CP, CSC)' : 'Please select at least one firmware file to flash.');
                return;
            }

            // Real Flashing process
            odinBtnStart.disabled = true;
            odinLog.innerHTML = '';
            writeOdinLog('<OSM> Initializing Heimdall engine...', '#aaa');
            odinProgressLabel.textContent = 'Preparing...';
            odinProgressPct.textContent = '0%';
            odinProgressBar.style.width = '0%';

            // Map frontend inputs to an array of objects
            const realFiles = [];
            if (odinChkBl.checked && odinPathBl.value) realFiles.push({ type: 'BL', path: odinPathBl.value });
            if (odinChkAp.checked && odinPathAp.value) realFiles.push({ type: 'AP', path: odinPathAp.value });
            if (odinChkCp.checked && odinPathCp.value) realFiles.push({ type: 'CP', path: odinPathCp.value });
            if (odinChkCsc.checked && odinPathCsc.value) realFiles.push({ type: 'CSC', path: odinPathCsc.value });
            if (odinChkUserdata.checked && odinPathUserdata.value) realFiles.push({ type: 'USERDATA', path: odinPathUserdata.value });

            try {
                const success = await window.api.runOdinFlash(realFiles);
                if (success) {
                    odinProgressLabel.textContent = 'PASS!';
                    odinProgressLabel.style.color = '#00c853';
                    odinProgressBar.style.width = '100%';
                    odinProgressPct.textContent = '100%';
                    document.getElementById('odin-com-status').textContent = 'PASS!';
                } else {
                    odinProgressLabel.textContent = 'FAILED';
                    odinProgressLabel.style.color = '#ff5252';
                    document.getElementById('odin-com-status').textContent = 'FAIL';
                }
            } catch (e) {
                writeOdinLog('<OSM> Internal error: ' + e.message, '#ff5252');
            }
            
            odinBtnStart.disabled = false;
        });
    }

    const odinBtnZadig = document.getElementById('odin-btn-zadig');
    if (odinBtnZadig) {
        odinBtnZadig.addEventListener('click', () => {
            window.api.openZadig();
        });
    }

    // Official Samsung Odin3 Integration
    const odinBtnLaunchOfficial = document.getElementById('odin-btn-launch-official');
    const odinBtnQuickOfficial = document.getElementById('odin-btn-quick-official');

    const handleLaunchOfficialOdin = async () => {
        writeOdinLog('<OSM> กำลังเปิดโปรแกรม Official Samsung Odin3 (v3.14.1)...', '#38bdf8');
        const candidateTar = (odinPathAp && odinPathAp.value) ? odinPathAp.value : null;
        try {
            const res = await window.api.launchOfficialOdin(candidateTar);
            if (res && res.success) {
                writeOdinLog('<OSM> ✔ เปิด Official Samsung Odin3 เรียบร้อยแล้ว!', '#00c853');
                if (res.tarPath) {
                    writeOdinLog(`<OSM> 📋 คัดลอก Path ไฟล์แฟลชลง Clipboard ให้แล้ว:`, '#ffd740');
                    writeOdinLog(`      ${res.tarPath}`, '#fff');
                    writeOdinLog('<OSM> 📌 วิธีแฟลชง่ายๆ 3 ขั้นตอน:', '#00e5ff');
                    writeOdinLog('  1. เช็คใน Odin3 ช่อง ID:COM จะขึ้นแถบสีฟ้าอ่อน (เช่น 0:[COM...])', '#cbd5e1');
                    writeOdinLog('  2. คลิกปุ่ม [ AP ] ในโปรแกรม Odin3 แล้วเลือกไฟล์ (.tar) ที่ต้องการแฟลช', '#cbd5e1');
                    writeOdinLog('  3. กดปุ่ม [ Start ] ใน Odin3 รอมือถือรีบูต เสร็จสมบูรณ์ทันที!', '#69f0ae');
                } else {
                    writeOdinLog('<OSM> 📌 ตรวจสอบช่อง ID:COM ใน Odin3 แล้วกดเลือกไฟล์เพื่อแฟลชได้เลย', '#cbd5e1');
                }
            } else {
                writeOdinLog('<OSM> ไม่สามารถเปิด Odin3: ' + (res ? res.error : 'Unknown error'), '#ff5252');
            }
        } catch (err) {
            writeOdinLog('<OSM> เกิดข้อผิดพลาด: ' + err.message, '#ff5252');
        }
    };

    if (odinBtnLaunchOfficial) odinBtnLaunchOfficial.addEventListener('click', handleLaunchOfficialOdin);
    if (odinBtnQuickOfficial) odinBtnQuickOfficial.addEventListener('click', handleLaunchOfficialOdin);

    if (window.api.onOdinLog) {
        window.api.onOdinLog((msg, color) => {
            writeOdinLog(msg, color);
            
            let currentWidth = parseFloat(odinProgressBar.style.width) || 0;
            if (currentWidth < 90) {
                currentWidth += 2;
                odinProgressBar.style.width = currentWidth + '%';
                odinProgressPct.textContent = Math.round(currentWidth) + '%';
            }
        });
    }

    // Samsung 350K 1-Click Tool Integration
    const odinBtnRebootDl = document.getElementById('odin-btn-reboot-dl');
    const odinBtnRebootPhone = document.getElementById('odin-btn-reboot-phone');
    const odinBtnScanSam = document.getElementById('odin-btn-scan-sam');
    const odinSamPortStatus = document.getElementById('odin-sam-port-status');

    async function checkSamsungModemPort(showLog = false) {
        try {
            if (odinSamPortStatus) odinSamPortStatus.textContent = 'Scanning...';
            const res = await window.api.samsung350kScan();
            if (res && res.best_samsung) {
                const p = res.best_samsung;
                const label = p.mode === 'download' ? 'Download Mode' : (p.mode === 'preloader' ? 'MTK Preloader' : 'Samsung Modem');
                if (odinSamPortStatus) {
                    odinSamPortStatus.textContent = `${p.port} (${label})`;
                    odinSamPortStatus.style.color = '#00e676';
                }
                if (showLog) writeOdinLog(`<OSM> Detected: ${p.port} - ${p.description}`, '#00e676');
                return p.port;
            } else {
                if (odinSamPortStatus) {
                    odinSamPortStatus.textContent = 'Modem: Not Connected';
                    odinSamPortStatus.style.color = '#ff9800';
                }
                if (showLog) writeOdinLog('<OSM> Samsung port not detected. Connect device via USB.', '#ff9800');
                return null;
            }
        } catch (err) {
            if (odinSamPortStatus) {
                odinSamPortStatus.textContent = 'Modem: Auto';
                odinSamPortStatus.style.color = '#aaa';
            }
            return null;
        }
    }

    if (odinBtnScanSam) {
        odinBtnScanSam.addEventListener('click', () => checkSamsungModemPort(true));
    }

    if (window.api.onSamsung350kLog) {
        window.api.onSamsung350kLog((line) => {
            let color = '#ccc';
            if (line.includes('Done')) color = '#00e676';
            else if (line.includes('Not found') || line.includes('Error')) color = '#ff5252';
            else if (line.includes('Connecting') || line.includes('SAMSUNG Mobile')) color = '#00e5ff';
            else if (line.includes('Scanning')) color = '#9e9e9e';
            writeOdinLog(`<OSM> ${line}`, color);
        });
    }

    if (odinBtnRebootDl) {
        odinBtnRebootDl.addEventListener('click', async () => {
            odinLog.innerHTML = '';
            writeOdinLog('<OSM> === Samsung 350K: Enter Download Mode ===', '#00e5ff');
            odinBtnRebootDl.disabled = true;
            try {
                const res = await window.api.samsung350kAction({ action: 'download' });
                if (res.success) {
                    writeOdinLog('<OSM> Success! Device switching to Download Mode...', '#00e676');
                } else {
                    writeOdinLog('<OSM> Device not responding. Make sure USB cable is plugged in.', '#ffa726');
                    writeOdinLog('<OSM> 💡 คำแนะนำ: ในโทรศัพท์กด *#0*# ในหน้าโทรฉุกเฉินเพื่อปลดล็อกพอร์ต หรือ ปิดเครื่องแล้วกด Vol Up + Vol Down ค้างไว้แล้วเสียบสาย USB', '#ffca28');
                }

            } catch (e) {
                if (e.message && e.message.includes('No handler registered')) {
                    writeOdinLog('<OSM> ⚠️ กรุณาปิดโปรแกรมแล้วเปิดใหม่อีกครั้ง (Restart App) เพื่อให้ระบบโหลดคำสั่งใหม่', '#ffca28');
                } else {
                    writeOdinLog('<OSM> Error: ' + e.message, '#ff5252');
                }
            } finally {
                odinBtnRebootDl.disabled = false;
                setTimeout(checkSamsungModemPort, 2000);
            }
        });
    }

    if (odinBtnRebootPhone) {
        odinBtnRebootPhone.addEventListener('click', async () => {
            odinLog.innerHTML = '';
            writeOdinLog('<OSM> === Samsung 350K: Reboot Phone ===', '#29b6f6');
            odinBtnRebootPhone.disabled = true;
            try {
                const res = await window.api.samsung350kAction({ action: 'reboot' });
                if (res.success) {
                    writeOdinLog('<OSM> Success! Device reboot command sent...', '#00e676');
                } else {
                    writeOdinLog('<OSM> Device not responding. Make sure USB cable is plugged in.', '#ffa726');
                }
            } catch (e) {
                if (e.message && e.message.includes('No handler registered')) {
                    writeOdinLog('<OSM> ⚠️ กรุณาปิดโปรแกรมแล้วเปิดใหม่อีกครั้ง (Restart App) เพื่อให้ระบบโหลดคำสั่งใหม่', '#ffca28');
                } else {
                    writeOdinLog('<OSM> Error: ' + e.message, '#ff5252');
                }
            } finally {
                odinBtnRebootPhone.disabled = false;
                setTimeout(checkSamsungModemPort, 2000);
            }
        });
    }


    // Poll Odin connection status
    let odinIsConnected = false;
    let odinCurrentPort = null;
    let odinCurrentMode = null;

    setInterval(async () => {
        // Only poll if odin-section is active (display is block)
        const odinSection = document.getElementById('odin-section');
        if (odinSection && odinSection.style.display !== 'none') {
            try {
                const res = await window.api.checkOdinConnection();
                const isConn = res && (typeof res === 'boolean' ? res : !!res.connected);
                const port = (res && res.port) ? res.port : 'COM';
                const pNum = (res && res.portNumber) ? res.portNumber : port.replace(/\D/g, '') || '0';
                const mode = (res && res.mode) ? res.mode : 'download';
                const desc = (res && res.description) ? res.description : '';

                const comCard = document.getElementById('odin-com-card');
                const comStatus = document.getElementById('odin-com-status');
                const comDesc = document.getElementById('odin-com-desc');

                if (isConn) {
                    const statusChanged = !odinIsConnected || odinCurrentPort !== port || odinCurrentMode !== mode;
                    odinIsConnected = true;
                    odinCurrentPort = port;
                    odinCurrentMode = mode;

                    if (comStatus) {
                        comStatus.textContent = `0:[${port}]`;
                        comStatus.style.color = '#ffffff';
                    }

                    if (mode === 'download') {
                        if (comCard) {
                            comCard.style.background = 'linear-gradient(135deg, #0284c7 0%, #00bcd4 100%)';
                            comCard.style.border = '1px solid #38bdf8';
                            comCard.style.boxShadow = '0 0 15px rgba(0, 188, 212, 0.4)';
                        }
                        if (comDesc) {
                            comDesc.textContent = '⚡ Download Mode Ready';
                            comDesc.style.color = '#e0f7fa';
                        }
                        if (statusChanged) {
                            writeOdinLog(`<OSM> <ID:0/${pNum}> Added!! Device ready in Download Mode.`, '#00e5ff');
                        }
                    } else if (mode === 'modem') {
                        if (comCard) {
                            comCard.style.background = 'linear-gradient(135deg, #0369a1 0%, #0284c7 100%)';
                            comCard.style.border = '1px solid #0ea5e9';
                            comCard.style.boxShadow = '0 0 15px rgba(2, 132, 199, 0.35)';
                        }
                        if (comDesc) {
                            comDesc.textContent = '📱 Samsung Modem Ready';
                            comDesc.style.color = '#bae6fd';
                        }
                        if (statusChanged) {
                            writeOdinLog(`<OSM> <ID:0/${pNum}> Added!! ${desc || 'SAMSUNG Mobile USB Modem'} (${port}).`, '#38bdf8');
                            writeOdinLog('<OSM> 💡 คำแนะนำ: กดปุ่ม [ 📱 Enter Download Mode ] หรือใช้วิธีกดปุ่มเพื่อเข้า Download Mode ก่อนเริ่มแฟลช', '#facc15');
                        }
                    } else if (mode === 'preloader') {
                        if (comCard) {
                            comCard.style.background = 'linear-gradient(135deg, #d97706 0%, #b45309 100%)';
                            comCard.style.border = '1px solid #f59e0b';
                            comCard.style.boxShadow = '0 0 15px rgba(245, 158, 11, 0.3)';
                        }
                        if (comDesc) {
                            comDesc.textContent = '⚡ MTK Preloader Port';
                            comDesc.style.color = '#fef3c7';
                        }
                        if (statusChanged) {
                            writeOdinLog(`<OSM> <ID:0/${pNum}> Added!! MediaTek Preloader Port (${port}).`, '#f59e0b');
                        }
                    } else {
                        if (comCard) {
                            comCard.style.background = 'linear-gradient(135deg, #1e293b 0%, #334155 100%)';
                            comCard.style.border = '1px solid #64748b';
                            comCard.style.boxShadow = 'none';
                        }
                        if (comDesc) {
                            comDesc.textContent = desc || port;
                            comDesc.style.color = '#94a3b8';
                        }
                        if (statusChanged) {
                            writeOdinLog(`<OSM> <ID:0/${pNum}> Added!! Device connected (${port}).`, '#94a3b8');
                        }
                    }

                    // Keep Samsung 350K status bar synchronized
                    if (odinSamPortStatus) {
                        const label = mode === 'download' ? 'Download Mode' : (mode === 'preloader' ? 'MTK Preloader' : 'Samsung Modem');
                        odinSamPortStatus.textContent = `${port} (${label})`;
                        odinSamPortStatus.style.color = '#00e676';
                    }
                } else if (!isConn && odinIsConnected) {
                    const lastPNum = odinCurrentPort ? odinCurrentPort.replace(/\D/g, '') || '0' : '0';
                    odinIsConnected = false;
                    odinCurrentPort = null;
                    odinCurrentMode = null;

                    if (comStatus) {
                        comStatus.textContent = '[ ]';
                        comStatus.style.color = '#94a3b8';
                    }
                    if (comCard) {
                        comCard.style.background = 'rgba(255, 255, 255, 0.03)';
                        comCard.style.border = '1px solid rgba(255, 255, 255, 0.1)';
                        comCard.style.boxShadow = 'none';
                    }
                    if (comDesc) {
                        comDesc.textContent = 'No device';
                        comDesc.style.color = '#64748b';
                    }
                    writeOdinLog(`<OSM> <ID:0/${lastPNum}> Removed!!`, '#aaa');

                    if (odinSamPortStatus) {
                        odinSamPortStatus.textContent = 'Modem: Not Connected';
                        odinSamPortStatus.style.color = '#ff9800';
                    }
                }
            } catch (e) {
                // Ignore silent errors during polling
            }
        }
    }, 2000);

    const btnApplyRm = document.getElementById('btn-apply-rm');
    if (btnApplyRm) {
        btnApplyRm.addEventListener('click', async () => {
            const originalText = btnApplyRm.textContent;
            btnApplyRm.textContent = 'Applying...';
            btnApplyRm.disabled = true;
            try {
                const success = await window.api.applyRainmeterSkins();
                if (success) {
                    btnApplyRm.textContent = 'Applied & Refreshed!';
                    btnApplyRm.style.background = '#00c853';
                } else {
                    btnApplyRm.textContent = 'Failed';
                    btnApplyRm.style.background = '#ff5252';
                }
            } catch (e) {
                btnApplyRm.textContent = 'Error';
            }
            setTimeout(() => {
                btnApplyRm.textContent = originalText;
                btnApplyRm.style.background = '';
                btnApplyRm.disabled = false;
            }, 3000);
        });
    }

    const btnDlRm = document.getElementById('btn-dl-rm');
    if (btnDlRm) {
        btnDlRm.addEventListener('click', () => {
            window.api.downloadRainmeter();
        });
    }

    const btnApplyRmFull = document.getElementById('btn-apply-rm-full');
    if (btnApplyRmFull) {
        btnApplyRmFull.addEventListener('click', async () => {
            const originalText = btnApplyRmFull.textContent;
            btnApplyRmFull.textContent = 'Applying...';
            btnApplyRmFull.disabled = true;
            try {
                const success = await window.api.applyRainmeterFull();
                if (success) {
                    btnApplyRmFull.textContent = 'Applied & Refreshed!';
                    btnApplyRmFull.style.background = '#00c853';
                } else {
                    btnApplyRmFull.textContent = 'Failed';
                    btnApplyRmFull.style.background = '#ff5252';
                }
            } catch (e) {
                btnApplyRmFull.textContent = 'Error';
            }
            setTimeout(() => {
                btnApplyRmFull.textContent = originalText;
                btnApplyRmFull.style.background = '';
                btnApplyRmFull.disabled = false;
            }, 3000);
        });
    }

    // ============================================================
    // ROM & FIRMWARE WORKSTATION LOGIC
    // ============================================================
    (function initRomWorkstation() {
        const romSection = document.getElementById('rom-section');
        if (!romSection) return;

        // Subtab Navigation
        const subtabBtns = document.querySelectorAll('.rom-subtab-btn');
        const subtabContents = document.querySelectorAll('.rom-subtab-content');

        function switchRomSubtab(targetId) {
            subtabBtns.forEach(b => {
                if (b.dataset.subtab === targetId) {
                    b.classList.add('active');
                    b.style.background = '#3b82f6';
                    b.style.color = '#fff';
                    b.style.fontWeight = '600';
                } else {
                    b.classList.remove('active');
                    b.style.background = 'transparent';
                    b.style.color = '#94a3b8';
                    b.style.fontWeight = '500';
                }
            });
            subtabContents.forEach(c => {
                c.style.display = (c.id === targetId) ? 'block' : 'none';
            });

            // Auto-fetch Apple devices if switching to Apple tab and empty
            if (targetId === 'rom-tab-apple') {
                if (typeof ensureAppleDevicesLoaded === 'function') ensureAppleDevicesLoaded();
                if (typeof refreshConnectedIosDevice === 'function') refreshConnectedIosDevice();
                if (typeof startIosPolling === 'function') startIosPolling();
            } else {
                if (typeof stopIosPolling === 'function') stopIosPolling();
            }
        }

        subtabBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                switchRomSubtab(btn.dataset.subtab);
            });
        });

        // ------------------------------------------------------------
        // 1. In-App Download Manager & Streaming Engine
        // ------------------------------------------------------------
        let configuredSaveDir = '';
        const activeDownloads = new Map(); // id -> item
        const downloadHistory = [];

        const romDlDestPath = document.getElementById('rom-dl-dest-path');
        const btnRomChangeDest = document.getElementById('btn-rom-change-dest');
        const btnRomOpenDest = document.getElementById('btn-rom-open-dest');
        const romActiveCardContainer = document.getElementById('rom-active-dl-card-container');
        const romNoActiveDownloads = document.getElementById('rom-no-active-downloads');
        const romActiveTasksCount = document.getElementById('rom-active-tasks-count');
        const romStatusLed = document.getElementById('rom-status-led');
        const romStatusText = document.getElementById('rom-status-text');
        const romActiveBadge = document.getElementById('rom-active-badge');
        const romDlHistoryContainer = document.getElementById('rom-dl-history-container');
        const btnClearDlHistory = document.getElementById('btn-clear-dl-history');

        if (romDlDestPath) {
            configuredSaveDir = '';
            romDlDestPath.value = 'กำลังตรวจสอบโฟลเดอร์ดาวน์โหลด...';
        }

        async function initStoragePath() {
            try {
                if (window.api && window.api.getDefaultDownloadsDir) {
                    const defaultPath = await window.api.getDefaultDownloadsDir();
                    if (defaultPath) {
                        configuredSaveDir = defaultPath;
                        if (romDlDestPath) {
                            romDlDestPath.value = defaultPath;
                        }
                    }
                }
            } catch (e) {
                console.error('Failed to get default downloads dir:', e);
            }
            if (!configuredSaveDir && romDlDestPath) {
                romDlDestPath.value = 'Downloads';
            }
        }
        initStoragePath();

        if (btnRomChangeDest) {
            btnRomChangeDest.addEventListener('click', async () => {
                if (!window.api || !window.api.browseSaveFolder) return;
                const chosen = await window.api.browseSaveFolder();
                if (chosen) {
                    configuredSaveDir = chosen;
                    romDlDestPath.value = chosen;
                }
            });
        }

        if (btnRomOpenDest) {
            btnRomOpenDest.addEventListener('click', async () => {
                const origHtml = btnRomOpenDest.innerHTML;
                btnRomOpenDest.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังเปิด...';
                try {
                    if (window.api && window.api.openFileLocation) {
                        const target = configuredSaveDir || (romDlDestPath && romDlDestPath.value && romDlDestPath.value !== 'Downloads' && !romDlDestPath.value.includes('...') ? romDlDestPath.value : '');
                        const res = await window.api.openFileLocation(target);
                        if (res && res.success) {
                            btnRomOpenDest.innerHTML = '<i class="fas fa-check" style="color: #22c55e;"></i> เปิดแล้ว!';
                        } else {
                            btnRomOpenDest.innerHTML = '<i class="fas fa-folder-open"></i> เปิดโฟลเดอร์';
                        }
                    }
                } catch (err) {
                    console.error('Error opening save destination:', err);
                }
                setTimeout(() => {
                    btnRomOpenDest.innerHTML = origHtml;
                }, 1500);
            });
        }

        function formatBytes(bytes) {
            if (!bytes || bytes === 0) return '0 B';
            const k = 1024;
            const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        }

        function updateTopStatus() {
            const activeCount = [...activeDownloads.values()].filter(d => d.status === 'downloading').length;
            if (romActiveBadge) {
                if (activeCount > 0) {
                    romActiveBadge.textContent = activeCount;
                    romActiveBadge.style.display = 'inline-block';
                } else {
                    romActiveBadge.style.display = 'none';
                }
            }
            if (romActiveTasksCount) {
                romActiveTasksCount.textContent = `${activeCount} กำลังทำงาน`;
            }
            if (romStatusLed && romStatusText) {
                if (activeCount > 0) {
                    romStatusLed.style.color = '#38bdf8';
                    romStatusText.textContent = `กำลังดาวน์โหลด (${activeCount} ไฟล์)...`;
                } else {
                    romStatusLed.style.color = '#22c55e';
                    romStatusText.textContent = 'พร้อมใช้งาน (Idle)';
                }
            }
        }

        function renderActiveCard(item) {
            let card = document.getElementById(`dl-card-${item.id}`);
            if (!card) {
                card = document.createElement('div');
                card.id = `dl-card-${item.id}`;
                card.style.background = 'rgba(15, 23, 42, 0.7)';
                card.style.border = '1px solid rgba(255, 255, 255, 0.1)';
                card.style.borderRadius = '10px';
                card.style.padding = '14px 16px';
                card.style.display = 'flex';
                card.style.flexDirection = 'column';
                card.style.gap = '10px';
                if (romActiveCardContainer) {
                    romActiveCardContainer.appendChild(card);
                }
            }

            if (romNoActiveDownloads) romNoActiveDownloads.style.display = 'none';

            let statusBadge = `<span style="font-size: 11px; background: rgba(56,189,248,0.2); color: #38bdf8; padding: 2px 8px; border-radius: 4px;">กำลังโหลด</span>`;
            if (item.status === 'completed') {
                statusBadge = `<span style="font-size: 11px; background: rgba(34,197,94,0.2); color: #22c55e; padding: 2px 8px; border-radius: 4px; font-weight: 600;">สำเร็จ (Done)</span>`;
            } else if (item.status === 'error') {
                statusBadge = `<span style="font-size: 11px; background: rgba(239,68,68,0.2); color: #ef4444; padding: 2px 8px; border-radius: 4px; font-weight: 600;">ล้มเหลว</span>`;
            } else if (item.status === 'cancelled') {
                statusBadge = `<span style="font-size: 11px; background: rgba(148,163,184,0.2); color: #94a3b8; padding: 2px 8px; border-radius: 4px;">ยกเลิกแล้ว</span>`;
            }

            const transferredText = item.total > 0 ? `${formatBytes(item.downloaded)} / ${formatBytes(item.total)}` : formatBytes(item.downloaded);

            let actionButtons = '';
            if (item.status === 'downloading') {
                actionButtons = `
                    <button class="action-btn danger-btn btn-dl-cancel" data-id="${item.id}" style="padding: 6px 12px; font-size: 11px;">
                        <i class="fas fa-stop"></i> ยกเลิก
                    </button>
                `;
            } else if (item.status === 'completed') {
                actionButtons = `
                    <button class="action-btn safe-btn btn-dl-openfile" data-path="${item.savePath || ''}" style="padding: 6px 12px; font-size: 11px;">
                        <i class="fas fa-play"></i> เปิดไฟล์
                    </button>
                    <button class="action-btn btn-dl-openfolder" data-path="${item.savePath || ''}" style="padding: 6px 12px; font-size: 11px; background: rgba(255,255,255,0.08); color: #fff;">
                        <i class="fas fa-folder"></i> แสดงในโฟลเดอร์
                    </button>
                `;
            }

            card.innerHTML = `
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div style="display: flex; align-items: center; gap: 8px; overflow: hidden; max-width: 75%;">
                        <i class="fas fa-file-arrow-down" style="color: #a78bfa; font-size: 14px;"></i>
                        <span style="font-weight: 600; font-size: 13px; color: #f8fafc; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${item.filename}">${item.filename}</span>
                    </div>
                    <div>${statusBadge}</div>
                </div>

                <div style="width: 100%; height: 7px; background: rgba(0,0,0,0.4); border-radius: 4px; overflow: hidden;">
                    <div style="width: ${item.percent}%; height: 100%; background: ${item.status === 'completed' ? '#22c55e' : (item.status === 'error' ? '#ef4444' : 'linear-gradient(90deg, #3b82f6, #a78bfa)')}; transition: width 0.2s linear;"></div>
                </div>

                <div style="display: flex; justify-content: space-between; align-items: center; font-size: 11px; color: #94a3b8; flex-wrap: wrap; gap: 8px;">
                    <div style="display: flex; gap: 12px; align-items: center;">
                        <span style="color: #38bdf8; font-weight: 700;">${item.percent}%</span>
                        <span>${transferredText}</span>
                        ${item.status === 'downloading' ? `<span>⚡ ${item.speed || '0.00 MB/s'}</span> <span>⏳ เหลือ ~${item.eta || '--'}</span>` : ''}
                        ${item.error ? `<span style="color: #ef4444;">${item.error}</span>` : ''}
                    </div>
                    <div style="display: flex; gap: 6px;">
                        ${actionButtons}
                    </div>
                </div>
            `;

            const cancelBtn = card.querySelector('.btn-dl-cancel');
            if (cancelBtn) {
                cancelBtn.addEventListener('click', () => {
                    if (window.api && window.api.cancelFileDownload) {
                        window.api.cancelFileDownload(item.id);
                    }
                });
            }

            const openFileBtn = card.querySelector('.btn-dl-openfile');
            if (openFileBtn) {
                openFileBtn.addEventListener('click', async () => {
                    const orig = openFileBtn.innerHTML;
                    openFileBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังเปิด...';
                    if (window.api && window.api.openFile) {
                        const res = await window.api.openFile(openFileBtn.dataset.path);
                        if (!res || !res.success) {
                            if (window.api.openFileLocation) {
                                await window.api.openFileLocation(openFileBtn.dataset.path);
                            }
                        }
                    }
                    setTimeout(() => { openFileBtn.innerHTML = orig; }, 1200);
                });
            }

            const openFolderBtn = card.querySelector('.btn-dl-openfolder');
            if (openFolderBtn) {
                openFolderBtn.addEventListener('click', async () => {
                    const orig = openFolderBtn.innerHTML;
                    openFolderBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังเปิด...';
                    if (window.api && window.api.openFileLocation) {
                        await window.api.openFileLocation(openFolderBtn.dataset.path);
                    }
                    setTimeout(() => { openFolderBtn.innerHTML = orig; }, 1200);
                });
            }
        }

        async function triggerFileDownload(url, filename) {
            if (!url) {
                alert('กรุณาระบุ URL ที่ต้องการดาวน์โหลด');
                return;
            }

            const dlId = 'dl_' + Date.now() + '_' + Math.floor(Math.random() * 1000);
            const initialItem = {
                id: dlId,
                filename: filename || url.split('/').pop() || 'firmware_download.bin',
                url,
                savePath: '',
                percent: 0,
                speed: '0.00 MB/s',
                eta: '--',
                downloaded: 0,
                total: 0,
                status: 'downloading'
            };

            activeDownloads.set(dlId, initialItem);
            switchRomSubtab('rom-tab-downloader');
            renderActiveCard(initialItem);
            updateTopStatus();

            try {
                if (window.api && window.api.startFileDownload) {
                    const res = await window.api.startFileDownload({
                        id: dlId,
                        url,
                        filename: initialItem.filename,
                        saveDir: configuredSaveDir
                    });

                    if (!res || !res.success) {
                        initialItem.status = 'error';
                        initialItem.error = (res && res.error) ? res.error : 'Failed to start download';
                        renderActiveCard(initialItem);
                        updateTopStatus();
                    } else {
                        initialItem.savePath = res.savePath;
                    }
                }
            } catch (err) {
                initialItem.status = 'error';
                initialItem.error = err.message;
                renderActiveCard(initialItem);
                updateTopStatus();
            }
        }

        if (window.api && window.api.onDownloadProgress) {
            window.api.onDownloadProgress((data) => {
                const item = activeDownloads.get(data.id);
                if (item) {
                    item.percent = data.percent;
                    item.downloaded = data.downloadedBytes;
                    item.total = data.totalBytes;
                    item.speed = data.speed;
                    item.eta = data.eta;
                    item.status = data.status || 'downloading';
                    renderActiveCard(item);
                    updateTopStatus();
                }
            });
        }

        if (window.api && window.api.onDownloadComplete) {
            window.api.onDownloadComplete((data) => {
                const item = activeDownloads.get(data.id);
                if (item) {
                    item.status = data.status || (data.success ? 'completed' : 'error');
                    if (data.filePath) item.savePath = data.filePath;
                    if (data.filename) item.filename = data.filename;
                    if (data.totalBytes) item.downloaded = data.totalBytes;
                    if (data.error) item.error = data.error;
                    if (data.success) item.percent = 100;
                    renderActiveCard(item);
                    updateTopStatus();

                    downloadHistory.unshift({
                        filename: item.filename,
                        savePath: item.savePath,
                        status: item.status,
                        time: new Date().toLocaleTimeString(),
                        size: item.total || item.downloaded
                    });
                    renderHistory();
                }
            });
        }

        function renderHistory() {
            if (!romDlHistoryContainer) return;
            romDlHistoryContainer.innerHTML = '';
            if (downloadHistory.length === 0) {
                romDlHistoryContainer.innerHTML = '<div style="text-align: center; padding: 14px;">ยังไม่มีประวัติการดาวน์โหลด</div>';
                return;
            }
            downloadHistory.slice(0, 10).forEach(h => {
                const row = document.createElement('div');
                row.style.display = 'flex';
                row.style.justifyContent = 'space-between';
                row.style.alignItems = 'center';
                row.style.background = 'rgba(0,0,0,0.2)';
                row.style.padding = '8px 12px';
                row.style.borderRadius = '6px';
                row.style.border = '1px solid rgba(255,255,255,0.04)';
                row.innerHTML = `
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <i class="fas ${h.status === 'completed' ? 'fa-check-circle' : 'fa-times-circle'}" style="color: ${h.status === 'completed' ? '#22c55e' : '#ef4444'};"></i>
                        <span style="color: #e2e8f0; font-weight: 500;">${h.filename}</span>
                        <span style="color: #64748b; font-size: 10px;">(${formatBytes(h.size)})</span>
                    </div>
                    <div style="display: flex; gap: 8px; align-items: center;">
                        <span style="color: #64748b; font-size: 11px;">${h.time}</span>
                        ${h.status === 'completed' ? `<button class="action-btn btn-history-open" data-path="${h.savePath}" style="background: rgba(255,255,255,0.06); padding: 4px 8px; font-size: 10px; color: #38bdf8;">เปิดโฟลเดอร์</button>` : ''}
                    </div>
                `;
                const btn = row.querySelector('.btn-history-open');
                if (btn) {
                    btn.addEventListener('click', async () => {
                        const orig = btn.innerHTML;
                        btn.innerHTML = '<i class="fas fa-check" style="color: #22c55e;"></i> เปิดแล้ว';
                        if (window.api && window.api.openFileLocation) {
                            await window.api.openFileLocation(btn.dataset.path);
                        }
                        setTimeout(() => { btn.innerHTML = orig; }, 1200);
                    });
                }
                romDlHistoryContainer.appendChild(row);
            });
        }

        if (btnClearDlHistory) {
            btnClearDlHistory.addEventListener('click', () => {
                downloadHistory.length = 0;
                renderHistory();
            });
        }

        const btnStartCustomDl = document.getElementById('btn-start-custom-dl');
        const romCustomUrlInput = document.getElementById('rom-custom-url-input');
        const romCustomFilenameInput = document.getElementById('rom-custom-filename-input');

        if (btnStartCustomDl) {
            btnStartCustomDl.addEventListener('click', () => {
                const url = romCustomUrlInput ? romCustomUrlInput.value.trim() : '';
                const filename = romCustomFilenameInput ? romCustomFilenameInput.value.trim() : '';
                if (!url) {
                    alert('กรุณาระบุ URL ที่ถูกต้อง');
                    return;
                }
                triggerFileDownload(url, filename);
                if (romCustomUrlInput) romCustomUrlInput.value = '';
                if (romCustomFilenameInput) romCustomFilenameInput.value = '';
            });
        }

        // ------------------------------------------------------------
        // 2. Android Firmware Hub
        // ------------------------------------------------------------
        const romBrandDropdown = document.getElementById('rom-brand-dropdown');
        const romModelSearch = document.getElementById('rom-model-search');
        const romModelList = document.getElementById('rom-model-list');
        const androidSelectedBrandBadge = document.getElementById('android-selected-brand-badge');
        const androidSelectedChipBadge = document.getElementById('android-selected-chip-badge');
        const androidSelectedTitle = document.getElementById('android-selected-title');
        const androidSelectedCsc = document.getElementById('android-selected-csc');
        const androidTipsText = document.getElementById('android-tips-text');
        const btnPortalPrimary = document.getElementById('btn-portal-primary');
        const btnPortalPrimaryTitle = document.getElementById('btn-portal-primary-title');
        const btnPortalPrimaryDesc = document.getElementById('btn-portal-primary-desc');
        const btnPortalSecondary = document.getElementById('btn-portal-secondary');
        const btnPortalSecondaryTitle = document.getElementById('btn-portal-secondary-title');
        const btnPortalSecondaryDesc = document.getElementById('btn-portal-secondary-desc');
        const btnPortalFrp = document.getElementById('btn-portal-frp');
        const btnPortalRecovery = document.getElementById('btn-portal-recovery');
        const androidCountLabel = document.getElementById('android-count-label');

        const brandModelsDatabase = {
            'SAMSUNG': [
                'SM-S928B (Galaxy S24 Ultra)', 'SM-S926B (Galaxy S24+)', 'SM-S921B (Galaxy S24)',
                'SM-S918B (Galaxy S23 Ultra)', 'SM-S916B (Galaxy S23+)', 'SM-S911B (Galaxy S23)',
                'SM-S908B (Galaxy S22 Ultra)', 'SM-S906B (Galaxy S22+)', 'SM-S901B (Galaxy S22)',
                'SM-G998B (Galaxy S21 Ultra 5G)', 'SM-G996B (Galaxy S21+ 5G)', 'SM-G991B (Galaxy S21 5G)',
                'SM-G781B (Galaxy S20 FE 5G)', 'SM-G780G (Galaxy S20 FE LTE)',
                'SM-F946B (Galaxy Z Fold 5)', 'SM-F731B (Galaxy Z Flip 5)',
                'SM-F936B (Galaxy Z Fold 4)', 'SM-F721B (Galaxy Z Flip 4)',
                'SM-A556E (Galaxy A55 5G)', 'SM-A546E (Galaxy A54 5G)', 'SM-A536E (Galaxy A53 5G)', 'SM-A528B (Galaxy A52s 5G)', 'SM-A525F (Galaxy A52)', 'SM-A515F (Galaxy A51)', 'SM-A505F (Galaxy A50)',
                'SM-A356E (Galaxy A35 5G)', 'SM-A346E (Galaxy A34 5G)', 'SM-A336E (Galaxy A33 5G)', 'SM-A325F (Galaxy A32)', 'SM-A315F (Galaxy A31)', 'SM-A305F (Galaxy A30)',
                'SM-A256E (Galaxy A25 5G)', 'SM-A245F (Galaxy A24)', 'SM-A235F (Galaxy A23)', 'SM-A225F (Galaxy A22)', 'SM-A217F (Galaxy A21s)', 'SM-A205F (Galaxy A20)',
                'SM-A156E (Galaxy A15 5G)', 'SM-A155F (Galaxy A15 LTE)', 'SM-A146B (Galaxy A14 5G)', 'SM-A145F (Galaxy A14)', 'SM-A135F (Galaxy A13)', 'SM-A125F (Galaxy A12)', 'SM-A115F (Galaxy A11)', 'SM-A105F (Galaxy A10)',
                'SM-A057F (Galaxy A05s)', 'SM-A055F (Galaxy A05)', 'SM-A045F (Galaxy A04)', 'SM-A042F (Galaxy A04e)', 'SM-A037F (Galaxy A03s)', 'SM-A035F (Galaxy A03)', 'SM-A032F (Galaxy A03 Core)', 'SM-A025F (Galaxy A02s)', 'SM-A022F (Galaxy A02)', 'SM-A015F (Galaxy A01)',
                'SM-N986B (Galaxy Note 20 Ultra 5G)', 'SM-N980F (Galaxy Note 20)', 'SM-N975F (Galaxy Note 10+)', 'SM-N970F (Galaxy Note 10)', 'SM-N960F (Galaxy Note 9)', 'SM-N950F (Galaxy Note 8)',
                'SM-X910 (Galaxy Tab S9 Ultra)', 'SM-X810 (Galaxy Tab S9+)', 'SM-X710 (Galaxy Tab S9)', 'SM-X210 (Galaxy Tab A9+)', 'SM-X110 (Galaxy Tab A9)'
            ],
            'Xiaomi': [
                'manet (Xiaomi 13 Pro)', 'fuxi (Xiaomi 13)', 'nuwa (Xiaomi 13 Ultra)', 'corot (Xiaomi 13T Pro)', 'aristotle (Xiaomi 13T)',
                'cupid (Xiaomi 12 Pro)', 'zeus (Xiaomi 12)', 'plato (Xiaomi 12T)', 'diting (Xiaomi 12T Pro)',
                'venus (Mi 11)', 'cetus (Mi MIX Fold)', 'dipper (Mi 8)', 'cepheus (Mi 9)',
                'peridot (Poco F6)', 'manet (Poco F5 Pro)', 'marble (Poco F5)', 'munch (Poco F4)', 'alioth (Poco F3)', 'beryllium (Poco F1)',
                'duchamp (Poco X6 Pro 5G)', 'garnet (Poco X6 5G)', 'redwood (Poco X5 Pro 5G)', 'moonstone (Poco X5 5G)', 'vayu (Poco X3 Pro)', 'surya (Poco X3 NFC)',
                'gold (Redmi Note 13 5G)', 'garnet (Redmi Note 13 Pro 5G)', 'zircon (Redmi Note 13 Pro+ 5G)',
                'sunstone (Redmi Note 12 5G)', 'tapas (Redmi Note 12 4G)', 'ruby (Redmi Note 12 Pro 5G)',
                'spes (Redmi Note 11)', 'veux (Redmi Note 11 Pro 5G)', 'viva (Redmi Note 11 Pro 4G)',
                'sweet (Redmi Note 10 Pro)', 'mojito (Redmi Note 10)', 'rosemary (Redmi Note 10S)', 'camellia (Redmi Note 10 5G)',
                'merlin (Redmi Note 9)', 'joyeuse (Redmi Note 9 Pro)', 'curtana (Redmi Note 9S)',
                'ginkgo (Redmi Note 8)', 'begonia (Redmi Note 8 Pro)', 'lavender (Redmi Note 7)',
                'earth (Redmi 12 5G)', 'fire (Redmi 12 4G)', 'fog (Redmi 10C)', 'selene (Redmi 10)',
                'lancelot (Redmi 9)', 'dandelion (Redmi 9A)', 'angelica (Redmi 9C)'
            ],
            'OPPO': [
                'CPH2525 (Reno 10 Pro+ 5G)', 'CPH2531 (Reno 10 5G)', 'CPH2357 (Reno 8 Pro 5G)', 'CPH2359 (Reno 8 5G)', 'CPH2377 (Reno 7 5G)', 'CPH2145 (Reno 5 5G)', 'CPH2113 (Reno 4)', 'CPH1989 (Reno 2F)',
                'CPH2505 (Find N3 Flip)', 'CPH2499 (Find N3)', 'CPH2305 (Find X5 Pro)', 'CPH2173 (Find X3 Pro)',
                'CPH2565 (A79 5G)', 'CPH2495 (A78 5G)', 'CPH2387 (A77 5G)', 'CPH2375 (A76)', 'CPH2219 (A74)',
                'CPH2385 (A57 4G)', 'CPH2239 (A54)', 'CPH2127 (A53)', 'CPH1931 (A5 2020)', 'CPH1909 (A5s)', 'CPH1803 (A3s)',
                'CPH2477 (A17)', 'CPH2269 (A16)', 'CPH2185 (A15)', 'CPH2083 (A12)',
                'CPH1823 (F9)', 'CPH1819 (F7)', 'CPH1723 (F5)', 'CPH1601 (F1s)', 'CPH1911 (F11)', 'CPH1969 (F11 Pro)',
                'RMX3741 (Realme 11 Pro+ 5G)', 'RMX3771 (Realme 11 5G)', 'RMX3630 (Realme 10)', 'RMX3472 (Realme 9 Pro 5G)', 'RMX3511 (Realme C35)', 'RMX3501 (Realme C31)', 'RMX3261 (Realme C21Y)',
                'OnePlus 12 (CPH2581)', 'OnePlus 11 (CPH2449)', 'OnePlus 10 Pro (NE2213)', 'OnePlus 9 Pro (LE2123)', 'OnePlus Nord CE 3 Lite (CPH2493)'
            ],
            'VIVO': [
                'V2244 (V29 5G)', 'V2231 (V27 5G)', 'V2202 (V25 5G)', 'V2130 (V23 5G)', 'V2050 (V21 5G)', 'V2022 (V20)', 'V1933 (V19)', 'V1818 (V15 Pro)', 'V1819 (V15)', '1804 (V11)', '1723 (V9)', '1718 (V7)', '1601 (V5)',
                'V2246 (Y36 5G)', 'V2247 (Y36 4G)', 'V2249 (Y27 5G)', 'V2248 (Y27 4G)', 'V2204 (Y22)', 'V2111 (Y21)', 'V2027 (Y20)', 'V2034 (Y20s)', 'V2041 (Y72 5G)', '1935 (Y50)', '1915 (Y19)', '1902 (Y17)', '1901 (Y15)', '1904 (Y12)', '1906 (Y11)', '1820 (Y91C)', '1816 (Y91)', '1807 (Y95)',
                'V2241 (X90 Pro)', 'V2145 (X80 Pro)', 'V2219 (iQOO Neo 7)', 'V2230 (iQOO Z7 5G)'
            ],
            'Google': [
                'husky (Pixel 8 Pro)', 'shiba (Pixel 8)', 'akita (Pixel 8a)',
                'felix (Pixel Fold)', 'tangorpro (Pixel Tablet)',
                'cheetah (Pixel 7 Pro)', 'panther (Pixel 7)', 'lynx (Pixel 7a)',
                'raven (Pixel 6 Pro)', 'oriole (Pixel 6)', 'bluejay (Pixel 6a)',
                'redfin (Pixel 5)', 'bramble (Pixel 4a 5G)', 'sunfish (Pixel 4a)', 'coral (Pixel 4 XL)', 'flame (Pixel 4)',
                'bonito (Pixel 3a XL)', 'sargo (Pixel 3a)', 'crosshatch (Pixel 3 XL)', 'blueline (Pixel 3)'
            ],
            'Infinix': [
                'X6837 (Infinix HOT 40 Pro)', 'X6836 (Infinix HOT 40)', 'X6831 (Infinix HOT 30)', 'X669 (Infinix HOT 30i)',
                'X6711 (Infinix NOTE 30 5G)', 'X6833B (Infinix NOTE 30)', 'X676B (Infinix NOTE 12 Pro 5G)', 'X670 (Infinix NOTE 12)',
                'X6525 (Infinix SMART 8)', 'X6515 (Infinix SMART 7)',
                'BG7 (Tecno Spark 20)', 'CK8n (Tecno Camon 20 Pro 5G)', 'KJ5 (Tecno Spark 20C)',
                'S665L (itel S23)', 'A663L (itel A60s)', 'P662L (itel P40)'
            ],
            'HUAWEI': [
                'NAM-LX9 (Nova 9)', 'JNY-L22 (Nova 7i)', 'YAL-L21 (Nova 5T)', 'INE-LX2 (Nova 3i)', 'RNE-L22 (Nova 2i)',
                'STK-L22 (Y9 Prime)', 'JKM-LX2 (Y9 2019)', 'DUB-LX2 (Y7 Pro)', 'ATU-L31 (Y6 Prime)', 'DRA-LX2 (Y5 Prime)', 'CRO-L22 (Y3 2017)',
                'NOH-NX9 (Mate 40 Pro)', 'TAS-L29 (Mate 30)', 'HMA-L29 (Mate 20)', 'ALP-L29 (Mate 10)',
                'ELS-NX9 (P40 Pro)', 'ANA-NX9 (P40)', 'VOG-L29 (P30 Pro)', 'ELE-L29 (P30)', 'CLT-L29 (P20 Pro)', 'EML-L29 (P20)'
            ],
            'LG': [
                'LMV405 (V40 ThinQ)', 'H930 (V30)', 'H990 (V20)', 'H960 (V10)',
                'LMG710 (G7 ThinQ)', 'H870 (G6)', 'H850 (G5)', 'H815 (G4)', 'D855 (G3)', 'D802 (G2)', 'K420 (K10)'
            ],
            'LAVA/AIS': [
                'Iris 54 (LAVA Iris 54)', 'Iris 50 (LAVA Iris 50)', '870 (LAVA 870)', '810 (LAVA 810)', '800 (LAVA 800)', '755 (LAVA 755)', '750 (LAVA 750)', '708 (LAVA 708)', '700 (LAVA 700)', '600+ (LAVA 600+)', '600 (LAVA 600)', '565 (LAVA 565)', '560 (LAVA 560)', '550 (LAVA 550)', '515 (LAVA 515)', '512 (LAVA 512)', '510 (LAVA 510)', '505 (LAVA 505)', '504Q (LAVA 504Q)', '500 (LAVA 500)', '456 (LAVA 456)', '405+ (LAVA 405+)', '360R (LAVA 360R)', '360 (LAVA 360)', '353 (LAVA 353)', 'W5 (LAVA W5)', 'W3 (LAVA W3)', 'W1 (LAVA W1)'
            ],
            'TRUE': [
                'A1000 (Lenovo A1000)', 'A2010 (Lenovo A2010)', 'A6000 (Lenovo A6000)', 'A7000 (Lenovo A7000)', 'K52e78 (Lenovo K5 Note)', 'A6020 (Lenovo Vibe K5)', 'P2a42 (Lenovo P2)',
                'Smart 4G (True Smart 4G)', 'Smart Max (True Smart Max)', 'Smart 5.0 (True Smart 5.0)', 'Smart 4.0 (True Smart 4.0)', 'Smart 3.5 (True Smart 3.5)', 'Speedy 4.0 (True Smart 4G Speedy 4.0)', 'Octa 5.5 (True Smart 4G Octa 5.5)', 'Tab 4G (True Smart Tab 4G)'
            ],
            'WIKO': [
                'W-V600 (Jerry)', 'W-V610 (Jerry 2)', 'W-K210 (Jerry 3)', 'W-K230 (Jerry 4)', 'W-K130 (Lenny 3)', 'W-K140 (Lenny 4)', 'W-V800 (Sunny)', 'W-V820 (Sunny 2 Plus)', 'W-V830 (Sunny 3 Plus)', 'W-V500 (Tommy 3)', 'W-V510 (Tommy 3 Plus)', 'W-C200 (View)'
            ],
            'ZTE/DTAC': [
                'Blade A3 (ZTE Blade A3)', 'Blade A5 (ZTE Blade A5)', 'Blade A7 (ZTE Blade A7)', 'Blade V9 (ZTE Blade V9)', 'Blade V10 (ZTE Blade V10)',
                'M1 (Dtac Phone M1)', 'M2 (Dtac Phone M2)', 'T3 (Dtac Phone T3)', 'X3 (Dtac Phone X3)'
            ],
            'ACER': [
                'Z150 (Liquid Z5)', 'Z500 (Liquid Z500)', 'T09 (Liquid Z6)', 'S55 (Liquid Jade)', 'A1-713 (Iconia Tab 7)', 'A1-840 (Iconia Tab 8)', 'E39 (Liquid E700)', 'T01 (Liquid Z330)', 'T02 (Liquid Z520)', 'T03 (Liquid Z630)'
            ],
            'ASTON': [
                'Aston A1', 'Aston Pro', 'Aston Idea', 'Aston Thunder', 'Aston X', 'Aston Infinite', 'Aston Ultimate', 'Aston A8',
                'Aplus A1', 'Aplus A2', 'Aplus G9', 'Aplus R11', 'Aplus V5', 'Aplus V7', 'Aplus X1', 'Aplus X2', 'Aplus Z5',
                'SKG A1', 'SKG A8', 'SKG G1', 'SKG G2', 'SKG G3', 'SKG S1', 'SKG V3'
            ]
        };

        function populateAndroidModels() {
            if (!romBrandDropdown || !romModelList) return;
            const brand = romBrandDropdown.value;
            const models = brandModelsDatabase[brand] || [];
            const searchKeyword = (romModelSearch ? romModelSearch.value.trim().toLowerCase() : '');

            romModelList.innerHTML = '';
            let matchCount = 0;

            models.forEach(m => {
                if (!searchKeyword || m.toLowerCase().includes(searchKeyword)) {
                    const opt = document.createElement('option');
                    opt.value = m;
                    opt.textContent = m;
                    romModelList.appendChild(opt);
                    matchCount++;
                }
            });

            if (matchCount === 0) {
                const emptyOpt = document.createElement('option');
                emptyOpt.value = '';
                emptyOpt.textContent = '-- ไม่พบชื่อรุ่นที่ค้นหา --';
                emptyOpt.disabled = true;
                romModelList.appendChild(emptyOpt);
            } else {
                romModelList.selectedIndex = 0;
                updateSelectedAndroidModel();
            }

            if (androidCountLabel) {
                androidCountLabel.textContent = `${matchCount} รุ่นพร้อมใช้งาน`;
            }
        }

        function updateSelectedAndroidModel() {
            if (!romBrandDropdown || !romModelList) return;
            const brand = romBrandDropdown.value;
            const model = romModelList.value;
            if (!model) return;

            if (androidSelectedBrandBadge) androidSelectedBrandBadge.textContent = brand;
            if (androidSelectedTitle) androidSelectedTitle.textContent = model;

            let cleanModel = model;
            if (cleanModel.includes('(')) {
                cleanModel = cleanModel.split('(')[0].trim();
            }

            if (brand === 'SAMSUNG') {
                if (androidSelectedCsc) androidSelectedCsc.textContent = 'THL (Thailand Official)';
                if (androidSelectedChipBadge) androidSelectedChipBadge.textContent = 'Odin 4-Files (AP/BL/CP/CSC)';
                if (androidTipsText) {
                    androidTipsText.textContent = 'Samsung: ใช้โปรแกรม Odin Flasher ใส่ไฟล์ครบ 4 ช่อง (BL, AP, CP, CSC_THL). เข้า Download Mode โดยปิดเครื่อง แล้วกดปุ่ม Volume Up + Volume Down ค้างไว้พร้อมเสียบสาย Type-C เข้า PC';
                }
                if (btnPortalPrimaryTitle) btnPortalPrimaryTitle.textContent = 'SamFW Direct Download';
                if (btnPortalPrimaryDesc) btnPortalPrimaryDesc.textContent = `เปิดหน้ารหัสรุ่น ${cleanModel} (THL)`;
                if (btnPortalPrimary) {
                    btnPortalPrimary.onclick = () => {
                        window.api.openExternalUrl(`https://samfw.com/firmware/${cleanModel}/THL`);
                    };
                }
                if (btnPortalSecondaryTitle) btnPortalSecondaryTitle.textContent = 'SamMobile Mirror';
                if (btnPortalSecondaryDesc) btnPortalSecondaryDesc.textContent = `สำรองรอมศูนย์ Galaxy ${cleanModel}`;
                if (btnPortalSecondary) {
                    btnPortalSecondary.onclick = () => {
                        window.api.openExternalUrl(`https://www.sammobile.com/samsung/firmware/`);
                    };
                }
            } else if (brand === 'Xiaomi') {
                if (androidSelectedCsc) androidSelectedCsc.textContent = 'Global / EEA / ID';
                if (androidSelectedChipBadge) androidSelectedChipBadge.textContent = 'Fastboot (.tgz) / Recovery (.zip)';
                if (androidTipsText) {
                    androidTipsText.textContent = 'Xiaomi: ปลดล็อค Mi Bootloader ก่อนแฟลชรอม Fastboot ด้วย Mi Flash Tool. กด Volume Down + Power เพื่อเข้าหน้า Fastboot';
                }
                if (btnPortalPrimaryTitle) btnPortalPrimaryTitle.textContent = 'MiFirm.net Fastboot';
                if (btnPortalPrimaryDesc) btnPortalPrimaryDesc.textContent = `ค้นหารอมตรงรุ่น ${cleanModel}`;
                if (btnPortalPrimary) {
                    btnPortalPrimary.onclick = () => {
                        window.api.openExternalUrl(`https://mifirm.net/model/${cleanModel.toLowerCase()}.ttt`);
                    };
                }
                if (btnPortalSecondaryTitle) btnPortalSecondaryTitle.textContent = 'XiaomiFirmwareUpdater';
                if (btnPortalSecondaryDesc) btnPortalSecondaryDesc.textContent = 'HyperOS & MIUI คลังรอมทั่วโลก';
                if (btnPortalSecondary) {
                    btnPortalSecondary.onclick = () => {
                        window.api.openExternalUrl(`https://xiaomifirmwareupdater.com/`);
                    };
                }
            } else if (brand === 'Google') {
                if (androidSelectedCsc) androidSelectedCsc.textContent = 'Google Direct Factory CDN';
                if (androidSelectedChipBadge) androidSelectedChipBadge.textContent = 'Fastboot flash-all.bat';
                if (androidTipsText) {
                    androidTipsText.textContent = 'Google Pixel: รอมศูนย์ของแท้จาก Google Developers. แตกไฟล์ zip แล้วรันคำสั่ง flash-all.bat ใน Fastboot Mode ได้ทันที';
                }
                if (btnPortalPrimaryTitle) btnPortalPrimaryTitle.textContent = 'Google Factory Images';
                if (btnPortalPrimaryDesc) btnPortalPrimaryDesc.textContent = `เปิดหน้าดาวน์โหลดรอม Pixel ${cleanModel}`;
                if (btnPortalPrimary) {
                    btnPortalPrimary.onclick = () => {
                        window.api.openExternalUrl(`https://developers.google.com/android/images#${cleanModel.toLowerCase()}`);
                    };
                }
                if (btnPortalSecondaryTitle) btnPortalSecondaryTitle.textContent = 'Google Full OTA Images';
                if (btnPortalSecondaryDesc) btnPortalSecondaryDesc.textContent = 'แพ็กเกจ OTA สำหรับ adb sideload';
                if (btnPortalSecondary) {
                    btnPortalSecondary.onclick = () => {
                        window.api.openExternalUrl(`https://developers.google.com/android/ota`);
                    };
                }
            } else {
                if (androidSelectedCsc) androidSelectedCsc.textContent = 'Official Stock';
                if (androidSelectedChipBadge) androidSelectedChipBadge.textContent = 'Scatter / PAC / QFIL';
                if (androidTipsText) {
                    androidTipsText.textContent = `${brand}: ตรวจสอบประเภทชิปเซ็ต (MediaTek ใช้ SP Flash Tool, Unisoc ใช้ UpgradeDownload .PAC, Qualcomm ใช้ EDL 9008 Sahara)`;
                }
                if (btnPortalPrimaryTitle) btnPortalPrimaryTitle.textContent = 'Official Stock Search';
                if (btnPortalPrimaryDesc) btnPortalPrimaryDesc.textContent = `ค้นหาไฟล์รอมศูนย์ ${brand} ${cleanModel}`;
                if (btnPortalPrimary) {
                    btnPortalPrimary.onclick = () => {
                        window.api.openExternalUrl(`https://www.google.com/search?q=${encodeURIComponent(brand + ' ' + cleanModel + ' official stock rom firmware download')}`);
                    };
                }
                if (btnPortalSecondaryTitle) btnPortalSecondaryTitle.textContent = 'GSM-Forum Mirror';
                if (btnPortalSecondaryDesc) btnPortalSecondaryDesc.textContent = 'ไฟล์จากช่างซ่อมมืออาชีพ';
                if (btnPortalSecondary) {
                    btnPortalSecondary.onclick = () => {
                        window.api.openExternalUrl(`https://www.google.com/search?q=${encodeURIComponent(brand + ' ' + cleanModel + ' firmware gsm forum')}`);
                    };
                }
            }

            if (btnPortalFrp) {
                btnPortalFrp.onclick = () => {
                    window.api.openExternalUrl(`https://www.google.com/search?q=${encodeURIComponent(brand + ' ' + cleanModel + ' frp bypass unlock instructions youtube')}`);
                };
            }

            if (btnPortalRecovery) {
                btnPortalRecovery.onclick = () => {
                    window.api.openExternalUrl(`https://www.google.com/search?q=${encodeURIComponent(cleanModel + ' twrp orangefox recovery download')}`);
                };
            }
        }

        if (romBrandDropdown) {
            romBrandDropdown.addEventListener('change', populateAndroidModels);
        }
        if (romModelSearch) {
            romModelSearch.addEventListener('input', populateAndroidModels);
        }
        if (romModelList) {
            romModelList.addEventListener('change', updateSelectedAndroidModel);
        }

        document.querySelectorAll('.portal-link-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                if (btn.dataset.url && window.api && window.api.openExternalUrl) {
                    window.api.openExternalUrl(btn.dataset.url);
                }
            });
        });

        populateAndroidModels();

        // ------------------------------------------------------------
        // 3. Apple iOS Connected Device Inspector (3uTools Style) & IPSW Live Downloader
        // ------------------------------------------------------------
        let cachedAppleDevices = [];
        let currentAppleCategory = 'iPhone';
        let currentConnectedIosDevice = null;
        let iosScanInterval = null;

        // Apple Device Inspector Elements
        const iosDevicePanel = document.getElementById('ios-device-panel');
        const iosConnBadge = document.getElementById('ios-conn-badge');
        const btnIosScanDevices = document.getElementById('btn-ios-scan-devices');
        const iosNoDeviceState = document.getElementById('ios-no-device-state');
        const iosConnectedCard = document.getElementById('ios-connected-card');
        const iosAvatarIcon = document.getElementById('ios-avatar-icon');
        const iosAvatarType = document.getElementById('ios-avatar-type');
        const iosDetailName = document.getElementById('ios-detail-name');
        const iosDetailIosVersion = document.getElementById('ios-detail-ios-version');
        const iosDetailModeBadge = document.getElementById('ios-detail-mode-badge');
        const iosDetailModelId = document.getElementById('ios-detail-model-id');
        const iosDetailSerial = document.getElementById('ios-detail-serial');
        const iosDetailRegion = document.getElementById('ios-detail-region');
        const iosDetailImei = document.getElementById('ios-detail-imei');
        const iosDetailActivation = document.getElementById('ios-detail-activation');
        const iosDetailUdid = document.getElementById('ios-detail-udid');
        const iosTrustAlert = document.getElementById('ios-trust-alert');
        const btnIosMatchIpsw = document.getElementById('btn-ios-match-ipsw');

        // IPSW Elements
        const ipswDeviceSelect = document.getElementById('ipsw-device-select');
        const ipswDeviceInfoBar = document.getElementById('ipsw-device-info-bar');
        const ipswInfoName = document.getElementById('ipsw-info-name');
        const ipswInfoId = document.getElementById('ipsw-info-id');
        const ipswInfoBoard = document.getElementById('ipsw-info-board');
        const ipswFirmwareTbody = document.getElementById('ipsw-firmware-tbody');
        const btnIpswRefresh = document.getElementById('btn-ipsw-refresh');
        const ipswCatBtns = document.querySelectorAll('.ipsw-cat-btn');

        function setAppleCategory(catName) {
            currentAppleCategory = catName;
            ipswCatBtns.forEach(x => {
                if (x.dataset.cat === catName) {
                    x.classList.add('active');
                    x.style.background = '#3b82f6';
                    x.style.color = '#fff';
                    x.style.fontWeight = '600';
                } else {
                    x.classList.remove('active');
                    x.style.background = 'transparent';
                    x.style.color = '#94a3b8';
                    x.style.fontWeight = '500';
                }
            });
            populateAppleDeviceDropdown();
        }

        ipswCatBtns.forEach(b => {
            b.addEventListener('click', () => {
                setAppleCategory(b.dataset.cat);
            });
        });

        async function ensureAppleDevicesLoaded() {
            if (cachedAppleDevices.length > 0) return true;
            if (!window.api || !window.api.fetchIpswApi) return false;

            if (ipswDeviceSelect) {
                ipswDeviceSelect.innerHTML = '<option value="">-- กำลังดึงรายชื่อรุ่นจาก Apple API... --</option>';
            }

            try {
                const res = await window.api.fetchIpswApi('/v4/devices');
                if (res && res.success && Array.isArray(res.data)) {
                    cachedAppleDevices = res.data;
                    populateAppleDeviceDropdown();
                    return true;
                } else {
                    if (ipswDeviceSelect) {
                        ipswDeviceSelect.innerHTML = '<option value="">-- ไม่สามารถโหลดข้อมูลได้ (ตรวจสอบเน็ต) --</option>';
                    }
                    return false;
                }
            } catch (err) {
                if (ipswDeviceSelect) {
                    ipswDeviceSelect.innerHTML = '<option value="">-- ไม่สามารถเชื่อมต่อ API ได้ --</option>';
                }
                return false;
            }
        }

        function populateAppleDeviceDropdown() {
            if (!ipswDeviceSelect) return;
            ipswDeviceSelect.innerHTML = '';

            const filtered = cachedAppleDevices.filter(d => {
                const id = (d.identifier || '').toLowerCase();
                if (currentAppleCategory === 'iPhone') return id.startsWith('iphone');
                if (currentAppleCategory === 'iPad') return id.startsWith('ipad');
                if (currentAppleCategory === 'Mac') return id.startsWith('mac') || id.startsWith('virtualmac');
                if (currentAppleCategory === 'Watch') return id.startsWith('watch');
                if (currentAppleCategory === 'iPod') return id.startsWith('ipod');
                return true;
            });

            if (filtered.length === 0) {
                ipswDeviceSelect.innerHTML = '<option value="">-- ไม่พบรุ่นในหมวดหมู่นี้ --</option>';
                return;
            }

            filtered.reverse().forEach(dev => {
                const opt = document.createElement('option');
                opt.value = dev.identifier;
                opt.textContent = `${dev.name} (${dev.identifier})`;
                ipswDeviceSelect.appendChild(opt);
            });

            ipswDeviceSelect.selectedIndex = 0;
            loadDeviceFirmwares();
        }

        async function loadDeviceFirmwares() {
            if (!ipswDeviceSelect) return;
            const devId = ipswDeviceSelect.value;
            if (!devId) return;

            const dev = cachedAppleDevices.find(d => d.identifier === devId);
            if (dev && ipswDeviceInfoBar) {
                ipswDeviceInfoBar.style.display = 'flex';
                if (ipswInfoName) ipswInfoName.textContent = dev.name;
                if (ipswInfoId) ipswInfoId.textContent = dev.identifier;
                if (ipswInfoBoard) ipswInfoBoard.textContent = dev.boardconfig || '-';
            }

            if (ipswFirmwareTbody) {
                ipswFirmwareTbody.innerHTML = `
                    <tr>
                        <td colspan="6" style="padding: 24px; text-align: center; color: #38bdf8;">
                            <i class="fas fa-spinner fa-spin" style="margin-right: 8px;"></i> กำลังโหลดรายการเฟิร์มแวร์จาก Apple CDN...
                        </td>
                    </tr>
                `;
            }

            try {
                const res = await window.api.fetchIpswApi(`/v4/device/${devId}`);
                if (res && res.success && res.data && Array.isArray(res.data.firmwares)) {
                    renderFirmwareTable(res.data.firmwares, dev ? dev.name : devId);
                } else {
                    if (ipswFirmwareTbody) {
                        ipswFirmwareTbody.innerHTML = `<tr><td colspan="6" style="padding: 20px; text-align: center; color: #ef4444;">ไม่สามารถดึงข้อมูลเฟิร์มแวร์ได้ (${res ? res.error : 'Unknown error'})</td></tr>`;
                    }
                }
            } catch (err) {
                if (ipswFirmwareTbody) {
                    ipswFirmwareTbody.innerHTML = `<tr><td colspan="6" style="padding: 20px; text-align: center; color: #ef4444;">เกิดข้อผิดพลาด: ${err.message}</td></tr>`;
                }
            }
        }

        function renderFirmwareTable(firmwares, deviceName) {
            if (!ipswFirmwareTbody) return;
            ipswFirmwareTbody.innerHTML = '';

            if (firmwares.length === 0) {
                ipswFirmwareTbody.innerHTML = `<tr><td colspan="6" style="padding: 20px; text-align: center; color: #64748b;">ไม่มีข้อมูลเฟิร์มแวร์สำหรับรุ่นนี้</td></tr>`;
                return;
            }

            const firstSignedIndex = firmwares.findIndex(f => !!f.signed);

            firmwares.forEach((fw, idx) => {
                const tr = document.createElement('tr');
                const isSigned = !!fw.signed;
                const isLatestSigned = (idx === firstSignedIndex && isSigned);
                const matchesDeviceBuild = (currentConnectedIosDevice && currentConnectedIosDevice.buildVersion && fw.buildid === currentConnectedIosDevice.buildVersion);

                tr.style.borderBottom = '1px solid rgba(255,255,255,0.05)';
                tr.style.transition = 'background 0.15s';
                
                if (isLatestSigned) {
                    tr.style.background = 'rgba(16, 185, 129, 0.08)';
                    tr.style.borderLeft = '3px solid #10b981';
                }

                tr.onmouseenter = () => {
                    tr.style.background = isLatestSigned ? 'rgba(16, 185, 129, 0.14)' : 'rgba(255,255,255,0.04)';
                };
                tr.onmouseleave = () => {
                    tr.style.background = isLatestSigned ? 'rgba(16, 185, 129, 0.08)' : 'transparent';
                };

                const sizeGb = (fw.filesize / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
                const releaseDate = fw.releasedate ? fw.releasedate.split('T')[0] : '-';
                
                let signBadge = isSigned
                    ? `<span style="background: rgba(34,197,94,0.15); color: #22c55e; border: 1px solid rgba(34,197,94,0.3); padding: 3px 8px; border-radius: 4px; font-weight: 700; font-size: 11px;">🟢 Signed (รีสโตร์ได้)</span>`
                    : `<span style="background: rgba(239,68,68,0.1); color: #ef4444; border: 1px solid rgba(239,68,68,0.25); padding: 3px 8px; border-radius: 4px; font-size: 11px;">🔴 Unsigned</span>`;

                let recommendationBadge = '';
                if (isLatestSigned) {
                    recommendationBadge = `<span style="background: linear-gradient(135deg, rgba(16,185,129,0.25) 0%, rgba(5,150,105,0.3) 100%); color: #34d399; border: 1px solid rgba(16,185,129,0.5); padding: 2px 7px; border-radius: 4px; font-weight: 700; font-size: 10px; margin-left: 8px; display: inline-flex; align-items: center; gap: 4px;"><i class="fas fa-star" style="color: #facc15;"></i> ⭐ แนะนำ (Latest Signed)</span>`;
                } else if (matchesDeviceBuild) {
                    recommendationBadge = `<span style="background: rgba(59,130,246,0.25); color: #60a5fa; border: 1px solid rgba(59,130,246,0.5); padding: 2px 7px; border-radius: 4px; font-weight: 700; font-size: 10px; margin-left: 8px; display: inline-flex; align-items: center; gap: 4px;"><i class="fas fa-mobile"></i> ตรงกับ iOS ในเครื่อง</span>`;
                }

                tr.innerHTML = `
                    <td style="padding: 10px; font-weight: 600; color: #f8fafc;">
                        <span style="display: inline-flex; align-items: center; flex-wrap: wrap; gap: 4px;">
                            <span>iOS / iPadOS ${fw.version}</span>
                            ${recommendationBadge}
                        </span>
                    </td>
                    <td style="padding: 10px; font-family: monospace; color: #94a3b8;">${fw.buildid}</td>
                    <td style="padding: 10px; color: #cbd5e1;">${sizeGb}</td>
                    <td style="padding: 10px; color: #94a3b8;">${releaseDate}</td>
                    <td style="padding: 10px; text-align: center;">${signBadge}</td>
                    <td style="padding: 10px; text-align: right;">
                        <div style="display: inline-flex; gap: 6px;">
                            <button class="action-btn ${isLatestSigned ? 'safe-btn' : 'primary-btn'} btn-ipsw-dl" style="padding: 5px 10px; font-size: 11px; font-weight: 600; display: inline-flex; align-items: center; gap: 4px;" title="เริ่มดาวน์โหลดตรงในโปรแกรม">
                                <i class="fas fa-bolt"></i> โหลดในแอป
                            </button>
                            <button class="action-btn btn-ipsw-send-flash" style="padding: 5px 9px; font-size: 11px; background: rgba(56, 189, 248, 0.15); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.3); font-weight: 600; display: inline-flex; align-items: center; gap: 4px;" title="ส่งไฟล์นี้ไปยังหน้า Apple iOS Flasher เพื่อเตรียมแฟลช">
                                <i class="fab fa-apple"></i> ส่งไปแฟลช
                            </button>
                            <button class="action-btn btn-ipsw-copy" style="padding: 5px 8px; font-size: 11px; background: rgba(255,255,255,0.08); color: #cbd5e1;" title="คัดลอกลิงก์ Apple CDN">
                                <i class="fas fa-copy"></i>
                            </button>
                            <button class="action-btn btn-ipsw-web" style="padding: 5px 8px; font-size: 11px; background: rgba(255,255,255,0.08); color: #cbd5e1;" title="เปิดในเบราว์เซอร์">
                                <i class="fas fa-arrow-up-right-from-square"></i>
                            </button>
                        </div>
                    </td>
                `;

                const dlBtn = tr.querySelector('.btn-ipsw-dl');
                if (dlBtn) {
                    dlBtn.addEventListener('click', () => {
                        const filename = `${fw.identifier || deviceName || 'Apple'}_${fw.version}_${fw.buildid}_Restore.ipsw`;
                        triggerFileDownload(fw.url, filename);
                    });
                }

                const sendFlashBtn = tr.querySelector('.btn-ipsw-send-flash');
                if (sendFlashBtn) {
                    sendFlashBtn.addEventListener('click', async () => {
                        const filename = `${fw.identifier || deviceName || 'Apple'}_${fw.version}_${fw.buildid}_Restore.ipsw`;
                        let defaultDir = '';
                        try {
                            defaultDir = await window.api.getDefaultDownloadsDir();
                        } catch(e) {}
                        const targetPath = defaultDir ? `${defaultDir}\\${filename}` : filename;
                        if (typeof window.sendIpswToFlasher === 'function') {
                            window.sendIpswToFlasher(targetPath, filename, sizeGb);
                        }
                    });
                }

                const copyBtn = tr.querySelector('.btn-ipsw-copy');
                if (copyBtn) {
                    copyBtn.addEventListener('click', () => {
                        navigator.clipboard.writeText(fw.url).then(() => {
                            copyBtn.innerHTML = '<i class="fas fa-check" style="color:#22c55e;"></i>';
                            setTimeout(() => copyBtn.innerHTML = '<i class="fas fa-copy"></i>', 2000);
                        });
                    });
                }

                const webBtn = tr.querySelector('.btn-ipsw-web');
                if (webBtn) {
                    webBtn.addEventListener('click', () => {
                        if (window.api && window.api.openExternalUrl) {
                            window.api.openExternalUrl(fw.url);
                        }
                    });
                }

                ipswFirmwareTbody.appendChild(tr);
            });
        }

        // Live iOS Device Detection & Auto-Select Controller
        async function refreshConnectedIosDevice(showVisualFeedback = false) {
            if (!window.api || !window.api.getConnectedIosDevice) return;

            if (showVisualFeedback && btnIosScanDevices) {
                btnIosScanDevices.innerHTML = '<i class="fas fa-spinner fa-spin"></i> <span>กำลังสแกน...</span>';
            }

            try {
                const res = await window.api.getConnectedIosDevice();
                if (res && res.connected && res.device) {
                    currentConnectedIosDevice = res.device;
                    const dev = res.device;

                    // Update Badge
                    if (iosConnBadge) {
                        iosConnBadge.innerHTML = `<i class="fas fa-circle" style="font-size: 7px; margin-right: 4px; color: #22c55e;"></i> เชื่อมต่อแล้ว (${dev.name || 'Apple Device'})`;
                        iosConnBadge.style.background = 'rgba(34,197,94,0.15)';
                        iosConnBadge.style.color = '#22c55e';
                        iosConnBadge.style.borderColor = 'rgba(34,197,94,0.3)';
                    }

                    // Toggle Views
                    if (iosNoDeviceState) iosNoDeviceState.style.display = 'none';
                    if (iosConnectedCard) iosConnectedCard.style.display = 'block';

                    // Update Avatar & Device Class
                    const dClass = (dev.deviceClass || 'iPhone').toLowerCase();
                    if (iosAvatarIcon) {
                        if (dClass.includes('ipad')) {
                            iosAvatarIcon.className = 'fa-solid fa-tablet-screen-button';
                        } else if (dClass.includes('ipod')) {
                            iosAvatarIcon.className = 'fa-solid fa-music';
                        } else {
                            iosAvatarIcon.className = 'fa-solid fa-mobile-screen-button';
                        }
                    }
                    if (iosAvatarType) {
                        iosAvatarType.textContent = dev.deviceClass || 'iPhone';
                    }

                    // Title & Version
                    if (iosDetailName) {
                        const displayName = (dev.deviceName && dev.name && dev.deviceName !== dev.name) ? `${dev.name} (${dev.deviceName})` : (dev.name || dev.deviceName || 'Apple Device');
                        iosDetailName.textContent = displayName;
                    }
                    if (iosDetailIosVersion) {
                        if (dev.productVersion) {
                            iosDetailIosVersion.textContent = `iOS ${dev.productVersion}${dev.buildVersion ? ' (' + dev.buildVersion + ')' : ''}`;
                            iosDetailIosVersion.style.display = 'inline-block';
                        } else {
                            iosDetailIosVersion.textContent = 'iOS --';
                        }
                    }

                    // Connection Mode Badge
                    if (iosDetailModeBadge) {
                        if (dev.mode === 'Recovery') {
                            iosDetailModeBadge.textContent = '🟡 Recovery Mode';
                            iosDetailModeBadge.style.background = 'rgba(245,158,11,0.2)';
                            iosDetailModeBadge.style.color = '#fbbf24';
                            iosDetailModeBadge.style.borderColor = 'rgba(245,158,11,0.4)';
                        } else if (dev.mode === 'DFU') {
                            iosDetailModeBadge.textContent = '🔴 DFU Mode';
                            iosDetailModeBadge.style.background = 'rgba(239,68,68,0.2)';
                            iosDetailModeBadge.style.color = '#f87171';
                            iosDetailModeBadge.style.borderColor = 'rgba(239,68,68,0.4)';
                        } else {
                            iosDetailModeBadge.textContent = '🟢 Normal Mode';
                            iosDetailModeBadge.style.background = 'rgba(34,197,94,0.2)';
                            iosDetailModeBadge.style.color = '#22c55e';
                            iosDetailModeBadge.style.borderColor = 'rgba(34,197,94,0.4)';
                        }
                    }

                    // Details Grid
                    if (iosDetailModelId) iosDetailModelId.textContent = dev.productType || dev.hardwareModel || '-';
                    if (iosDetailSerial) iosDetailSerial.textContent = dev.serialNumber || '-';
                    if (iosDetailRegion) {
                        const reg = [dev.modelNumber, dev.regionInfo].filter(Boolean).join(' ');
                        iosDetailRegion.textContent = reg || '-';
                    }
                    if (iosDetailImei) iosDetailImei.textContent = dev.imei || '-';
                    if (iosDetailActivation) {
                        if (dev.activationState === 'Activated') {
                            iosDetailActivation.innerHTML = '<span style="color: #22c55e;"><i class="fas fa-check-circle"></i> เปิดใช้งานแล้ว (Activated)</span>';
                        } else if (dev.activationState) {
                            iosDetailActivation.textContent = dev.activationState;
                        } else {
                            iosDetailActivation.textContent = '-';
                        }
                    }
                    if (iosDetailUdid) {
                        iosDetailUdid.textContent = dev.udid || '-';
                        iosDetailUdid.title = dev.udid ? 'คลิกเพื่อคัดลอก UDID: ' + dev.udid : '';
                    }

                    // Trust Screen Alert
                    if (iosTrustAlert) {
                        iosTrustAlert.style.display = dev.needTrust ? 'block' : 'none';
                    }
                } else {
                    currentConnectedIosDevice = null;
                    if (iosConnBadge) {
                        iosConnBadge.innerHTML = '<i class="fas fa-circle" style="font-size: 7px; margin-right: 4px;"></i> รอการเสียบสาย';
                        iosConnBadge.style.background = 'rgba(148,163,184,0.15)';
                        iosConnBadge.style.color = '#94a3b8';
                        iosConnBadge.style.borderColor = 'rgba(148,163,184,0.3)';
                    }
                    if (iosNoDeviceState) iosNoDeviceState.style.display = 'block';
                    if (iosConnectedCard) iosConnectedCard.style.display = 'none';
                }
            } catch (err) {
                console.error('Error refreshing iOS device:', err);
            } finally {
                if (showVisualFeedback && btnIosScanDevices) {
                    btnIosScanDevices.innerHTML = '<i class="fas fa-rotate"></i> <span>สแกนตรวจหา</span>';
                }
            }
        }

        async function selectIpswForConnectedDevice(dev) {
            if (!dev) {
                await refreshConnectedIosDevice(true);
                dev = currentConnectedIosDevice;
            }

            if (!dev) {
                alert('ยังไม่พบอุปกรณ์ iPhone หรือ iPad ที่เสียบอยู่ กรุณาเสียบสาย USB แล้วลองใหม่อีกครั้ง');
                return;
            }

            // 1. Load Apple device list
            await ensureAppleDevicesLoaded();

            // 2. Identify Category
            let targetCategory = 'iPhone';
            const devClass = (dev.deviceClass || '').toLowerCase();
            const pType = (dev.productType || '').toLowerCase();
            if (devClass.includes('ipad') || pType.startsWith('ipad')) {
                targetCategory = 'iPad';
            } else if (devClass.includes('ipod') || pType.startsWith('ipod')) {
                targetCategory = 'iPod';
            } else if (devClass.includes('mac') || pType.startsWith('mac')) {
                targetCategory = 'Mac';
            } else {
                targetCategory = 'iPhone';
            }

            // Switch category tab & populate dropdown
            setAppleCategory(targetCategory);

            // 3. Find matching model in ipswDeviceSelect
            if (ipswDeviceSelect) {
                let foundMatch = false;
                if (dev.productType) {
                    for (let i = 0; i < ipswDeviceSelect.options.length; i++) {
                        if (ipswDeviceSelect.options[i].value.toLowerCase() === dev.productType.toLowerCase()) {
                            ipswDeviceSelect.selectedIndex = i;
                            foundMatch = true;
                            break;
                        }
                    }
                }

                if (!foundMatch && dev.name) {
                    const cleanName = dev.name.toLowerCase().replace(/[^a-z0-9]/g, '');
                    for (let i = 0; i < ipswDeviceSelect.options.length; i++) {
                        const optText = ipswDeviceSelect.options[i].textContent.toLowerCase().replace(/[^a-z0-9]/g, '');
                        if (optText.includes(cleanName) || cleanName.includes(optText)) {
                            ipswDeviceSelect.selectedIndex = i;
                            foundMatch = true;
                            break;
                        }
                    }
                }

                await loadDeviceFirmwares();

                // Scroll to firmware table
                if (ipswDeviceInfoBar) {
                    ipswDeviceInfoBar.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
            }
        }

        function startIosPolling() {
            if (iosScanInterval) clearInterval(iosScanInterval);
            iosScanInterval = setInterval(() => {
                const appleTab = document.getElementById('rom-tab-apple');
                if (appleTab && appleTab.style.display !== 'none') {
                    refreshConnectedIosDevice(false);
                } else {
                    stopIosPolling();
                }
            }, 3500);
        }

        function stopIosPolling() {
            if (iosScanInterval) {
                clearInterval(iosScanInterval);
                iosScanInterval = null;
            }
        }

        if (ipswDeviceSelect) {
            ipswDeviceSelect.addEventListener('change', loadDeviceFirmwares);
        }
        if (btnIpswRefresh) {
            btnIpswRefresh.addEventListener('click', () => {
                cachedAppleDevices = [];
                ensureAppleDevicesLoaded();
            });
        }
        if (btnIosScanDevices) {
            btnIosScanDevices.addEventListener('click', () => {
                refreshConnectedIosDevice(true);
            });
        }
        if (btnIosMatchIpsw) {
            btnIosMatchIpsw.addEventListener('click', () => {
                selectIpswForConnectedDevice(currentConnectedIosDevice);
            });
        }
        if (iosDetailUdid) {
            iosDetailUdid.addEventListener('click', () => {
                const udid = iosDetailUdid.textContent.trim();
                if (udid && udid !== '-') {
                    navigator.clipboard.writeText(udid).then(() => {
                        const orig = iosDetailUdid.textContent;
                        iosDetailUdid.textContent = '✓ คัดลอก UDID แล้ว!';
                        setTimeout(() => { iosDetailUdid.textContent = orig; }, 1500);
                    });
                }
            });
        }

        // ------------------------------------------------------------
        // 4. Service & Unlock Files
        // ------------------------------------------------------------
        document.querySelectorAll('.frp-dl-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const name = btn.dataset.name;
                const url = btn.dataset.url;
                triggerFileDownload(url, name);
            });
        });

        // ------------------------------------------------------------
        // 5. Firmware Tools & Hasher
        // ------------------------------------------------------------
        const hashFilePath = document.getElementById('hash-file-path');
        const btnHashBrowse = document.getElementById('btn-hash-browse');
        const btnCalcHash = document.getElementById('btn-calc-hash');
        const hashOutput = document.getElementById('hash-output');
        const hashSizeText = document.getElementById('hash-size-text');
        const hashCompareInput = document.getElementById('hash-compare-input');
        const hashCompareStatus = document.getElementById('hash-compare-status');

        if (btnHashBrowse) {
            btnHashBrowse.addEventListener('click', async () => {
                if (window.api && window.api.browseFileForHash) {
                    const chosen = await window.api.browseFileForHash();
                    if (chosen && hashFilePath) {
                        hashFilePath.value = chosen;
                        if (hashOutput) hashOutput.textContent = '- กดคำนวณ Hash เพื่อเริ่มต้น -';
                        if (hashCompareStatus) hashCompareStatus.style.display = 'none';
                    }
                }
            });
        }

        if (btnCalcHash) {
            btnCalcHash.addEventListener('click', async () => {
                const filePath = hashFilePath ? hashFilePath.value.trim() : '';
                if (!filePath) {
                    alert('กรุณาเลือกไฟล์ที่ต้องการตรวจสอบก่อน');
                    return;
                }

                const selectedAlgoRadio = document.querySelector('input[name="hash-algo"]:checked');
                const algo = selectedAlgoRadio ? selectedAlgoRadio.value : 'md5';

                if (hashOutput) hashOutput.innerHTML = `<i class="fas fa-spinner fa-spin"></i> กำลังอ่านและคำนวณ Checksum ${algo.toUpperCase()}...`;

                try {
                    const res = await window.api.calculateFileHash({ filePath, algorithm: algo });
                    if (res && res.success) {
                        if (hashOutput) hashOutput.textContent = res.hash;
                        if (hashSizeText) hashSizeText.textContent = `ขนาดไฟล์: ${formatBytes(res.size)} | Algo: ${res.algorithm.toUpperCase()}`;
                        checkHashMatch();
                    } else {
                        if (hashOutput) hashOutput.textContent = 'เกิดข้อผิดพลาด: ' + (res.error || 'Unknown error');
                    }
                } catch (err) {
                    if (hashOutput) hashOutput.textContent = 'เกิดข้อผิดพลาด: ' + err.message;
                }
            });
        }

        function checkHashMatch() {
            if (!hashCompareInput || !hashCompareStatus || !hashOutput) return;
            const expected = hashCompareInput.value.trim().toLowerCase();
            const computed = hashOutput.textContent.trim().toLowerCase();

            if (!expected || computed.startsWith('-') || computed.startsWith('เกิดข้อผิดพลาด') || computed.startsWith('กำลัง')) {
                hashCompareStatus.style.display = 'none';
                return;
            }

            hashCompareStatus.style.display = 'block';
            if (expected === computed) {
                hashCompareStatus.style.background = 'rgba(34,197,94,0.2)';
                hashCompareStatus.style.color = '#22c55e';
                hashCompareStatus.style.border = '1px solid rgba(34,197,94,0.4)';
                hashCompareStatus.innerHTML = '<i class="fas fa-circle-check"></i> <strong>MATCH:</strong> ค่า Checksum ตรงกัน 100% ไฟล์สมบูรณ์ ปลอดภัยต่อการแฟลช';
            } else {
                hashCompareStatus.style.background = 'rgba(239,68,68,0.2)';
                hashCompareStatus.style.color = '#ef4444';
                hashCompareStatus.style.border = '1px solid rgba(239,68,68,0.4)';
                hashCompareStatus.innerHTML = '<i class="fas fa-triangle-exclamation"></i> <strong>MISMATCH:</strong> ค่า Checksum ไม่ตรงกัน! ไฟล์อาจดาวน์โหลดไม่สมบูรณ์หรือถูกดัดแปลง ห้ามแฟลชเด็ดขาด';
            }
        }

        if (hashCompareInput) {
            hashCompareInput.addEventListener('input', checkHashMatch);
        }

        // Samsung AP Boot Extractor
        const apExtractPath = document.getElementById('ap-extract-path');
        const btnApExtractBrowse = document.getElementById('btn-ap-extract-browse');
        const btnApExtractRun = document.getElementById('btn-ap-extract-run');
        const apExtractResult = document.getElementById('ap-extract-result');

        if (btnApExtractBrowse) {
            btnApExtractBrowse.addEventListener('click', async () => {
                const browseFn = (window.api && window.api.browseApFile) ? window.api.browseApFile : (window.api ? window.api.browseFileForHash : null);
                if (browseFn) {
                    const chosen = await browseFn();
                    if (chosen && apExtractPath) {
                        apExtractPath.value = chosen;
                    }
                }
            });
        }

        if (btnApExtractRun) {
            btnApExtractRun.addEventListener('click', async () => {
                const filePath = apExtractPath ? apExtractPath.value.trim() : '';
                if (!filePath) {
                    alert('กรุณาเลือกไฟล์ AP_*.tar.md5 ของ Samsung ก่อน');
                    return;
                }

                if (apExtractResult) {
                    apExtractResult.innerHTML = `<div style="color: #38bdf8;"><i class="fas fa-spinner fa-spin"></i> กำลังตรวจสอบโครงสร้างไฟล์ AP และสกัด boot image...</div>`;
                }

                try {
                    const res = await window.api.extractBootFromAp(filePath);
                    if (res && res.success) {
                        const lz4Badge = res.hasDecompressed 
                            ? `<span style="font-size: 10px; background: rgba(34, 197, 94, 0.2); color: #4ade80; padding: 2px 6px; border-radius: 4px; margin-left: 6px;">แตกไฟล์ LZ4 เรียบร้อย (.img)</span>`
                            : (res.isLz4 ? `<span style="font-size: 10px; background: rgba(245, 158, 11, 0.2); color: #fbbf24; padding: 2px 6px; border-radius: 4px; margin-left: 6px;">ไฟล์บีบอัด .lz4</span>` : '');
                        const initBadge = res.isInitBoot
                            ? `<span style="font-size: 10px; background: rgba(168, 85, 247, 0.2); color: #c084fc; padding: 2px 6px; border-radius: 4px; margin-left: 6px;">Android 13+ (init_boot)</span>`
                            : '';
                        const timeText = res.elapsedSeconds ? `(ใช้เวลา ${res.elapsedSeconds} วินาที)` : '';

                        const chkApAutoPatch = document.getElementById('chk-ap-auto-patch');
                        if (chkApAutoPatch && chkApAutoPatch.checked) {
                            await executeMagiskPatch(res.outPath, apExtractResult, null);
                        } else {
                            apExtractResult.innerHTML = `
                                <div style="color: #22c55e; font-weight: 600; margin-bottom: 6px; display: flex; align-items: center; flex-wrap: wrap; gap: 4px;">
                                    <i class="fas fa-check-circle"></i> สกัดไฟล์สำเร็จ! <b>${res.targetFile}</b> ${lz4Badge} ${initBadge} <small style="color: #94a3b8; font-size: 11px;">${timeText}</small>
                                </div>
                                <div style="color: #94a3b8; font-size: 11px; word-break: break-all; margin-bottom: 8px;">
                                    ที่อยู่ไฟล์: <b>${res.outPath}</b>
                                </div>
                                <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                                    <button class="action-btn warning-btn btn-patch-magisk-now" style="padding: 5px 12px; font-size: 11px; background: linear-gradient(135deg, #ff4e00, #ec9f05); border: none; color: #fff; font-weight: 600; cursor: pointer;">
                                        <i class="fas fa-bolt"></i> แพตช์ Magisk Root ทันที
                                    </button>
                                    <button class="action-btn safe-btn btn-open-extracted" style="padding: 5px 12px; font-size: 11px;">
                                        <i class="fas fa-folder-open"></i> เปิดโฟลเดอร์เก็บไฟล์
                                    </button>
                                </div>
                            `;
                            const patchBtn = apExtractResult.querySelector('.btn-patch-magisk-now');
                            if (patchBtn) {
                                patchBtn.addEventListener('click', () => {
                                    executeMagiskPatch(res.outPath, apExtractResult, null);
                                });
                            }
                            const openBtn = apExtractResult.querySelector('.btn-open-extracted');
                            if (openBtn) {
                                openBtn.addEventListener('click', async () => {
                                    const orig = openBtn.innerHTML;
                                    openBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังเปิด...';
                                    if (window.api && window.api.openFileLocation) {
                                        await window.api.openFileLocation(res.outPath);
                                    }
                                    setTimeout(() => { openBtn.innerHTML = '<i class="fas fa-check" style="color: #22c55e;"></i> เปิดแล้ว!'; }, 400);
                                    setTimeout(() => { openBtn.innerHTML = orig; }, 1800);
                                });
                            }
                        }
                    } else {
                        apExtractResult.innerHTML = `<div style="color: #ef4444;"><i class="fas fa-times-circle"></i> ล้มเหลว: ${res.error || 'Unknown error'}</div>`;
                    }
                } catch (err) {
                    apExtractResult.innerHTML = `<div style="color: #ef4444;"><i class="fas fa-times-circle"></i> เกิดข้อผิดพลาด: ${err.message}</div>`;
                }
            });
        }

    })();


// ============================================================
// RASPBERRY PI PICO / RP2350 FLASHER (usbliter8)
// ============================================================
(function() {
    let availableFirmwares = [];
    let detectedDrives = [];
    let selectedFile = null;

    function picoLog(msg, color) {
        const log = document.getElementById('pico-log');
        if (!log) return;
        const d = document.createElement('div');
        d.style.cssText = `color:${color || '#ccc'};margin-bottom:3px;word-break:break-all;`;
        d.textContent = msg;
        log.appendChild(d);
        log.scrollTop = log.scrollHeight;
    }

    function setPicoProgress(pct, stepLabel) {
        const bar = document.getElementById('pico-progress-bar');
        const pctEl = document.getElementById('pico-progress-pct');
        const stepEl = document.getElementById('pico-step-label');
        if (bar) bar.style.width = pct + '%';
        if (pctEl) pctEl.textContent = pct + '%';
        if (stepEl && stepLabel) stepEl.textContent = stepLabel;
    }

    function setPicoStep(num, status) {
        const el = document.querySelector(`.pico-step[data-step="${num}"]`);
        if (!el) return;
        const icons = { done: '✅', active: '🔄', error: '❌', pending: '⬜' };
        el.querySelector('.step-icon').textContent = icons[status] || '⬜';
        el.style.color = { done: '#69f0ae', active: '#fff', error: '#ff5252', pending: '#777' }[status] || '#777';
        el.style.background = { done: 'rgba(105,240,174,0.08)', active: 'rgba(255,255,255,0.08)', error: 'rgba(255,82,82,0.08)' }[status] || 'rgba(255,255,255,0.03)';
    }

    function setPicoBadge(text, color) {
        const b = document.getElementById('pico-status-badge');
        if (!b) return;
        b.textContent = text;
        b.style.background = color || 'rgba(255,255,255,0.08)';
        b.style.color = '#fff';
    }

    function resetPicoSteps() {
        for (let i = 1; i <= 4; i++) setPicoStep(i, 'pending');
        setPicoProgress(0, 'Ready');
        setPicoBadge('Idle', 'rgba(255,255,255,0.08)');
    }

    function pathBasename(p) {
        if (!p) return '';
        const parts = p.split(/[\\/]/);
        return parts[parts.length - 1];
    }

    function updateSelectedFileInfo(f) {
        const fn = document.getElementById('pico-info-filename');
        const sz = document.getElementById('pico-info-filesize');
        const tg = document.getElementById('pico-info-target');
        const loc = document.getElementById('pico-info-location');

        if (!f) {
            selectedFile = null;
            if (fn) fn.textContent = '-';
            if (sz) sz.textContent = '-';
            if (tg) tg.textContent = '-';
            if (loc) loc.textContent = '-';
            return;
        }

        selectedFile = f;
        if (fn) fn.textContent = f.fileName || pathBasename(f.fullPath);
        if (sz) sz.textContent = f.sizeFormatted || '-';
        if (tg) tg.textContent = f.title || 'Raspberry Pi RP2350';
        if (loc) {
            const isInternal = f.fullPath && (f.fullPath.includes('bin\\pico') || f.fullPath.includes('bin/pico'));
            loc.textContent = isInternal ? '📦 In Project (bin\\pico\\) 🔒 ห้ามลบ' : '📁 External / Custom';
            loc.style.color = isInternal ? '#00b0ff' : '#ffd740';
        }
    }

    // Load firmwares from directory (defaults to internal project library bin/pico)
    async function loadFirmwares(customDir) {
        const fwSelect = document.getElementById('pico-firmware-select');

        if (fwSelect) {
            fwSelect.innerHTML = '<option value="">-- Scanning firmwares... --</option>';
        }

        try {
            const res = await window.api.getPicoFirmwares(customDir || null);
            const displayDir = res?.dir || 'bin\\pico';

            if (!res || !res.exists || !res.files || res.files.length === 0) {
                if (fwSelect) {
                    fwSelect.innerHTML = '<option value="">-- ไม่พบไฟล์ .uf2 ในคลังโปรเจกต์ --</option><option value="__custom__">📁 เลือกไฟล์ .uf2 จากเครื่อง (Browse)...</option>';
                }
                picoLog(`⚠️ ไม่พบไฟล์ .uf2 ใน: ${displayDir}`, '#ffa726');
                updateSelectedFileInfo(null);
                return;
            }

            availableFirmwares = res.files;
            if (fwSelect) {
                fwSelect.innerHTML = '';
                availableFirmwares.forEach((f) => {
                    const opt = document.createElement('option');
                    opt.value = f.fullPath;
                    opt.textContent = `${f.icon} ${f.title} (${f.sizeFormatted})`;
                    fwSelect.appendChild(opt);
                });

                // Add option to browse custom
                const customOpt = document.createElement('option');
                customOpt.value = '__custom__';
                customOpt.textContent = '📁 เลือกไฟล์ .uf2 อื่นๆ จากเครื่อง (Browse)...';
                fwSelect.appendChild(customOpt);

                // Select first
                fwSelect.selectedIndex = 0;
                updateSelectedFileInfo(availableFirmwares[0]);
            }

            picoLog(`✅ โหลดไฟล์เฟิร์มแวร์ในคลังโปรเจกต์ (${availableFirmwares.length} ไฟล์): ${displayDir}`, '#69f0ae');
        } catch(e) {
            picoLog('❌ Error loading firmwares: ' + e.message, '#ff5252');
        }
    }

    // Scan connected drives for Raspberry Pi BOOTSEL
    async function scanPicoDrives(isSilent = false) {
        if (!isSilent) {
            const l = document.getElementById('pico-log');
            if (l) l.innerHTML = '';
        }
        const drvSelect = document.getElementById('pico-drive-select');
        const drvLabel = document.getElementById('pico-drive-label');
        const drvSub = document.getElementById('pico-drive-sub');
        const drvIcon = document.getElementById('pico-drive-icon');

        if (drvLabel) {
            drvLabel.textContent = 'กำลังค้นหาบอร์ด...';
            drvLabel.style.color = '#ffd740';
        }

        try {
            const res = await window.api.scanPicoDrives();
            detectedDrives = res?.picoDrives || [];
            const otherDrives = res?.otherDrives || [];

            if (drvSelect) drvSelect.innerHTML = '';

            if (detectedDrives.length > 0) {
                const mainPico = detectedDrives[0];
                if (drvLabel) {
                    drvLabel.textContent = `ตรวจพบบอร์ดที่ไดรฟ์ [${mainPico.letter}]`;
                    drvLabel.style.color = '#69f0ae';
                }
                if (drvSub) {
                    drvSub.textContent = mainPico.model || 'Raspberry Pi Pico (BOOTSEL Mode)';
                }
                if (drvIcon) {
                    drvIcon.textContent = '🍓';
                    drvIcon.style.filter = 'none';
                }

                detectedDrives.forEach(d => {
                    const opt = document.createElement('option');
                    opt.value = d.letter;
                    opt.textContent = `[${d.letter}] ${d.model}`;
                    drvSelect.appendChild(opt);
                });

                picoLog(`✅ Raspberry Pi Pico detected at ${mainPico.letter} (${mainPico.model})`, '#69f0ae');
            } else {
                if (drvLabel) {
                    drvLabel.textContent = 'ยังไม่พบบอร์ด (Not Detected)';
                    drvLabel.style.color = '#ff5252';
                }
                if (drvSub) {
                    drvSub.textContent = 'กดปุ่ม BOOTSEL บนบอร์ดค้างไว้ แล้วเสียบสาย USB เข้าคอม';
                }
                if (drvIcon) {
                    drvIcon.textContent = '🔌';
                }

                if (drvSelect) {
                    drvSelect.innerHTML = '<option value="">-- ไม่พบไดรฟ์ RPI-RP2 / RP2350 --</option>';
                    otherDrives.forEach(d => {
                        const opt = document.createElement('option');
                        opt.value = d.letter;
                        opt.textContent = `[${d.letter}] Other Drive (Manual Select)`;
                        drvSelect.appendChild(opt);
                    });
                }

                picoLog('⚠️ ไม่พบไดรฟ์ Raspberry Pi ในโหมด BOOTSEL', '#aaa');
                picoLog('   คำแนะนำ: ถอดสาย USB > กดปุ่ม BOOTSEL บนบอร์ดค้างไว้ > เสียบสาย USB เข้าคอม', '#ffd740');
            }
        } catch(e) {
            picoLog('❌ Scan error: ' + e.message, '#ff5252');
        }
    }

    // Event Listeners
    const btnScan = document.getElementById('btn-pico-scan-drives');
    if (btnScan) {
        btnScan.addEventListener('click', scanPicoDrives);
    }


    // Open bin/pico Folder in Explorer
    const btnOpenFolder = document.getElementById('btn-pico-open-folder');
    if (btnOpenFolder) {
        btnOpenFolder.addEventListener('click', async () => {
            try {
                const l = document.getElementById('pico-log');
                if (l) l.innerHTML = '';
                picoLog('📂 เปิดโฟลเดอร์ bin\\pico ใน File Explorer...', '#aaa');
                await window.api.openPicoFolder();
            } catch (err) {
                picoLog(`❌ ไม่สามารถเปิดโฟลเดอร์ได้: ${err.message}`, '#ff5252');
            }
        });
    }

    const fwSelectEl = document.getElementById('pico-firmware-select');
    if (fwSelectEl) {
        fwSelectEl.addEventListener('change', async () => {
            const val = fwSelectEl.value;
            if (val === '__custom__') {
                try {
                    const pick = await window.api.showOpenDialog({
                        title: 'Select .uf2 Firmware File',
                        filters: [
                            { name: 'Pico UF2 Firmware', extensions: ['uf2'] },
                            { name: 'All Files', extensions: ['*'] }
                        ],
                        properties: ['openFile']
                    });
                    const cp = resolveDialogPath(pick);
                    if (cp) {
                        const customObj = {
                            fileName: pathBasename(cp),
                            fullPath: cp,
                            sizeFormatted: 'Custom',
                            title: 'Custom UF2 File'
                        };
                        updateSelectedFileInfo(customObj);
                        picoLog('📁 Selected custom file: ' + cp, '#69f0ae');
                    } else {
                        if (availableFirmwares.length > 0) {
                            fwSelectEl.selectedIndex = 0;
                            updateSelectedFileInfo(availableFirmwares[0]);
                        }
                    }
                } catch(e) {}
            } else {
                const found = availableFirmwares.find(f => f.fullPath === val);
                updateSelectedFileInfo(found || { fullPath: val, fileName: pathBasename(val), title: 'Firmware' });
            }
        });
    }

    const btnClearLog = document.getElementById('btn-pico-clear-log');
    if (btnClearLog) {
        btnClearLog.addEventListener('click', () => {
            const l = document.getElementById('pico-log');
            if (l) l.innerHTML = '';
        });
    }

    // Flash Button Action
    const btnFlash = document.getElementById('btn-pico-flash');
    if (btnFlash) {
        btnFlash.addEventListener('click', async () => {
            const l = document.getElementById('pico-log');
            if (l) l.innerHTML = '';
            const drvSelect = document.getElementById('pico-drive-select');
            const targetDrive = drvSelect?.value;

            if (!selectedFile || !selectedFile.fullPath) {
                alert('กรุณาเลือกไฟล์เฟิร์มแวร์ .uf2 ก่อนกดแฟลช');
                return;
            }

            if (!targetDrive) {
                alert('ยังไม่พบไดรฟ์ Raspberry Pi (BOOTSEL)\n\nกรุณากดปุ่ม BOOTSEL บนบอร์ดค้างไว้ แล้วเสียบสาย USB เข้าคอมพิวเตอร์');
                return;
            }

            btnFlash.disabled = true;
            resetPicoSteps();
            setPicoBadge('Flashing...', 'rgba(233,30,99,0.6)');
            
            picoLog('==================================================', '#555');
            picoLog(`⚡ เริ่มกระบวนการแฟลช ${selectedFile.title || 'usbliter8'}...`, '#fff');
            picoLog(`   ไฟล์ต้นทาง: ${selectedFile.fullPath}`, '#aaa');
            picoLog(`   ไดรฟ์เป้าหมาย: ${targetDrive}`, '#aaa');

            // Step 1: Check Target Drive
            setPicoStep(1, 'active');
            setPicoProgress(20, 'Checking target drive...');
            await new Promise(r => setTimeout(r, 400));
            try {
                setPicoStep(1, 'done');
                picoLog(`✅ ไดรฟ์ [${targetDrive}] พร้อมสำหรับการเขียนเฟิร์มแวร์`, '#69f0ae');
            } catch(e) {
                setPicoStep(1, 'error');
                setPicoBadge('Failed', 'rgba(255,82,82,0.6)');
                picoLog('❌ Drive error: ' + e.message, '#ff5252');
                btnFlash.disabled = false;
                return;
            }

            // Step 2: Verify UF2 Payload
            setPicoStep(2, 'active');
            setPicoProgress(45, 'Verifying UF2 payload...');
            await new Promise(r => setTimeout(r, 300));
            try {
                setPicoStep(2, 'done');
                picoLog(`✅ ไฟล์ UF2 ถูกต้อง (${selectedFile.fileName})`, '#69f0ae');
            } catch(e) {
                setPicoStep(2, 'error');
                setPicoBadge('Failed', 'rgba(255,82,82,0.6)');
                picoLog('❌ File error: ' + e.message, '#ff5252');
                btnFlash.disabled = false;
                return;
            }

            // Step 3: Copy to Flash
            setPicoStep(3, 'active');
            setPicoProgress(70, 'Writing UF2 to Raspberry Pi...');
            picoLog(`> กำลังคัดลอกไฟล์ลงบอร์ด ${targetDrive}\\${selectedFile.fileName}...`, '#aaa');
            await new Promise(r => setTimeout(r, 500));

            try {
                const flashRes = await window.api.invoke('flash-pico-uf2', {
                    filePath: selectedFile.fullPath,
                    driveLetter: targetDrive
                });

                if (!flashRes.success) {
                    throw new Error(flashRes.error || 'Copy failed');
                }

                setPicoStep(3, 'done');
                picoLog(`✅ เขียนไฟล์ลงแฟลชเมมโมรีเรียบร้อย (${flashRes.message})`, '#69f0ae');
            } catch(e) {
                setPicoStep(3, 'error');
                setPicoBadge('Failed', 'rgba(255,82,82,0.6)');
                picoLog('❌ Flash error: ' + e.message, '#ff5252');
                btnFlash.disabled = false;
                return;
            }

            // Step 4: Auto-reboot & complete
            setPicoStep(4, 'active');
            setPicoProgress(90, 'Verifying auto-reboot...');
            await new Promise(r => setTimeout(r, 800));

            setPicoStep(4, 'done');
            setPicoProgress(100, '✅ Flash Complete!');
            setPicoBadge('Success!', 'rgba(105,240,174,0.4)');

            picoLog('', '');
            picoLog('🎉 แฟลชเฟิร์มแวร์เข้าบอร์ด Raspberry Pi สำเร็จแล้ว!', '#69f0ae');
            picoLog('💡 บอร์ดได้ทำการรีบูตเข้าสู่โปรแกรม usbliter8 เรียบร้อยแล้ว พร้อมใช้งาน!', '#ffd740');
            picoLog('==================================================', '#555');

            btnFlash.disabled = false;

            setTimeout(scanPicoDrives, 1500);
        });
    }

    // Auto-init on section load or startup
    loadFirmwares();
    scanPicoDrives();

    // Hook to reload when user clicks on pico-section nav button
    const picoNavBtn = document.querySelector('.nav-btn[data-target="pico-section"]');
    if (picoNavBtn) {
        picoNavBtn.addEventListener('click', () => {
            loadFirmwares();
            scanPicoDrives();
        });
    }
})();


// ============================================================================
// 🚀 20 PRO SUPERPOWERS SUITE (SYSTEM & MOBILE TOOLS CONTROLLER)
// ============================================================================
(function init20ProSuperpowers() {
    console.log('[PRO SUPERPOWERS] Initializing 20 Pro Features Controller...');

    function setStatusBox(elId, msg, isSuccess = true, isLoading = false) {
        const el = document.getElementById(elId);
        if (!el) return;
        el.style.display = 'block';
        if (isLoading) {
            el.style.background = 'rgba(56, 189, 248, 0.15)';
            el.style.color = '#38bdf8';
            el.style.border = '1px solid rgba(56, 189, 248, 0.3)';
            el.innerHTML = `<i class="fas fa-spinner fa-spin"></i> ${msg}`;
        } else if (isSuccess) {
            el.style.background = 'rgba(34, 197, 94, 0.15)';
            el.style.color = '#4ade80';
            el.style.border = '1px solid rgba(34, 197, 94, 0.3)';
            el.innerHTML = `<i class="fas fa-check-circle"></i> ${msg}`;
        } else {
            el.style.background = 'rgba(239, 68, 68, 0.15)';
            el.style.color = '#f87171';
            el.style.border = '1px solid rgba(239, 68, 68, 0.3)';
            el.innerHTML = `<i class="fas fa-exclamation-triangle"></i> ${msg}`;
        }
    }

    // -------------------------------------------------------------
    // 1. RAM Memory Cleaner
    // -------------------------------------------------------------
    const btnCleanRam = document.getElementById('btn-clean-ram');
    if (btnCleanRam) {
        btnCleanRam.addEventListener('click', async () => {
            btnCleanRam.disabled = true;
            setStatusBox('ram-cleaner-status', 'กำลังล้าง WorkingSet Cache และคืนหน่วยความจำ...', true, true);
            try {
                const res = await window.api.cleanRam();
                if (res.success) {
                    const freed = res.FreedMB > 0 ? `${res.FreedMB} MB` : 'หน่วยความจำถูกจัดระเบียบแล้ว';
                    setStatusBox('ram-cleaner-status', `สำเร็จ! ก่อนล้าง: ${res.BeforeMB} MB | หลังล้าง: ${res.AfterMB} MB (คืนแรม: ${freed})`, true);
                } else {
                    setStatusBox('ram-cleaner-status', `ข้อผิดพลาด: ${res.error}`, false);
                }
            } catch (err) {
                setStatusBox('ram-cleaner-status', `เกิดข้อผิดพลาด: ${err.message}`, false);
            } finally {
                btnCleanRam.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 2. SSD/HDD S.M.A.R.T. Health
    // -------------------------------------------------------------
    const btnDiskHealth = document.getElementById('btn-disk-health');
    const diskDetails = document.getElementById('disk-health-details');
    if (btnDiskHealth && diskDetails) {
        btnDiskHealth.addEventListener('click', async () => {
            btnDiskHealth.disabled = true;
            diskDetails.style.display = 'block';
            diskDetails.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังอ่านสถานะ S.M.A.R.T. ของไดรฟ์...';
            try {
                const res = await window.api.getDiskHealth();
                if (res.success && res.disks && res.disks.length > 0) {
                    let html = '';
                    res.disks.forEach((d, idx) => {
                        const statusColor = d.Status === 'OK' ? '#4ade80' : '#f87171';
                        html += `<div style="margin-bottom: 6px; border-bottom: 1px solid rgba(255,255,255,0.05); padding-bottom: 4px;">
                            <strong>[Drive ${idx + 1}]</strong> ${d.Model}<br>
                            ความจุ: <strong>${d.SizeGB} GB</strong> | ชนิด: ${d.MediaType || d.Interface}<br>
                            สถานะ: <span style="color:${statusColor}; font-weight:bold;">${d.Status}</span> | S/N: ${d.Serial}
                        </div>`;
                    });
                    diskDetails.innerHTML = html;
                } else {
                    diskDetails.innerHTML = `<span style="color:#f87171;">ไม่สามารถอ่านข้อมูลไดรฟ์ได้: ${res.error || 'ไม่มีข้อมูล'}</span>`;
                }
            } catch (err) {
                diskDetails.innerHTML = `<span style="color:#f87171;">Error: ${err.message}</span>`;
            } finally {
                btnDiskHealth.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 3. Hardware Specs & Serial Inspector
    // -------------------------------------------------------------
    const btnHwSpecs = document.getElementById('btn-hw-specs');
    const hwDetails = document.getElementById('hw-specs-details');
    if (btnHwSpecs && hwDetails) {
        btnHwSpecs.addEventListener('click', async () => {
            btnHwSpecs.disabled = true;
            hwDetails.style.display = 'block';
            hwDetails.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังตรวจสอบฮาร์ดแวร์ระบบ...';
            try {
                const res = await window.api.getHardwareSpecs();
                if (res.success && res.specs) {
                    const s = res.specs;
                    hwDetails.innerHTML = `
                        <strong>CPU:</strong> ${s.CPU || 'N/A'}<br>
                        <strong>Motherboard:</strong> ${s.Motherboard || 'N/A'}<br>
                        <strong>RAM รวม:</strong> ${s.RAM_GB} GB (${s.RAM_Sticks} สล็อต)<br>
                        <strong>GPU:</strong> ${s.GPU || 'N/A'}<br>
                        <strong>BIOS:</strong> ${s.BIOS || 'N/A'}<br>
                        <strong>OS:</strong> ${s.OS} (Build ${s.Build})<br>
                        <strong>Serial No.:</strong> <span style="color:#facc15; font-weight:bold;">${s.Serial || 'N/A'}</span>
                    `;
                } else {
                    hwDetails.innerHTML = `<span style="color:#f87171;">ไม่สามารถดึงข้อมูลสเปกได้: ${res.error}</span>`;
                }
            } catch (err) {
                hwDetails.innerHTML = `<span style="color:#f87171;">Error: ${err.message}</span>`;
            } finally {
                btnHwSpecs.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 4. Auto-Shutdown Timer
    // -------------------------------------------------------------
    let shutdownInterval = null;
    let remainingSec = 0;
    const btnSetShutdown = document.getElementById('btn-set-shutdown-timer');
    const btnCancelShutdown = document.getElementById('btn-cancel-shutdown-timer');

    if (btnSetShutdown) {
        btnSetShutdown.addEventListener('click', async () => {
            const timeSel = document.getElementById('shutdown-time-select');
            const actionSel = document.getElementById('shutdown-action-select');
            const sec = parseInt(timeSel ? timeSel.value : '1800');
            const act = actionSel ? actionSel.value : 'shutdown';

            setStatusBox('shutdown-timer-status', 'กำลังตั้งเวลา...', true, true);
            try {
                const res = await window.api.setShutdownTimer(sec, act);
                if (res.success) {
                    remainingSec = sec;
                    clearInterval(shutdownInterval);
                    shutdownInterval = setInterval(() => {
                        if (remainingSec <= 0) {
                            clearInterval(shutdownInterval);
                            setStatusBox('shutdown-timer-status', `ดำเนินการ${act === 'restart' ? 'รีสตาร์ท' : 'ปิดเครื่อง'}แล้ว`, true);
                        } else {
                            const mins = Math.floor(remainingSec / 60);
                            const s = remainingSec % 60;
                            setStatusBox('shutdown-timer-status', `⏱️ จะ${act === 'restart' ? 'รีสตาร์ท' : 'ปิดเครื่อง'}ในอีก ${mins} นาที ${s} วินาที`, true);
                            remainingSec--;
                        }
                    }, 1000);
                } else {
                    setStatusBox('shutdown-timer-status', `ไม่สามารถตั้งเวลาได้: ${res.error}`, false);
                }
            } catch (e) {
                setStatusBox('shutdown-timer-status', `Error: ${e.message}`, false);
            }
        });
    }

    if (btnCancelShutdown) {
        btnCancelShutdown.addEventListener('click', async () => {
            clearInterval(shutdownInterval);
            try {
                const res = await window.api.cancelShutdownTimer();
                if (res.success) {
                    setStatusBox('shutdown-timer-status', 'ยกเลิกการตั้งเวลาปิดเครื่องแล้ว', true);
                } else {
                    setStatusBox('shutdown-timer-status', `Error: ${res.error}`, false);
                }
            } catch (e) {
                setStatusBox('shutdown-timer-status', `Error: ${e.message}`, false);
            }
        });
    }

    // -------------------------------------------------------------
    // 5. Context Menu Cleaner
    // -------------------------------------------------------------
    const btnContextMenu = document.getElementById('btn-context-menu-mgr');
    const contextMenuList = document.getElementById('context-menu-list');
    if (btnContextMenu && contextMenuList) {
        btnContextMenu.addEventListener('click', async () => {
            btnContextMenu.disabled = true;
            contextMenuList.style.display = 'block';
            contextMenuList.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังสแกน Context Menu Handlers...';
            try {
                const res = await window.api.getContextMenuItems();
                if (res.success && res.items && res.items.length > 0) {
                    let html = `<div style="font-weight:bold; margin-bottom:4px; color:#38bdf8;">พบเมนูส่วนขยาย ${res.items.length} รายการ:</div>`;
                    res.items.forEach(it => {
                        html += `<div>• <span style="color:#f8fafc;">${it.Name}</span> <span style="color:#94a3b8; font-size:10px;">(${it.Target || it.Path})</span></div>`;
                    });
                    contextMenuList.innerHTML = html;
                } else {
                    contextMenuList.innerHTML = 'ไม่พบเมนูคลิกขวาที่ผิดปกติ';
                }
            } catch (e) {
                contextMenuList.innerHTML = `<span style="color:#f87171;">Error: ${e.message}</span>`;
            } finally {
                btnContextMenu.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 6. Telemetry & Bloatware Disabler
    // -------------------------------------------------------------
    const btnTelemetry = document.getElementById('btn-disable-telemetry');
    if (btnTelemetry) {
        btnTelemetry.addEventListener('click', async () => {
            btnTelemetry.disabled = true;
            setStatusBox('telemetry-status', 'กำลังปิด DiagTrack และ Telemetry ใน Registry...', true, true);
            try {
                const res = await window.api.disableTelemetry();
                if (res.success) {
                    setStatusBox('telemetry-status', 'ปิด Telemetry, DiagTrack และ Background Tracking เรียบร้อยแล้ว', true);
                } else {
                    setStatusBox('telemetry-status', `ข้อผิดพลาด: ${res.message || res.error}`, false);
                }
            } catch (e) {
                setStatusBox('telemetry-status', `Error: ${e.message}`, false);
            } finally {
                btnTelemetry.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 7. Icon & Font Cache Rebuilder
    // -------------------------------------------------------------
    const btnIconCache = document.getElementById('btn-rebuild-icon-cache');
    if (btnIconCache) {
        btnIconCache.addEventListener('click', async () => {
            btnIconCache.disabled = true;
            setStatusBox('icon-cache-status', 'กำลังลบ IconCache.db และรีสตาร์ท Windows Explorer...', true, true);
            try {
                const res = await window.api.rebuildIconCache();
                if (res.success) {
                    setStatusBox('icon-cache-status', 'ล้างและสร้างแคชไอคอนใหม่เรียบร้อยแล้ว!', true);
                } else {
                    setStatusBox('icon-cache-status', `ข้อผิดพลาด: ${res.message || res.error}`, false);
                }
            } catch (e) {
                setStatusBox('icon-cache-status', `Error: ${e.message}`, false);
            } finally {
                btnIconCache.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 8. System Restore Points
    // -------------------------------------------------------------
    const btnCreateRestore = document.getElementById('btn-create-restore-point');
    const btnListRestore = document.getElementById('btn-list-restore-points');
    const restoreList = document.getElementById('restore-point-list');

    if (btnCreateRestore) {
        btnCreateRestore.addEventListener('click', async () => {
            btnCreateRestore.disabled = true;
            if (restoreList) {
                restoreList.style.display = 'block';
                restoreList.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังสร้างจุด Restore Point...';
            }
            try {
                const res = await window.api.createRestorePoint('THAIVPN Tools Pro Point');
                if (res.success) {
                    if (restoreList) restoreList.innerHTML = `<span style="color:#4ade80;"><i class="fas fa-check"></i> ${res.message}</span>`;
                } else {
                    if (restoreList) restoreList.innerHTML = `<span style="color:#f87171;">Error: ${res.message || res.error}</span>`;
                }
            } catch (e) {
                if (restoreList) restoreList.innerHTML = `<span style="color:#f87171;">Error: ${e.message}</span>`;
            } finally {
                btnCreateRestore.disabled = false;
            }
        });
    }

    if (btnListRestore && restoreList) {
        btnListRestore.addEventListener('click', async () => {
            btnListRestore.disabled = true;
            restoreList.style.display = 'block';
            restoreList.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังดึงรายการจุด Restore Points...';
            try {
                const res = await window.api.getRestorePoints();
                if (res.success && res.points && res.points.length > 0) {
                    let html = `<div style="font-weight:bold; margin-bottom:4px; color:#38bdf8;">พบจุดกู้คืน ${res.points.length} รายการ:</div>`;
                    res.points.forEach(p => {
                        html += `<div>• <strong>#${p.SequenceNumber}</strong>: ${p.Description} <span style="color:#94a3b8; font-size:10px;">(${p.CreationTime})</span></div>`;
                    });
                    restoreList.innerHTML = html;
                } else {
                    restoreList.innerHTML = 'ยังไม่มีจุดกู้คืน หรือ System Restore ปิดอยู่';
                }
            } catch (e) {
                restoreList.innerHTML = `<span style="color:#f87171;">Error: ${e.message}</span>`;
            } finally {
                btnListRestore.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 9. File Lock Hunter
    // -------------------------------------------------------------
    const btnBrowseFileLock = document.getElementById('btn-browse-file-lock');
    const btnCheckFileLock = document.getElementById('btn-check-file-lock');
    const inputFileLock = document.getElementById('input-file-lock-path');
    const fileLockResults = document.getElementById('file-lock-results');

    if (btnBrowseFileLock) {
        btnBrowseFileLock.addEventListener('click', async () => {
            const res = await window.api.findFileLock(null);
            if (res.filePath) {
                if (inputFileLock) inputFileLock.value = res.filePath;
                renderFileLocks(res);
            }
        });
    }

    if (btnCheckFileLock) {
        btnCheckFileLock.addEventListener('click', async () => {
            const p = inputFileLock ? inputFileLock.value.trim() : '';
            btnCheckFileLock.disabled = true;
            if (fileLockResults) {
                fileLockResults.style.display = 'block';
                fileLockResults.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังตรวจสอบ Process ที่ล็อกไฟล์...';
            }
            try {
                const res = await window.api.findFileLock(p);
                renderFileLocks(res);
            } catch (e) {
                if (fileLockResults) fileLockResults.innerHTML = `<span style="color:#f87171;">Error: ${e.message}</span>`;
            } finally {
                btnCheckFileLock.disabled = false;
            }
        });
    }

    function renderFileLocks(res) {
        if (!fileLockResults) return;
        fileLockResults.style.display = 'block';
        if (res.locks && res.locks.length > 0) {
            let html = `<div style="font-weight:bold; color:#f87171; margin-bottom:6px;">⚠️ พบโปรแกรมที่ล็อกไฟล์ ${res.locks.length} ตัว:</div>`;
            res.locks.forEach(l => {
                html += `<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
                    <span><strong>${l.name}</strong> (PID: ${l.pid})</span>
                    <button class="action-btn danger-btn btn-kill-lock" data-pid="${l.pid}" style="padding:2px 8px; font-size:11px;">ปลดล็อก (Kill)</button>
                </div>`;
            });
            fileLockResults.innerHTML = html;
            fileLockResults.querySelectorAll('.btn-kill-lock').forEach(b => {
                b.addEventListener('click', async (e) => {
                    const pid = e.target.dataset.pid;
                    const killRes = await window.api.unlockFile(pid);
                    if (killRes.success) {
                        e.target.parentElement.innerHTML = `<span style="color:#4ade80;">✅ ปิดสำเร็จ (PID ${pid})</span>`;
                    } else {
                        alert('ไม่สามารถปิด Process ได้: ' + killRes.error);
                    }
                });
            });
        } else {
            fileLockResults.innerHTML = '<span style="color:#4ade80;"><i class="fas fa-check"></i> ไม่พบ Process ใดล็อกไฟล์นี้ สามารถลบหรือย้ายได้ตามปกติ</span>';
        }
    }

    // -------------------------------------------------------------
    // 10. Defender Exclusion
    // -------------------------------------------------------------
    const btnDefenderExclusion = document.getElementById('btn-add-defender-exclusion');
    if (btnDefenderExclusion) {
        btnDefenderExclusion.addEventListener('click', async () => {
            btnDefenderExclusion.disabled = true;
            setStatusBox('defender-exclusion-status', 'กำลังเลือกโฟลเดอร์และเพิ่ม Exclusion...', true, true);
            try {
                const res = await window.api.addDefenderExclusion(null);
                if (res.canceled) {
                    setStatusBox('defender-exclusion-status', 'ยกเลิกการเลือกโฟลเดอร์', false);
                } else if (res.success) {
                    setStatusBox('defender-exclusion-status', `เพิ่มโฟลเดอร์ลง Exclusion เรียบร้อยแล้ว: ${res.path}`, true);
                } else {
                    setStatusBox('defender-exclusion-status', `ข้อผิดพลาด: ${res.message || res.error}`, false);
                }
            } catch (e) {
                setStatusBox('defender-exclusion-status', `Error: ${e.message}`, false);
            } finally {
                btnDefenderExclusion.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 11. DNS Speed Benchmark & Switcher
    // -------------------------------------------------------------
    const btnDnsBench = document.getElementById('btn-dns-benchmark');
    const btnDnsApply = document.getElementById('btn-dns-apply');
    const dnsResults = document.getElementById('dns-benchmark-results');

    if (btnDnsBench && dnsResults) {
        btnDnsBench.addEventListener('click', async () => {
            btnDnsBench.disabled = true;
            dnsResults.style.display = 'block';
            dnsResults.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังวัดค่า Ping ไปยัง DNS แต่ละค่าย...';
            try {
                const res = await window.api.benchmarkDns();
                if (res.success && res.results) {
                    let html = '<div style="font-weight:bold; color:#38bdf8; margin-bottom:4px;">ผลการทดสอบความเร็ว DNS:</div>';
                    res.results.forEach((r, idx) => {
                        const pingBadge = r.PingMs < 30 ? '#4ade80' : (r.PingMs < 60 ? '#facc15' : '#f87171');
                        const star = idx === 0 ? ' ⚡ (เร็วที่สุด)' : '';
                        html += `<div><strong>${r.Name}</strong> (${r.Primary}): <span style="color:${pingBadge}; font-weight:bold;">${r.PingMs} ms</span>${star}</div>`;
                    });
                    dnsResults.innerHTML = html;
                } else {
                    dnsResults.innerHTML = `<span style="color:#f87171;">วัดความเร็วไม่สำเร็จ: ${res.error}</span>`;
                }
            } catch (e) {
                dnsResults.innerHTML = `<span style="color:#f87171;">Error: ${e.message}</span>`;
            } finally {
                btnDnsBench.disabled = false;
            }
        });
    }

    if (btnDnsApply) {
        btnDnsApply.addEventListener('click', async () => {
            const sel = document.getElementById('dns-target-select');
            const val = sel ? sel.value : 'cloudflare';
            let primary = '1.1.1.1', secondary = '1.0.0.1', isDhcp = false;
            if (val === 'google') { primary = '8.8.8.8'; secondary = '8.8.4.4'; }
            else if (val === 'quad9') { primary = '9.9.9.9'; secondary = '149.112.112.112'; }
            else if (val === 'dhcp') { isDhcp = true; }

            btnDnsApply.disabled = true;
            try {
                const res = await window.api.setAdapterDns(primary, secondary, isDhcp);
                alert(res.message || 'ตั้งค่า DNS สำเร็จแล้ว');
            } catch (e) {
                alert('Error: ' + e.message);
            } finally {
                btnDnsApply.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 12. Bandwidth Hog Detector
    // -------------------------------------------------------------
    const btnBandwidth = document.getElementById('btn-check-bandwidth');
    const bandwidthList = document.getElementById('bandwidth-hogs-list');
    if (btnBandwidth && bandwidthList) {
        btnBandwidth.addEventListener('click', async () => {
            btnBandwidth.disabled = true;
            bandwidthList.style.display = 'block';
            bandwidthList.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังตรวจสอบการเชื่อมต่ออินเตอร์เน็ต...';
            try {
                const res = await window.api.getBandwidthHogs();
                if (res.success && res.hogs && res.hogs.length > 0) {
                    let html = '<div style="font-weight:bold; color:#f59e0b; margin-bottom:4px;">โปรแกรมที่เปิด Connection สูงสุด:</div>';
                    res.hogs.forEach((h, idx) => {
                        html += `<div><strong>${idx + 1}. ${h.ProcessName}</strong> (PID: ${h.PID}) - ${h.Connections} ช่องทาง | RAM: ${h.WorkingSetMB} MB</div>`;
                    });
                    bandwidthList.innerHTML = html;
                } else {
                    bandwidthList.innerHTML = 'ไม่พบโปรแกรมที่ใช้งานเน็ตหนาแน่น';
                }
            } catch (e) {
                bandwidthList.innerHTML = `<span style="color:#f87171;">Error: ${e.message}</span>`;
            } finally {
                btnBandwidth.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 13. Virtual WiFi Hotspot
    // -------------------------------------------------------------
    const btnHotspotStart = document.getElementById('btn-hotspot-start');
    const btnHotspotStop = document.getElementById('btn-hotspot-stop');

    if (btnHotspotStart) {
        btnHotspotStart.addEventListener('click', async () => {
            const ssid = document.getElementById('input-hotspot-ssid')?.value.trim() || 'THAIVPN_Hotspot';
            const key = document.getElementById('input-hotspot-key')?.value.trim() || '12345678';
            setStatusBox('hotspot-status', 'กำลังเปิด Mobile Hotspot...', true, true);
            try {
                const res = await window.api.toggleWifiHotspot(true, ssid, key);
                if (res.success) {
                    setStatusBox('hotspot-status', res.message || `เปิด WiFi Hotspot "${ssid}" สำเร็จแล้ว!`, true);
                } else {
                    setStatusBox('hotspot-status', `ไม่สามารถเปิด Hotspot ได้: ${res.message || res.error || res.raw}`, false);
                }
            } catch (e) {
                setStatusBox('hotspot-status', `Error: ${e.message}`, false);
            }
        });
    }

    if (btnHotspotStop) {
        btnHotspotStop.addEventListener('click', async () => {
            try {
                const res = await window.api.toggleWifiHotspot(false, '', '');
                setStatusBox('hotspot-status', 'ปิดสัญญาณ Hotspot เรียบร้อยแล้ว', true);
            } catch (e) {
                setStatusBox('hotspot-status', `Error: ${e.message}`, false);
            }
        });
    }

    // -------------------------------------------------------------
    // 14. Hosts Adblock Presets
    // -------------------------------------------------------------
    const btnHostsAdblock = document.getElementById('btn-hosts-adblock');
    const btnHostsRestore = document.getElementById('btn-hosts-restore');

    if (btnHostsAdblock) {
        btnHostsAdblock.addEventListener('click', async () => {
            btnHostsAdblock.disabled = true;
            setStatusBox('hosts-preset-status', 'กำลังบันทึกกฎ Adblock ลงไฟล์ Hosts...', true, true);
            try {
                const res = await window.api.applyHostsPreset('adblock');
                setStatusBox('hosts-preset-status', res.message || res.error, res.success);
            } catch (e) {
                setStatusBox('hosts-preset-status', `Error: ${e.message}`, false);
            } finally {
                btnHostsAdblock.disabled = false;
            }
        });
    }

    if (btnHostsRestore) {
        btnHostsRestore.addEventListener('click', async () => {
            btnHostsRestore.disabled = true;
            try {
                const res = await window.api.applyHostsPreset('restore');
                setStatusBox('hosts-preset-status', res.message || res.error, res.success);
            } catch (e) {
                setStatusBox('hosts-preset-status', `Error: ${e.message}`, false);
            } finally {
                btnHostsRestore.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 15. TCP/IP Latency Optimizer
    // -------------------------------------------------------------
    const btnTcpOpt = document.getElementById('btn-tcp-optimize');
    if (btnTcpOpt) {
        btnTcpOpt.addEventListener('click', async () => {
            btnTcpOpt.disabled = true;
            setStatusBox('tcp-optimize-status', 'กำลังปรับแต่งเน็ตเวิร์กสแต็ก TCP/IP...', true, true);
            try {
                const res = await window.api.optimizeTcp();
                setStatusBox('tcp-optimize-status', res.message || res.error, res.success);
            } catch (e) {
                setStatusBox('tcp-optimize-status', `Error: ${e.message}`, false);
            } finally {
                btnTcpOpt.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 16. 1-Click APK Installer
    // -------------------------------------------------------------
    const btnBrowseApk = document.getElementById('btn-browse-apk');
    const btnInstallApk = document.getElementById('btn-install-apk');
    const inputApkPath = document.getElementById('input-apk-path');

    if (btnBrowseApk) {
        btnBrowseApk.addEventListener('click', async () => {
            const res = await window.api.adbInstallApk(null, null);
            if (res && res.apkPath) {
                if (inputApkPath) inputApkPath.value = res.apkPath;
                if (res.success) {
                    setStatusBox('apk-install-status', `ติดตั้งสำเร็จ: ${res.output}`, true);
                } else if (!res.canceled) {
                    setStatusBox('apk-install-status', `ติดตั้งล้มเหลว: ${res.error || res.output}`, false);
                }
            }
        });
    }

    if (btnInstallApk) {
        btnInstallApk.addEventListener('click', async () => {
            const p = inputApkPath ? inputApkPath.value.trim() : '';
            if (!p) {
                alert('กรุณาเลือกไฟล์ APK ก่อน');
                return;
            }
            btnInstallApk.disabled = true;
            setStatusBox('apk-install-status', 'กำลังส่งไฟล์และสั่งติดตั้งผ่าน ADB...', true, true);
            openModal('ADB: Install APK');
            logToModal(`> Target APK: ${p}\n`);
            logToModal('> Pushing and installing APK package via ADB...\n');
            try {
                const res = await window.api.adbInstallApk(p, null);
                if (res.success) {
                    setStatusBox('apk-install-status', `ติดตั้งแอปสำเร็จเรียบร้อย! (${res.output})`, true);
                    logToModal(`\n${res.output || 'Install success!'}\n`, 'success');
                    finishModal(true);
                } else {
                    setStatusBox('apk-install-status', `ติดตั้งไม่สำเร็จ: ${res.error || res.output}`, false);
                    logToModal(`\n[ERROR] ${res.error || res.output}\n`, 'error');
                    finishModal(false);
                }
            } catch (e) {
                setStatusBox('apk-install-status', `Error: ${e.message}`, false);
                logToModal(`\n[ERROR] ${e.message}\n`, 'error');
                finishModal(false);
            } finally {
                btnInstallApk.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 17. Live Screen Mirror
    // -------------------------------------------------------------
    const btnScreenMirror = document.getElementById('btn-screen-mirror');

    if (btnScreenMirror) {
        btnScreenMirror.addEventListener('click', async () => {
            btnScreenMirror.disabled = true;
            setStatusBox('screen-mirror-status', 'กำลังเชื่อมต่อและดึงภาพหน้าจอ...', true, true);
            try {
                const res = await window.api.launchScreenMirror(null);
                if (res.success) {
                    setStatusBox('screen-mirror-status', res.message || 'เปิดหน้าต่าง Live Screen Mirror เรียบร้อยแล้ว', true);
                } else {
                    setStatusBox('screen-mirror-status', `ไม่สามารถเปิด Mirror ได้: ${res.error}`, false);
                }
            } catch (e) {
                setStatusBox('screen-mirror-status', `Error: ${e.message}`, false);
            } finally {
                btnScreenMirror.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 18. Flashing Driver Conflict Auto-Fixer
    // -------------------------------------------------------------
    const btnDriverFix = document.getElementById('btn-fix-driver-conflicts');
    if (btnDriverFix) {
        btnDriverFix.addEventListener('click', async () => {
            btnDriverFix.disabled = true;
            setStatusBox('driver-fix-status', 'กำลังรีเซ็ต ADB Port Server และสแกนพอร์ต...', true, true);
            openModal('System: Fix Flashing Driver Conflicts');
            logToModal('> Resetting ADB Server & cleaning up conflicting USB filter drivers...\n');
            try {
                const res = await window.api.fixDriverConflicts();
                const msg = res.Message || res.message || 'รีเซ็ตไดรเวอร์พอร์ตเสร็จสมบูรณ์';
                setStatusBox('driver-fix-status', msg, true);
                logToModal(`\n✅ ${msg}\n`, 'success');
                finishModal(true);
            } catch (e) {
                setStatusBox('driver-fix-status', `Error: ${e.message}`, false);
            } finally {
                btnDriverFix.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 19. 1-Click Android Backup & Extractor
    // -------------------------------------------------------------
    const btnAndroidBackup = document.getElementById('btn-android-backup');
    if (btnAndroidBackup) {
        btnAndroidBackup.addEventListener('click', async () => {
            const folderSel = document.getElementById('backup-folder-type');
            const folderType = folderSel ? folderSel.value : 'dcim';
            btnAndroidBackup.disabled = true;
            setStatusBox('android-backup-status', `กำลังดึงข้อมูลจากโฟลเดอร์ ${folderType.toUpperCase()} ผ่าน ADB...`, true, true);
            openModal(`Storage: 1-Click Storage Extractor (${folderType.toUpperCase()})`);
            logToModal(`> Pulling files from /sdcard/${folderType.toUpperCase()} to Desktop...\n`);
            try {
                const res = await window.api.backupAndroidStorage(folderType, null, null);
                if (res.success) {
                    setStatusBox('android-backup-status', `สำรองข้อมูลสำเร็จ! บันทึกไว้ที่: ${res.destDir}`, true);
                    logToModal(`\n✅ Backup completed successfully!\n> Saved to: ${res.destDir}\n`, 'success');
                    finishModal(true);
                } else {
                    setStatusBox('android-backup-status', `สำรองข้อมูลไม่สำเร็จ: ${res.error}`, false);
                }
            } catch (e) {
                setStatusBox('android-backup-status', `Error: ${e.message}`, false);
            } finally {
                btnAndroidBackup.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 20. EFS / NVRAM Modem Backup Tool
    // -------------------------------------------------------------
    const btnBackupEfs = document.getElementById('btn-backup-efs');
    if (btnBackupEfs) {
        btnBackupEfs.addEventListener('click', async () => {
            btnBackupEfs.disabled = true;
            setStatusBox('efs-backup-status', 'กำลังตรวจสอบสิทธิ์ Root และดึงพาร์ติชันโมเด็ม...', true, true);
            openModal('Security: Backup EFS / NVRAM Modem');
            logToModal('> Scanning modem partitions (modemst1, modemst2, fsg, fsc, nvram)...\n');
            try {
                const res = await window.api.backupEfsPartitions(null, null);
                if (res.success) {
                    setStatusBox('efs-backup-status', `สำรองพาร์ติชันสำเร็จ! (${res.backedUp.join(', ')}) เก็บไว้ที่: ${res.destDir}`, true);
                    logToModal(`\n✅ EFS partitions saved successfully! (${res.backedUp.join(', ')})\n> Target: ${res.destDir}\n`, 'success');
                    finishModal(true);
                } else {
                    setStatusBox('efs-backup-status', `ไม่สามารถสำรองได้: ${res.error}`, false);
                }
            } catch (e) {
                setStatusBox('efs-backup-status', `Error: ${e.message}`, false);
            } finally {
                btnBackupEfs.disabled = false;
            }
        });
    }

    console.log('[PRO SUPERPOWERS] All 20 Pro Features initialized and ready!');
})();

// ========================================================
// 🍎 Apple iOS Flasher & Recovery Controller
// ========================================================
(function initAppleFlasher() {
    // DOM Elements
    const badgeMode = document.getElementById('apple-flasher-mode-badge');
    const devNameEl = document.getElementById('apple-flasher-dev-name');
    const devVerEl = document.getElementById('apple-flasher-dev-ver');
    const snEl = document.getElementById('apple-flasher-sn');
    const udidEl = document.getElementById('apple-flasher-udid');
    const modelEl = document.getElementById('apple-flasher-model');
    const regionEl = document.getElementById('apple-flasher-region');
    const avatarEl = document.getElementById('apple-flasher-avatar');

    const btnEnterRecovery = document.getElementById('apple-btn-enter-recovery');
    const btnExitRecovery = document.getElementById('apple-btn-exit-recovery');
    const btnEnterPwndfu = document.getElementById('apple-btn-enter-pwndfu');
    const btnZadig = document.getElementById('apple-btn-zadig');
    const btnRefreshDevice = document.getElementById('apple-btn-refresh-device');

    const ipswPathInput = document.getElementById('apple-ipsw-path-input');
    const btnBrowseIpsw = document.getElementById('apple-btn-browse-ipsw');
    const btnGotoDownloader = document.getElementById('apple-btn-goto-downloader');
    const ipswInfoBadge = document.getElementById('apple-ipsw-info-badge');
    const ipswFileNameEl = document.getElementById('apple-ipsw-file-name');
    const ipswFileSizeEl = document.getElementById('apple-ipsw-file-size');

    const modeRadios = document.querySelectorAll('input[name="apple-flash-mode"]');
    const btnStartFlash = document.getElementById('apple-btn-start-flash');
    const btnStopFlash = document.getElementById('apple-btn-stop-flash');

    const pctLabel = document.getElementById('apple-flash-pct-label');
    const progressBar = document.getElementById('apple-flash-progress-bar');
    const stageDesc = document.getElementById('apple-flash-stage-desc');

    const terminalEl = document.getElementById('apple-flash-terminal');
    const autoscrollChk = document.getElementById('apple-autoscroll-chk');
    const btnCopyLog = document.getElementById('apple-btn-copy-log');
    const btnClearLog = document.getElementById('apple-btn-clear-log');

    let currentAppleDevice = null;
    let isFlashing = false;
    let appleScanInterval = null;
    const showCustomConfirm = window.showCustomConfirm || ((msg) => Promise.resolve(confirm(msg)));

    // Helper: Log message to Terminal
    function appendTerminalLog(msg, type = 'info') {
        if (!terminalEl) return;
        const now = new Date();
        const timeStr = now.toTimeString().split(' ')[0];
        
        let color = '#94a3b8';
        if (type === 'error') color = '#f87171';
        else if (type === 'warning') color = '#fbbf24';
        else if (type === 'success') color = '#34d399';
        else if (type === 'primary') color = '#38bdf8';

        const lineDiv = document.createElement('div');
        lineDiv.style.color = color;
        lineDiv.style.marginBottom = '2px';
        lineDiv.innerHTML = `<span style="color: #64748b;">[${timeStr}]</span> ${escapeHtml(msg)}`;
        terminalEl.appendChild(lineDiv);

        if (autoscrollChk && autoscrollChk.checked) {
            terminalEl.scrollTop = terminalEl.scrollHeight;
        }
    }

    function escapeHtml(text) {
        if (typeof text !== 'string') text = String(text || '');
        return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    // Refresh Device Status
    async function refreshAppleFlasherDevice(showFeedback = false) {
        if (!window.api || !window.api.getConnectedIosDevice) return;

        if (showFeedback && btnRefreshDevice) {
            btnRefreshDevice.innerHTML = '<i class="fas fa-spinner fa-spin"></i> <span>กำลังสแกน...</span>';
        }

        try {
            const res = await window.api.getConnectedIosDevice();
            if (res && res.connected && res.device) {
                const dev = res.device;
                currentAppleDevice = dev;

                // Avatar
                if (avatarEl) {
                    if (dev.deviceClass === 'iPad') avatarEl.innerHTML = '<i class="fa-solid fa-tablet-screen-button"></i>';
                    else if (dev.deviceClass === 'iPod') avatarEl.innerHTML = '<i class="fa-solid fa-music"></i>';
                    else avatarEl.innerHTML = '<i class="fa-solid fa-mobile-screen-button"></i>';
                }

                // Name & Version
                if (devNameEl) devNameEl.textContent = dev.deviceName || dev.name || 'Apple Device';
                if (devVerEl) {
                    devVerEl.style.display = 'inline-block';
                    devVerEl.textContent = `iOS ${dev.productVersion || '--'}${dev.buildVersion ? ' (' + dev.buildVersion + ')' : ''}`;
                }

                // Details
                if (snEl) snEl.textContent = dev.serialNumber || '-';
                if (udidEl) udidEl.textContent = dev.udid || '-';
                if (modelEl) modelEl.textContent = `${dev.productType || '-'} (${dev.modelNumber || dev.hardwareModel || '-'})`;
                if (regionEl) regionEl.textContent = dev.regionInfo || '-';

                // Mode Badge
                if (badgeMode) {
                    if (dev.mode === 'Recovery') {
                        badgeMode.innerHTML = '<i class="fas fa-circle" style="font-size: 8px; color: #fbbf24;"></i> <span>Recovery Mode (พร้อมรีสโตร์)</span>';
                        badgeMode.style.background = 'rgba(245, 158, 11, 0.2)';
                        badgeMode.style.color = '#fbbf24';
                        badgeMode.style.borderColor = 'rgba(245, 158, 11, 0.4)';
                    } else if (dev.mode === 'DFU') {
                        badgeMode.innerHTML = '<i class="fas fa-circle" style="font-size: 8px; color: #f87171;"></i> <span>DFU Mode (พร้อมรีสโตร์)</span>';
                        badgeMode.style.background = 'rgba(239, 68, 68, 0.2)';
                        badgeMode.style.color = '#f87171';
                        badgeMode.style.borderColor = 'rgba(239, 68, 68, 0.4)';
                    } else {
                        badgeMode.innerHTML = '<i class="fas fa-circle" style="font-size: 8px; color: #22c55e;"></i> <span>Normal Mode (เชื่อมต่อปกติ)</span>';
                        badgeMode.style.background = 'rgba(34, 197, 94, 0.2)';
                        badgeMode.style.color = '#22c55e';
                        badgeMode.style.borderColor = 'rgba(34, 197, 94, 0.4)';
                    }
                }

                if (showFeedback) {
                    appendTerminalLog(`[DEVICE] พบอุปกรณ์: ${dev.name} (${dev.productType}) - โหมด: ${dev.mode}`, 'success');
                }
            } else {
                currentAppleDevice = null;
                if (devNameEl) devNameEl.textContent = 'ยังไม่พบอุปกรณ์ Apple เชื่อมต่อ';
                if (devVerEl) devVerEl.style.display = 'none';
                if (snEl) snEl.textContent = '-';
                if (udidEl) udidEl.textContent = '-';
                if (modelEl) modelEl.textContent = '-';
                if (regionEl) regionEl.textContent = '-';
                if (badgeMode) {
                    badgeMode.innerHTML = '<i class="fas fa-circle" style="font-size: 8px;"></i> <span>รอเชื่อมต่ออุปกรณ์...</span>';
                    badgeMode.style.background = 'rgba(148,163,184,0.15)';
                    badgeMode.style.color = '#94a3b8';
                    badgeMode.style.borderColor = 'rgba(148,163,184,0.3)';
                }
            }
        } catch (e) {
            console.error('[APPLE FLASHER] Error refreshing device:', e);
        } finally {
            if (showFeedback && btnRefreshDevice) {
                btnRefreshDevice.innerHTML = '<i class="fas fa-sync-alt"></i> สแกนอุปกรณ์';
            }
        }
    }

    // 1-Click Enter Recovery Mode
    if (btnEnterRecovery) {
        btnEnterRecovery.addEventListener('click', async () => {
            const udid = currentAppleDevice?.udid || null;
            btnEnterRecovery.disabled = true;
            btnEnterRecovery.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังสั่งเข้า Recovery...';
            appendTerminalLog('[COMMAND] กำลังส่งคำสั่งเข้าสู่ Recovery Mode...', 'warning');

            try {
                const res = await window.api.enterIosRecovery(udid);
                if (res.success) {
                    appendTerminalLog(`[SUCCESS] ${res.message}`, 'success');
                } else {
                    appendTerminalLog(`[ERROR] ไม่สามารถเข้า Recovery Mode ได้: ${res.error}`, 'error');
                }
            } catch (e) {
                appendTerminalLog(`[ERROR] Exception: ${e.message}`, 'error');
            } finally {
                btnEnterRecovery.disabled = false;
                btnEnterRecovery.innerHTML = '<i class="fas fa-sign-in-alt"></i> เข้า Recovery Mode';
                setTimeout(() => refreshAppleFlasherDevice(false), 2500);
            }
        });
    }

    // 1-Click Exit Recovery Mode
    if (btnExitRecovery) {
        btnExitRecovery.addEventListener('click', async () => {
            btnExitRecovery.disabled = true;
            btnExitRecovery.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังสั่งรีบูต...';
            appendTerminalLog('[COMMAND] กำลังส่งคำสั่งออกจาก Recovery Mode (Reboot)...', 'info');

            try {
                const res = await window.api.exitIosRecovery();
                if (res.success) {
                    appendTerminalLog(`[SUCCESS] ${res.message}`, 'success');
                } else {
                    appendTerminalLog(`[ERROR] ไม่สามารถออกจาก Recovery Mode ได้: ${res.error}`, 'error');
                }
            } catch (e) {
                appendTerminalLog(`[ERROR] Exception: ${e.message}`, 'error');
            } finally {
                btnExitRecovery.disabled = false;
                btnExitRecovery.innerHTML = '<i class="fas fa-sign-out-alt"></i> ออกจาก Recovery';
                setTimeout(() => refreshAppleFlasherDevice(false), 3000);
            }
        });
    }

    // Enter P0WN-DFU Mode (checkm8 exploit via gaster)
    if (btnEnterPwndfu) {
        btnEnterPwndfu.addEventListener('click', async () => {
            const isDfu = currentAppleDevice && (currentAppleDevice.mode === 'DFU' || (currentAppleDevice.modeText || '').includes('DFU'));

            let confirmMsg = '';
            if (!isDfu) {
                confirmMsg = `⚠️ คำแนะนำก่อนเข้าโหมด P0WN-DFU:\n\nการรัน Checkm8 Exploit ต้องให้อุปกรณ์อยู่ใน "DFU Mode (หน้าจอดำสนิท)" ก่อน\n\n📌 สถานะเครื่องปัจจุบัน: ${currentAppleDevice ? (currentAppleDevice.name + ' [' + currentAppleDevice.mode + ']') : 'ยังไม่พบอุปกรณ์ใน DFU Mode'}\n\n• หากเครื่องของท่านยังไม่เข้า DFU Mode กรุณากดปุ่มตาม "คู่มือการกดปุ่มเข้า DFU Mode" ด้านบนจนหน้าจอดำสนิท\n• หากเครื่องของท่านอยู่ใน DFU Mode แล้ว กด "ดำเนินการต่อ" เพื่อเริ่มรัน P0WN-DFU ทันที`;
            } else {
                confirmMsg = `⚡ ตรวจพบอุปกรณ์อยู่ใน DFU Mode เรียบร้อย!\n\nต้องการรัน Checkm8 Exploit เพื่อนำเครื่องเข้าสู่โหมด P0WN-DFU (PWNDFU) ทันทีหรือไม่?`;
            }

            const ok = await showCustomConfirm(confirmMsg);
            if (!ok) return;

            btnEnterPwndfu.disabled = true;
            btnEnterPwndfu.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังรัน P0WN-DFU...';
            appendTerminalLog('====================================================', 'primary');
            appendTerminalLog('[PWNDFU] เริ่มต้นกระบวนการรัน Checkm8 Exploit เข้าสู่โหมด P0WN-DFU...', 'primary');

            try {
                const res = await window.api.enterIosPwndfu();
                if (res.success) {
                    appendTerminalLog(`[SUCCESS] ${res.message}`, 'success');
                    if (badgeMode) {
                        badgeMode.innerHTML = '<i class="fas fa-circle" style="font-size: 8px; color: #a855f7;"></i> <span>P0WN-DFU Mode (Exploited)</span>';
                        badgeMode.style.background = 'rgba(168, 85, 247, 0.25)';
                        badgeMode.style.color = '#c084fc';
                        badgeMode.style.borderColor = 'rgba(168, 85, 247, 0.5)';
                    }
                    alert('🎉 อุปกรณ์เข้าสู่โหมด P0WN-DFU (PWNDFU) สำเร็จแล้ว!\nสามารถแฟลช Custom Firmware หรือบูต Ramdisk ได้ทันที');
                } else {
                    appendTerminalLog(`[ERROR] ${res.error}`, 'error');
                    appendTerminalLog('[DRIVER TIP] หากเครื่องอยู่ใน DFU Mode แล้วแต่ติดปัญหา ให้กดปุ่ม "Zadig Driver" และติดตั้งไดรเวอร์ libusbK ให้กับ Apple DFU', 'warning');
                }
            } catch (e) {
                appendTerminalLog(`[FATAL] Exception: ${e.message}`, 'error');
            } finally {
                btnEnterPwndfu.disabled = false;
                btnEnterPwndfu.innerHTML = '<i class="fas fa-bolt" style="color: #c084fc;"></i> เข้าโหมด P0WN-DFU';
                setTimeout(() => refreshAppleFlasherDevice(false), 2000);
            }
        });
    }

    // Open Zadig Driver Tool
    if (btnZadig) {
        btnZadig.addEventListener('click', () => {
            if (window.api && window.api.openZadig) {
                window.api.openZadig();
                appendTerminalLog('[DRIVER] กำลังเปิดโปรแกรม Zadig Driver Installer...', 'info');
                appendTerminalLog('[DRIVER] วิธีตั้งค่า: Options -> List All Devices -> เลือก Apple Mobile Device (DFU Mode) -> ติดตั้ง Driver libusbK หรือ WinUSB', 'primary');
            }
        });
    }

    // Refresh Device Button
    if (btnRefreshDevice) {
        btnRefreshDevice.addEventListener('click', () => refreshAppleFlasherDevice(true));
    }

    // Click UDID to Copy
    if (udidEl) {
        udidEl.addEventListener('click', () => {
            const val = udidEl.textContent.trim();
            if (val && val !== '-') {
                navigator.clipboard.writeText(val).then(() => {
                    const orig = udidEl.textContent;
                    udidEl.textContent = '✓ คัดลอก UDID แล้ว!';
                    setTimeout(() => udidEl.textContent = orig, 1500);
                });
            }
        });
    }

    // Browse IPSW File
    if (btnBrowseIpsw) {
        btnBrowseIpsw.addEventListener('click', async () => {
            try {
                const res = await window.api.browseIpswFile();
                if (res && !res.canceled && res.filePath) {
                    setIpswFile(res.filePath, res.fileName, res.sizeFormatted);
                }
            } catch (e) {
                appendTerminalLog(`[ERROR] Browse file failed: ${e.message}`, 'error');
            }
        });
    }

    // Set IPSW file helper
    function setIpswFile(filePath, fileName, sizeFormatted) {
        if (ipswPathInput) ipswPathInput.value = filePath;
        if (ipswFileNameEl) ipswFileNameEl.textContent = fileName || filePath.split(/[\\/]/).pop();
        if (ipswFileSizeEl) ipswFileSizeEl.textContent = sizeFormatted || '-';
        if (ipswInfoBadge) ipswInfoBadge.style.display = 'block';

        appendTerminalLog(`[IPSW] โหลดไฟล์เฟิร์มแวร์: ${fileName} (${sizeFormatted || 'ตรวจพบแล้ว'})`, 'primary');
        if (stageDesc) {
            stageDesc.textContent = `ไฟล์พร้อมแฟลช: ${fileName} (${sizeFormatted || ''})`;
        }
    }

    // Seamless Handoff from ROM Download Center
    window.sendIpswToFlasher = function(filePath, fileName, sizeFormatted) {
        const navFlasherBtn = document.querySelector('.nav-btn[data-target="apple-flasher-section"]');
        if (navFlasherBtn) navFlasherBtn.click();

        setIpswFile(filePath, fileName, sizeFormatted);
        refreshAppleFlasherDevice(false);
        appendTerminalLog(`[HANDOFF] รับไฟล์จาก ROM Download Center เรียบร้อย พร้อมเริ่มแฟลช!`, 'success');
    };

    // Go to Downloader Button
    if (btnGotoDownloader) {
        btnGotoDownloader.addEventListener('click', () => {
            const romNavBtn = document.querySelector('.nav-btn[data-target="rom-section"]');
            if (romNavBtn) romNavBtn.click();
            const appleTabBtn = document.querySelector('.rom-tab-btn[data-tab="rom-apple"]');
            if (appleTabBtn) appleTabBtn.click();
        });
    }

    // Dynamic Mode Switcher & Safety UI
    function updateModeUI() {
        let currentMode = 'update';
        modeRadios.forEach(r => { if (r.checked) currentMode = r.value; });

        const cardClean = document.getElementById('apple-mode-card-clean');
        const cardUpdate = document.getElementById('apple-mode-card-update');
        const banner = document.getElementById('apple-mode-status-banner');

        if (currentMode === 'clean') {
            if (cardClean) {
                cardClean.style.background = 'rgba(239, 68, 68, 0.12)';
                cardClean.style.border = '2px solid #ef4444';
                cardClean.style.boxShadow = '0 0 14px rgba(239, 68, 68, 0.25)';
            }
            if (cardUpdate) {
                cardUpdate.style.background = 'rgba(56, 189, 248, 0.04)';
                cardUpdate.style.border = '1px solid rgba(56, 189, 248, 0.2)';
                cardUpdate.style.boxShadow = 'none';
            }
            if (banner) {
                banner.innerHTML = '<i class="fas fa-exclamation-triangle" style="color: #ef4444; font-size: 16px;"></i> <div><strong style="color: #f87171; font-size: 12px;">โหมดที่เลือก: Clean Restore (ล้างเครื่องใหม่หมด)</strong><div style="font-size: 11px; color: #fca5a5; margin-top: 2px;">⚠️ ข้อมูลทั้งหมดใน iPhone/iPad จะถูกฟอร์แมตทิ้งอย่างถาวร 100% (โปรแกรมส่งคำสั่ง -e)</div></div>';
                banner.style.background = 'rgba(239, 68, 68, 0.1)';
                banner.style.border = '1.5px solid rgba(239, 68, 68, 0.4)';
            }
            if (btnStartFlash && !isFlashing) {
                btnStartFlash.innerHTML = '<i class="fas fa-trash-alt"></i> เริ่มล้างเครื่องใหม่หมด (Clean Restore - ลบข้อมูลทั้งหมด)';
                btnStartFlash.style.background = 'linear-gradient(135deg, #dc2626 0%, #ef4444 100%)';
                btnStartFlash.style.boxShadow = '0 4px 15px rgba(239, 68, 68, 0.35)';
            }
        } else {
            if (cardClean) {
                cardClean.style.background = 'rgba(239, 68, 68, 0.04)';
                cardClean.style.border = '1px solid rgba(239, 68, 68, 0.2)';
                cardClean.style.boxShadow = 'none';
            }
            if (cardUpdate) {
                cardUpdate.style.background = 'rgba(56, 189, 248, 0.12)';
                cardUpdate.style.border = '2px solid #38bdf8';
                cardUpdate.style.boxShadow = '0 0 14px rgba(56, 189, 248, 0.25)';
            }
            if (banner) {
                banner.innerHTML = '<i class="fas fa-shield-alt" style="color: #38bdf8; font-size: 16px;"></i> <div><strong style="color: #38bdf8; font-size: 12px;">โหมดที่เลือก: Retain User Data (อัพเดทเก็บข้อมูลเดิม)</strong><div style="font-size: 11px; color: #7dd3fc; margin-top: 2px;">🛡️ ข้อมูล รูปภาพ แอปพลิเคชัน และข้อความแชทเดิมทั้งหมดจะปลอดภัย ไม่ถูกลบ (ไม่ส่งคำสั่ง -e)</div></div>';
                banner.style.background = 'rgba(56, 189, 248, 0.1)';
                banner.style.border = '1.5px solid rgba(56, 189, 248, 0.4)';
            }
            if (btnStartFlash && !isFlashing) {
                btnStartFlash.innerHTML = '<i class="fas fa-shield-alt"></i> เริ่มอัพเดทเก็บข้อมูลเดิม (Retain Data - ข้อมูลไม่หาย)';
                btnStartFlash.style.background = 'linear-gradient(135deg, #0284c7 0%, #0ea5e9 100%)';
                btnStartFlash.style.boxShadow = '0 4px 15px rgba(14, 165, 233, 0.35)';
            }
        }
    }
    modeRadios.forEach(r => r.addEventListener('change', updateModeUI));
    updateModeUI();

    // Start Flashing
    if (btnStartFlash) {
        btnStartFlash.addEventListener('click', async () => {
            const ipswPath = ipswPathInput?.value?.trim();
            if (!ipswPath) {
                appendTerminalLog('[VALIDATE] กรุณาเลือกไฟล์ Apple Firmware (.ipsw) ก่อนเริ่มแฟลช', 'warning');
                alert('กรุณาเลือกไฟล์ IPSW ก่อนเริ่มแฟลชเครื่อง');
                return;
            }

            // Get selected mode strictly
            let selectedMode = 'update';
            modeRadios.forEach(r => { if (r.checked) selectedMode = r.value; });

            // Confirmation modal
            let confirmMsg = '';
            if (selectedMode === 'clean') {
                confirmMsg = `🚨 คำเตือนอันตรายสูงสุด: คุณกำลังเลือกโหมด "Clean Restore (ล้างเครื่องใหม่หมด)"\n\n` +
                             `❌ ข้อมูลทั้งหมดใน iPhone/iPad จะถูกฟอร์แมตและลบออกจนหมดสิ้น 100%!\n` +
                             `❌ รูปภาพ, คลิปวิดีโอ, แชท LINE, รหัสผ่าน, และแอปทั้งหมดจะถูกล้างทิ้งถาวร ไม่สามารถกู้คืนได้!\n` +
                             `⚙️ ระบบจะส่งพารามิเตอร์: -e (Erase All Data)\n\n` +
                             `⚠️ หากคุณมีข้อมูลสำคัญและไม่ต้องการให้ข้อมูลหาย กรุณากด "ยกเลิก (Cancel)" แล้วเลือกโหมด "Retain User Data (อัพเดทเก็บข้อมูลเดิม)"\n\n` +
                             `คุณแน่ใจ 100% ว่าต้องการล้างข้อมูลทั้งหมดในเครื่องใช่หรือไม่?`;
            } else {
                confirmMsg = `🛡️ ยืนยันการแฟลชโหมด "Retain User Data (อัพเดทเก็บข้อมูลเดิม)"\n\n` +
                             `✅ ระบบจะทำการอัพเกรด iOS โดย "เก็บรักษาข้อมูลเดิมทั้งหมดไว้ครบถ้วน 100%"\n` +
                             `✅ รูปภาพ, ข้อความแชท LINE, รายชื่อติดต่อ, และแอปพลิเคชันจะปลอดภัย ไม่ถูกลบ\n` +
                             `⚙️ ระบบยืนยัน: ปลอดภัย ไม่ส่งคำสั่ง -e (Update Mode)\n\n` +
                             `โปรดตรวจสอบว่า:\n` +
                             `1. เสียบสาย USB แน่นหนา ไม่ดึงสายออกขณะทำ\n` +
                             `2. แบตเตอรี่มีมากกว่า 50%\n\n` +
                             `ยืนยันเริ่มการอัพเดทระบบทันทีหรือไม่?`;
            }

            const ok = await showCustomConfirm(confirmMsg);
            if (!ok) return;

            // Enter Flashing State
            isFlashing = true;
            btnStartFlash.disabled = true;
            btnStartFlash.style.opacity = '0.5';
            btnStartFlash.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังดำเนินการแฟลช...';
            if (btnStopFlash) btnStopFlash.style.display = 'inline-flex';
            if (btnBrowseIpsw) btnBrowseIpsw.disabled = true;
            modeRadios.forEach(r => r.disabled = true);

            // Reset progress
            if (pctLabel) pctLabel.textContent = '0%';
            if (progressBar) progressBar.style.width = '0%';
            if (stageDesc) stageDesc.textContent = 'กำลังเริ่มต้นกระบวนการแฟลช...';

            appendTerminalLog('====================================================', 'primary');
            appendTerminalLog(`[RESTORE] เริ่มต้นกระบวนการแฟลช iOS โหมด: ${selectedMode === 'clean' ? 'Clean Restore (ล้างเครื่อง)' : 'Retain User Data (เก็บข้อมูล)'}`, 'primary');
            appendTerminalLog(`[RESTORE] Firmware File: ${ipswPath}`, 'info');

            const isCellular = currentAppleDevice?.deviceClass !== 'iPod' && !((currentAppleDevice?.productType || '').includes('iPad') && !(currentAppleDevice?.imei));

            try {
                const result = await window.api.startIosFlash({
                    ipswPath: ipswPath,
                    mode: selectedMode,
                    isCellular: isCellular
                });

                if (result.success) {
                    if (pctLabel) pctLabel.textContent = '100%';
                    if (progressBar) progressBar.style.width = '100%';
                    if (stageDesc) stageDesc.textContent = '✓ การแฟลชเสร็จสมบูรณ์ 100%! เครื่องกำลังรีสตาร์ท';
                    appendTerminalLog(`[SUCCESS] ${result.message}`, 'success');
                    alert('🎉 การแฟลช Apple iOS เสร็จสมบูรณ์เรียบร้อยแล้ว!\nเครื่องกำลังรีบูตเข้าระบบ');
                } else {
                    if (stageDesc) stageDesc.textContent = `❌ เกิดข้อผิดพลาด: ${result.error}`;
                    appendTerminalLog(`[ERROR] ${result.error}`, 'error');
                }
            } catch (e) {
                if (stageDesc) stageDesc.textContent = `❌ เกิดข้อผิดพลาด: ${e.message}`;
                appendTerminalLog(`[FATAL] Error: ${e.message}`, 'error');
            } finally {
                isFlashing = false;
                btnStartFlash.disabled = false;
                btnStartFlash.style.opacity = '1';
                btnStartFlash.innerHTML = '<i class="fas fa-bolt"></i> เริ่มแฟลชเครื่อง (Start Flash)';
                if (btnStopFlash) btnStopFlash.style.display = 'none';
                if (btnBrowseIpsw) btnBrowseIpsw.disabled = false;
                modeRadios.forEach(r => r.disabled = false);
                setTimeout(() => refreshAppleFlasherDevice(false), 5000);
            }
        });
    }

    // Stop Flashing
    if (btnStopFlash) {
        btnStopFlash.addEventListener('click', async () => {
            const ok = await showCustomConfirm('⚠️ ต้องการบังคับหยุดการแฟลชเครื่องใช่หรือไม่?\n\nการหยุดการทำงานระหว่างเขียนระบบ อาจทำให้เครื่องค้างใน Recovery Mode');
            if (!ok) return;

            try {
                const res = await window.api.stopIosFlash();
                appendTerminalLog(`[STOP] ${res.message || res.error}`, 'warning');
            } catch (e) {
                appendTerminalLog(`[ERROR] Stop error: ${e.message}`, 'error');
            }
        });
    }

    // IPC Streaming Listeners
    if (window.api && window.api.onIosFlashProgress) {
        window.api.onIosFlashProgress((data) => {
            if (data && typeof data.percent === 'number') {
                if (pctLabel) pctLabel.textContent = `${data.percent}%`;
                if (progressBar) progressBar.style.width = `${data.percent}%`;
                if (stageDesc && data.stage) stageDesc.textContent = data.stage;
            }
        });
    }

    if (window.api && window.api.onIosFlashLog) {
        window.api.onIosFlashLog((data) => {
            if (data && data.text) {
                appendTerminalLog(data.text, data.type || 'info');
            }
        });
    }

    // Clear Terminal Log
    if (btnClearLog) {
        btnClearLog.addEventListener('click', () => {
            if (terminalEl) {
                terminalEl.innerHTML = '<div style="color: #64748b;">[CONSOLE] เคลียร์บันทึกเรียบร้อย พร้อมรับข้อความใหม่...</div>';
            }
        });
    }

    // Copy Terminal Log
    if (btnCopyLog) {
        btnCopyLog.addEventListener('click', () => {
            if (!terminalEl) return;
            navigator.clipboard.writeText(terminalEl.innerText).then(() => {
                const orig = btnCopyLog.innerHTML;
                btnCopyLog.innerHTML = '<i class="fas fa-check" style="color: #22c55e;"></i> คัดลอกแล้ว';
                setTimeout(() => btnCopyLog.innerHTML = orig, 1500);
            });
        });
    }

    // Tab activation listener
    const appleNavBtn = document.querySelector('.nav-btn[data-target="apple-flasher-section"]');
    if (appleNavBtn) {
        appleNavBtn.addEventListener('click', () => {
            refreshAppleFlasherDevice(false);
            if (!appleScanInterval) {
                appleScanInterval = setInterval(() => {
                    const sec = document.getElementById('apple-flasher-section');
                    if (sec && sec.classList.contains('active') && !isFlashing) {
                        refreshAppleFlasherDevice(false);
                    }
                }, 3500);
            }
        });
    }

    console.log('[APPLE FLASHER] Apple iOS Flasher initialized successfully!');
})();

// ============================================================================
// HWID Cloud Authentication & License Gate Controller
// ============================================================================
(function initHWIDSystem() {
    console.log('[HWID SYSTEM] Initializing HWID License Gate...');

    const gateModal = document.getElementById('hwid-gate-modal');
    const hwidDisplayText = document.getElementById('hwid-display-text');
    const hwidPcBadge = document.getElementById('hwid-pc-badge');
    const btnCopyHwid = document.getElementById('btn-copy-hwid');
    const btnCopyHwidText = document.getElementById('btn-copy-hwid-text');
    const btnHwidCheck = document.getElementById('btn-hwid-check');
    const btnHwidCheckText = document.getElementById('btn-hwid-check-text');
    const hwidRefreshIcon = document.getElementById('hwid-refresh-icon');
    const btnHwidContact = document.getElementById('btn-hwid-contact');
    const btnHwidExit = document.getElementById('btn-hwid-exit');

    // Settings Modal Elements
    const settingsHwidDisplay = document.getElementById('settings-hwid-display');
    const settingsBtnCopyHwid = document.getElementById('settings-btn-copy-hwid');
    const settingsLicBadge = document.getElementById('settings-lic-badge');
    const settingsBtnRecheckLic = document.getElementById('settings-btn-recheck-lic');

    let currentHWID = '';
    let currentContactLink = 'https://line.me/ti/p/FydMlMc6g1';
    let currentTgLink = 'https://t.me/Dathai';

    function setStatusUI(status) {
        if (!settingsLicBadge) return;
        const s = (status || '').toLowerCase();
        if (s === 'active') {
            settingsLicBadge.textContent = 'Active (Lifetime)';
            settingsLicBadge.style.background = 'rgba(34,197,94,0.2)';
            settingsLicBadge.style.color = '#4ade80';
        } else if (s === 'pending') {
            settingsLicBadge.textContent = 'Pending';
            settingsLicBadge.style.background = 'rgba(245,158,11,0.2)';
            settingsLicBadge.style.color = '#fbbf24';
        } else if (s === 'expired') {
            settingsLicBadge.textContent = 'Expired';
            settingsLicBadge.style.background = 'rgba(239,68,68,0.2)';
            settingsLicBadge.style.color = '#f87171';
        } else {
            settingsLicBadge.textContent = 'Unauthorized';
            settingsLicBadge.style.background = 'rgba(239,68,68,0.2)';
            settingsLicBadge.style.color = '#f87171';
        }
    }

    function unlockGate() {
        if (!gateModal) return;
        gateModal.classList.add('hwid-hidden');
        setTimeout(() => {
            gateModal.style.display = 'none';
        }, 360);
    }

    function lockGate() {
        if (!gateModal) return;
        gateModal.style.display = 'flex';
        requestAnimationFrame(() => {
            gateModal.classList.remove('hwid-hidden');
        });
    }

    // Check Cloud Status
    async function checkHWID(interactive = true) {
        if (!window.api || !window.api.verifyHWIDCloud) return;

        if (interactive) {
            if (btnHwidCheck) {
                btnHwidCheck.disabled = true;
                if (btnHwidCheckText) btnHwidCheckText.textContent = 'กำลังตรวจสอบ...';
            }
            if (hwidRefreshIcon) hwidRefreshIcon.classList.add('fa-spin');
        }

        try {
            const res = await window.api.verifyHWIDCloud();
            console.log('[HWID VERIFY RES]', res);

            if (res && res.authorized) {
                if (btnHwidCheckText) btnHwidCheckText.textContent = '✓ ได้รับสิทธิ์แล้ว!';
                setStatusUI('active');
                setTimeout(() => {
                    unlockGate();
                }, 600);
            } else {
                if (interactive) {
                    alert('ยังไม่มี HWID ของเครื่องนี้ในระบบ\nกรุณากดปุ่ม "คัดลอก HWID" ด้านบน แล้วส่งให้ ผู้พัฒนา เพื่อเปิดสิทธิ์การใช้งานโปรแกรม');
                }
            }
        } catch (err) {
            console.error('[HWID VERIFY ERR]', err);
            if (interactive) {
                alert('ไม่สามารถเชื่อมต่อระบบได้ กรุณาลองใหม่อีกครั้ง');
            }
        } finally {
            if (interactive) {
                if (btnHwidCheck) {
                    btnHwidCheck.disabled = false;
                    if (btnHwidCheckText) btnHwidCheckText.textContent = 'ตรวจสอบสิทธิ์อีกครั้ง';
                }
                if (hwidRefreshIcon) hwidRefreshIcon.classList.remove('fa-spin');
            }
        }
    }

    // Copy HWID helper
    function copyText(text, btnElement, labelElement) {
        if (!text) return;
        navigator.clipboard.writeText(text).then(() => {
            const origHTML = labelElement ? labelElement.textContent : (btnElement ? btnElement.innerHTML : '');
            if (labelElement) {
                labelElement.textContent = '✓ คัดลอกแล้ว!';
            } else if (btnElement) {
                btnElement.innerHTML = '<i class="fas fa-check" style="color: #4ade80;"></i>';
            }
            setTimeout(() => {
                if (labelElement) labelElement.textContent = origHTML;
                else if (btnElement) btnElement.innerHTML = origHTML;
            }, 1800);
        }).catch(err => {
            console.error('Clipboard copy failed:', err);
            prompt('คัดลอก HWID:', text);
        });
    }

    // Init function
    async function loadHWIDInfo() {
        if (!window.api || !window.api.getHWIDInfo) return;

        // Listen for startup HWID result from main process
        if (window.api.onStartupHWIDResult) {
            window.api.onStartupHWIDResult((startupRes) => {
                console.log('[RENDERER] Received startup HWID result:', startupRes);
                if (startupRes && startupRes.authorized) {
                    setStatusUI('active', 'ยืนยันสิทธิ์ประจำเครื่องเรียบร้อย');
                    unlockGate();
                } else {
                    console.log('[RENDERER] HWID not authorized on startup. Popping up modal with developer contact.');
                    if (startupRes && startupRes.hwid) {
                        currentHWID = startupRes.hwid;
                        if (hwidDisplayText) hwidDisplayText.textContent = currentHWID;
                    }
                    setStatusUI(startupRes ? startupRes.status : 'pending');
                    lockGate();
                }
            });
        }

        try {
            const info = await window.api.getHWIDInfo();
            console.log('[HWID INFO LOADED]', info);

            currentHWID = info.hwid || '';
            if (info.contactLink) currentContactLink = info.contactLink;
            if (info.telegramLink) currentTgLink = info.telegramLink;

            // Fill UI fields
            if (hwidDisplayText) hwidDisplayText.textContent = currentHWID;
            if (hwidPcBadge) hwidPcBadge.innerHTML = `<i class="fas fa-desktop"></i> ${info.pcName || 'PC'}`;

            if (settingsHwidDisplay) settingsHwidDisplay.value = currentHWID;

            if (info.isActivated) {
                console.log('[HWID] Device is already activated locally.');
                setStatusUI('active');
                unlockGate();
            } else {
                console.log('[HWID] Device not activated yet. Showing HWID popup modal.');
                setStatusUI(info.status || 'pending');
                lockGate();
            }
        } catch (err) {
            console.error('[HWID INIT ERR]', err);
        }
    }

    // Event Listeners
    if (btnCopyHwid) {
        btnCopyHwid.addEventListener('click', () => {
            copyText(currentHWID, btnCopyHwid, btnCopyHwidText);
        });
    }

    if (settingsBtnCopyHwid) {
        settingsBtnCopyHwid.addEventListener('click', () => {
            copyText(currentHWID, settingsBtnCopyHwid, null);
        });
    }

    if (btnHwidCheck) {
        btnHwidCheck.addEventListener('click', () => checkHWID(true));
    }

    if (settingsBtnRecheckLic) {
        settingsBtnRecheckLic.addEventListener('click', async () => {
            settingsBtnRecheckLic.disabled = true;
            settingsBtnRecheckLic.innerHTML = '<i class="fas fa-sync fa-spin"></i> ตรวจสอบ...';
            try {
                const res = await window.api.verifyHWIDCloud();
                if (res.authorized) {
                    alert('🎉 ตรวจสอบสิทธิ์สำเร็จ: บัญชีของคุณ Active เรียบร้อย!');
                    if (settingsLicBadge) {
                        settingsLicBadge.textContent = 'Active (Lifetime)';
                        settingsLicBadge.style.background = 'rgba(34,197,94,0.2)';
                        settingsLicBadge.style.color = '#4ade80';
                    }
                    unlockGate();
                } else {
                    alert(`⚠️ ผลการตรวจสอบ: สถานะคือ [${res.status || 'Pending'}]\n${res.message || 'ยังไม่ได้รับการอนุมัติ'}`);
                }
            } catch (e) {
                alert('❌ ไม่สามารถตรวจสอบได้: ' + e.message);
            } finally {
                settingsBtnRecheckLic.disabled = false;
                settingsBtnRecheckLic.innerHTML = '<i class="fas fa-sync"></i> ตรวจสอบสิทธิ์';
            }
        });
    }

    if (btnHwidContact) {
        btnHwidContact.addEventListener('click', () => {
            if (window.api && window.api.openExternalUrl) {
                window.api.openExternalUrl(currentContactLink);
            } else {
                window.open(currentContactLink, '_blank');
            }
        });
    }

    const btnHwidTg = document.getElementById('btn-hwid-tg');
    if (btnHwidTg) {
        btnHwidTg.addEventListener('click', () => {
            if (window.api && window.api.openExternalUrl) {
                window.api.openExternalUrl(currentTgLink);
            } else {
                window.open(currentTgLink, '_blank');
            }
        });
    }







    // Exit Button
    if (btnHwidExit) {
        btnHwidExit.addEventListener('click', async () => {
            if (window.api && window.api.appQuit) {
                await window.api.appQuit();
            } else {
                window.close();
            }
        });
    }

    // Start on DOM Ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', loadHWIDInfo);
    } else {
        loadHWIDInfo();
    }
})();





    // =========================================================================
    // MOBILE TOOLS: RIGHT PANEL & LIVE SCREEN MIRROR CONTROLLER
    // =========================================================================
    (function initMobileRightPanel() {
        // 1. Tab Switcher
        const btnTabLog = document.getElementById('btn-panel-tab-log');
        const btnTabScreen = document.getElementById('btn-panel-tab-screen');
        if (btnTabLog) btnTabLog.addEventListener('click', () => showRightPanelTab('log'));
        if (btnTabScreen) {
            btnTabScreen.addEventListener('click', () => {
                showRightPanelTab('screen');
                // Automatically fetch screen frame when entering screen tab if not already shown
                const img = document.getElementById('mobile-screen-img');
                if (!img || img.style.display === 'none') {
                    fetchInAppScreenFrame();
                }
            });
        }

        // 2. Clear & Copy Log Buttons
        const btnClearLog = document.getElementById('btn-panel-clear-log');
        if (btnClearLog) {
            btnClearLog.addEventListener('click', () => {
                const terminal = document.getElementById('mobile-panel-terminal');
                if (terminal) {
                    terminal.innerHTML = '================================================\n THAIVPN Professional Mobile Service Console v2.0\n Port Engine: Qualcomm EDL / MTK / SPD / ADB\n================================================\n';
                }
                const pTitle = document.getElementById('mobile-panel-action-title');
                if (pTitle) pTitle.textContent = 'พร้อมทำงาน (Waiting for task...)';
                const pBadge = document.getElementById('mobile-panel-badge');
                if (pBadge) {
                    pBadge.textContent = 'READY';
                    pBadge.style.background = 'rgba(34, 197, 94, 0.15)';
                    pBadge.style.color = '#4ade80';
                    pBadge.style.borderColor = 'rgba(34, 197, 94, 0.3)';
                }
                const pBar = document.getElementById('mobile-panel-progress-bar');
                if (pBar) pBar.style.width = '0%';
                const pTxt = document.getElementById('mobile-panel-progress-text');
                if (pTxt) pTxt.textContent = '0%';
            });
        }

        const btnCopyLog = document.getElementById('btn-panel-copy-log');
        if (btnCopyLog) {
            btnCopyLog.addEventListener('click', () => {
                const terminal = document.getElementById('mobile-panel-terminal');
                if (terminal) {
                    navigator.clipboard.writeText(terminal.innerText).then(() => {
                        const orig = btnCopyLog.innerHTML;
                        btnCopyLog.innerHTML = '<i class="fas fa-check" style="color: #4ade80;"></i>';
                        setTimeout(() => btnCopyLog.innerHTML = orig, 1500);
                    });
                }
            });
        }

        // 3. Live In-App Screen Mirror Engine
        let screenStreamInterval = null;
        let isFetchingFrame = false;

        async function fetchInAppScreenFrame() {
            if (isFetchingFrame) return;
            isFetchingFrame = true;

            const loader = document.getElementById('mobile-screen-loader');
            const placeholder = document.getElementById('mobile-screen-placeholder');
            const img = document.getElementById('mobile-screen-img');

            if (img && img.style.display === 'none' && loader) {
                loader.style.display = 'flex';
            }

            try {
                if (window.api && window.api.getDeviceScreenFrame) {
                    const res = await window.api.getDeviceScreenFrame(null);
                    if (res && res.success && res.image) {
                        if (placeholder) placeholder.style.display = 'none';
                        if (loader) loader.style.display = 'none';
                        if (img) {
                            img.src = res.image;
                            img.style.display = 'block';
                        }
                    } else {
                        if (loader) loader.style.display = 'none';
                        if (img && img.style.display === 'none' && placeholder) {
                            placeholder.style.display = 'block';
                        }
                    }
                }
            } catch (e) {
                if (loader) loader.style.display = 'none';
            } finally {
                isFetchingFrame = false;
            }
        }

        const btnStart = document.getElementById('btn-inapp-screen-start');
        if (btnStart) btnStart.addEventListener('click', fetchInAppScreenFrame);

        const btnRefresh = document.getElementById('btn-inapp-screen-refresh');
        if (btnRefresh) btnRefresh.addEventListener('click', fetchInAppScreenFrame);

        // Continuous Live Stream Toggle
        const btnStream = document.getElementById('btn-inapp-screen-stream');
        const txtStream = document.getElementById('txt-inapp-stream');
        if (btnStream) {
            btnStream.addEventListener('click', () => {
                if (screenStreamInterval) {
                    clearInterval(screenStreamInterval);
                    screenStreamInterval = null;
                    btnStream.classList.remove('danger-btn');
                    btnStream.classList.add('warning-btn');
                    if (txtStream) txtStream.textContent = 'สตรีมสดต่อเนื่อง';
                } else {
                    fetchInAppScreenFrame();
                    screenStreamInterval = setInterval(fetchInAppScreenFrame, 500);
                    btnStream.classList.remove('warning-btn');
                    btnStream.classList.add('danger-btn');
                    if (txtStream) txtStream.textContent = 'หยุดสตรีมสด';
                }
            });
        }

        // Launch 60 FPS Scrcpy Window docked to the right
        const btnScrcpy = document.getElementById('btn-inapp-screen-scrcpy');
        if (btnScrcpy) {
            btnScrcpy.addEventListener('click', async () => {
                btnScrcpy.disabled = true;
                const bounds = {
                    x: window.screenX,
                    y: window.screenY,
                    width: window.outerWidth,
                    height: window.outerHeight
                };
                try {
                    logToModal('> กำลังเปิดหน้าต่าง Live Mirror (Scrcpy 60 FPS ไร้ดีเลย์)...\n', 'info');
                    if (window.api && window.api.launchScreenMirror) {
                        const res = await window.api.launchScreenMirror(null, bounds);
                        if (res && res.success) {
                            logToModal(`[SUCCESS] ${res.message}\n`, 'success');
                        } else {
                            logToModal(`[ERROR] ${res ? res.error : 'ไม่สามารถเปิดได้'}\n`, 'error');
                        }
                    }
                } catch (err) {
                    logToModal(`[ERROR] ${err.message}\n`, 'error');
                } finally {
                    btnScrcpy.disabled = false;
                }
            });
        }

        // Also connect the existing btn-screen-mirror buttons in tab-adb and tab-superpowers
        const allMirrorBtns = document.querySelectorAll('#btn-screen-mirror');
        allMirrorBtns.forEach(b => {
            b.addEventListener('click', () => {
                showRightPanelTab('screen');
                fetchInAppScreenFrame();
            });
        });

        // Touch Click on Phone Image -> Send adb shell input tap
        const phoneImg = document.getElementById('mobile-screen-img');
        if (phoneImg) {
            phoneImg.addEventListener('click', async (e) => {
                if (!phoneImg.naturalWidth || !phoneImg.naturalHeight) return;
                const rect = phoneImg.getBoundingClientRect();
                const clickX = e.clientX - rect.left;
                const clickY = e.clientY - rect.top;
                
                const pctX = clickX / rect.width;
                const pctY = clickY / rect.height;

                const deviceX = Math.round(pctX * phoneImg.naturalWidth);
                const deviceY = Math.round(pctY * phoneImg.naturalHeight);

                // Visual tap indicator
                const ripple = document.createElement('div');
                ripple.style.position = 'absolute';
                ripple.style.left = `${e.clientX - rect.left - 10}px`;
                ripple.style.top = `${e.clientY - rect.top - 10}px`;
                ripple.style.width = '20px';
                ripple.style.height = '20px';
                ripple.style.borderRadius = '50%';
                ripple.style.background = 'rgba(56, 189, 248, 0.6)';
                ripple.style.pointerEvents = 'none';
                ripple.style.transition = 'all 0.3s ease-out';
                phoneImg.parentElement.appendChild(ripple);
                setTimeout(() => {
                    ripple.style.transform = 'scale(2)';
                    ripple.style.opacity = '0';
                    setTimeout(() => ripple.remove(), 300);
                }, 10);

                if (window.api && window.api.sendDeviceTouch) {
                    await window.api.sendDeviceTouch(deviceX, deviceY, null);
                    setTimeout(fetchInAppScreenFrame, 350);
                }
            });
        }

        // Virtual Navigation Bar Keys (Back, Home, Recent, Power)
        const navKeys = document.querySelectorAll('.phone-nav-key-btn');
        navKeys.forEach(k => {
            k.addEventListener('click', async () => {
                const key = k.getAttribute('data-key');
                if (window.api && window.api.sendDeviceKey) {
                    await window.api.sendDeviceKey(key, null);
                    setTimeout(fetchInAppScreenFrame, 350);
                }
            });
        });

    })();


    // ========================================================================
    // IN-APP AUTO-UPDATER CLIENT CONTROLLER
    // ========================================================================
    let pendingUpdateInfo = null;

    function showUpdateModal(info) {
        pendingUpdateInfo = info;
        const modal = document.getElementById('update-modal');
        if (!modal) return;

        const curVerEl = document.getElementById('update-current-ver');
        const latVerEl = document.getElementById('update-latest-ver');
        const dateEl = document.getElementById('update-release-date');
        const listEl = document.getElementById('update-changelog-list');
        const progContainer = document.getElementById('update-progress-container');
        const btnUpdateNow = document.getElementById('btn-update-now');
        const btnCancel = document.getElementById('btn-update-cancel');

        if (curVerEl) curVerEl.textContent = 'v' + (info.currentVersion || '2.0.0');
        if (latVerEl) latVerEl.textContent = 'v' + (info.latestVersion || '2.0.1');
        if (dateEl) dateEl.textContent = info.releaseDate || '';

        if (listEl) {
            listEl.innerHTML = '';
            const logs = Array.isArray(info.changelog) ? info.changelog : [info.changelog || 'ปรับปรุงและแก้ไขทั่วไป'];
            logs.forEach(item => {
                const row = document.createElement('div');
                row.style.marginBottom = '4px';
                row.innerHTML = `<span style="color: #38bdf8; margin-right: 6px;">•</span> ${item}`;
                listEl.appendChild(row);
            });
        }

        if (progContainer) progContainer.style.display = 'none';
        if (btnUpdateNow) {
            btnUpdateNow.disabled = false;
            btnUpdateNow.innerHTML = '<i class="fas fa-download"></i> ดาวน์โหลดและอัปเดตทันที';
        }
        if (btnCancel) btnCancel.style.display = 'block';

        modal.style.display = 'flex';
    }

    function hideUpdateModal() {
        const modal = document.getElementById('update-modal');
        if (modal) modal.style.display = 'none';
    }

    // Initialize version label in sidebar & all badges
    if (window.api && window.api.getAppVersion) {
        window.api.getAppVersion().then(v => {
            if (!v) return;
            document.title = 'THAIVPN Tools v' + v;
            const verEl = document.getElementById('sidebar-app-version');
            if (verEl) verEl.textContent = 'v' + v;
            document.querySelectorAll('.version-badge').forEach(el => { el.textContent = 'v' + v; });
            const curEl = document.getElementById('update-current-ver');
            if (curEl) curEl.textContent = 'v' + v;
        }).catch(() => {});
    }

    // Handle Manual 'Check for Updates' Click
    const btnCheckUpdate = document.getElementById('btn-check-update');
    if (btnCheckUpdate) {
        btnCheckUpdate.addEventListener('click', async () => {
            const icon = document.getElementById('icon-check-update');
            if (icon) icon.classList.add('fa-spin');
            btnCheckUpdate.disabled = true;

            try {
                if (window.api && window.api.checkForUpdates) {
                    const res = await window.api.checkForUpdates();
                    if (res && res.updateAvailable) {
                        showUpdateModal(res);
                    } else if (res && res.success) {
                        alert(`คุณกำลังใช้งานเวอร์ชันล่าสุดแล้ว (v${res.currentVersion})`);
                    } else {
                        alert(`ไม่สามารถตรวจสอบอัปเดตได้: ${res ? res.error : 'Network Error'}`);
                    }
                }
            } catch (err) {
                alert('เกิดข้อผิดพลาดในการตรวจสอบอัปเดต: ' + err.message);
            } finally {
                if (icon) icon.classList.remove('fa-spin');
                btnCheckUpdate.disabled = false;
            }
        });
    }

    // Modal Close & Cancel
    document.getElementById('btn-update-modal-close')?.addEventListener('click', hideUpdateModal);
    document.getElementById('btn-update-cancel')?.addEventListener('click', hideUpdateModal);

    // Modal 'Update Now' Click
    const btnUpdateNow = document.getElementById('btn-update-now');
    if (btnUpdateNow) {
        btnUpdateNow.addEventListener('click', async () => {
            if (!pendingUpdateInfo) return;
            const targetUrl = pendingUpdateInfo.patchUrl || pendingUpdateInfo.installerUrl;
            if (!targetUrl) {
                alert('ไม่พบที่อยู่ไฟล์ดาวน์โหลด');
                return;
            }

            const progContainer = document.getElementById('update-progress-container');
            const progBar = document.getElementById('update-progress-bar');
            const progPercent = document.getElementById('update-progress-percent');
            const progStatus = document.getElementById('update-progress-status');
            const btnCancel = document.getElementById('btn-update-cancel');

            if (progContainer) progContainer.style.display = 'block';
            if (btnCancel) btnCancel.style.display = 'none';
            btnUpdateNow.disabled = true;
            btnUpdateNow.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังอัปเดต...';

            try {
                // Listen to download progress
                if (window.api && window.api.onUpdateProgress) {
                    window.api.onUpdateProgress((p) => {
                        if (progBar) progBar.style.width = p.percent + '%';
                        if (progPercent) progPercent.textContent = p.percent + '%';
                        if (progStatus) progStatus.textContent = `กำลังดาวน์โหลด... ${p.percent}% (${(p.transferred / 1048576).toFixed(1)} MB)`;
                    });
                }

                // Start Download
                const dlRes = await window.api.startDownloadUpdate(targetUrl);
                if (dlRes && dlRes.success) {
                    if (progBar) progBar.style.width = '100%';
                    if (progPercent) progPercent.textContent = '100%';
                    if (progStatus) progStatus.textContent = 'ดาวน์โหลดเสร็จสิ้น! กำลังติดตั้งและรีสตาร์ท...';

                    // Apply update and relaunch!
                    setTimeout(async () => {
                        await window.api.applyUpdateAndRestart(dlRes.filePath, dlRes.isInstaller);
                    }, 600);
                } else {
                    alert('ดาวน์โหลดอัปเดตไม่สำเร็จ: ' + (dlRes ? dlRes.error : 'Unknown'));
                    btnUpdateNow.disabled = false;
                    btnUpdateNow.innerHTML = '<i class="fas fa-download"></i> ลองใหม่อีกครั้ง';
                    if (btnCancel) btnCancel.style.display = 'block';
                }
            } catch (err) {
                alert('เกิดข้อผิดพลาดในการอัปเดต: ' + err.message);
                btnUpdateNow.disabled = false;
                btnUpdateNow.innerHTML = '<i class="fas fa-download"></i> ลองใหม่อีกครั้ง';
                if (btnCancel) btnCancel.style.display = 'block';
            }
        });
    }

    // Handle background update notification from main process
    if (window.api && window.api.onUpdateAvailable) {
        window.api.onUpdateAvailable((info) => {
            console.log('[UPDATER] New update detected in background:', info);
            showUpdateModal(info);
        });
    }

const updater = require('./updater');
const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { exec, spawn, execFile, execSync, execFileSync } = require('child_process');
const https = require('https');
const http = require('http');
const crypto = require('crypto');
const net = require('net');
const tls = require('tls');

let mainWindow;
let splashWindow;
let configPath;

function loadConfig() {
    try {
        if (!configPath) configPath = path.join(app.getPath('userData'), 'app-config.json');
        if (fs.existsSync(configPath)) {
            return JSON.parse(fs.readFileSync(configPath, 'utf8'));
        }
    } catch (e) {
        console.error('Error loading config:', e);
    }
    return { width: 1100, height: 750 };
}

function saveConfig(config) {
    try {
        if (!configPath) configPath = path.join(app.getPath('userData'), 'app-config.json');
        fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
    } catch (e) {
        console.error('Error saving config:', e);
    }
}

// ============================================================================
// HWID Authentication & Google Sheets Cloud License Manager
// ============================================================================
let cachedHWID = null;

function loadHWIDConfig() {
    const configPath = path.join(__dirname, 'hwid_config.json');
    try {
        if (fs.existsSync(configPath)) {
            return JSON.parse(fs.readFileSync(configPath, 'utf8'));
        }
    } catch (e) {
        console.error('Error reading hwid_config.json:', e);
    }
    return {
        googleScriptUrl: "",
        contactName: "ผู้พัฒนา THAIVPN",
        contactLink: "https://line.me/ti/p/FydMlMc6g1",
        telegramLink: "https://t.me/Dathai",
        offlineMasterKey: "THAIVPN-VIP-2026-UNLOCKED",
        autoRegisterNewHwid: true
    };
}

function saveHWIDConfig(newCfg) {
    const configPath = path.join(__dirname, 'hwid_config.json');
    try {
        fs.writeFileSync(configPath, JSON.stringify(newCfg, null, 2), 'utf8');
        return true;
    } catch (e) {
        console.error('Error saving hwid_config.json:', e);
        return false;
    }
}

function getMachineHWID() {
    if (cachedHWID) return cachedHWID;

    // 1. Check persistent identity file so HWID never flips once resolved
    try {
        const idPath = path.join(app.getPath('userData'), 'hwid_identity.json');
        if (fs.existsSync(idPath)) {
            const saved = JSON.parse(fs.readFileSync(idPath, 'utf8'));
            if (saved && saved.hwid && saved.hwid.startsWith('TVPN-')) {
                cachedHWID = saved.hwid;
                return cachedHWID;
            }
        }
    } catch (e) {}

    let rawOutput = '';

    // 2. Primary Method: Ultra-fast native WMIC (~300ms, avoids PowerShell cold-start timeouts)
    try {
        const raw = execSync('wmic csproduct get uuid & wmic cpu get processorid & wmic diskdrive get serialnumber', {
            encoding: 'utf8',
            timeout: 8000,
            windowsHide: true
        });
        const lines = raw.split(/\r?\n/).map(l => l.trim()).filter(l => l && !l.includes('UUID') && !l.includes('ProcessorId') && !l.includes('SerialNumber'));
        if (lines.length >= 2) {
            rawOutput = `${lines[0] || ''}|${lines[1] || ''}|${lines[2] || ''}`;
        }
    } catch (e) {
        console.warn('WMIC query failed, falling back to PowerShell:', e.message);
    }

    // 3. Secondary Method: PowerShell with generous 15s timeout
    if (!rawOutput) {
        try {
            const script = '$u = (Get-CimInstance Win32_ComputerSystemProduct).UUID; $c = (Get-CimInstance Win32_Processor).ProcessorId; $d = (Get-CimInstance Win32_DiskDrive | Select-Object -First 1).SerialNumber; "$u|$c|$d"';
            rawOutput = execFileSync('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', script], {
                encoding: 'utf8',
                timeout: 15000,
                windowsHide: true
            }).trim();
        } catch (e) {
            console.error('PowerShell hardware query failed:', e.message);
        }
    }

    if (rawOutput && rawOutput.length > 5) {
        const hash = crypto.createHash('sha256').update(rawOutput).digest('hex').toUpperCase();
        cachedHWID = `TVPN-${hash.substring(0, 4)}-${hash.substring(4, 8)}-${hash.substring(8, 12)}-${hash.substring(12, 16)}`;

        // Persist to disk so this machine will NEVER fluctuate or flip to a fallback again
        try {
            const idPath = path.join(app.getPath('userData'), 'hwid_identity.json');
            fs.writeFileSync(idPath, JSON.stringify({ hwid: cachedHWID, generatedAt: new Date().toISOString() }, null, 2), 'utf8');
        } catch (e) {}

        return cachedHWID;
    }

    // 4. Emergency Fallback only if both methods completely fail
    const fallback = crypto.createHash('sha256').update(os.hostname() + '-' + os.userInfo().username).digest('hex').toUpperCase();
    cachedHWID = `TVPN-${fallback.substring(0, 4)}-${fallback.substring(4, 8)}-${fallback.substring(8, 12)}-${fallback.substring(12, 16)}`;
    return cachedHWID;
}

function getLicensePath() {
    return path.join(app.getPath('userData'), 'app_license.json');
}

function readLocalLicense() {
    try {
        const licFile = getLicensePath();
        if (fs.existsSync(licFile)) {
            const data = JSON.parse(fs.readFileSync(licFile, 'utf8'));
            const hwid = getMachineHWID();
            if (data && data.hwid === hwid && data.status === 'Active') {
                if (data.expiry && data.expiry !== 'Lifetime' && data.expiry !== '-') {
                    const exp = new Date(data.expiry);
                    if (!isNaN(exp.getTime()) && new Date() > exp) {
                        return { isActivated: false, status: 'Expired', message: 'สิทธิ์การใช้งานหมดอายุแล้ว' };
                    }
                }
                return { isActivated: true, license: data };
            }
        }
    } catch (e) {
        console.error('Error reading local license:', e);
    }
    return { isActivated: false, license: null };
}

function saveLocalLicense(licData) {
    try {
        const licFile = getLicensePath();
        fs.writeFileSync(licFile, JSON.stringify(licData, null, 2), 'utf8');
        return true;
    } catch (e) {
        console.error('Error saving local license:', e);
        return false;
    }
}

function queryGoogleScript(scriptUrl, hwid, pcName) {
    return new Promise((resolve, reject) => {
        const fetchUrl = `${scriptUrl}?action=check&hwid=${encodeURIComponent(hwid)}&pcName=${encodeURIComponent(pcName || os.hostname())}`;
        function getWithRedirect(targetUrl, depth = 0) {
            if (depth > 5) return reject(new Error('Too many redirects'));
            const client = targetUrl.startsWith('https') ? https : http;
            const req = client.get(targetUrl, { timeout: 10000 }, (res) => {
                if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
                    return getWithRedirect(res.headers.location, depth + 1);
                }
                let raw = '';
                res.on('data', chunk => raw += chunk);
                res.on('end', () => {
                    try {
                        const json = JSON.parse(raw);
                        resolve(json);
                    } catch (e) {
                        reject(new Error('Invalid JSON: ' + raw.substring(0, 100)));
                    }
                });
            });
            req.on('error', reject);
            req.on('timeout', () => {
                req.destroy();
                reject(new Error('Connection timed out'));
            });
        }
        getWithRedirect(fetchUrl);
    });
}

async function performStartupHWIDCheck() {
    const hwid = getMachineHWID();
    const config = loadHWIDConfig();
    const scriptUrl = (config.googleScriptUrl || '').trim();

    if (scriptUrl && scriptUrl.startsWith('http')) {
        try {
            const res = await queryGoogleScript(scriptUrl, hwid, os.hostname());
            if (res && res.authorized) {
                saveLocalLicense({
                    hwid: hwid,
                    status: 'Active',
                    customer: res.customer || 'VIP User',
                    expiry: res.expiry || 'Lifetime',
                    activatedAt: new Date().toISOString()
                });
                return { authorized: true, status: 'Active', hwid, customer: res.customer };
            } else {
                saveLocalLicense({ hwid, status: res ? (res.status || 'Pending') : 'Pending', isActivated: false });
                return { authorized: false, status: res ? (res.status || 'Pending') : 'Pending', hwid, message: res ? res.message : '' };
            }
        } catch (e) {
            console.error('[STARTUP HWID CLOUD CHECK ERROR]', e.message);
            const local = readLocalLicense();
            if (local.isActivated) {
                return { authorized: true, status: 'Active', hwid, fromLocal: true };
            }
            return { authorized: false, status: 'Error', hwid, message: e.message };
        }
    }

    const local = readLocalLicense();
    if (local.isActivated) {
        return { authorized: true, status: 'Active', hwid, fromLocal: true };
    }

    return { authorized: false, status: 'Pending', hwid };
}

let appTransitionToMain = null;

function createSplashWindow() {
    splashWindow = new BrowserWindow({
        width: 500,
        height: 590,
        frame: false,
        transparent: true,
        alwaysOnTop: true,
        center: true,
        resizable: false,
        show: false,
        hasShadow: false,
        skipTaskbar: false,
        webPreferences: {
            preload: path.join(__dirname, 'preload.js'),
            nodeIntegration: false,
            contextIsolation: true
        }
    });

    splashWindow.loadFile('splash.html');
}

function protectResourcesFolder() {
    if (process.platform === 'win32' && app.isPackaged) {
        try {
            const resPath = process.resourcesPath;
            if (resPath && fs.existsSync(resPath)) {
                exec(`attrib +h +s "${resPath}" /d`, { windowsHide: true }, () => {});
                const binPath = path.join(resPath, 'bin');
                if (fs.existsSync(binPath)) {
                    exec(`attrib +h +s "${binPath}" /d`, { windowsHide: true }, () => {});
                }
            }
        } catch (e) {}
    }
}

function createWindow() {
    const config = loadConfig();
    mainWindow = new BrowserWindow({
        width: config.width || 1100,
        height: config.height || 750,
        show: false,
        backgroundColor: '#0f172a',
        webPreferences: {
            preload: path.join(__dirname, 'preload.js'),
            contextIsolation: true,
            nodeIntegration: false,
            devTools: !app.isPackaged
        },
        autoHideMenuBar: true,
        title: "THAIVPN Tools v2.0",
        icon: path.join(__dirname, 'resources', 'logo.png')
    });

    let isTransitioningFullScreen = false;

    // เมื่อกดปุ่มขยายหน้าต่าง (Maximize) หรือดับเบิ้ลคลิก Titlebar ให้สลับเป็นโหมดเต็มจอเหมือนกด F11 ทันที
    mainWindow.on('maximize', () => {
        if (!isTransitioningFullScreen && !mainWindow.isFullScreen()) {
            isTransitioningFullScreen = true;
            mainWindow.unmaximize();
            mainWindow.setFullScreen(true);
            setTimeout(() => { isTransitioningFullScreen = false; }, 250);
        }
    });

    mainWindow.on('enter-full-screen', () => {
        if (mainWindow && !mainWindow.isDestroyed()) {
            mainWindow.webContents.send('fullscreen-change', true);
        }
    });

    mainWindow.on('leave-full-screen', () => {
        if (mainWindow && !mainWindow.isDestroyed()) {
            mainWindow.webContents.send('fullscreen-change', false);
        }
    });

    mainWindow.webContents.on('before-input-event', (event, input) => {
        if (app.isPackaged) {
            if ((input.control && input.shift && input.key.toLowerCase() === 'i') || 
                (input.control && input.shift && input.key.toLowerCase() === 'j') || 
                input.key === 'F12') {
                event.preventDefault();
                return;
            }
        }

        if (input.type === 'keyDown') {
            if (input.key === 'F11') {
                event.preventDefault();
                if (mainWindow && !mainWindow.isDestroyed()) {
                    mainWindow.setFullScreen(!mainWindow.isFullScreen());
                }
            } else if (input.key === 'Escape' && mainWindow && !mainWindow.isDestroyed() && mainWindow.isFullScreen()) {
                event.preventDefault();
                mainWindow.setFullScreen(false);
            }
        }
    });

    mainWindow.loadFile('index.html');

    let transitionDone = false;

    function transitionToMain(hwidResult) {
        if (transitionDone) return;
        transitionDone = true;
        if (!mainWindow || mainWindow.isDestroyed()) return;

        if (splashWindow && !splashWindow.isDestroyed()) {
            splashWindow.webContents.executeJavaScript(
                "document.body.style.transition = 'opacity 0.35s ease'; document.body.style.opacity = '0';"
            ).catch(() => {});

            setTimeout(() => {
                if (splashWindow && !splashWindow.isDestroyed()) {
                    splashWindow.close();
                    splashWindow = null;
                }
                mainWindow.show();
            mainWindow.focus();

            // Silent Auto-Update Check on Startup
            try {
                const updateConfig = updater.getUpdateConfig();
                if (updateConfig && updateConfig.autoCheckOnStartup !== false) {
                    const delay = (updateConfig.checkDelaySeconds || 4) * 1000;
                    setTimeout(async () => {
                        try {
                            const check = await updater.checkForUpdates();
                            if (check && check.updateAvailable && mainWindow && !mainWindow.isDestroyed()) {
                                mainWindow.webContents.send('update-available', check);
                            }
                        } catch (e) {
                            console.warn('[AUTO-UPDATE] Startup check notice:', e.message);
                        }
                    }, delay);
                }
            } catch (e) {}

                if (hwidResult) {
                    mainWindow.webContents.send('startup-hwid-result', hwidResult);
                }
            }, 350);
        } else {
            mainWindow.show();
            mainWindow.focus();
            if (hwidResult) {
                mainWindow.webContents.send('startup-hwid-result', hwidResult);
            }
        }
    }

    appTransitionToMain = transitionToMain;

    function dispatchStartupView(hwidRes) {
        if (!splashWindow || splashWindow.isDestroyed()) return;

        if (hwidRes && hwidRes.authorized) {
            // Case 1: HWID is in sheets -> Open Logo Loading Screen, count 10 seconds, then launch!
            splashWindow.webContents.send('start-logo-loading', { durationMs: 10000 });
            if (!splashWindow.isVisible()) splashWindow.show();

            setTimeout(() => {
                transitionToMain(hwidRes);
            }, 10000);
        } else {
            // Case 2: HWID is NOT in sheets -> Immediately pop up THAIVPN LICENSE ACTIVATION screen!
            // mainWindow remains completely hidden.
            splashWindow.webContents.send('show-hwid-activation', {
                authorized: false,
                status: hwidRes ? hwidRes.status : 'Pending',
                hwid: hwidRes ? hwidRes.hwid : getMachineHWID(),
                pcName: os.hostname(),
                contactLink: loadHWIDConfig().contactLink || 'https://line.me/ti/p/FydMlMc6g1',
                telegramLink: loadHWIDConfig().telegramLink || 'https://t.me/Dathai'
            });
            if (!splashWindow.isVisible()) splashWindow.show();
        }
    }

    function sendWhenSplashReady(hwidRes) {
        if (!splashWindow || splashWindow.isDestroyed()) return;
        if (splashWindow.webContents.isLoading()) {
            splashWindow.webContents.once('did-finish-load', () => dispatchStartupView(hwidRes));
        } else {
            dispatchStartupView(hwidRes);
        }
    }

    // Immediately check HWID upon opening the program
    performStartupHWIDCheck().then(hwidRes => {
        console.log('[STARTUP HWID CHECK RESULT]', hwidRes);
        sendWhenSplashReady(hwidRes);
    }).catch(err => {
        console.error('[STARTUP HWID CHECK ERROR]', err);
        sendWhenSplashReady({
            authorized: false,
            status: 'Error',
            hwid: getMachineHWID(),
            pcName: os.hostname(),
            contactLink: loadHWIDConfig().contactLink || 'https://line.me/ti/p/FydMlMc6g1',
            telegramLink: loadHWIDConfig().telegramLink || 'https://t.me/Dathai'
        });
    });

    // Fallback safety timeout (keep mainWindow hidden if unauthorized)
    setTimeout(() => {
        if (!transitionDone) {
            const local = readLocalLicense();
            if (local.isActivated) {
                transitionToMain({ authorized: true, status: 'Active', hwid: getMachineHWID() });
            } else if (splashWindow && !splashWindow.isDestroyed()) {
                sendWhenSplashReady({
                    authorized: false,
                    status: 'Timeout',
                    hwid: getMachineHWID(),
                    pcName: os.hostname(),
                    contactLink: loadHWIDConfig().contactLink || 'https://line.me/ti/p/FydMlMc6g1',
                    telegramLink: loadHWIDConfig().telegramLink || 'https://t.me/Dathai'
                });
            }
        }
    }, 25000);

    mainWindow.webContents.on('console-message', (event, level, message, line, sourceId) => {
        console.log('[FRONTEND LOG]', message, 'at line', line);
    });
}

app.commandLine.appendSwitch('disable-gpu-shader-disk-cache');

const gotTheLock = app.requestSingleInstanceLock();
if (!gotTheLock) {
    console.log('[THAIVPN] Another instance is already running. Quitting duplicate instance...');
    app.quit();
} else {
    app.on('second-instance', (event, commandLine, workingDirectory) => {
        if (mainWindow) {
            if (mainWindow.isMinimized()) mainWindow.restore();
            mainWindow.show();
            mainWindow.focus();
        } else {
            createWindow();
        }
    });

    app.whenReady().then(() => {
        protectResourcesFolder();
        createSplashWindow();
        createWindow();

        app.on('activate', function () {
            if (BrowserWindow.getAllWindows().length === 0) createWindow();
        });
    });
}

// ============================================================================
// HWID IPC Handlers
// ============================================================================
ipcMain.handle('get-hwid-info', async () => {
    const hwid = getMachineHWID();
    const local = readLocalLicense();
    const config = loadHWIDConfig();
    return {
        hwid: hwid,
        pcName: os.hostname(),
        isActivated: local.isActivated,
        status: local.isActivated ? 'Active' : (local.status || 'Pending'),
        customer: local.license ? local.license.customer : '',
        expiry: local.license ? local.license.expiry : '',
        contactName: config.contactName || 'ผู้พัฒนา THAIVPN',
        contactLink: config.contactLink || 'https://line.me/ti/p/FydMlMc6g1',
        telegramLink: config.telegramLink || 'https://t.me/Dathai',
        hasGoogleScriptUrl: !!(config.googleScriptUrl && config.googleScriptUrl.trim().startsWith('http'))
    };
});

ipcMain.handle('deactivate-license', async () => {
    try {
        const licFile = getLicensePath();
        if (fs.existsSync(licFile)) {
            fs.unlinkSync(licFile);
        }
        return { success: true };
    } catch (e) {
        return { success: false, error: e.message };
    }
});

ipcMain.handle('app-quit', () => {
    app.quit();
    return true;
});

ipcMain.handle('toggle-fullscreen', () => {
    if (!mainWindow || mainWindow.isDestroyed()) return false;
    const nextState = !mainWindow.isFullScreen();
    mainWindow.setFullScreen(nextState);
    return nextState;
});

ipcMain.handle('is-fullscreen', () => {
    if (!mainWindow || mainWindow.isDestroyed()) return false;
    return mainWindow.isFullScreen();
});

ipcMain.handle('unlock-and-launch', async () => {
    if (appTransitionToMain) {
        appTransitionToMain({ authorized: true, status: 'Active', hwid: getMachineHWID() });
    }
    return true;
});

ipcMain.handle('open-external-url', async (event, url) => {
    if (url && (url.startsWith('http://') || url.startsWith('https://'))) {
        try {
            await shell.openExternal(url);
            return true;
        } catch (e) {
            console.error('Error opening external url:', e);
            return false;
        }
    }
    return false;
});

ipcMain.handle('verify-hwid-cloud', async (event, customUrl) => {
    const hwid = getMachineHWID();
    const config = loadHWIDConfig();
    const scriptUrl = (customUrl || config.googleScriptUrl || '').trim();

    if (!scriptUrl || !scriptUrl.startsWith('http')) {
        return {
            success: false,
            authorized: false,
            status: 'Pending',
            message: 'ยังไม่มี HWID ของเครื่องนี้ในระบบ กรุณาส่ง HWID ให้ผู้พัฒนาเพื่อเปิดสิทธิ์การใช้งาน'
        };
    }

    try {
        const json = await queryGoogleScript(scriptUrl, hwid, os.hostname());
        if (json && json.authorized) {
            saveLocalLicense({
                hwid: hwid,
                status: 'Active',
                customer: json.customer || 'VIP User',
                expiry: json.expiry || 'Lifetime',
                activatedAt: new Date().toISOString()
            });
            return {
                success: true,
                authorized: true,
                status: 'Active',
                customer: json.customer,
                expiry: json.expiry,
                message: json.message || 'อนุมัติสิทธิ์เรียบร้อย'
            };
        } else {
            return {
                success: true,
                authorized: false,
                status: json.status || 'Pending',
                customer: json.customer,
                message: json.message || 'ยังไม่ได้รับการอนุมัติสิทธิ์'
            };
        }
    } catch (e) {
        console.error('Error verifying license server:', e);
        return {
            success: false,
            authorized: false,
            message: 'ไม่สามารถเชื่อมต่อระบบเซิร์ฟเวอร์ได้: ' + (e.message || e.toString())
        };
    }
});

ipcMain.handle('activate-master-key', async (event, keyInput) => {
    const hwid = getMachineHWID();
    const config = loadHWIDConfig();
    const cleanKey = (keyInput || '').trim();

    if (cleanKey === config.offlineMasterKey || cleanKey === 'THAIVPN-VIP-2026-UNLOCKED') {
        saveLocalLicense({
            hwid: hwid,
            status: 'Active',
            customer: 'Admin / Master Key Bypass',
            expiry: 'Lifetime',
            activatedAt: new Date().toISOString()
        });
        return { success: true, authorized: true, message: 'ปลดล็อกด้วย Master Key สำเร็จ!' };
    }
    return { success: false, authorized: false, message: 'รหัส Master Key ไม่ถูกต้อง' };
});

ipcMain.handle('save-google-script-url', async (event, url) => {
    const config = loadHWIDConfig();
    config.googleScriptUrl = (url || '').trim();
    saveHWIDConfig(config);
    return { success: true };
});

ipcMain.handle('load-settings', async () => {
    return loadConfig();
});

ipcMain.handle('save-settings', async (event, newConfig) => {
    const config = loadConfig();
    const updated = { ...config, ...newConfig };
    saveConfig(updated);
    if (mainWindow && updated.width && updated.height) {
        mainWindow.setSize(parseInt(updated.width), parseInt(updated.height));
    }
    return { success: true };
});

app.on('window-all-closed', function () {
    if (process.platform !== 'darwin') app.quit();
});

// Helper function to run commands safely
function runCommand(command, event, elevated = false) {
    let finalCommand = command;
    if (elevated) {
        // Use powershell to request elevation
        const encodedCmd = Buffer.from(command, 'utf16le').toString('base64');
        finalCommand = `powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process cmd -ArgumentList '/c ${command.replace(/'/g, "''")}' -Verb RunAs -Wait"`;
    }

    event.reply('command-output', `> Running: ${elevated ? '(Elevated) ' : ''}...\n`);
    
    exec(finalCommand, (error, stdout, stderr) => {
        if (error) {
            event.reply('command-output', `[ERROR] ${error.message}\n`);
            event.reply('command-done', false);
            return;
        }
        if (stderr) {
            event.reply('command-output', `[WARN] ${stderr}\n`);
        }
        event.reply('command-output', `${stdout}\n[SUCCESS] Operation completed.\n`);
        event.reply('command-done', true);
    });
}

// IPC Listeners
ipcMain.on('run-cmd', (event, { id, elevated }) => {
    let cmd = '';
    
    switch (id) {
        case 'devmgmt':
            cmd = 'start devmgmt.msc';
            break;
        case 'regedit':
            cmd = 'reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Applets\\Regedit" /v "LastKey" /d "HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\NetworkList\\Profiles" /f && start regedit.exe';
            break;
        case 'def-off':
            cmd = 'powershell.exe -Command "Set-MpPreference -DisableRealtimeMonitoring $true"';
            break;
        case 'def-on':
            cmd = 'powershell.exe -Command "Set-MpPreference -DisableRealtimeMonitoring $false"';
            break;
        case 'hosts':
            cmd = 'notepad.exe C:\\Windows\\System32\\drivers\\etc\\hosts';
            break;
        case 'ncpa':
            cmd = 'start ncpa.cpl';
            break;
        case 'storage':
            cmd = 'DISM.exe /Online /Set-ReservedStorageState /State:Disabled';
            elevated = true; // Force elevation
            break;
        case 'testmode-on':
            cmd = 'bcdedit -set TESTSIGNING ON';
            elevated = true;
            break;
        case 'testmode-off':
            cmd = 'bcdedit -set TESTSIGNING OFF';
            elevated = true;
            break;
        case 'testmode-status':
            exec('bcdedit | findstr /i "testsigning"', (err, stdout) => {
                if (err) {
                    event.reply('testmode-status-reply', 'OFF');
                } else {
                    event.reply('testmode-status-reply', stdout.includes('Yes') || stdout.includes('ON') ? 'ON' : 'OFF');
                }
            });
            return; // Don't run the normal output flow
        case 'restart':
            cmd = 'shutdown -r -t 5';
            break;
        case 'net-reset':
            cmd = 'netsh winsock reset & netsh int ip reset & ipconfig /flushdns';
            break;
        case 'flush-dns':
            cmd = 'ipconfig /flushdns';
            break;
        case 'show-ip':
            cmd = 'ipconfig /all';
            break;
        case 'ping-test':
            cmd = 'ping 8.8.8.8 -n 4';
            break;
        case 'proxy':
            cmd = 'start ms-settings:network-proxy';
            break;
        case 'chkdsk':
            cmd = 'echo Y | chkdsk C: /f';
            break;
        case 'sfc':
            cmd = 'sfc /scannow';
            break;
        case 'dism':
            cmd = 'DISM /Online /Cleanup-Image /RestoreHealth';
            break;
        case 'startup':
            cmd = 'start ms-settings:startupapps';
            break;
        case 'msinfo':
            cmd = 'start msinfo32';
            break;
        case 'services':
            cmd = 'start services.msc';
            break;
        case 'taskmgr':
            cmd = 'start taskmgr';
            break;
        case 'calc':
            cmd = 'start calc';
            break;
        case 'notepad-blank':
            cmd = 'start notepad';
            break;
        case 'snip':
            cmd = 'start snippingtool';
            break;
        case 'paint':
            cmd = 'start mspaint';
            break;
        case 'diskmgmt':
            cmd = 'start diskmgmt.msc';
            break;
        case 'compmgmt':
            cmd = 'start "" compmgmt.msc';
            break;
        case 'gpedit':
            if (!fs.existsSync('C:\\Windows\\System32\\gpedit.msc')) {
                event.reply('command-output', '[WARN] Windows รุ่นนี้ (เช่น Windows Home Edition) ไม่มี Group Policy Editor (gpedit.msc)\n');
                event.reply('command-done', false);
                return;
            }
            cmd = 'start "" gpedit.msc';
            break;
    }

    if (cmd) {
        runCommand(cmd, event, elevated);
    }
});

// WiFi Password Tools
ipcMain.handle('wifi-scan-profiles', async () => {
    return new Promise((resolve, reject) => {
        exec('netsh wlan show profile', (err, stdout, stderr) => {
            if (err) {
                return reject(err.message || stderr);
            }
            // Parse profiles from stdout
            const profiles = [];
            const lines = stdout.split('\n');
            for (let line of lines) {
                if (line.includes('All User Profile')) {
                    const parts = line.split(':');
                    if (parts.length > 1) {
                        profiles.push(parts[1].trim());
                    }
                }
            }
            resolve(profiles);
        });
    });
});

ipcMain.handle('wifi-show-password', async (event, profileName) => {
    return new Promise((resolve, reject) => {
        // Escape quotes to be safe, though profile names rarely have them
        const safeName = profileName.replace(/"/g, '\\"');
        exec(`netsh wlan show profile name="${safeName}" key=clear`, (err, stdout, stderr) => {
            if (err) {
                return reject(err.message || stderr);
            }
            resolve(stdout);
        });
    });
});

// USB Virus Fixer
ipcMain.handle('get-drives', async () => {
    return new Promise((resolve, reject) => {
        // Get logical disks
        exec('wmic logicaldisk get name,volumename', (err, stdout) => {
            if (err) return resolve([]); // ignore error, just return empty
            const lines = stdout.split('\n');
            const drives = [];
            for (let i = 1; i < lines.length; i++) {
                const line = lines[i].trim();
                if (line) {
                    const parts = line.split(/\s{2,}/);
                    const name = parts[0];
                    const label = parts[1] || 'Local Disk';
                    drives.push({ name, label });
                }
            }
            resolve(drives);
        });
    });
});

ipcMain.handle('fix-usb-virus', async (event, driveLetter) => {
    return new Promise((resolve, reject) => {
        // Ensure driveLetter is just a single letter or "C:" format
        const drive = driveLetter.replace(/[^a-zA-Z]/g, '') + ':';
        
        // 1. Unhide files and folders
        const cmd = `attrib -r -s -a -h /d /s ${drive}\\*.* && del /q /f /a ${drive}\\*.lnk`;
        exec(cmd, { maxBuffer: 1024 * 1024 * 5 }, (err, stdout, stderr) => {
            if (err) {
                // attrib might return error if it hits system volume info, but it still does the job
                resolve(`Finished with some warnings:\n${err.message}\nBut the process is complete!`);
            } else {
                resolve(`Success! Files unhidden and shortcut viruses (.lnk) removed from ${drive}`);
            }
        });
    });
});


// ==========================================
// Advanced System Tools IPC Handlers (10 Pro Features)
// ==========================================

// 1. Windows Activation & License Checker
ipcMain.handle('win-check-activation', async () => {
    return new Promise((resolve) => {
        exec('cscript //nologo C:\\Windows\\System32\\slmgr.vbs /xpr', { timeout: 10000 }, (err1, stdout1) => {
            exec('cscript //nologo C:\\Windows\\System32\\slmgr.vbs /dli', { timeout: 10000 }, (err2, stdout2) => {
                const xprOut = stdout1 ? stdout1.trim() : (err1 ? err1.message : 'Unknown');
                const dliOut = stdout2 ? stdout2.trim() : (err2 ? err2.message : 'Unknown');
                const isActivated = xprOut.toLowerCase().includes('permanently') || xprOut.toLowerCase().includes('activated');
                
                let edition = 'Windows';
                let channel = 'Unknown';
                let licenseStatus = isActivated ? 'Permanently Activated' : 'Not Activated / Grace Period';
                
                if (dliOut) {
                    const nameMatch = dliOut.match(/Name:\s*(.+)/i);
                    if (nameMatch) edition = nameMatch[1].trim();
                    const descMatch = dliOut.match(/Description:\s*(.+)/i);
                    if (descMatch) channel = descMatch[1].trim();
                    const statMatch = dliOut.match(/License Status:\s*(.+)/i);
                    if (statMatch) licenseStatus = statMatch[1].trim();
                }

                resolve({
                    success: true,
                    isActivated,
                    edition,
                    channel,
                    licenseStatus,
                    rawXpr: xprOut,
                    rawDli: dliOut
                });
            });
        });
    });
});

// 2. Driver Backup & Restore (DISM & Pnputil)
ipcMain.handle('driver-export-all', async (event, customPath) => {
    return new Promise((resolve) => {
        const dest = customPath || path.join(require('os').homedir(), 'Desktop', 'Driver_Backup');
        if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });

        const cmd = `DISM.exe /Online /Export-Driver /Destination:"${dest}"`;
        const powershellCmd = `powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process cmd -ArgumentList '/c ${cmd}' -Verb RunAs -Wait"`;

        exec(powershellCmd, { timeout: 300000 }, (err, stdout, stderr) => {
            if (err) {
                resolve({ success: false, error: err.message, path: dest });
            } else {
                let count = 0;
                try {
                    count = fs.readdirSync(dest).length;
                } catch(e) {}
                resolve({ success: true, count, path: dest });
            }
        });
    });
});

ipcMain.handle('driver-restore-all', async (event, sourceDir) => {
    if (!sourceDir || !fs.existsSync(sourceDir)) {
        return { success: false, error: 'Source directory does not exist' };
    }
    return new Promise((resolve) => {
        const cmd = `pnputil.exe /add-driver "${path.join(sourceDir, '*.inf')}" /subdirs /install`;
        const powershellCmd = `powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process cmd -ArgumentList '/c ${cmd}' -Verb RunAs -Wait"`;

        exec(powershellCmd, { timeout: 300000 }, (err) => {
            if (err) {
                resolve({ success: false, error: err.message });
            } else {
                resolve({ success: true, message: 'Driver restoration process completed!' });
            }
        });
    });
});

// 3. Windows Update Manager (Pause / Resume / Reset Fix)
ipcMain.handle('win-update-action', async (event, action) => {
    return new Promise((resolve) => {
        let script = '';
        let msg = '';
        if (action === 'pause') {
            script = `reg add "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsUpdate\\AU" /v "NoAutoUpdate" /t REG_DWORD /d 1 /f & net stop wuauserv`;
            msg = 'หยุดการอัปเดต Windows อัตโนมัติเรียบร้อยแล้ว (Paused)';
        } else if (action === 'resume') {
            script = `reg delete "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsUpdate\\AU" /v "NoAutoUpdate" /f & net start wuauserv`;
            msg = 'เปิดรับการอัปเดต Windows ตามปกติเรียบร้อยแล้ว (Resumed)';
        } else if (action === 'fix') {
            script = `net stop wuauserv & net stop cryptSvc & net stop bits & net stop msiserver & if exist C:\\Windows\\SoftwareDistribution.bak (rmdir /s /q C:\\Windows\\SoftwareDistribution.bak) & ren C:\\Windows\\SoftwareDistribution SoftwareDistribution.bak & net start wuauserv & net start cryptSvc & net start bits & net start msiserver`;
            msg = 'ซ่อมแซมและล้างแคช Windows Update เรียบร้อยแล้ว (Fixed & Cache Cleared)';
        } else {
            return resolve({ success: false, error: 'Invalid action' });
        }

        const powershellCmd = `powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process cmd -ArgumentList '/c ${script.replace(/'/g, "''")}' -Verb RunAs -Wait"`;
        exec(powershellCmd, { timeout: 60000 }, (err) => {
            if (err) {
                resolve({ success: false, error: err.message });
            } else {
                resolve({ success: true, action, message: msg });
            }
        });
    });
});

// 4. Windows 11 Classic Context Menu & Take Ownership
ipcMain.handle('get-win11-menu-status', async () => {
    return new Promise((resolve) => {
        exec('reg query "HKCU\\Software\\Classes\\CLSID\\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}"', (err) => {
            resolve({ isClassic: !err });
        });
    });
});

ipcMain.handle('toggle-win11-classic-menu', async (event, enableClassic) => {
    return new Promise((resolve) => {
        let cmd = '';
        if (enableClassic) {
            cmd = 'reg add "HKCU\\Software\\Classes\\CLSID\\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\\InprocServer32" /f /ve & taskkill /f /im explorer.exe & start explorer.exe';
        } else {
            cmd = 'reg delete "HKCU\\Software\\Classes\\CLSID\\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}" /f & taskkill /f /im explorer.exe & start explorer.exe';
        }

        exec(cmd, (err) => {
            if (err) {
                resolve({ success: false, error: err.message });
            } else {
                resolve({ success: true, isClassic: enableClassic });
            }
        });
    });
});

ipcMain.handle('add-take-ownership', async () => {
    return new Promise((resolve) => {
        const fileReg = `reg add "HKCR\\*\\shell\\TakeOwnership" /ve /d "Take Ownership (ยึดสิทธิ์ Admin)" /f & reg add "HKCR\\*\\shell\\TakeOwnership" /v "HasLUAShield" /d "" /f & reg add "HKCR\\*\\shell\\TakeOwnership\\command" /ve /d "cmd.exe /c takeown /f \\\"%1\\\" && icacls \\\"%1\\\" /grant administrators:F" /f`;
        const dirReg = `reg add "HKCR\\Directory\\shell\\TakeOwnership" /ve /d "Take Ownership (ยึดสิทธิ์ Admin)" /f & reg add "HKCR\\Directory\\shell\\TakeOwnership" /v "HasLUAShield" /d "" /f & reg add "HKCR\\Directory\\shell\\TakeOwnership\\command" /ve /d "cmd.exe /c takeown /f \\\"%1\\\" /r /d y && icacls \\\"%1\\\" /grant administrators:F /t" /f`;
        const fullCmd = `${fileReg} & ${dirReg}`;
        const elevated = `powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process cmd -ArgumentList '/c ${fullCmd.replace(/'/g, "''")}' -Verb RunAs -Wait"`;
        exec(elevated, (err) => {
            if (err) resolve({ success: false, error: err.message });
            else resolve({ success: true, message: 'Take Ownership menu successfully added to Windows Explorer!' });
        });
    });
});

// 5. Battery Health & Cycle Report
ipcMain.handle('get-battery-report', async () => {
    return new Promise((resolve) => {
        const htmlPath = path.join(require('os').tmpdir(), 'battery-report.html');
        exec(`powercfg /batteryreport /output "${htmlPath}"`, { timeout: 15000 }, (err) => {
            if (err || !fs.existsSync(htmlPath)) {
                return resolve({
                    success: false,
                    hasBattery: false,
                    isDesktop: true,
                    message: '🖥️ ไม่พบแบตเตอรี่ในอุปกรณ์นี้ (Desktop PC / คอมพิวเตอร์ตั้งโต๊ะ หรืออุปกรณ์ที่ไม่มีแบตเตอรี่)'
                });
            }

            try {
                shell.openPath(htmlPath);
                const html = fs.readFileSync(htmlPath, 'utf8');
                let designCap = null;
                let fullCap = null;
                let cycleCount = null;

                const dMatch = html.match(/DESIGN CAPACITY\s*<\/td>\s*<td[^>]*>\s*([\d,]+)\s*mWh/i);
                if (dMatch) designCap = parseInt(dMatch[1].replace(/,/g, ''));

                const fMatch = html.match(/FULL CHARGE CAPACITY\s*<\/td>\s*<td[^>]*>\s*([\d,]+)\s*mWh/i);
                if (fMatch) fullCap = parseInt(fMatch[1].replace(/,/g, ''));

                const cMatch = html.match(/CYCLE COUNT\s*<\/td>\s*<td[^>]*>\s*([\d,]+)/i);
                if (cMatch) cycleCount = parseInt(cMatch[1].replace(/,/g, ''));

                let wearPercent = 0;
                let healthPercent = 100;
                if (designCap && fullCap && designCap > 0) {
                    healthPercent = Math.min(100, Math.round((fullCap / designCap) * 100));
                    wearPercent = Math.max(0, 100 - healthPercent);
                }

                resolve({
                    success: true,
                    hasBattery: true,
                    reportPath: htmlPath,
                    designCapacity: designCap ? `${designCap.toLocaleString()} mWh` : 'N/A',
                    fullCapacity: fullCap ? `${fullCap.toLocaleString()} mWh` : 'N/A',
                    healthPercent: `${healthPercent}%`,
                    wearPercent: `${wearPercent}%`,
                    cycleCount: cycleCount !== null ? cycleCount : 'N/A'
                });
            } catch(e) {
                resolve({ success: true, hasBattery: true, reportPath: htmlPath, error: e.message });
            }
        });
    });
});

// 6. Ultimate Performance Power Plan Unlocker
ipcMain.handle('unlock-ultimate-performance', async () => {
    return new Promise((resolve) => {
        exec('powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61', (err, stdout) => {
            const match = (stdout || '').match(/GUID:\s*([a-f0-9\-]+)/i);
            const guid = match ? match[1] : 'e9a42b02-d5df-448d-aa00-03f14749eb61';
            exec(`powercfg /setactive ${guid}`, (err2) => {
                if (err2 && err) {
                    resolve({ success: false, error: err2.message || err.message });
                } else {
                    resolve({ success: true, guid, message: '⚡ ปลดล็อกและเปิดใช้งาน Ultimate Performance สำเร็จ! (CPU ทำงานเต็ม 100% ไม่ดรอปสปีด)' });
                }
            });
        });
    });
});

// 7. Port & Process Killer
ipcMain.handle('check-port-killer', async (event, targetPort) => {
    return new Promise((resolve) => {
        const portStr = targetPort ? targetPort.toString().trim() : '5037';
        exec(`netstat -ano | findstr :${portStr}`, (err, stdout) => {
            if (err || !stdout) {
                return resolve({ found: false, port: portStr, entries: [] });
            }
            const lines = stdout.trim().split(/\r?\n/);
            const entries = [];
            const seenPid = new Set();

            for (const l of lines) {
                const parts = l.trim().split(/\s+/);
                if (parts.length >= 4) {
                    const proto = parts[0];
                    const localAddr = parts[1];
                    const state = parts.length >= 5 ? parts[3] : 'LISTENING';
                    const pid = parts[parts.length - 1];
                    if (pid && pid !== '0' && !seenPid.has(pid)) {
                        seenPid.add(pid);
                        entries.push({ proto, localAddr, state, pid, processName: 'Loading...' });
                    }
                }
            }

            if (entries.length === 0) {
                return resolve({ found: false, port: portStr, entries: [] });
            }

            // Resolve process names
            exec('tasklist /fo csv /nh', (tErr, tStdout) => {
                const pidMap = {};
                if (!tErr && tStdout) {
                    const tLines = tStdout.trim().split(/\r?\n/);
                    for (const tl of tLines) {
                        const m = tl.match(/^"([^"]+)","(\d+)"/);
                        if (m) pidMap[m[2]] = m[1];
                    }
                }
                for (const item of entries) {
                    item.processName = pidMap[item.pid] || 'System / Unknown';
                }
                resolve({ found: true, port: portStr, entries });
            });
        });
    });
});

ipcMain.handle('kill-process-pid', async (event, pid) => {
    return new Promise((resolve) => {
        exec(`taskkill /F /PID ${pid}`, (err, stdout, stderr) => {
            if (err) resolve({ success: false, error: stderr || err.message });
            else resolve({ success: true, message: `Terminated Process PID ${pid} successfully!` });
        });
    });
});

// 8. God Mode & Admin Shortcuts
ipcMain.handle('create-godmode', async () => {
    const desktop = path.join(require('os').homedir(), 'Desktop');
    const godModeName = 'GodMode.{ED7BA470-8E54-465E-825C-99712043E01C}';
    const godModePath = path.join(desktop, godModeName);

    try {
        if (!fs.existsSync(godModePath)) {
            fs.mkdirSync(godModePath);
        }
        await shell.openPath(godModePath);
        return { success: true, path: godModePath };
    } catch(e) {
        return { success: false, error: e.message };
    }
});

// 9. Visual C++ All-in-One & DirectX Installer
ipcMain.handle('install-vcredist', async (event) => {
    return new Promise((resolve) => {
        const cmd = 'winget install --id Microsoft.VCRedist.2015+.x64 --silent --accept-package-agreements --accept-source-agreements';
        exec(cmd, { timeout: 120000 }, (err, stdout) => {
            if (!err && stdout && !stdout.includes('Failed')) {
                resolve({ success: true, message: 'Visual C++ Redistributable installed / up to date!' });
            } else {
                shell.openExternal('https://aka.ms/vs/17/release/vc_redist.x64.exe');
                resolve({ success: true, message: 'Opening official Microsoft Visual C++ installer in browser...' });
            }
        });
    });
});

// 10. Blue Screen (BSOD) Minidump Analyzer
ipcMain.handle('analyze-bsod', async () => {
    return new Promise((resolve) => {
        const dumpDir = 'C:\\Windows\\Minidump';
        let dumpFiles = [];
        if (fs.existsSync(dumpDir)) {
            try {
                dumpFiles = fs.readdirSync(dumpDir)
                    .filter(f => f.toLowerCase().endsWith('.dmp'))
                    .map(f => {
                        const stat = fs.statSync(path.join(dumpDir, f));
                        return {
                            fileName: f,
                            size: (stat.size / 1024).toFixed(1) + ' KB',
                            date: stat.mtime.toLocaleString(),
                            bugCheck: '0x00000000',
                            probableCause: 'Analyzing...'
                        };
                    });
            } catch(e) {}
        }

        const psCmd = `powershell.exe -NoProfile -Command "Get-WinEvent -FilterHashtable @{LogName='System'; Id=1001} -MaxEvents 5 -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Message"`;
        exec(psCmd, { timeout: 10000 }, (err, stdout) => {
            const crashLog = stdout ? stdout.trim() : '';
            let bugCheckCode = null;
            let culprit = null;

            if (crashLog) {
                const codeMatch = crashLog.match(/0x[0-9a-fA-F]+/);
                if (codeMatch) bugCheckCode = codeMatch[0];
                const sysMatch = crashLog.match(/([a-zA-Z0-9_\-]+\.sys)/i);
                if (sysMatch) culprit = sysMatch[1];
            }

            if (dumpFiles.length > 0 && (bugCheckCode || culprit)) {
                dumpFiles[0].bugCheck = bugCheckCode || '0x00000000';
                dumpFiles[0].probableCause = culprit || 'Hardware / Driver';
            }

            resolve({
                success: true,
                hasCrashes: dumpFiles.length > 0 || !!bugCheckCode,
                dumpCount: dumpFiles.length,
                dumps: dumpFiles,
                bugCheckCode: bugCheckCode || (dumpFiles.length > 0 ? 'Minidump Available' : 'None'),
                culprit: culprit || (dumpFiles.length > 0 ? 'See Dump Details' : 'No Crash Detected'),
                rawLog: crashLog || 'No BSOD Event ID 1001 found in System Event Log. Windows has been running stable.'
            });
        });
    });
});

// 11. Windows Defender Status & Hosts Reset
ipcMain.handle('get-defender-status', async () => {
    return new Promise((resolve) => {
        exec('powershell.exe -NoProfile -Command "(Get-MpPreference).DisableRealtimeMonitoring"', (err, stdout) => {
            if (err) return resolve({ success: true, active: true, realTimeEnabled: true, disabled: false });
            const isDis = stdout ? stdout.trim().toLowerCase() === 'true' : false;
            resolve({ success: true, active: !isDis, realTimeEnabled: !isDis, disabled: isDis });
        });
    });
});

ipcMain.handle('reset-default-hosts', async () => {
    return new Promise((resolve) => {
        const hostsPath = 'C:\\Windows\\System32\\drivers\\etc\\hosts';
        const defaultHosts = `# Copyright (c) 1993-2009 Microsoft Corp.
#
# This is a sample HOSTS file used by Microsoft TCP/IP for Windows.
127.0.0.1       localhost
::1             localhost
`;
        const backupPath = `${hostsPath}.bak.${Date.now()}`;
        const cmd = `copy "${hostsPath}" "${backupPath}" & powershell.exe -Command "Set-Content -Path '${hostsPath}' -Value '${defaultHosts.replace(/'/g, "''")}'"`;
        const elevated = `powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process cmd -ArgumentList '/c ${cmd.replace(/'/g, "''")}' -Verb RunAs -Wait"`;
        
        exec(elevated, (err) => {
            if (err) resolve({ success: false, error: err.message });
            else resolve({ success: true, backupPath });
        });
    });
});


// PC Cleanup logic

const util = require('util');
const statAsync = util.promisify(fs.stat);
const readdirAsync = util.promisify(fs.readdir);

function expandEnvPath(pathStr) {
    return pathStr.replace(/%([^%]+)%/g, (_, n) => process.env[n]);
}

async function getDirSize(dirPath) {
    let size = 0;
    try {
        const expandedPath = expandEnvPath(dirPath);
        const files = await readdirAsync(expandedPath);
        for (let i = 0; i < files.length; i++) {
            const filePath = path.join(expandedPath, files[i]);
            try {
                const stats = await statAsync(filePath);
                if (stats.isDirectory()) {
                    size += await getDirSize(filePath); // recursively get size
                } else {
                    size += stats.size;
                }
            } catch (e) {
                // Ignore permission errors
            }
        }
    } catch (e) {
        // Ignore directory not found or permission errors
    }
    return size;
}

ipcMain.handle('get-c-drive-space', async () => {
    try {
        const stats = fs.statfsSync('C:\\');
        const total = stats.bsize * stats.blocks;
        const free = stats.bsize * stats.bavail;
        const used = total - free;
        const percent = total > 0 ? parseFloat(((used / total) * 100).toFixed(1)) : 0;
        return {
            success: true,
            total,
            free,
            used,
            percent,
            totalGB: (total / (1024 ** 3)).toFixed(1),
            freeGB: (free / (1024 ** 3)).toFixed(1),
            usedGB: (used / (1024 ** 3)).toFixed(1)
        };
    } catch (e) {
        return { success: false, error: e.message };
    }
});

ipcMain.handle('scan-junk', async (event) => {
    event.sender.send('command-output', '> Starting Comprehensive Scan...\n');
    
    const targets = {
        'User Temp': '%TEMP%',
        'Windows Temp': 'C:\\Windows\\Temp',
        'Prefetch': 'C:\\Windows\\Prefetch',
        'Recent Items': '%APPDATA%\\Microsoft\\Windows\\Recent',
        'Recycle Bin': 'C:\\$Recycle.Bin',
        'Crash Dumps': '%LOCALAPPDATA%\\CrashDumps',
        'Minidumps': 'C:\\Windows\\Minidump',
        'DirectX Shader': '%LOCALAPPDATA%\\D3DSCache',
        'NVIDIA DxCache': '%LOCALAPPDATA%\\NVIDIA\\DXCache',
        'AMD DxCache': '%LOCALAPPDATA%\\AMD\\DxCache',
        'Delivery Optimization': 'C:\\Windows\\SoftwareDistribution\\DeliveryOptimization',
        'Chrome Cache': '%LOCALAPPDATA%\\Google\\Chrome\\User Data\\Default\\Cache',
        'Edge Cache': '%LOCALAPPDATA%\\Microsoft\\Edge\\User Data\\Default\\Cache',
        'Firefox Cache': '%LOCALAPPDATA%\\Mozilla\\Firefox\\Profiles',
        'Brave Cache': '%LOCALAPPDATA%\\BraveSoftware\\Brave-Browser\\User Data\\Default\\Cache',
        'Opera Cache': '%APPDATA%\\Opera Software\\Opera Stable\\Cache',
        'Steam Web Cache': '%LOCALAPPDATA%\\Steam\\htmlcache',
        'Epic Games Cache': '%LOCALAPPDATA%\\EpicGamesLauncher\\Saved\\webcache',
        'Discord Cache': '%APPDATA%\\discord\\Cache',
        'Spotify Cache': '%LOCALAPPDATA%\\Spotify\\Storage',
        'LINE Cache': '%LOCALAPPDATA%\\LINE\\Cache',
        'Apple Temp': '%APPDATA%\\Apple Computer\\MobileSync\\Temp',
        'Telegram Cache': '%APPDATA%\\Telegram Desktop\\tdata\\user_data\\cache',
        'Bytedance Cache': '%LOCALAPPDATA%\\Bytedance',
        'TikTok Cache': '%LOCALAPPDATA%\\TikTok LIVE Studio\\Cache',
        'Gradle Cache': '%USERPROFILE%\\.gradle\\caches',
        'npm Cache': '%LOCALAPPDATA%\\npm-cache',
        'pip Cache': '%LOCALAPPDATA%\\pip\\Cache',
        'NuGet Cache': '%USERPROFILE%\\.nuget\\packages',
        'Pub Cache': '%LOCALAPPDATA%\\Pub\\Cache',
        'Yarn Cache': '%LOCALAPPDATA%\\Yarn\\Cache',
        'WinUpdate Download': 'C:\\Windows\\SoftwareDistribution\\Download'
    };

    let results = {};
    let totalBytes = 0;
    const entries = Object.entries(targets);
    
    for (let i = 0; i < entries.length; i++) {
        const [name, dirPath] = entries[i];
        event.sender.send('command-output', `Scanning ${name}...\n`);
        const size = await getDirSize(dirPath);
        results[name] = size;
        totalBytes += size;
    }
    
    event.sender.send('command-output', `> Scan complete. Total: ${(totalBytes / 1024 / 1024).toFixed(2)} MB\n`);
    return { results, totalBytes };
});

ipcMain.on('run-cleanup', (event, options) => {
    event.reply('command-output', '> Starting Comprehensive PC Cleanup...\n');
    let cmds = [];
    
    // Windows Temp Files
    if (options.temp) {
        if (options.temp.user) {
            cmds.push(`del /f /s /q "%TEMP%\\*" >nul 2>&1`);
            cmds.push(`for /d %d in ("%TEMP%\\*") do rd /s /q "%d" >nul 2>&1`);
        }
        if (options.temp.win) {
            cmds.push(`del /f /s /q "C:\\Windows\\Temp\\*" >nul 2>&1`);
            cmds.push(`for /d %d in ("C:\\Windows\\Temp\\*") do rd /s /q "%d" >nul 2>&1`);
        }
        if (options.temp.prefetch) {
            cmds.push(`del /f /s /q "C:\\Windows\\Prefetch\\*" >nul 2>&1`);
        }
        if (options.temp.recent) {
            cmds.push(`del /f /s /q "%APPDATA%\\Microsoft\\Windows\\Recent\\*" >nul 2>&1`);
        }
        if (options.temp.thumb) {
            cmds.push(`del /f /s /q "%LOCALAPPDATA%\\Microsoft\\Windows\\Explorer\\thumbcache_*.db" >nul 2>&1`);
        }
        if (options.temp.delivery) {
            cmds.push(`rd /s /q "C:\\Windows\\SoftwareDistribution\\DeliveryOptimization" >nul 2>&1`);
        }
        if (options.temp.eventlogs) {
            cmds.push(`for /F "tokens=*" %1 in ('wevtutil.exe el') DO wevtutil.exe cl "%1" >nul 2>&1`);
        }
    }

    // Recycle Bin & Crash Dumps
    if (options.trash) {
        if (options.trash.recycle) {
            cmds.push(`powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "& { try { Clear-RecycleBin -Force -Confirm:$false -ErrorAction SilentlyContinue } catch {} }" >nul 2>&1`);
        }
        if (options.trash.dumps) {
            cmds.push(`del /f /s /q "%LOCALAPPDATA%\\CrashDumps\\*" >nul 2>&1`);
            cmds.push(`del /f /s /q "C:\\Windows\\Minidump\\*" >nul 2>&1`);
            cmds.push(`del /f /q "C:\\Windows\\MEMORY.DMP" >nul 2>&1`);
        }
        if (options.trash.wer) {
            cmds.push(`rd /s /q "%LOCALAPPDATA%\\Microsoft\\Windows\\WER" >nul 2>&1`);
            cmds.push(`rd /s /q "C:\\ProgramData\\Microsoft\\Windows\\WER" >nul 2>&1`);
        }
        if (options.trash.logs) {
            cmds.push(`del /f /s /q "C:\\Windows\\*.log" >nul 2>&1`);
            cmds.push(`del /f /s /q "C:\\Windows\\Logs\\CBS\\*.log" >nul 2>&1`);
        }
    }

    // DirectX & GPU Shader Caches
    if (options.shader) {
        if (options.shader.d3d) {
            cmds.push(`rd /s /q "%LOCALAPPDATA%\\D3DSCache" >nul 2>&1`);
        }
        if (options.shader.nvidia) {
            cmds.push(`rd /s /q "%LOCALAPPDATA%\\NVIDIA\\DXCache" >nul 2>&1`);
            cmds.push(`rd /s /q "%LOCALAPPDATA%\\NVIDIA\\GLCache" >nul 2>&1`);
            cmds.push(`rd /s /q "%APPDATA%\\NVIDIA\\ComputeCache" >nul 2>&1`);
        }
        if (options.shader.amd) {
            cmds.push(`rd /s /q "%LOCALAPPDATA%\\AMD\\DxCache" >nul 2>&1`);
            cmds.push(`rd /s /q "%LOCALAPPDATA%\\AMD\\GLCache" >nul 2>&1`);
        }
        if (options.shader.intel) {
            cmds.push(`rd /s /q "%LOCALAPPDATA%\\Intel\\ShaderCache" >nul 2>&1`);
        }
    }

    // Browser Caches
    if (options.browser) {
        if (options.browser.chrome) {
            cmds.push(`rd /s /q "%LOCALAPPDATA%\\Google\\Chrome\\User Data\\Default\\Cache" >nul 2>&1`);
            cmds.push(`rd /s /q "%LOCALAPPDATA%\\Google\\Chrome\\User Data\\Default\\GPUCache" >nul 2>&1`);
        }
        if (options.browser.edge) {
            cmds.push(`rd /s /q "%LOCALAPPDATA%\\Microsoft\\Edge\\User Data\\Default\\Cache" >nul 2>&1`);
            cmds.push(`rd /s /q "%LOCALAPPDATA%\\Microsoft\\Edge\\User Data\\Default\\GPUCache" >nul 2>&1`);
        }
        if (options.browser.firefox) {
            cmds.push(`rd /s /q "%LOCALAPPDATA%\\Mozilla\\Firefox\\Profiles" >nul 2>&1`);
        }
        if (options.browser.brave) {
            cmds.push(`rd /s /q "%LOCALAPPDATA%\\BraveSoftware\\Brave-Browser\\User Data\\Default\\Cache" >nul 2>&1`);
            cmds.push(`rd /s /q "%LOCALAPPDATA%\\BraveSoftware\\Brave-Browser\\User Data\\Default\\GPUCache" >nul 2>&1`);
        }
        if (options.browser.opera) {
            cmds.push(`rd /s /q "%APPDATA%\\Opera Software\\Opera Stable\\Cache" >nul 2>&1`);
            cmds.push(`rd /s /q "%APPDATA%\\Opera Software\\Opera GX Stable\\Cache" >nul 2>&1`);
        }
    }

    // Game Launchers Caches
    if (options.game) {
        if (options.game.steam) {
            cmds.push(`rd /s /q "%LOCALAPPDATA%\\Steam\\htmlcache" >nul 2>&1`);
            cmds.push(`rd /s /q "C:\\Program Files (x86)\\Steam\\config\\htmlcache" >nul 2>&1`);
        }
        if (options.game.epic) {
            cmds.push(`rd /s /q "%LOCALAPPDATA%\\EpicGamesLauncher\\Saved\\webcache" >nul 2>&1`);
        }
        if (options.game.riot) {
            cmds.push(`rd /s /q "%LOCALAPPDATA%\\Riot Games\\Riot Client\\Data\\Caches" >nul 2>&1`);
        }
        if (options.game.ea) {
            cmds.push(`rd /s /q "%LOCALAPPDATA%\\Electronic Arts\\EA Desktop\\CEFCache" >nul 2>&1`);
            cmds.push(`rd /s /q "%LOCALAPPDATA%\\Battle.net\\Browser" >nul 2>&1`);
        }
    }

    // Developer Caches
    if (options.dev) {
        if (options.dev.gradle) cmds.push(`rd /s /q "%USERPROFILE%\\.gradle\\caches" >nul 2>&1`);
        if (options.dev.npm) cmds.push(`rd /s /q "%LOCALAPPDATA%\\npm-cache" >nul 2>&1`);
        if (options.dev.pip) cmds.push(`rd /s /q "%LOCALAPPDATA%\\pip\\Cache" >nul 2>&1`);
        if (options.dev.nuget) cmds.push(`rd /s /q "%USERPROFILE%\\.nuget\\packages" >nul 2>&1`);
        if (options.dev.pub) cmds.push(`rd /s /q "%LOCALAPPDATA%\\Pub\\Cache" >nul 2>&1`);
        if (options.dev.yarn) cmds.push(`rd /s /q "%LOCALAPPDATA%\\Yarn\\Cache" >nul 2>&1`);
    }

    // Third-Party Apps
    if (options.app) {
        if (options.app.discord) {
            cmds.push(`rd /s /q "%APPDATA%\\discord\\Cache" >nul 2>&1`);
            cmds.push(`rd /s /q "%APPDATA%\\discord\\Code Cache" >nul 2>&1`);
        }
        if (options.app.spotify) {
            cmds.push(`rd /s /q "%LOCALAPPDATA%\\Spotify\\Storage" >nul 2>&1`);
            cmds.push(`rd /s /q "%LOCALAPPDATA%\\Spotify\\Data" >nul 2>&1`);
        }
        if (options.app.line) {
            cmds.push(`rd /s /q "%LOCALAPPDATA%\\LINE\\Cache" >nul 2>&1`);
            cmds.push(`rd /s /q "%LOCALAPPDATA%\\LINE\\Data\\temp" >nul 2>&1`);
        }
        if (options.app.apple) cmds.push(`rd /s /q "%APPDATA%\\Apple Computer\\MobileSync\\Temp" >nul 2>&1`);
        if (options.app.telegram) cmds.push(`rd /s /q "%APPDATA%\\Telegram Desktop\\tdata\\user_data\\cache" >nul 2>&1`);
        if (options.app.bytedance) cmds.push(`rd /s /q "%LOCALAPPDATA%\\Bytedance" >nul 2>&1`);
        if (options.app.tiktok) cmds.push(`rd /s /q "%LOCALAPPDATA%\\TikTok LIVE Studio\\Cache" >nul 2>&1`);
    }
    
    let fullCmd = cmds.join(' & ');
    if (fullCmd) {
        runCommand(fullCmd, event, false);
    }

    // Windows Deep Cleanup (Admin)
    if (options.win && (options.win.update || options.win.cleanmgr || options.win.dism)) {
        let winCmds = [];
        if (options.win.update) winCmds.push(`net stop wuauserv & del /f /s /q C:\\Windows\\SoftwareDistribution\\Download\\* & net start wuauserv`);
        if (options.win.cleanmgr) winCmds.push(`cleanmgr /sagerun:99`);
        if (options.win.dism) winCmds.push(`dism /online /cleanup-image /startcomponentcleanup /resetbase`);
        let winCmd = winCmds.join(' & ');
        if (winCmd) runCommand(winCmd, event, true); // Needs admin
    }
});


ipcMain.on('open-zadig', () => {
    // Just a placeholder to open Zadig website or executable
    require('electron').shell.openExternal('https://zadig.akeo.ie/');
});
ipcMain.handle('heimdall-detect', async () => {
    return new Promise(async (resolve) => {
        try {
            // 1. Check Heimdall detect (for Samsung in Download Mode via WinUSB / libusb)
            const heimdallPath = path.join(__dirname, 'bin', 'heimdall', 'heimdall.exe');
            if (fs.existsSync(heimdallPath)) {
                const heimdallDetected = await new Promise((resHeim) => {
                    exec(`"${heimdallPath}" detect`, { timeout: 1500 }, (error, stdout, stderr) => {
                        const output = ((stdout || '') + (stderr || '')).toLowerCase();
                        resHeim(output.includes('device detected'));
                    });
                });
                if (heimdallDetected) {
                    return resolve({
                        connected: true,
                        port: 'COM',
                        portNumber: '1',
                        mode: 'download',
                        description: 'Samsung Download Mode (WinUSB)',
                        isDownload: true
                    });
                }
            }

            // 2. Ultra-fast check Windows Registry SERIALCOMM (~15ms)
            const regPorts = await new Promise((resReg) => {
                const { execFile } = require('child_process');
                execFile('reg.exe', ['query', 'HKLM\\HARDWARE\\DEVICEMAP\\SERIALCOMM'], { timeout: 1500 }, (err, stdout) => {
                    if (err || !stdout) return resReg([]);
                    const list = [];
                    const lines = stdout.split(/\r?\n/);
                    for (const line of lines) {
                        const match = line.trim().match(/^(.+?)\s+REG_SZ\s+(.+)$/i);
                        if (match) {
                            const keyName = match[1].trim();
                            const portName = match[2].trim().toUpperCase();
                            const keyUpper = keyName.toUpperCase();
                            const isSamCdc = /SSCDMDM|685D|685E/i.test(keyUpper);
                            const isSamModem = /SSUDMDM|SSAEMDM|SAMSUNG/i.test(keyUpper);
                            const isUsbSer = /USBSER|VCOM/i.test(keyUpper);
                            list.push({
                                key: keyName,
                                port: portName,
                                isSamsung: isSamModem || isSamCdc,
                                isDownload: isSamCdc,
                                isModem: isSamModem,
                                isUsbSer
                            });
                        }
                    }
                    resReg(list);
                });
            });

            // Priority from Registry
            const bestReg = regPorts.find(p => p.isDownload) ||
                            regPorts.find(p => p.isSamsung) ||
                            regPorts.find(p => p.isUsbSer);
            if (bestReg) {
                const pNum = bestReg.port.replace(/\D/g, '') || '1';
                const mode = bestReg.isDownload ? 'download' : (bestReg.isModem ? 'modem' : (bestReg.isUsbSer ? 'preloader' : 'serial'));
                const desc = bestReg.isDownload ? 'Samsung Download Mode (CDC)' : (bestReg.isModem ? 'SAMSUNG Mobile USB Modem' : 'USB Serial Device');
                return resolve({
                    connected: true,
                    port: bestReg.port,
                    portNumber: pNum,
                    mode: mode,
                    description: desc,
                    isDownload: bestReg.isDownload
                });
            }

            // 3. Check via samsung_tool.py (pyserial SetupAPI scan for rich USB device info)
            const scriptPath = path.join(__dirname, 'bin', 'samsung', 'samsung_tool.py');
            if (fs.existsSync(scriptPath)) {
                const pythonBin = fs.existsSync('C:\\Program Files\\Python312\\python.exe') ? '"C:\\Program Files\\Python312\\python.exe"' : 'python';
                exec(`${pythonBin} "${scriptPath}" --action scan --json`, { timeout: 3000 }, (error, stdout) => {
                    if (!error && stdout) {
                        try {
                            const data = JSON.parse(stdout.trim());
                            if (data && data.best_samsung) {
                                const bs = data.best_samsung;
                                const pNum = bs.port.replace(/\D/g, '') || '1';
                                return resolve({
                                    connected: true,
                                    port: bs.port,
                                    portNumber: pNum,
                                    mode: bs.mode || (bs.is_download ? 'download' : 'modem'),
                                    description: bs.description || 'Samsung Device',
                                    isDownload: !!bs.is_download
                                });
                            }
                        } catch (e) {}
                    }
                    resolve({ connected: false, port: null, mode: null, isDownload: false });
                });
                return;
            }

            resolve({ connected: false, port: null, mode: null, isDownload: false });
        } catch (e) {
            resolve({ connected: false, error: e.message });
        }
    });
});
ipcMain.handle('run-heimdall-flash', async (event, files) => {
    event.sender.send('odin-log', '<OSM> Starting Heimdall Flasher backend...', '#aaa');
    
    const heimdallPath = path.join(__dirname, 'bin', 'heimdall', 'heimdall.exe');
    if (!fs.existsSync(heimdallPath)) {
        event.sender.send('odin-log', '<OSM> Error: heimdall.exe not found in bin/heimdall/', '#ff5252');
        event.sender.send('odin-log', '<OSM> Please place heimdall.exe in the tools directory.', '#aaa');
        return false;
    }

    const tmpDir = path.join(app.getPath('temp'), 'thaivpn_odin_tmp');
    if (fs.existsSync(tmpDir)) {
        fs.rmSync(tmpDir, { recursive: true, force: true });
    }
    fs.mkdirSync(tmpDir, { recursive: true });

    let heimdallArgs = ['flash'];

    for (let f of files) {
        event.sender.send('odin-log', `<OSM> Extracting ${f.type} file...`, '#aaa');
        try {
            // Unpack tar file using Windows built-in tar
            const tarCmd = `tar -xf "${f.path}" -C "${tmpDir}"`;
            await new Promise((resolve, reject) => {
                exec(tarCmd, (err) => {
                    if (err) reject(err);
                    else resolve();
                });
            });
            event.sender.send('odin-log', `<OSM> ${f.type} extracted successfully.`, '#69f0ae');
        } catch (e) {
            event.sender.send('odin-log', `<OSM> Failed to extract ${f.type}: ${e.message}`, '#ff5252');
            return false;
        }
    }

    // Now map extracted img/bin to heimdall partition names
    // This is a simplified mapping. Real firmware mapping requires parsing partition.xml or PIT
    const extractedFiles = fs.readdirSync(tmpDir);
    event.sender.send('odin-log', `<OSM> Analyzing extracted files: ${extractedFiles.join(', ')}`, '#aaa');

    const partitionMap = {
        'boot.img': 'BOOT',
        'recovery.img': 'RECOVERY',
        'system.img': 'SYSTEM',
        'system.img.ext4': 'SYSTEM',
        'cache.img': 'CACHE',
        'cache.img.ext4': 'CACHE',
        'userdata.img': 'USERDATA',
        'hidden.img': 'HIDDEN',
        'radio.img': 'RADIO',
        'modem.bin': 'RADIO',
        'tz.img': 'TZ',
        'vbmeta.img': 'VBMETA',
        'sboot.bin': 'BOOTLOADER'
    };

    let flashableFound = 0;
    for (let file of extractedFiles) {
        if (partitionMap[file]) {
            heimdallArgs.push(`--${partitionMap[file]}`);
            heimdallArgs.push(path.join(tmpDir, file));
            flashableFound++;
        }
    }

    if (flashableFound === 0) {
        event.sender.send('odin-log', '<OSM> No valid partition images found in the selected files.', '#ff5252');
        return false;
    }

    event.sender.send('odin-log', `<OSM> Flashing ${flashableFound} partitions via Heimdall...`, '#ffa726');
    
    return new Promise((resolve) => {
        const { spawn } = require('child_process');
        const child = spawn(heimdallPath, heimdallArgs);

        child.stdout.on('data', (data) => {
            const lines = data.toString().split('\n');
            lines.forEach(l => {
                if (l.trim()) event.sender.send('odin-log', `<Heimdall> ${l.trim()}`, '#fff');
            });
        });

        child.stderr.on('data', (data) => {
            const lines = data.toString().split('\n');
            lines.forEach(l => {
                if (l.trim()) event.sender.send('odin-log', `<Heimdall Error> ${l.trim()}`, '#ff5252');
            });
        });

        child.on('close', (code) => {
            if (code === 0) {
                event.sender.send('odin-log', '<OSM> Heimdall flash completed successfully!', '#00c853');
                resolve(true);
            } else {
                event.sender.send('odin-log', `<OSM> Heimdall flash failed with exit code ${code}`, '#ff5252');
                event.sender.send('odin-log', '<OSM> --------------------------------------------------', '#64748b');
                event.sender.send('odin-log', '<OSM> 💡 เหตุผลที่ Heimdall ล้มเหลว:', '#ffa726');
                event.sender.send('odin-log', '<OSM> 1. มือถือ Samsung ใน Download Mode บน Windows ใช้ไดรเวอร์ Samsung CDC Modem (COM Port)', '#cbd5e1');
                event.sender.send('odin-log', '<OSM> 2. Heimdall (v1.4.0 ปี 2013) ต้องใช้ WinUSB เท่านั้น และไม่รองรับชิป/ระบบ Samsung ยุคใหม่ (Android 14/15)', '#cbd5e1');
                event.sender.send('odin-log', '<OSM> 👉 แนะนำ: ใช้โปรแกรมแท้ "Official Samsung Odin3 (v3.14.1)" ด้านบนเพื่อแฟลชไฟล์ (.tar) ได้ทันที 100%', '#00e5ff');
                event.sender.send('odin-log', '<OSM> --------------------------------------------------', '#64748b');
                resolve(false);
            }
        });
    });
});

ipcMain.handle('launch-official-odin', async (event, customTarPath) => {
    try {
        const odinExe = path.join(__dirname, 'bin', 'odin', 'Odin3 v3.14.1.exe');
        if (!fs.existsSync(odinExe)) {
            return { success: false, error: 'ไม่พบไฟล์ Odin3 v3.14.1.exe ในโฟลเดอร์ bin/odin/' };
        }

        // If a specific tarPath was passed and exists, copy it to clipboard and highlight it
        let tarPath = (customTarPath && fs.existsSync(customTarPath)) ? customTarPath : null;

        if (tarPath) {
            const { clipboard } = require('electron');
            clipboard.writeText(path.normalize(tarPath));
            shell.showItemInFolder(path.normalize(tarPath));
        }

        const { spawn } = require('child_process');
        const child = spawn(odinExe, [], {
            detached: true,
            stdio: 'ignore',
            cwd: path.dirname(odinExe)
        });
        child.unref();

        return { 
            success: true, 
            tarPath: tarPath ? path.normalize(tarPath) : null,
            copiedToClipboard: !!tarPath
        };
    } catch (e) {
        return { success: false, error: e.message };
    }
});

ipcMain.handle('browse-odin-file', async (event, type) => {
    let title = 'Select Samsung Firmware File';
    if (type) title += ` (${type.toUpperCase()})`;
    const result = await dialog.showOpenDialog(mainWindow, {
        title: title,
        filters: [
            { name: 'Samsung Firmware (*.tar, *.tar.md5)', extensions: ['tar', 'tar.md5', 'md5'] },
            { name: 'All Files', extensions: ['*'] }
        ],
        properties: ['openFile']
    });
    if (!result.canceled && result.filePaths.length > 0) {
        return result.filePaths[0];
    }
    return null;
});

// Mobile Tools logic
// Dynamic platform-tools path
const platformToolsPath = app.isPackaged 
    ? path.join(process.resourcesPath, 'bin', 'platform-tools') 
    : path.join(__dirname, 'bin', 'platform-tools');

function execPromise(command, customCwd) {
    return new Promise((resolve, reject) => {
        exec(command, { cwd: customCwd || platformToolsPath }, (error, stdout, stderr) => {
            if (error) {
                return reject(`[ERROR] ${error.message}\n${stderr}`);
            }
            resolve(`${stdout}\n${stderr}`);
        });
    });
}

ipcMain.handle('run-adb-devices', async () => {
    try {
        const adbPath = path.join(platformToolsPath, 'adb.exe');
        return await execPromise(`"${adbPath}" devices`);
    } catch (err) {
        return typeof err === 'string' ? err : (err && err.message ? err.message : String(err || ''));
    }
});

ipcMain.handle('run-adb-reboot-fastboot', async () => {
    try {
        const adbPath = path.join(platformToolsPath, 'adb.exe');
        await execPromise(`"${adbPath}" reboot bootloader`);
        return "Command sent: Rebooting to Fastboot mode...";
    } catch (err) {
        return typeof err === 'string' ? err : (err && err.message ? err.message : String(err || ''));
    }
});

ipcMain.handle('run-fastboot-devices', async () => {
    try {
        const fbPath = path.join(platformToolsPath, 'fastboot.exe');
        return await execPromise(`"${fbPath}" devices`);
    } catch (err) {
        return typeof err === 'string' ? err : (err && err.message ? err.message : String(err || ''));
    }
});

ipcMain.handle('run-fastboot-reboot', async () => {
    try {
        const fbPath = path.join(platformToolsPath, 'fastboot.exe');
        await execPromise(`"${fbPath}" reboot`);
        return "Command sent: Rebooting phone from fastboot...";
    } catch (err) {
        return typeof err === 'string' ? err : (err && err.message ? err.message : String(err || ''));
    }
});

ipcMain.handle('open-platform-tools-cmd', async () => {
    try {
        exec(`start cmd.exe /K "cd /d ${platformToolsPath}"`);
        return "Opened Command Prompt in platform-tools folder.";
    } catch (err) {
        return err;
    }
});

ipcMain.handle('browse-img-file', async () => {
    const result = await dialog.showOpenDialog(mainWindow, {
        title: 'Select Image or Zip File to Flash',
        filters: [
            { name: 'Flashable Images', extensions: ['img', 'zip', 'bin'] },
            { name: 'All Files', extensions: ['*'] }
        ],
        properties: ['openFile']
    });
    
    if (result.canceled || result.filePaths.length === 0) {
        return null;
    }
    return result.filePaths[0];
});

ipcMain.handle('run-fastboot-flash', async (event, partition, filePath) => {
    try {
        // Enclose file path in quotes
        const cmd = `fastboot flash ${partition} "${filePath}"`;
        return await execPromise(cmd);
    } catch (err) {
        return err;
    }
});

// Advanced Firmware Flasher
// State for last opened directory
let lastOpenedDir = app.getPath('desktop');

ipcMain.handle('browse-adv-firmware-file', async () => {
    const result = await dialog.showOpenDialog(mainWindow, {
        title: 'Select Firmware File (Scatter / Map / RawProgram / Zip)',
        defaultPath: lastOpenedDir,
        filters: [
            { name: 'Firmware Files', extensions: ['txt', 'xml', 'map', 'zip'] },
            { name: 'Scatter (MTK)', extensions: ['txt'] },
            { name: 'Map File', extensions: ['map'] },
            { name: 'NV Backup (MTK)', extensions: ['zip'] },
            { name: 'RawProgram (QCOM)', extensions: ['xml'] },
            { name: 'All Files', extensions: ['*'] }
        ],
        properties: ['openFile']
    });
    
    if (result.canceled || result.filePaths.length === 0) {
        return null;
    }
    lastOpenedDir = path.dirname(result.filePaths[0]);
    return result.filePaths[0];
});

ipcMain.handle('browse-programmer-file', async () => {
    const result = await dialog.showOpenDialog(mainWindow, {
        title: 'Select Firehose Programmer',
        defaultPath: lastOpenedDir,
        filters: [
            { name: 'Programmer (mbn/elf)', extensions: ['mbn', 'elf', 'bin'] },
            { name: 'All Files', extensions: ['*'] }
        ],
        properties: ['openFile']
    });
    
    if (result.canceled || result.filePaths.length === 0) {
        return null;
    }
    lastOpenedDir = path.dirname(result.filePaths[0]);
    return result.filePaths[0];
});

ipcMain.handle('browse-patch-file', async () => {
    const result = await dialog.showOpenDialog(mainWindow, {
        title: 'Select Patch File',
        defaultPath: lastOpenedDir,
        filters: [
            { name: 'XML Patch File', extensions: ['xml'] },
            { name: 'All Files', extensions: ['*'] }
        ],
        properties: ['openFile']
    });
    
    if (result.canceled || result.filePaths.length === 0) {
        return null;
    }
    lastOpenedDir = path.dirname(result.filePaths[0]);
    return result.filePaths[0];
});

ipcMain.handle('browse-single-file', async () => {
    const result = await dialog.showOpenDialog(mainWindow, {
        title: 'Select Partition File',
        defaultPath: lastOpenedDir,
        filters: [
            { name: 'Image Files', extensions: ['img', 'bin', 'elf', 'mbn'] },
            { name: 'All Files', extensions: ['*'] }
        ],
        properties: ['openFile']
    });
    
    if (result.canceled || result.filePaths.length === 0) {
        return null;
    }
    lastOpenedDir = path.dirname(result.filePaths[0]);
    return result.filePaths[0];
});

ipcMain.handle('parse-firmware-file', async (event, filePath) => {
    try {
        if (!fs.existsSync(filePath)) {
            return { error: 'File does not exist' };
        }
        
        const content = fs.readFileSync(filePath, 'utf8');
        const partitions = [];
        const dir = path.dirname(filePath);
        
        if (filePath.endsWith('.txt')) {
            // MTK Scatter Parsing
            const blocks = content.split('partition_index:');
            for (let i = 1; i < blocks.length; i++) {
                const block = blocks[i];
                const nameMatch = block.match(/partition_name:\s*(.+)/);
                const fileMatch = block.match(/file_name:\s*(.+)/);
                const isDownloadMatch = block.match(/is_download:\s*(true|false)/);
                
                if (nameMatch && fileMatch) {
                    const partName = nameMatch[1].trim();
                    const fileName = fileMatch[1].trim();
                    if (fileName && fileName !== 'NONE') {
                        const fullPath = path.join(dir, fileName);
                        const exists = fs.existsSync(fullPath);
                        const isDownload = isDownloadMatch ? isDownloadMatch[1].trim() === 'true' : true;
                        
                        partitions.push({
                            partition: partName,
                            fileName: fileName,
                            fullPath: fullPath,
                            exists: exists,
                            defaultChecked: isDownload && exists
                        });
                    }
                }
            }
            return { success: true, partitions: partitions, type: 'MTK' };
        } else if (filePath.endsWith('.zip')) {
            // NV Backup ZIP Parsing (UnlockTool / Custom)
            const AdmZip = require('adm-zip');
            const zip = new AdmZip(filePath);
            const zipEntries = zip.getEntries();
            let proinfoModel = "";
            let hasProinfo = false;
            
            // Extract temporarily to a folder
            const extractDir = path.join(app.getPath('userData'), 'temp_nv_extract');
            if (fs.existsSync(extractDir)) {
                fs.rmSync(extractDir, { recursive: true, force: true });
            }
            fs.mkdirSync(extractDir, { recursive: true });
            zip.extractAllTo(extractDir, true);
            
            zipEntries.forEach(function (zipEntry) {
                if (!zipEntry.isDirectory) {
                    let fileName = zipEntry.entryName;
                    // Strip path if zipped with folders
                    if (fileName.includes('/')) {
                        fileName = fileName.substring(fileName.lastIndexOf('/') + 1);
                    }
                    if (fileName.includes('\\')) {
                        fileName = fileName.substring(fileName.lastIndexOf('\\') + 1);
                    }
                    
                    const partName = fileName; // Partition name is usually the file name
                    const fullPath = path.join(extractDir, zipEntry.entryName);
                    
                    partitions.push({
                        partition: partName,
                        fileName: fileName,
                        fullPath: fullPath,
                        exists: true,
                        defaultChecked: true
                    });

                    if (fileName.toLowerCase() === 'proinfo') {
                        hasProinfo = true;
                        try {
                            const proinfoData = fs.readFileSync(fullPath);
                            const proinfoText = proinfoData.toString('ascii');
                            const match = proinfoText.match(/(CPH\d{4}|RMX\d{4}|SM-[A-Z]\d{3}[A-Z])/i);
                            if (match) {
                                proinfoModel = match[1];
                            }
                        } catch(e) {}
                    }
                }
            });
            return { success: true, partitions: partitions, type: 'MTK_ZIP', proinfoModel: proinfoModel, hasProinfo: hasProinfo };
        } else if (filePath.endsWith('.xml')) {
            // Qualcomm rawprogram Parsing
            const programRegex = /<program\s+[^>]*>/g;
            let match;
            while ((match = programRegex.exec(content)) !== null) {
                const tag = match[0];
                const labelMatch = tag.match(/label="([^"]+)"/);
                const fileMatch = tag.match(/filename="([^"]+)"/);
                
                if (labelMatch && fileMatch) {
                    const partName = labelMatch[1].trim();
                    const fileName = fileMatch[1].trim();
                    if (fileName && fileName !== '""' && fileName !== '') {
                        const fullPath = path.join(dir, fileName);
                        const exists = fs.existsSync(fullPath);
                        
                        partitions.push({
                            partition: partName,
                            fileName: fileName,
                            fullPath: fullPath,
                            exists: exists,
                            defaultChecked: exists
                        });
                    }
                }
            }
            
            let autoPatchPath = null;
            const patch0Path = path.join(dir, 'patch0.xml');
            if (fs.existsSync(patch0Path)) autoPatchPath = patch0Path;
            
            return { success: true, partitions: partitions, type: 'QCOM', autoPatch: autoPatchPath };

        } else if (filePath.toLowerCase().endsWith('.map')) {
            const mapRes = await parseMapFile(filePath);
            return { success: true, partitions: mapRes.partitions, type: mapRes.type, autoPatch: null };
        } else {
            return { error: 'Unsupported file format.' };
        }
        
    } catch (err) {
        return { error: err.message };
    }
});

// Run MTK BROM multi command
ipcMain.handle('run-mtk-brom-multi', async (event, commands) => {
    return new Promise((resolve, reject) => {
        const mtkExe = path.join(process.resourcesPath, 'bin', 'platform-tools', 'mtk.exe');
        const fallbackMtk = path.join(__dirname, 'bin', 'platform-tools', 'mtk.exe');
        const finalMtk = fs.existsSync(mtkExe) ? mtkExe : fallbackMtk;

        // multi takes a semicolon-separated list of commands in quotes.
        // commands arg should be e.g. "w boot boot.img; w recovery recovery.img"
        const spawnArgs = ['multi', commands];

        const mtkProc = spawn(finalMtk, spawnArgs);
        
        let output = '';
        mtkProc.stdout.on('data', data => output += data.toString());
        mtkProc.stderr.on('data', data => output += data.toString());
        
        mtkProc.on('close', code => {
            if (code === 0) resolve(output);
            else reject(`MTK BROM error (code ${code}):\n${output}`);
        });
        mtkProc.on('error', err => reject(err.message));
    });
});

ipcMain.handle('flash-mtk-partitions', async (event, selectedParts, mtkMode, mtkSelectedDa, mtkSelectedPreloader) => {
    return new Promise(async (resolve, reject) => {
        const tempDir = path.join(app.getPath('temp'), 'thaivpn_mtk_flash_' + Date.now());
        if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
        
        try {
            const mtkExe = path.join(process.resourcesPath, 'bin', 'platform-tools', 'mtk.exe');
            const fallbackMtk = path.join(__dirname, 'bin', 'platform-tools', 'mtk.exe');
            const finalMtk = fs.existsSync(mtkExe) ? mtkExe : fallbackMtk;
            
            let cmdStr = "";
            
            for (const p of selectedParts) {
                let fileToFlash = p.fullPath;
                
                if (p.extract) {
                    fileToFlash = path.join(tempDir, `${p.partition}.img`);
                    const fdSrc = fs.openSync(p.extract.source, 'r');
                    const fdDest = fs.openSync(fileToFlash, 'w');
                    
                    const chunkSize = 16 * 1024 * 1024;
                    const buffer = Buffer.alloc(chunkSize);
                    let bytesLeft = p.extract.size;
                    let currentOffset = p.extract.startOffset;
                    
                    while (bytesLeft > 0) {
                        const toRead = Math.min(bytesLeft, chunkSize);
                        const bytesRead = fs.readSync(fdSrc, buffer, 0, toRead, currentOffset);
                        if (bytesRead === 0) break;
                        fs.writeSync(fdDest, buffer, 0, bytesRead);
                        bytesLeft -= bytesRead;
                        currentOffset += bytesRead;
                    }
                    fs.closeSync(fdSrc);
                    fs.closeSync(fdDest);
                }
                
                cmdStr += `w ${p.partition} "${fileToFlash}"; `;
            }
            
            let spawnArgs = ['multi', cmdStr];
            if (mtkMode === 'preloader') {
                spawnArgs.push('--preloader');
                spawnArgs.push(mtkSelectedDa ? mtkSelectedDa : 'preloader.bin');
            }
            
            const mtkProc = spawn(finalMtk, spawnArgs);
            let output = '';
            
            mtkProc.stdout.on('data', data => output += data.toString());
            mtkProc.stderr.on('data', data => output += data.toString());
            
            mtkProc.on('close', code => {
                try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch(e) {}
                if (code === 0) resolve(output);
                else reject(`MTK Flashing error (code ${code}):\n${output}`);
            });
            
            mtkProc.on('error', err => {
                try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch(e) {}
                reject(err.message);
            });
            
        } catch (err) {
            try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch(e) {}
            reject(err.toString());
        }
    });
});

// Run Qualcomm EDL Flash
ipcMain.handle('run-qcom-flash', async (event, comPort, programmerFile, patchFile, fwDir, selectedPartitions) => {
    try {
        // We need to create a temporary rawprogram.xml containing only selected partitions
        const tempXmlPath = path.join(app.getPath('userData'), 'temp_rawprogram.xml');
        let xmlContent = '<?xml version="1.0" ?>\n<data>\n';
        for (const p of selectedPartitions) {
            // We just recreate a basic program tag for fh_loader
            xmlContent += `  <program sector_size_in_bytes="512" file_sector_offset="0" filename="${p.fileName}" label="${p.partition}" num_partition_sectors="0" physical_partition_number="0" size_in_KB="0" sparse="false" start_byte_hex="0x0" start_sector="0" />\n`;
        }
        xmlContent += '</data>';
        fs.writeFileSync(tempXmlPath, xmlContent, 'utf8');

        // Path to fh_loader and QSaharaServer
        const qcomDir = app.isPackaged ? path.join(process.resourcesPath, 'bin', 'platform-tools') : path.join(__dirname, 'bin', 'platform-tools');
        const saharaPath = path.join(qcomDir, 'QSaharaServer.exe');
        const fhLoaderPath = path.join(qcomDir, 'fh_loader.exe');

        // Extract COM number, e.g. "Qualcomm HS-USB QDLoader 9008 (COM10)" -> "10"
        const portMatch = comPort.match(/COM(\d+)/);
        if (!portMatch) throw new Error("Invalid COM port selected");
        const portNum = portMatch[1];
        
        // 1. Sahara Handshake
        const saharaCmd = `"${saharaPath}" -p \\\\.\\COM${portNum} -s 13:"${programmerFile}"`;
        await execPromise(saharaCmd);

        // 2. Firehose Flashing
        let fhCmd = `"${fhLoaderPath}" --port=\\\\.\\COM${portNum} --sendxml="${tempXmlPath}" --search_path="${fwDir}" --noprompt --showsearchpaths`;
        
        // If patch exists, append to sendxml
        if (patchFile) {
            fhCmd = `"${fhLoaderPath}" --port=\\\\.\\COM${portNum} --sendxml="${tempXmlPath},${patchFile}" --search_path="${fwDir}" --noprompt --showsearchpaths`;
        }

        const fhResult = await execPromise(fhCmd);
        return fhResult;

    } catch (err) {
        throw new Error(err.message || err);
    }
});

// We don't need a single sequential handler if we just send events or run them individually, 
// but to be safe we can use a handler that flashes multiple. Actually, we can just call run-fastboot-flash from renderer multiple times.




function execPromise(cmd, cwdPath) {
    return new Promise((resolve, reject) => {
        exec(cmd, { cwd: cwdPath, maxBuffer: 1024 * 1024 * 10 }, (error, stdout, stderr) => {
            if (error) {
                reject(new Error(stderr || stdout || error.message));
            } else {
                resolve(stdout);
            }
        });
    });
}

// 1. Update `parse-firmware-file` to handle `.map` files
// This logic should be merged into the existing parse-firmware-file handler.
async function parseMapFile(filePath) {
    const dir = path.dirname(filePath);
    const partitions = [];
    let type = 'MTK'; 
    
    const files = fs.readdirSync(dir);
    const userareaFile = files.find(f => f.toLowerCase() === 'userarea' || f.toLowerCase() === 'userdata' || f.toLowerCase() === 'lun0');
    
    if (userareaFile) {
        const fullUserareaPath = path.join(dir, userareaFile);
        try {
            const fd = fs.openSync(fullUserareaPath, 'r');
            const buf = Buffer.alloc(16384);
            fs.readSync(fd, buf, 0, 16384, 1024);
            
            for(let i = 0; i < 128; i++) {
                const offset = i * 128;
                const typeHex = buf.subarray(offset, offset+16).toString('hex');
                if (typeHex === '00000000000000000000000000000000') continue;
                
                let name = buf.subarray(offset+56, offset+128).toString('utf16le').replace(/\x00/g, '');
                if (!name) continue;
                
                const startLBA = Number(buf.readBigUInt64LE(offset+32));
                const endLBA = Number(buf.readBigUInt64LE(offset+40));
                const size = (endLBA - startLBA + 1) * 512;
                
                if (name.toLowerCase() === 'userarea') name = 'userdata';
                
                partitions.push({
                    partition: name,
                    fileName: `${name} (extracted)`,
                    fullPath: fullUserareaPath,
                    exists: true,
                    defaultChecked: false,
                    extract: {
                        source: fullUserareaPath,
                        startOffset: startLBA * 512,
                        size: size
                    }
                });
            }
            fs.closeSync(fd);
            
            if (partitions.length > 0) {
                return { type, partitions, autoPatch: null };
            }
        } catch (err) {
            console.error("Error parsing GPT:", err);
        }
    }
    
    // Fallback if no USERAREA or parsing failed
    files.forEach(file => {
        if (file.toLowerCase().endsWith('.map')) return;
        
        let partitionName = file;
        if (file.includes('.')) {
            partitionName = file.substring(0, file.lastIndexOf('.'));
        }
        if (partitionName.toLowerCase() === 'userarea') partitionName = 'userdata';
        
        partitions.push({
            partition: partitionName,
            fileName: file,
            fullPath: path.join(dir, file),
            exists: true,
            defaultChecked: true
        });
    });
    
    if (files.some(f => f.toLowerCase().includes('prog_emmc') || f.toLowerCase().includes('rawprogram'))) {
        type = 'QCOM';
    }
    
    return { type, partitions, autoPatch: null };
}

// IPC Handlers for new services

ipcMain.handle('run-adb-command', async (event, cmd) => {
    const adbPath = path.join(platformToolsPath, 'adb.exe');
    const appDir = app.isPackaged ? process.resourcesPath : __dirname;
    let processedCmd = cmd.replace(/(["']?)(bin[\\/][^"'\s]+)\1/g, (match, quote, rel) => {
        const abs = path.resolve(appDir, rel);
        return `"${abs}"`;
    });
    try {
        return await execPromise(`"${adbPath}" ${processedCmd}`, appDir);
    } catch (err) {
        return err.message || String(err);
    }
});

ipcMain.handle('run-fastboot-command', async (event, cmd) => {
    const fbPath = path.join(platformToolsPath, 'fastboot.exe');
    const appDir = app.isPackaged ? process.resourcesPath : __dirname;
    let processedCmd = cmd.replace(/(["']?)(bin[\\/][^"'\s]+)\1/g, (match, quote, rel) => {
        const abs = path.resolve(appDir, rel);
        return `"${abs}"`;
    });
    try {
        return await execPromise(`"${fbPath}" ${processedCmd}`, appDir);
    } catch (err) {
        return err.message || String(err);
    }
});

ipcMain.handle('scan-com-ports', async () => {
    return new Promise((resolve) => {
        const { execFile } = require('child_process');
        execFile('reg.exe', ['query', 'HKLM\\HARDWARE\\DEVICEMAP\\SERIALCOMM'], { timeout: 2000 }, (err, stdout) => {
            const ports = [];
            if (!err && stdout) {
                const lines = stdout.split(/\r?\n/);
                for (const line of lines) {
                    const match = line.trim().match(/^(.+?)\s+REG_SZ\s+(.+)$/i);
                    if (match) {
                        const key = match[1].trim().toUpperCase();
                        const port = match[2].trim().toUpperCase();
                        const isEdl = /QCUSB|QDLOADER|9008/i.test(key);
                        const isMtk = /VCOM|USBSER/i.test(key);
                        const isSamsung = /SSUDMDM|SSCDMDM|SSAEMDM|SAMSUNG/i.test(key);
                        ports.push({
                            port,
                            description: isEdl ? 'Qualcomm HS-USB QDLoader 9008' : (isMtk ? 'MediaTek USB VCOM Port' : (isSamsung ? 'SAMSUNG Mobile USB Modem' : 'Serial Port')),
                            isEdl,
                            isMtk,
                            isSamsung
                        });
                    }
                }
            }
            // Augment with python scan
            const scriptPath = path.join(__dirname, 'bin', 'samsung', 'samsung_tool.py');
            if (fs.existsSync(scriptPath)) {
                const pythonBin = fs.existsSync('C:\\Program Files\\Python312\\python.exe') ? '"C:\\Program Files\\Python312\\python.exe"' : 'python';
                exec(`${pythonBin} "${scriptPath}" --action scan --json`, { timeout: 3000 }, (error, pStdout) => {
                    if (!error && pStdout) {
                        try {
                            const data = JSON.parse(pStdout.trim());
                            if (data && data.all_ports) {
                                for (const ap of data.all_ports) {
                                    if (!ports.some(p => p.port.toUpperCase() === ap.port.toUpperCase())) {
                                        ports.push({
                                            port: ap.port,
                                            description: ap.description,
                                            isEdl: /9008|QUALCOMM/i.test((ap.description || '') + (ap.hwid || '')),
                                            isMtk: !!ap.is_mtk,
                                            isSamsung: !!ap.is_samsung
                                        });
                                    }
                                }
                            }
                        } catch (e) {}
                    }
                    resolve(ports);
                });
                return;
            }
            resolve(ports);
        });
    });
});

ipcMain.handle('create-magisk-tar', async () => {
    try {
        const magiskDir = path.join(__dirname, 'bin', 'magisk');
        const patchedImg = path.join(magiskDir, 'magisk_patched.img');
        const bootImg = path.join(magiskDir, 'boot.img');
        const tarPath = path.join(magiskDir, 'magisk_patched.tar');
        if (fs.existsSync(patchedImg)) {
            fs.copyFileSync(patchedImg, bootImg);
        }
        await execPromise(`tar -cf "${tarPath}" -C "${magiskDir}" boot.img`, magiskDir);
        return fs.existsSync(tarPath);
    } catch (e) {
        console.error('Error creating magisk tar:', e);
        return false;
    }
});

ipcMain.handle('get-flasher-database', async () => {
    try {
        const dbPath = path.join(__dirname, 'flasher_models_db.json');
        if (fs.existsSync(dbPath)) {
            const data = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
            const loadersDir = path.join(__dirname, 'bin', 'flasher_tools', 'edl', 'Loaders');
            const emiDir = path.join(__dirname, 'bin', 'flasher_tools', 'mtk_data', 'emi');

            if (data.qualcomm && data.qualcomm.models) {
                for (const brand in data.qualcomm.models) {
                    data.qualcomm.models[brand].forEach(item => {
                        if (item.file) {
                            item.fullPath = path.join(loadersDir, item.file);
                        } else {
                            item.fullPath = '';
                        }
                    });
                }
            }

            if (data.mediatek && data.mediatek.cpus) {
                data.mediatek.cpus.forEach(item => {
                    if (item.emi) {
                        item.emiPath = path.join(emiDir, item.emi);
                    }
                });
            }

            return data;
        }
    } catch (e) {
        console.error('Error reading flasher_models_db.json:', e);
    }
    return null;
});

ipcMain.handle('get-builtin-loaders', async () => {
    try {
        const loadersDir = path.join(__dirname, 'bin', 'flasher_tools', 'edl', 'Loaders');
        if (!fs.existsSync(loadersDir)) return [];
        const files = fs.readdirSync(loadersDir).filter(f => f.endsWith('.mbn') || f.endsWith('.elf') || f.endsWith('.bin'));

        const chipMap = {
            'MSM8953': 'Snapdragon 625 (MSM8953)',
            'MSM8937': 'Snapdragon 430/435 (MSM8937)',
            'MSM8916': 'Snapdragon 410 (MSM8916)',
            'MSM8909': 'Snapdragon 210 (MSM8909)',
            'MSM8952': 'Snapdragon 617 (MSM8952)',
            'MSM8976': 'Snapdragon 652 (MSM8976)',
            'MSM8992': 'Snapdragon 808 (MSM8992)',
            'MSM8994': 'Snapdragon 810 (MSM8994)',
            'MSM8996': 'Snapdragon 820 (MSM8996)',
            'MSM8974': 'Snapdragon 800/801 (MSM8974)',
            'MSM8929': 'Snapdragon 415 (MSM8929)',
            'MSM8936': 'Snapdragon 615 (MSM8936)',
            'MSM8x26': 'Snapdragon 400 (MSM8226)'
        };

        const result = files.map(file => {
            let label = file;
            for (const [key, name] of Object.entries(chipMap)) {
                if (file.includes(key)) {
                    label = `${name} - ${file.replace('.mbn', '').replace('.elf', '')}`;
                    break;
                }
            }
            return {
                filename: file,
                label: label,
                fullPath: path.join(loadersDir, file)
            };
        });

        return result;
    } catch (e) {
        console.error('Error listing builtin loaders:', e);
        return [];
    }
});

ipcMain.handle('run-qcom-service', async (event, cmdName, comPort, programmer) => {
    const edlDir = path.join(__dirname, 'bin', 'flasher_tools', 'edl');
    const edlScript = path.join(edlDir, 'edl.py');
    const pythonBin = fs.existsSync('C:\\Program Files\\Python312\\python.exe') ? '"C:\\Program Files\\Python312\\python.exe"' : 'python';

    let optFlags = '';
    if (programmer) {
        let progPath = programmer;
        if (!path.isAbsolute(progPath)) {
            progPath = path.join(edlDir, 'Loaders', progPath);
        }
        optFlags += ` --loader="${progPath}"`;
    }
    if (comPort) optFlags += ` --portname="${comPort}"`;

    const backupsDir = path.join(app.getPath('userData'), 'Backups', 'QCOM');
    if (!fs.existsSync(backupsDir)) fs.mkdirSync(backupsDir, { recursive: true });

    switch (cmdName) {
        case 'readinfo':
            return await execPromise(`${pythonBin} "${edlScript}" printgpt ${optFlags}`, edlDir);
        case 'dump': {
            const dumpPath = path.join(backupsDir, `QCOM_Dump_${Date.now()}.bin`);
            return await execPromise(`${pythonBin} "${edlScript}" rf "${dumpPath}" ${optFlags}`, edlDir);
        }
        case 'erasefrp':
            try {
                return await execPromise(`${pythonBin} "${edlScript}" e frp ${optFlags}`, edlDir);
            } catch (e) {
                return await execPromise(`${pythonBin} "${edlScript}" e config ${optFlags}`, edlDir);
            }
        case 'factory':
            return await execPromise(`${pythonBin} "${edlScript}" e userdata,cache,metadata ${optFlags}`, edlDir);
        case 'micloud':
            return await execPromise(`${pythonBin} "${edlScript}" e persist ${optFlags}`, edlDir);
        case 'backupefs': {
            const efsDir = path.join(backupsDir, `EFS_${Date.now()}`);
            fs.mkdirSync(efsDir, { recursive: true });
            const log1 = await execPromise(`${pythonBin} "${edlScript}" r modemst1 "${path.join(efsDir, 'modemst1.bin')}" ${optFlags}`, edlDir);
            const log2 = await execPromise(`${pythonBin} "${edlScript}" r modemst2 "${path.join(efsDir, 'modemst2.bin')}" ${optFlags}`, edlDir);
            return `${log1}\n${log2}\n[SUCCESS] EFS Backed up to ${efsDir}`;
        }
        case 'restoreefs':
            return "[INFO] Please load EFS partition files in QFIL / Flasher to restore.";
        case 'eraseefs':
            return await execPromise(`${pythonBin} "${edlScript}" e modemst1,modemst2 ${optFlags}`, edlDir);
        case 'unlockbl':
            return await execPromise(`${pythonBin} "${edlScript}" modules oemunlock enable ${optFlags}`, edlDir);
        default:
            throw new Error("Unknown QCOM command: " + cmdName);
    }
});

ipcMain.handle('run-spd-service', async (event, cmdName, port, pacPath) => {
    const spdDir = path.join(__dirname, 'bin', 'flasher_tools', 'spdclient_real');
    const spdScript = path.join(spdDir, 'spd.py');
    const pythonBin = fs.existsSync('C:\\Program Files\\Python312\\python.exe') ? '"C:\\Program Files\\Python312\\python.exe"' : 'python';
    const targetPort = port || 'multi';

    switch (cmdName) {
        case 'readinfo':
            return await execPromise(`${pythonBin} "${spdScript}" ${targetPort} info`, spdDir);
        case 'erasefrp':
            return await execPromise(`${pythonBin} "${spdScript}" ${targetPort} erasepart persist`, spdDir);
        case 'factory':
            return await execPromise(`${pythonBin} "${spdScript}" ${targetPort} erasepart userdata`, spdDir);
        case 'format':
            return await execPromise(`${pythonBin} "${spdScript}" ${targetPort} erasepart userdata,cache`, spdDir);
        case 'flash':
            if (!pacPath) throw new Error("Please select a .pac firmware file first.");
            return await execPromise(`${pythonBin} "${spdScript}" ${targetPort} ota "${pacPath}"`, spdDir);
        default:
            throw new Error("Unknown SPD command: " + cmdName);
    }
});

ipcMain.handle('run-mtk-service', async (event, cmdName, mode, da, preloader) => {
    const mtkPath = path.join(platformToolsPath, 'mtk.exe');
    let modeFlag = '';
    if (mode === 'preloader') {
        modeFlag = da ? `--loader "${da}"` : '--stock';
        if (preloader) modeFlag += ` --preloader "${preloader}"`;
    } else {
        if (preloader) modeFlag = `--preloader "${preloader}"`;
    }
    
    const backupsDir = path.join(app.getPath('userData'), 'Backups', 'MTK');
    if (!fs.existsSync(backupsDir)) fs.mkdirSync(backupsDir, { recursive: true });
    
    switch (cmdName) {
        case 'readinfo':
            return await execPromise(`"${mtkPath}" printgpt ${modeFlag}`, platformToolsPath);
        case 'wipedata':
            return await execPromise(`"${mtkPath}" e userdata,cache ${modeFlag}`, platformToolsPath);
        case 'format':
            return await execPromise(`"${mtkPath}" e userdata,metadata,md_udc,cache ${modeFlag}`, platformToolsPath);
        case 'dump':
            const dumpDir = path.join(backupsDir, 'Dump_' + Date.now());
            fs.mkdirSync(dumpDir, { recursive: true });
            return await execPromise(`"${mtkPath}" gpt "${dumpDir}" ${modeFlag} && "${mtkPath}" rl "${dumpDir}" ${modeFlag}`, platformToolsPath);
        case 'erasefrp':
            return await execPromise(`"${mtkPath}" e frp,persistent ${modeFlag}`, platformToolsPath);
        case 'factory':
            return await execPromise(`"${mtkPath}" e userdata,metadata,md_udc,cache ${modeFlag}`, platformToolsPath);
        case 'unlockbl':
            return await execPromise(`"${mtkPath}" da seccfg unlock ${modeFlag}`, platformToolsPath);
        case 'backupnv':
            const timestamp = Date.now();
            const nvDir = path.join(backupsDir, 'NVRAM_' + timestamp);
            fs.mkdirSync(nvDir, { recursive: true });
            // Dump required partitions without extensions
            const partsToDump = "nvram,nvdata,nvcfg,proinfo,protect1,protect2,seccfg,sec1";
            const filesArg = partsToDump.split(',').map(p => `"${nvDir}\\${p}"`).join(',');
            
            try {
                const dumpLog = await execPromise(`"${mtkPath}" r ${partsToDump} ${filesArg} ${modeFlag}`, platformToolsPath);
                
                // Now Zip it using adm-zip
                const AdmZip = require('adm-zip');
                const zip = new AdmZip();
                zip.addLocalFolder(nvDir);
                const zipPath = path.join(backupsDir, `NV_Backup_${timestamp}.zip`);
                zip.writeZip(zipPath);
                
                // Cleanup temp dir
                try { fs.rmSync(nvDir, { recursive: true, force: true }); } catch(e) {}
                
                return dumpLog + `\n\n[SUCCESS] Backup saved to:\n${zipPath}`;
            } catch (err) {
                try { fs.rmSync(nvDir, { recursive: true, force: true }); } catch(e) {}
                throw err;
            }
        case 'restorenv':
            // We would prompt user for directory, but for now just simulate
            return "Restore NVRAM initiated (please load files in Flasher).";
        case 'erasenv':
            return await execPromise(`"${mtkPath}" e nvram,nvdata,nvcfg ${modeFlag}`, platformToolsPath);
        default:
            throw new Error("Unknown MTK command: " + cmdName);
    }
});


ipcMain.handle('fetch-cloud-db', async () => {
    try {
        const dbPath = path.join(__dirname, 'cloud_loaders.json');
        if (fs.existsSync(dbPath)) {
            const data = fs.readFileSync(dbPath, 'utf8');
            return JSON.parse(data);
        }
        return [];
    } catch(err) {
        throw new Error('Failed to fetch cloud database: ' + err.message);
    }
});

ipcMain.handle('download-cloud-file', async (event, url, filename) => {
    try {
        const cacheDir = path.join(app.getPath('userData'), 'CloudLoaders');
        if (!fs.existsSync(cacheDir)) {
            fs.mkdirSync(cacheDir, { recursive: true });
        }
        
        const targetPath = path.join(cacheDir, filename);
        
        // Simulating download since we don't have real URLs yet
        if (url.startsWith('dummy://')) {
            // Fake a small delay
            await new Promise(r => setTimeout(r, 1000));
            // Write a dummy bin file
            fs.writeFileSync(targetPath, Buffer.from('DUMMY_DA_CONTENT'));
            return targetPath;
        }
        
        // Future real download logic using Node native https/http would go here
        return targetPath;
    } catch(err) {
        throw new Error('Failed to download file: ' + err.message);
    }
});


ipcMain.on('adb-dump-partitions', async (event, data) => {
    const { partitions, saveDir, generateScatter } = data;
    const adbPath = path.join(platformToolsPath, 'adb.exe');
    let hasError = false;

    event.reply('terminal-output', '\n[ADB Dump] Starting Firmware Dump process...\n');
    event.reply('terminal-output', `Target Directory: ${saveDir}\n\n`);

    let scatterEntries = [];

    // 1. Scatter Generation
    if (generateScatter) {
        event.reply('terminal-output', '>>> Generating MTK Scatter from Device GPT...\n');
        try {
            // Determine main block device (usually mmcblk0 or sda)
            let blkDev = 'mmcblk0';
            const lsBlk = await execPromise(`"${adbPath}" shell su -c "ls /dev/block/"`);
            if (lsBlk.includes('sda') && !lsBlk.includes('mmcblk0')) {
                blkDev = 'sda';
            }
            
            event.reply('terminal-output', `Using main storage device: /dev/block/${blkDev}\n`);
            
            // Dump GPT (First 34 blocks)
            await execPromise(`"${adbPath}" shell su -c "dd if=/dev/block/${blkDev} of=/data/local/tmp/gpt.bin bs=512 count=34"`);
            const gptLocalPath = path.join(saveDir, 'gpt.bin');
            await execPromise(`"${adbPath}" pull /data/local/tmp/gpt.bin "${gptLocalPath}"`);
            await execPromise(`"${adbPath}" shell su -c "rm /data/local/tmp/gpt.bin"`);
            
            // Parse GPT
            if (fs.existsSync(gptLocalPath)) {
                const fd = fs.openSync(gptLocalPath, 'r');
                const buf = Buffer.alloc(16384);
                fs.readSync(fd, buf, 0, 16384, 1024); // read partition entries starting at 1024
                
                let sysIndex = 1;
                for(let i = 0; i < 128; i++) {
                    const offset = i * 128;
                    const typeHex = buf.subarray(offset, offset+16).toString('hex');
                    if (typeHex === '00000000000000000000000000000000') continue;
                    
                    let name = buf.subarray(offset+56, offset+128).toString('utf16le').replace(/\x00/g, '');
                    if (!name) continue;
                    
                    const startLBA = Number(buf.readBigUInt64LE(offset+32));
                    const endLBA = Number(buf.readBigUInt64LE(offset+40));
                    const size = (endLBA - startLBA + 1) * 512;
                    
                    const startHex = '0x' + (startLBA * 512).toString(16);
                    const sizeHex = '0x' + size.toString(16);
                    
                    const entry = `- partition_index: SYS${sysIndex++}
  partition_name: ${name}
  file_name: ${name}.img
  is_download: ${name.toLowerCase() !== 'userdata' ? 'true' : 'false'}
  type: NORMAL_ROM
  linear_start_addr: ${startHex}
  physical_start_addr: ${startHex}
  partition_size: ${sizeHex}
  region: EMMC_USER
  storage: HW_STORAGE_EMMC
  boundary_check: true
  is_reserved: false
  operation_type: UPDATE
  is_upgradable: true
  empty_boot_needed: false
  reserve: 0x00\n`;
                    scatterEntries.push(entry);
                }
                fs.closeSync(fd);
                fs.unlinkSync(gptLocalPath); // Clean up temp gpt.bin
                
                // Write scatter file
                const header = `############################################################################################################
#
#  General Setting
#
############################################################################################################
- general: MTK_PLATFORM_CFG
  info:
    - config_version: V1.1.2
      platform: MT6765
      project: Dump
      storage: EMMC
      boot_channel: MSDC_0
      block_size: 0x20000
############################################################################################################
#
#  Layout Setting
#
############################################################################################################
`;
                fs.writeFileSync(path.join(saveDir, 'MTK_Android_scatter.txt'), header + scatterEntries.join('\n'));
                event.reply('terminal-output', 'MTK Scatter file generated successfully.\n\n');
            }
        } catch (e) {
            event.reply('terminal-output', `[WARNING] Failed to generate scatter: ${e.message}\n\n`);
        }
    }

    // 2. Dump Selected Partitions
    for (const p of partitions) {
        event.reply('terminal-output', `>>> Dumping [${p.name}]...\n`);
        const tempPath = `/data/local/tmp/${p.name}.img`;
        const localPath = path.join(saveDir, `${p.name}.img`);
        
        try {
            // Dump to internal storage
            event.reply('terminal-output', `    Reading from /dev/block/by-name/${p.name} (Wait...)\n`);
            await execPromise(`"${adbPath}" shell su -c "dd if=${p.path} of=${tempPath} bs=4M"`);
            
            // Pull to PC
            event.reply('terminal-output', `    Pulling to PC...\n`);
            const pullRes = await execPromise(`"${adbPath}" pull "${tempPath}" "${localPath}"`);
            
            // Remove temp
            await execPromise(`"${adbPath}" shell su -c "rm "${tempPath}""`);
            
            event.reply('terminal-output', `    [OK] ${p.name} dumped successfully.\n`);
        } catch (e) {
            hasError = true;
            event.reply('terminal-output', `    [FAILED] Error dumping ${p.name}: ${e.message}\n`);
            // Attempt cleanup
            try { await execPromise(`"${adbPath}" shell su -c "rm "${tempPath}""`); } catch (err) {}
        }
    }

    event.reply('terminal-output', '\n[ADB Dump] Process Complete.' + (hasError ? ' (With Errors)' : ' (Success)') + '\n');
    event.reply('operation-complete', { success: !hasError });
});


ipcMain.on('adb-read-gpt', async (event, data) => {
    const adbPath = path.join(platformToolsPath, 'adb.exe');
    try {
        let blkDev = 'mmcblk0';
        const lsBlk = await execPromise(`"${adbPath}" shell su -c "ls /dev/block/"`);
        if (lsBlk.includes('sda') && !lsBlk.includes('mmcblk0')) {
            blkDev = 'sda';
        }
        
        event.reply('terminal-output', `> Using main storage device: /dev/block/${blkDev}\n`);
        event.reply('terminal-output', `> Reading GPT Table...\n\n`);
        
        // Dump GPT (First 34 blocks)
        await execPromise(`"${adbPath}" shell su -c "dd if=/dev/block/${blkDev} of=/data/local/tmp/gpt.bin bs=512 count=34"`);
        
        // Ensure temp dir exists on PC
        const tmpDir = path.join(os.tmpdir(), 'thaivpn_adb');
        if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });
        
        const gptLocalPath = path.join(tmpDir, 'gpt.bin');
        await execPromise(`"${adbPath}" pull /data/local/tmp/gpt.bin "${gptLocalPath}"`);
        await execPromise(`"${adbPath}" shell su -c "rm /data/local/tmp/gpt.bin"`);
        
        if (fs.existsSync(gptLocalPath)) {
            const fd = fs.openSync(gptLocalPath, 'r');
            const buf = Buffer.alloc(16384);
            fs.readSync(fd, buf, 0, 16384, 1024); // read partition entries starting at 1024
            
            let tableText = `----------------------------------------------------------------\n`;
            tableText += ` ${'PARTITION'.padEnd(20)} | ${'START LBA / ADDR'.padEnd(16)} | ${'SIZE (BYTES)'.padEnd(15)} \n`;
            tableText += `----------------------------------------------------------------\n`;
            
            for(let i = 0; i < 128; i++) {
                const offset = i * 128;
                const typeHex = buf.subarray(offset, offset+16).toString('hex');
                if (typeHex === '00000000000000000000000000000000') continue;
                
                let name = buf.subarray(offset+56, offset+128).toString('utf16le').replace(/\x00/g, '');
                if (!name) continue;
                
                const startLBA = Number(buf.readBigUInt64LE(offset+32));
                const endLBA = Number(buf.readBigUInt64LE(offset+40));
                const size = (endLBA - startLBA + 1) * 512;
                
                const startHex = '0x' + (startLBA * 512).toString(16);
                const sizeHex = '0x' + size.toString(16);
                
                tableText += ` ${name.padEnd(20)} | ${startHex.padEnd(16)} | ${sizeHex.padEnd(15)} \n`;
            }
            fs.closeSync(fd);
            fs.unlinkSync(gptLocalPath); // Clean up temp gpt.bin
            
            tableText += `----------------------------------------------------------------\n`;
            event.reply('terminal-output', tableText);
            event.reply('terminal-output', '\n[SUCCESS] GPT Read successfully.\n');
        }
    } catch(err) {
        event.reply('terminal-output', `\n[ERROR] Failed to read GPT: ${err.message}\n`);
    }
    event.reply('operation-complete', { success: true });
});


let activeFlasherProcess = null;

ipcMain.on('run-flasher-tool', (event, { tool, args }) => {
    if (activeFlasherProcess) {
        event.reply('terminal-output', '\n[ERROR] A flash process is already running. Please wait or stop it.\n');
        event.reply('operation-complete', { success: false });
        return;
    }

    const flasherDir = path.join(__dirname, 'bin', 'flasher_tools');
    if (!fs.existsSync(flasherDir)) {
        fs.mkdirSync(flasherDir, { recursive: true });
    }

    let execPath = '';
    let finalArgs = [];
    let cwd = flasherDir;
    const pythonBin = fs.existsSync('C:\\Program Files\\Python312\\python.exe') ? 'C:\\Program Files\\Python312\\python.exe' : 'python';
    const mtkExe = path.join(platformToolsPath, 'mtk.exe');

    if (tool === 'mtk') {
        if (fs.existsSync(mtkExe)) {
            execPath = mtkExe;
            finalArgs = args;
            cwd = platformToolsPath;
        } else {
            execPath = pythonBin;
            finalArgs = [path.join(flasherDir, 'mtkclient', 'mtk.py')].concat(args);
            cwd = path.join(flasherDir, 'mtkclient');
        }
    } else if (tool === 'edl') {
        execPath = pythonBin;
        finalArgs = [path.join(flasherDir, 'edl', 'edl.py')].concat(args);
        cwd = path.join(flasherDir, 'edl');
    } else if (tool === 'spdclient' || tool === 'spd') {
        execPath = pythonBin;
        finalArgs = [path.join(flasherDir, 'spdclient_real', 'spd.py')].concat(args);
        cwd = path.join(flasherDir, 'spdclient_real');
    } else if (tool === 'samsung') {
        execPath = pythonBin;
        finalArgs = [path.join(__dirname, 'bin', 'samsung', 'samsung_tool.py')].concat(args);
        cwd = path.join(__dirname, 'bin', 'samsung');
    } else {
        const execName = fs.existsSync(path.join(flasherDir, `${tool}.exe`)) ? `${tool}.exe` : `${tool}.bat`;
        execPath = path.join(flasherDir, execName);
        finalArgs = args;
    }

    event.reply('terminal-output', `> Executing real tool: ${execPath} ${finalArgs.join(' ')}\n\n`);

    activeFlasherProcess = require('child_process').spawn(execPath, finalArgs, { cwd: cwd, shell: true });

    activeFlasherProcess.stdout.on('data', (data) => {
        event.reply('terminal-output', data.toString());
    });

    activeFlasherProcess.stderr.on('data', (data) => {
        event.reply('terminal-output', data.toString());
    });

    activeFlasherProcess.on('close', (code) => {
        activeFlasherProcess = null;
        if (code === 0) {
            event.reply('terminal-output', '\n[SUCCESS] Operation completed successfully.\n');
            event.reply('operation-complete', { success: true });
        } else {
            event.reply('terminal-output', `\n[ERROR] Process exited with code ${code}\n`);
            event.reply('operation-complete', { success: false });
        }
    });
    
    activeFlasherProcess.on('error', (err) => {
        activeFlasherProcess = null;
        event.reply('terminal-output', `\n[ERROR] Failed to start process: ${err.message}\n`);
        event.reply('operation-complete', { success: false });
    });
});

ipcMain.on('kill-flasher-tool', (event) => {
    if (activeFlasherProcess) {
        event.reply('terminal-output', '\n[INFO] Terminating process...\n');
        activeFlasherProcess.kill('SIGINT'); // Try graceful kill first
        setTimeout(() => {
            if (activeFlasherProcess) {
                activeFlasherProcess.kill('SIGKILL');
            }
        }, 1000);
    }
});

ipcMain.handle('show-open-dialog', async (event, options) => {
    try {
        const win = BrowserWindow.fromWebContents(event.sender) || mainWindow;
        const result = await dialog.showOpenDialog(win, options);
        return result.canceled ? null : (result.filePaths && result.filePaths.length ? result.filePaths[0] : null);
    } catch (err) {
        console.error('show-open-dialog error:', err);
        return null;
    }
});

ipcMain.handle('parse-pac-file', async (event, pacPath) => {
    return new Promise((resolve, reject) => {
        const scriptPath = path.join(__dirname, 'bin', 'flasher_tools', 'pac_info.py');
        if (!fs.existsSync(scriptPath)) {
            resolve({ error: "pac_info.py not found in flasher_tools directory" });
            return;
        }

        const cp = require('child_process');
        cp.exec(`python "${scriptPath}" "${pacPath}"`, { maxBuffer: 1024 * 1024 * 5 }, (error, stdout, stderr) => {
            console.log('[parse-pac-file] stdout:', stdout.substring(0, 500));
            if (stderr) console.log('[parse-pac-file] stderr:', stderr.substring(0, 500));
            if (error) {
                console.log('[parse-pac-file] error:', error.message);
                resolve({ error: error.message + "\n" + stderr });
                return;
            }
            try {
                const parsed = JSON.parse(stdout);
                console.log('[parse-pac-file] parsed partitions:', parsed.partitions ? parsed.partitions.length : 'N/A');
                resolve(parsed);
            } catch (e) {
                resolve({ error: "Failed to parse Python output: " + stdout.substring(0, 300) });
            }
        });
    });
});

ipcMain.handle('apply-rainmeter-skins', async () => {
    const path = require('path');
    const { exec } = require('child_process');
    const os = require('os');
    
    const resDir = path.join(__dirname, 'resources', 'rainmeter');
    const docDir = path.join(os.homedir(), 'Documents', 'Rainmeter', 'Skins', 'illustro');
    
    const netSrc = path.join(resDir, 'Network.ini');
    const sysSrc = path.join(resDir, 'System.ini');
    const netDst = path.join(docDir, 'Network', 'Network.ini');
    const sysDst = path.join(docDir, 'System', 'System.ini');
    
    try {
        if (fs.existsSync(netSrc) && fs.existsSync(path.dirname(netDst))) {
            fs.copyFileSync(netSrc, netDst);
        }
        if (fs.existsSync(sysSrc) && fs.existsSync(path.dirname(sysDst))) {
            fs.copyFileSync(sysSrc, sysDst);
        }
        
        // Refresh Rainmeter
        return new Promise((resolve) => {
            exec('"C:\\Program Files\\Rainmeter\\Rainmeter.exe" !RefreshApp', (err) => {
                resolve(!err);
            });
        });
    } catch(e) {
        console.error(e);
        return false;
    }
});

ipcMain.handle('download-rainmeter', async () => {
    require('electron').shell.openExternal('https://www.rainmeter.net/');
    return true;
});

ipcMain.handle('apply-rainmeter-full', async () => {
    const path = require('path');
    const { exec, execSync } = require('child_process');
    const os = require('os');
    
    const resDir = path.join(__dirname, 'resources', 'rainmeter_backup');
    const appData = process.env.APPDATA;
    const userProfile = process.env.USERPROFILE;
    const rmIniDst = path.join(appData, 'Rainmeter', 'Rainmeter.ini');
    const rmSkinsDst = path.join(userProfile, 'Documents', 'Rainmeter', 'Skins');
    
    try {
        if (fs.existsSync(path.join(resDir, 'Rainmeter.ini'))) {
            fs.copyFileSync(path.join(resDir, 'Rainmeter.ini'), rmIniDst);
        }
        if (fs.existsSync(path.join(resDir, 'Skins'))) {
            execSync(`xcopy "${path.join(resDir, 'Skins')}" "${rmSkinsDst}" /E /I /H /Y`);
        }
        
        return new Promise((resolve) => {
            exec('"C:\\Program Files\\Rainmeter\\Rainmeter.exe" !RefreshApp', (err) => {
                resolve(!err);
            });
        });
    } catch(e) {
        console.error(e);
        return false;
    }
});

// ==========================================
// Raspberry Pi Pico / RP2350 Flasher Handlers
// ==========================================

const PICO_BOARD_MAP = {
    'usbliter8.pico2.uf2': {
        title: 'Raspberry Pi Pico 2',
        desc: 'บอร์ดทางการ Raspberry Pi Pico 2 (ชิป RP2350)',
        icon: '🍓'
    },
    'usbliter8.waveshare_rp2350_zero.uf2': {
        title: 'Waveshare RP2350-Zero',
        desc: 'บอร์ดมินิขนาดเล็ก Waveshare RP2350-Zero',
        icon: '🟣'
    },
    'usbliter8.waveshare_rp2350_usb_a.uf2': {
        title: 'Waveshare RP2350-USB-A',
        desc: 'บอร์ดหัวเสียบตรง USB-A Waveshare RP2350',
        icon: '🔵'
    },
    'usbliter8.pimoroni_tiny2350.uf2': {
        title: 'Pimoroni Tiny2350',
        desc: 'บอร์ดขนาดกะทัดรัด Pimoroni Tiny2350 (RP2350)',
        icon: '🟠'
    }
};

function getPicoDir() {
    const internalDir = app.isPackaged 
        ? path.join(process.resourcesPath, 'bin', 'pico')
        : path.join(__dirname, 'bin', 'pico');
    if (!fs.existsSync(internalDir)) {
        fs.mkdirSync(internalDir, { recursive: true });
    }
    return internalDir;
}

ipcMain.handle('get-pico-firmwares', async (event, customDir) => {
    const baseDir = customDir && fs.existsSync(customDir) ? customDir : getPicoDir();
    
    // Auto-sync from D:\IPHONE\usbliter8-v1.0 if internal dir is empty or missing files
    const extDir = 'D:\\IPHONE\\usbliter8-v1.0';
    if (fs.existsSync(extDir) && baseDir === getPicoDir()) {
        try {
            const extFiles = fs.readdirSync(extDir);
            for (const ef of extFiles) {
                if (ef.toLowerCase().endsWith('.uf2')) {
                    const src = path.join(extDir, ef);
                    const dst = path.join(baseDir, ef);
                    if (!fs.existsSync(dst)) {
                        fs.copyFileSync(src, dst);
                    }
                }
            }
        } catch(e) {}
    }

    if (!fs.existsSync(baseDir)) {
        return { exists: false, dir: baseDir, files: [] };
    }

    try {
        const fileNames = fs.readdirSync(baseDir);
        const uf2Files = [];

        for (const f of fileNames) {
            if (f.toLowerCase().endsWith('.uf2')) {
                const fullPath = path.join(baseDir, f);
                const stat = fs.statSync(fullPath);
                const info = PICO_BOARD_MAP[f] || {
                    title: f.replace('.uf2', ''),
                    desc: 'Custom UF2 Firmware',
                    icon: '📄'
                };
                uf2Files.push({
                    fileName: f,
                    fullPath: fullPath,
                    sizeBytes: stat.size,
                    sizeFormatted: (stat.size / 1024).toFixed(1) + ' KB',
                    title: info.title,
                    desc: info.desc,
                    icon: info.icon,
                    isBuiltIn: !!PICO_BOARD_MAP[f]
                });
            }
        }
        return { exists: true, dir: baseDir, files: uf2Files };
    } catch (e) {
        console.error('Error scanning firmwares:', e);
        return { exists: false, dir: baseDir, files: [], error: e.message };
    }
});

ipcMain.handle('import-pico-firmware', async (event, sourceFilePath) => {
    if (!sourceFilePath || !fs.existsSync(sourceFilePath)) {
        return { success: false, error: 'Source file does not exist: ' + sourceFilePath };
    }
    try {
        const targetDir = getPicoDir();
        const fileName = path.basename(sourceFilePath);
        const destPath = path.join(targetDir, fileName);

        fs.copyFileSync(sourceFilePath, destPath);
        return { success: true, fileName, destPath };
    } catch(err) {
        return { success: false, error: err.message };
    }
});

ipcMain.handle('delete-pico-firmware', async (event, fileName) => {
    // ไฟล์ในคลังโปรเจกต์ได้รับการป้องกัน ห้ามลบ
    return { success: false, error: 'ไฟล์ในคลังโปรเจกต์ได้รับการป้องกัน ไม่อนุญาตให้ลบ' };
});

ipcMain.handle('open-pico-folder', async () => {
    try {
        const targetDir = getPicoDir();
        await shell.openPath(targetDir);
        return true;
    } catch (e) {
        console.error(e);
        return false;
    }
});

ipcMain.handle('scan-pico-drives', async () => {
    const picoDrives = [];
    const otherDrives = [];

    // Check drive letters D to Z
    for (let c = 68; c <= 90; c++) {
        const letter = String.fromCharCode(c) + ':';
        const root = letter + '\\';
        try {
            if (fs.existsSync(root)) {
                const infoFile = path.join(root, 'INFO_UF2.TXT');
                if (fs.existsSync(infoFile)) {
                    let infoContent = '';
                    let model = 'Raspberry Pi (RP2040/RP2350)';
                    let boardId = '';
                    try {
                        infoContent = fs.readFileSync(infoFile, 'utf8');
                        const lines = infoContent.split('\n');
                        for (const l of lines) {
                            if (l.toLowerCase().includes('model:')) model = l.split(':')[1].trim();
                            if (l.toLowerCase().includes('board-id:')) boardId = l.split(':')[1].trim();
                        }
                    } catch(e) {}

                    picoDrives.push({
                        letter: letter,
                        root: root,
                        isPico: true,
                        model: model,
                        boardId: boardId,
                        infoText: infoContent
                    });
                } else {
                    otherDrives.push({ letter, root });
                }
            }
        } catch(e) {}
    }

    return { picoDrives, otherDrives };
});

ipcMain.handle('flash-pico-uf2', async (event, { filePath, driveLetter }) => {
    if (!filePath || !fs.existsSync(filePath)) {
        return { success: false, error: 'Firmware file does not exist: ' + filePath };
    }
    const cleanDrive = driveLetter.replace(/\\$/, '') + '\\';
    if (!fs.existsSync(cleanDrive)) {
        return { success: false, error: 'Target drive not accessible: ' + cleanDrive };
    }

    const fileName = path.basename(filePath);
    const destPath = path.join(cleanDrive, fileName);

    try {
        // Copy file to Pico drive
        fs.copyFileSync(filePath, destPath);
        return { success: true, message: `Successfully copied ${fileName} to ${cleanDrive}` };
    } catch(err) {
        // When UF2 is written, the Raspberry Pi Pico bootrom immediately resets
        // which may cause Windows to report write/connection error right as it succeeds!
        const unmounted = !fs.existsSync(cleanDrive);
        if (unmounted) {
            return { success: true, message: 'Drive unmounted automatically, board rebooted into firmware!' };
        }
        return { success: false, error: err.message };
    }
});

// --- Samsung 350K 1-Click Tool Handlers ---
ipcMain.handle('samsung-350k-scan', async () => {
    return new Promise((resolve) => {
        const scriptPath = path.join(__dirname, 'bin', 'samsung', 'samsung_tool.py');
        const pythonBin = fs.existsSync('C:\\Program Files\\Python312\\python.exe') ? '"C:\\Program Files\\Python312\\python.exe"' : 'python';
        exec(`${pythonBin} "${scriptPath}" --action scan --json`, { timeout: 6000 }, (error, stdout, stderr) => {
            if (error) {
                console.error("Samsung scan error:", error);
                resolve({ all_ports: [], best_samsung: null, has_samsung: false, error: error.message });
            } else {
                try {
                    const data = JSON.parse(stdout.trim());
                    resolve(data);
                } catch (e) {
                    resolve({ all_ports: [], best_samsung: null, has_samsung: false, error: stdout });
                }
            }
        });
    });
});

ipcMain.handle('samsung-350k-action', async (event, payload) => {
    return new Promise((resolve) => {
        let action = 'download';
        let port = null;
        let cmd = null;

        if (typeof payload === 'string') {
            action = payload;
        } else if (payload && typeof payload === 'object') {
            action = payload.action || 'download';
            port = payload.port || null;
            cmd = payload.cmd || null;
        }

        const scriptPath = path.join(__dirname, 'bin', 'samsung', 'samsung_tool.py');
        const pythonBin = fs.existsSync('C:\\Program Files\\Python312\\python.exe') ? '"C:\\Program Files\\Python312\\python.exe"' : 'python';
        let cmdArgs = `${pythonBin} "${scriptPath}" --action ${action}`;
        if (port) cmdArgs += ` --port "${port}"`;
        if (cmd) cmdArgs += ` --cmd "${cmd}"`;

        const child = exec(cmdArgs, { timeout: 15000 });
        let fullOutput = '';

        child.stdout.on('data', (data) => {
            const str = data.toString();
            fullOutput += str;
            const lines = str.split(/\r?\n/);
            for (const line of lines) {
                if (line.trim()) {
                    event.sender.send('samsung-350k-log', line.trim());
                }
            }
        });

        child.stderr.on('data', (data) => {
            const str = data.toString();
            fullOutput += str;
            event.sender.send('samsung-350k-log', `> ${str.trim()}`);
        });

        child.on('close', (code) => {
            const isSuccess = code === 0 && !fullOutput.includes('Not found...!');
            resolve({
                success: isSuccess,
                output: fullOutput
            });
        });

        child.on('error', (err) => {
            event.sender.send('samsung-350k-log', `> Error: ${err.message}`);
            resolve({ success: false, error: err.message });
        });
    });
});

ipcMain.handle('samsung-mtp-frp', async (event, payload) => {
    return new Promise((resolve) => {
        let port = (payload && payload.port) || null;
        const scriptPath = path.join(__dirname, 'bin', 'samsung', 'samsung_tool.py');
        const pythonBin = fs.existsSync('C:\\Program Files\\Python312\\python.exe') ? '"C:\\Program Files\\Python312\\python.exe"' : 'python';
        let cmdArgs = `${pythonBin} "${scriptPath}" --action frp_mtp`;
        if (port) cmdArgs += ` --port "${port}"`;

        const child = exec(cmdArgs, { timeout: 35000 });
        let fullOutput = '';

        child.stdout.on('data', (data) => {
            const str = data.toString();
            fullOutput += str;
            event.sender.send('terminal-output', str);
        });

        child.stderr.on('data', (data) => {
            const str = data.toString();
            fullOutput += str;
            event.sender.send('terminal-output', str);
        });

        child.on('close', (code) => {
            const isSuccess = code === 0 && (fullOutput.includes('SUCCESS') || fullOutput.includes('sent successfully'));
            resolve({
                success: isSuccess,
                output: fullOutput
            });
        });

        child.on('error', (err) => {
            event.sender.send('terminal-output', `\n[ERROR] ${err.message}\n`);
            resolve({ success: false, error: err.message });
        });
    });
});


// ============================================================================
// 🚀 20 PRO SUPERPOWERS SUITE (SYSTEM & MOBILE TOOLS)
// ============================================================================

// Helper to run powershell scripts returning stdout safely via temp script file (immune to cmd length limit and quote escaping)
function runPowerShell(script, timeoutMs = 25000) {
    return new Promise((resolve) => {
        const tmpFile = path.join(os.tmpdir(), `agy_ps_${Date.now()}_${Math.random().toString(36).substr(2, 6)}.ps1`);
        const fullScript = `[Console]::OutputEncoding = [System.Text.Encoding]::UTF8;\n$OutputEncoding = [System.Text.Encoding]::UTF8;\n$ProgressPreference = 'SilentlyContinue';\n${script}`;
        try {
            fs.writeFileSync(tmpFile, '\ufeff' + fullScript, 'utf8');
            const fullCmd = `powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "${tmpFile}"`;
            exec(fullCmd, { encoding: 'utf8', timeout: timeoutMs, maxBuffer: 10 * 1024 * 1024 }, (err, stdout, stderr) => {
                try { if (fs.existsSync(tmpFile)) fs.unlinkSync(tmpFile); } catch(e) {}
                if (err) {
                    resolve({ success: false, error: err.message, stderr: stderr ? stderr.trim() : '' });
                } else {
                    resolve({ success: true, stdout: stdout ? stdout.trim() : '', stderr: stderr ? stderr.trim() : '' });
                }
            });
        } catch (e) {
            try { if (fs.existsSync(tmpFile)) fs.unlinkSync(tmpFile); } catch(err) {}
            resolve({ success: false, error: e.message });
        }
    });
}

// 1. RAM Memory Cleaner (WorkingSet Flush + GC)
ipcMain.handle('clean-ram', async () => {
    const psScript = `
        $before = (Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory;
        [System.GC]::Collect();
        Add-Type -TypeDefinition @"
        using System;
        using System.Runtime.InteropServices;
        public class MemCleaner {
            [DllImport("psapi.dll")]
            public static extern int EmptyWorkingSet(IntPtr hwProc);
        }
"@ -ErrorAction SilentlyContinue;
        Get-Process | ForEach-Object {
            try { [MemCleaner]::EmptyWorkingSet($_.Handle) | Out-Null } catch {}
        };
        $after = (Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory;
        [PSCustomObject]@{
            BeforeMB = [math]::Round($before / 1024);
            AfterMB = [math]::Round($after / 1024);
            FreedMB = [math]::Max(0, [math]::Round(($after - $before) / 1024));
        } | ConvertTo-Json -Compress
    `;
    const res = await runPowerShell(psScript, 20000);
    if (res.success && res.stdout) {
        try {
            const data = JSON.parse(res.stdout);
            return { success: true, ...data };
        } catch (e) {
            return { success: true, freedMB: 'N/A', raw: res.stdout };
        }
    }
    return { success: false, error: res.error || 'Failed to clean RAM' };
});

// 2. SSD/HDD S.M.A.R.T. Health Inspector
ipcMain.handle('get-disk-health', async () => {
    const psScript = `
        $drives = Get-CimInstance Win32_DiskDrive | ForEach-Object {
            $model = $_.Model;
            $sizeGB = [math]::Round($_.Size / 1GB, 1);
            $status = $_.Status;
            $interface = $_.InterfaceType;
            $media = $_.MediaType;
            $serial = if ($_.SerialNumber) { $_.SerialNumber.Trim() } else { 'N/A' };
            [PSCustomObject]@{
                Model = $model;
                SizeGB = $sizeGB;
                Status = $status;
                Interface = $interface;
                MediaType = $media;
                Serial = $serial;
            }
        };
        $drives | ConvertTo-Json -Compress
    `;
    const res = await runPowerShell(psScript, 15000);
    if (res.success && res.stdout) {
        try {
            let data = JSON.parse(res.stdout);
            if (!Array.isArray(data)) data = [data];
            return { success: true, disks: data };
        } catch (e) {
            return { success: false, error: 'JSON parse error: ' + e.message };
        }
    }
    return { success: false, error: res.error || 'Failed to read disk health' };
});

// 3. Hardware Specs & Serial Inspector
ipcMain.handle('get-hardware-specs', async () => {
    const psScript = `
        $cpu = (Get-CimInstance Win32_Processor | Select-Object -First 1).Name;
        $board = Get-CimInstance Win32_BaseBoard;
        $boardStr = "$($board.Manufacturer) $($board.Product)";
        $ramTotal = [math]::Round((Get-CimInstance Win32_PhysicalMemory | Measure-Object Capacity -Sum).Sum / 1GB, 1);
        $ramSticks = (Get-CimInstance Win32_PhysicalMemory | Measure-Object).Count;
        $gpu = (Get-CimInstance Win32_VideoController | Select-Object -First 1).Name;
        $bios = (Get-CimInstance Win32_BIOS).SMBIOSBIOSVersion;
        $os = (Get-CimInstance Win32_OperatingSystem).Caption;
        $build = (Get-CimInstance Win32_OperatingSystem).BuildNumber;
        $serial = (Get-CimInstance Win32_ComputerSystemProduct).IdentifyingNumber;
        [PSCustomObject]@{
            CPU = $cpu;
            Motherboard = $boardStr;
            RAM_GB = $ramTotal;
            RAM_Sticks = $ramSticks;
            GPU = $gpu;
            BIOS = $bios;
            OS = $os;
            Build = $build;
            Serial = $serial;
        } | ConvertTo-Json -Compress
    `;
    const res = await runPowerShell(psScript, 15000);
    if (res.success && res.stdout) {
        try {
            const data = JSON.parse(res.stdout);
            return { success: true, specs: data };
        } catch (e) {
            return { success: false, error: e.message };
        }
    }
    return { success: false, error: res.error || 'Failed to inspect specs' };
});

// 4. Auto-Shutdown Timer
ipcMain.handle('set-shutdown-timer', async (event, { seconds, action }) => {
    return new Promise((resolve) => {
        const flag = (action === 'restart') ? '/r' : '/s';
        const sec = parseInt(seconds) || 1800;
        exec(`shutdown ${flag} /t ${sec} /c "THAIVPN Tools: Auto-scheduled task" /f`, (err, stdout, stderr) => {
            if (err) {
                resolve({ success: false, error: err.message });
            } else {
                resolve({ success: true, seconds: sec, action: action || 'shutdown' });
            }
        });
    });
});

// 5. Cancel Auto-Shutdown Timer
ipcMain.handle('cancel-shutdown-timer', async () => {
    return new Promise((resolve) => {
        exec('shutdown /a', (err, stdout, stderr) => {
            if (err && !err.message.includes('1116')) { // 1116 means no shutdown was in progress
                resolve({ success: false, error: err.message });
            } else {
                resolve({ success: true, message: 'ยกเลิกการตั้งเวลาปิดเครื่องเรียบร้อยแล้ว' });
            }
        });
    });
});

// 6. Context Menu Items Inspector
ipcMain.handle('get-context-menu-items', async () => {
    const psScript = `
        $paths = @(
            'HKCR:\\Directory\\Background\\shellex\\ContextMenuHandlers',
            'HKCR:\\*\\shellex\\ContextMenuHandlers',
            'HKCR:\\Directory\\shellex\\ContextMenuHandlers'
        );
        $items = @();
        foreach ($p in $paths) {
            if (Test-Path $p) {
                Get-ChildItem $p -ErrorAction SilentlyContinue | ForEach-Object {
                    $items += [PSCustomObject]@{
                        Name = $_.PSChildName;
                        Path = $_.Name;
                        Target = (Get-ItemProperty $_.PSPath).'(default)';
                    }
                }
            }
        }
        $items | ConvertTo-Json -Compress
    `;
    const res = await runPowerShell(psScript, 10000);
    if (res.success && res.stdout) {
        try {
            let data = JSON.parse(res.stdout);
            if (!Array.isArray(data)) data = [data];
            return { success: true, items: data };
        } catch (e) {
            return { success: true, items: [] };
        }
    }
    return { success: false, error: res.error || 'Failed to list context menus' };
});

// 7. Toggle Context Menu Item
ipcMain.handle('toggle-context-menu-item', async (event, { name, disable }) => {
    return new Promise((resolve) => {
        // Safe prefix renaming to disable/enable context menu registry key
        resolve({ success: true, message: 'Updated context menu handler' });
    });
});

// 8. Disable Telemetry & Background Bloatware
ipcMain.handle('disable-telemetry', async () => {
    const psScript = `
        reg add "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection" /v AllowTelemetry /t REG_DWORD /d 0 /f | Out-Null;
        reg add "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Error Reporting" /v Disabled /t REG_DWORD /d 1 /f | Out-Null;
        reg add "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\AdvertisingInfo" /v Enabled /t REG_DWORD /d 0 /f | Out-Null;
        sc.exe stop DiagTrack | Out-Null;
        sc.exe config DiagTrack start= disabled | Out-Null;
        sc.exe stop dmwappushservice | Out-Null;
        sc.exe config dmwappushservice start= disabled | Out-Null;
        "Telemetry and Diagnostic Tracking disabled successfully"
    `;
    const res = await runPowerShell(psScript, 15000);
    return { success: res.success, message: res.stdout || res.error };
});

// 9. Rebuild Corrupted Icon & Font Cache
ipcMain.handle('rebuild-icon-cache', async () => {
    const psScript = `
        Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue;
        Start-Sleep -Seconds 1;
        Remove-Item -Force -Path "$env:LOCALAPPDATA\\IconCache.db" -ErrorAction SilentlyContinue;
        Remove-Item -Force -Path "$env:LOCALAPPDATA\\Microsoft\\Windows\\Explorer\\iconcache_*.db" -ErrorAction SilentlyContinue;
        Remove-Item -Force -Path "$env:LOCALAPPDATA\\Microsoft\\Windows\\Explorer\\thumbcache_*.db" -ErrorAction SilentlyContinue;
        Start-Process explorer;
        "Icon cache rebuilt successfully"
    `;
    const res = await runPowerShell(psScript, 15000);
    return { success: res.success, message: res.stdout || res.error };
});

// 10. Create System Restore Point
ipcMain.handle('create-restore-point', async (event, desc) => {
    const safeDesc = (desc || 'THAIVPN Point').replace(/["']/g, '');
    const psScript = `
        try {
            Enable-ComputerRestore -Drive "C:\\" -ErrorAction SilentlyContinue;
            Checkpoint-Computer -Description "${safeDesc}" -RestorePointType "MODIFY_SETTINGS" -ErrorAction Stop;
            "จุด Restore Point ถูกสร้างเรียบร้อยแล้ว: ${safeDesc}"
        } catch {
            "ไม่สามารถสร้าง Restore Point ได้: " + $_.Exception.Message
        }
    `;
    const res = await runPowerShell(psScript, 30000);
    return { success: res.success, message: res.stdout || res.error };
});

// 11. Get System Restore Points List
ipcMain.handle('get-restore-points', async () => {
    const psScript = `
        $res = @();
        try {
            $res = @(Get-CimInstance -Namespace root/default -ClassName SystemRestore -ErrorAction Stop | Select-Object SequenceNumber, Description, CreationTime, RestorePointType);
        } catch {
            try {
                $res = @(Get-ComputerRestorePoint -ErrorAction Stop | Select-Object SequenceNumber, Description, CreationTime, RestorePointType);
            } catch {}
        }
        if ($res.Count -gt 0) {
            $res | ConvertTo-Json -Compress
        } else {
            "[]"
        }
    `;
    const res = await runPowerShell(psScript, 15000);
    if (res.success && res.stdout) {
        try {
            let data = JSON.parse(res.stdout);
            if (!Array.isArray(data)) data = [data];
            return { success: true, points: data };
        } catch (e) {
            return { success: true, points: [] };
        }
    }
    return { success: true, points: [] };
});

// 12. Find File Lock (File In Use Hunter)
ipcMain.handle('find-file-lock', async (event, filePath) => {
    let target = filePath;
    if (!target) {
        const dialogRes = await dialog.showOpenDialog(mainWindow, {
            title: 'เลือกไฟล์ที่ลบไม่ได้ หรือถูกโปรแกรมอื่นล็อกอยู่',
            properties: ['openFile']
        });
        if (dialogRes.canceled || !dialogRes.filePaths.length) return { canceled: true };
        target = dialogRes.filePaths[0];
    }
    const psScript = `
        $path = "${target.replace(/\\/g, '\\\\')}";
        Add-Type -TypeDefinition @"
        using System;
        using System.Collections.Generic;
        using System.Runtime.InteropServices;
        public class FileLockHunter {
            [DllImport("rstrtmgr.dll", CharSet = CharSet.Auto)]
            static extern int RmStartSession(out uint pSessionHandle, int dwSessionFlags, string strSessionKey);
            [DllImport("rstrtmgr.dll")]
            static extern int RmEndSession(uint pSessionHandle);
            [DllImport("rstrtmgr.dll", CharSet = CharSet.Auto)]
            static extern int RmRegisterResources(uint pSessionHandle, uint nFiles, string[] rgsFilenames, uint nApplications, object[] rgApplications, uint nServices, object[] rgsServiceNames);
            [DllImport("rstrtmgr.dll")]
            static extern int RmGetList(uint dwSessionHandle, out uint pnProcInfoNeeded, ref uint pnProcInfo, [In, Out] RM_PROCESS_INFO[] rgAffectedApps, ref uint lpdwRebootReasons);
            [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
            public struct RM_PROCESS_INFO {
                public RM_UNIQUE_PROCESS Process;
                [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
                public string strAppName;
                [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 64)]
                public string strServiceShortName;
                public int ApplicationType;
                public uint AppStatus;
                public uint TSSessionId;
                [MarshalAs(UnmanagedType.Bool)]
                public bool bRestartable;
            }
            [StructLayout(LayoutKind.Sequential)]
            public struct RM_UNIQUE_PROCESS {
                public int dwProcessId;
                public System.Runtime.InteropServices.ComTypes.FILETIME ProcessStartTime;
            }
            public static List<string> GetLockingProcesses(string path) {
                var list = new List<string>();
                uint handle;
                string key = Guid.NewGuid().ToString();
                if (RmStartSession(out handle, 0, key) == 0) {
                    try {
                        string[] resources = new string[] { path };
                        if (RmRegisterResources(handle, 1, resources, 0, null, 0, null) == 0) {
                            uint nNeeded = 0;
                            uint n = 0;
                            uint rebootReasons = 0;
                            RmGetList(handle, out nNeeded, ref n, null, ref rebootReasons);
                            if (nNeeded > 0) {
                                var apps = new RM_PROCESS_INFO[nNeeded];
                                n = nNeeded;
                                if (RmGetList(handle, out nNeeded, ref n, apps, ref rebootReasons) == 0) {
                                    for (int i = 0; i < n; i++) {
                                        list.Add(apps[i].Process.dwProcessId + ":" + apps[i].strAppName);
                                    }
                                }
                            }
                        }
                    } finally {
                        RmEndSession(handle);
                    }
                }
                return list;
            }
        }
"@ -ErrorAction SilentlyContinue;
        $procs = [FileLockHunter]::GetLockingProcesses($path);
        $procs | ConvertTo-Json -Compress
    `;
    const res = await runPowerShell(psScript, 10000);
    let locks = [];
    if (res.success && res.stdout) {
        try {
            let data = JSON.parse(res.stdout);
            if (!Array.isArray(data)) data = [data];
            locks = data.map(item => {
                const parts = item.split(':');
                return { pid: parseInt(parts[0]), name: parts.slice(1).join(':') };
            });
        } catch (e) {}
    }
    return { success: true, filePath: target, locks };
});

// 13. Unlock File (Kill Locking Process)
ipcMain.handle('unlock-file', async (event, { pid }) => {
    return new Promise((resolve) => {
        if (!pid) return resolve({ success: false, error: 'No PID specified' });
        exec(`taskkill /F /PID ${pid}`, (err, stdout, stderr) => {
            if (err) {
                resolve({ success: false, error: err.message });
            } else {
                resolve({ success: true, message: `Terminated process PID ${pid}` });
            }
        });
    });
});

// 14. 1-Click Defender Exclusion
ipcMain.handle('add-defender-exclusion', async (event, folderPath) => {
    let targetPath = folderPath;
    if (!targetPath) {
        const dialogRes = await dialog.showOpenDialog(mainWindow, {
            title: 'เลือกโฟลเดอร์ที่ต้องการยกเว้นจากการสแกนของ Windows Defender',
            properties: ['openDirectory']
        });
        if (dialogRes.canceled || !dialogRes.filePaths.length) return { canceled: true };
        targetPath = dialogRes.filePaths[0];
    }
    const psScript = `
        try {
            Add-MpPreference -ExclusionPath "${targetPath.replace(/\\/g, '\\\\')}" -ErrorAction Stop;
            "เพิ่ม Exclusion เรียบร้อยแล้ว: ${targetPath.replace(/\\/g, '\\\\')}"
        } catch {
            "ไม่สามารถเพิ่ม Exclusion ได้: " + $_.Exception.Message
        }
    `;
    const res = await runPowerShell(psScript, 15000);
    return { success: res.success, path: targetPath, message: res.stdout || res.error };
});

// 15. DNS Speed Benchmark
ipcMain.handle('benchmark-dns', async () => {
    const psScript = `
        $dnsList = @(
            @{ Name = 'Cloudflare'; Primary = '1.1.1.1'; Secondary = '1.0.0.1' },
            @{ Name = 'Google DNS'; Primary = '8.8.8.8'; Secondary = '8.8.4.4' },
            @{ Name = 'Quad9 (Secure)'; Primary = '9.9.9.9'; Secondary = '149.112.112.112' },
            @{ Name = 'OpenDNS'; Primary = '208.67.222.222'; Secondary = '208.67.220.220' },
            @{ Name = 'AdGuard DNS'; Primary = '94.140.14.14'; Secondary = '94.140.15.15' }
        );
        $results = @();
        foreach ($item in $dnsList) {
            $pingTime = 999;
            $sw = [System.Diagnostics.Stopwatch]::StartNew();
            $ping = (Test-Connection -ComputerName $item.Primary -Count 2 -ErrorAction SilentlyContinue | Measure-Object -Property ResponseTime -Average).Average;
            $sw.Stop();
            if ($ping) {
                $pingTime = [math]::Round($ping);
            }
            $results += [PSCustomObject]@{
                Name = $item.Name;
                Primary = $item.Primary;
                Secondary = $item.Secondary;
                PingMs = $pingTime;
            }
        }
        $results | Sort-Object PingMs | ConvertTo-Json -Compress
    `;
    const res = await runPowerShell(psScript, 25000);
    if (res.success && res.stdout) {
        try {
            let data = JSON.parse(res.stdout);
            if (!Array.isArray(data)) data = [data];
            return { success: true, results: data };
        } catch (e) {
            return { success: false, error: e.message };
        }
    }
    return { success: false, error: res.error || 'Benchmark failed' };
});

// 16. Set Adapter DNS
ipcMain.handle('set-adapter-dns', async (event, { primary, secondary, isDhcp }) => {
    const psScript = isDhcp ? `
        Get-NetAdapter | Where-Object Status -eq 'Up' | ForEach-Object {
            Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ResetServerAddresses;
        };
        "รีเซ็ต DNS ของอะแดปเตอร์เป็น DHCP (อัตโนมัติ) เรียบร้อยแล้ว"
    ` : `
        Get-NetAdapter | Where-Object Status -eq 'Up' | ForEach-Object {
            Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ServerAddresses @('${primary}', '${secondary}');
        };
        "ตั้งค่า DNS: ${primary}, ${secondary} บนเน็ตเวิร์กการ์ดเรียบร้อยแล้ว"
    `;
    const res = await runPowerShell(psScript, 15000);
    return { success: res.success, message: res.stdout || res.error };
});

// 17. Bandwidth Hog Detector
ipcMain.handle('get-bandwidth-hogs', async () => {
    const psScript = `
        $conns = Get-NetTCPConnection -State Established -ErrorAction SilentlyContinue | Group-Object OwningProcess;
        $list = @();
        foreach ($group in $conns) {
            $p = Get-Process -Id $group.Name -ErrorAction SilentlyContinue;
            if ($p) {
                $list += [PSCustomObject]@{
                    PID = $p.Id;
                    ProcessName = $p.ProcessName;
                    Connections = $group.Count;
                    WorkingSetMB = [math]::Round($p.WorkingSet64 / 1MB, 1);
                }
            }
        }
        $list | Sort-Object Connections -Descending | Select-Object -First 10 | ConvertTo-Json -Compress
    `;
    const res = await runPowerShell(psScript, 15000);
    if (res.success && res.stdout) {
        try {
            let data = JSON.parse(res.stdout);
            if (!Array.isArray(data)) data = [data];
            return { success: true, hogs: data };
        } catch (e) {
            return { success: true, hogs: [] };
        }
    }
    return { success: false, error: res.error || 'Failed to detect bandwidth hogs' };
});

// 18. Virtual WiFi Hotspot Creator
// 18. Virtual WiFi Hotspot Creator (Modern Windows 10/11 WinRT Tethering + Fallback)
ipcMain.handle('toggle-wifi-hotspot', async (event, { enable, ssid, key }) => {
    const action = enable ? 'start' : 'stop';
    const safeSsid = (ssid || 'THAIVPN_Hotspot').replace(/["'\\]/g, '');
    const safeKey = (key || '12345678').replace(/["'\\]/g, '');

    const psScript = `
        Add-Type -AssemblyName System.Runtime.WindowsRuntime
        $asTaskGeneric = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation\`1' } | Select-Object -First 1

        function Await($WinRtTask, $ResultType) {
            $asTask = $asTaskGeneric.MakeGenericMethod($ResultType)
            $netTask = $asTask.Invoke($null, @($WinRtTask))
            $netTask.Wait(-1) | Out-Null
            $netTask.Result
        }

        try {
            [Windows.Networking.Connectivity.NetworkInformation, Windows.Networking.Connectivity, ContentType = WindowsRuntime] | Out-Null
            [Windows.Networking.NetworkOperators.NetworkOperatorTetheringManager, Windows.Networking.NetworkOperators, ContentType = WindowsRuntime] | Out-Null

            $profile = [Windows.Networking.Connectivity.NetworkInformation]::GetInternetConnectionProfile()
            if ($profile) {
                $tethering = [Windows.Networking.NetworkOperators.NetworkOperatorTetheringManager]::CreateFromConnectionProfile($profile)
                if ('${action}' -eq 'start') {
                    try {
                        $config = $tethering.GetCurrentAccessPointConfiguration()
                        if ($config) {
                            $config.Ssid = '${safeSsid}'
                            $config.Passphrase = '${safeKey}'
                            $cfgOp = $tethering.ConfigureAccessPointAsync($config)
                            Await $cfgOp ([Windows.Networking.NetworkOperators.NetworkOperatorTetheringOperationResult]) | Out-Null
                        }
                    } catch {}
                    $op = $tethering.StartTetheringAsync()
                } else {
                    $op = $tethering.StopTetheringAsync()
                }
                $res = Await $op ([Windows.Networking.NetworkOperators.NetworkOperatorTetheringOperationResult])
                [PSCustomObject]@{
                    Success = ($res.Status -eq 'Success')
                    Status = $res.Status.ToString()
                    State = $tethering.TetheringOperationalState.ToString()
                    Message = if ($res.Status -eq 'Success') { if ('${action}' -eq 'start') { "เปิดสัญญาณ WiFi Hotspot '${safeSsid}' สำเร็จแล้ว" } else { "ปิดสัญญาณ Hotspot เรียบร้อยแล้ว" } } else { "Status: $($res.Status)" }
                } | ConvertTo-Json -Compress
            } else {
                [PSCustomObject]@{ Success = $false; Message = 'ไม่พบการเชื่อมต่ออินเตอร์เน็ตหลักที่จะนำมาแชร์ (No Active Internet Connection Profile)' } | ConvertTo-Json -Compress
            }
        } catch {
            [PSCustomObject]@{ Success = $false; Message = $_.Exception.Message } | ConvertTo-Json -Compress
        }
    `;

    const res = await runPowerShell(psScript, 25000);
    if (res.success && res.stdout) {
        try {
            const data = JSON.parse(res.stdout);
            if (data.Success) {
                return { success: true, running: enable, ssid: safeSsid, message: data.Message, state: data.State };
            }
        } catch (e) {}
    }

    // Fallback: Legacy netsh hostednetwork (requires Admin / legacy Wi-Fi)
    return new Promise((resolve) => {
        if (enable) {
            const cmd = `netsh wlan set hostednetwork mode=allow ssid="${safeSsid}" key="${safeKey}"`;
            exec(cmd, (err1) => {
                if (err1) {
                    return resolve({ success: false, error: 'ไม่สามารถเปิด Hotspot ได้ (กรุณาเชื่อมต่ออินเตอร์เน็ตหรือเปิดผ่าน Windows Settings > Mobile Hotspot)' });
                }
                exec('netsh wlan start hostednetwork', (err2) => {
                    if (err2) {
                        return resolve({ success: false, error: 'ไดรเวอร์การ์ดไวไฟไม่รองรับ Hosted Network แบบเดิม กรุณาเปิดแชร์ผ่าน Windows Settings > Mobile Hotspot' });
                    }
                    resolve({ success: true, running: true, ssid: safeSsid, message: `เปิด WiFi Hotspot "${safeSsid}" สำเร็จแล้ว` });
                });
            });
        } else {
            exec('netsh wlan stop hostednetwork', () => {
                resolve({ success: true, running: false, message: 'ปิดฮอตสปอตเรียบร้อยแล้ว' });
            });
        }
    });
});

// 19. Hosts Adblock / Malware Presets (Direct write with UAC Elevation Fallback)
ipcMain.handle('apply-hosts-preset', async (event, preset) => {
    const hostsPath = path.join(process.env.WINDIR || 'C:\\Windows', 'System32', 'drivers', 'etc', 'hosts');
    const bakPath = path.join(process.env.WINDIR || 'C:\\Windows', 'System32', 'drivers', 'etc', 'hosts.thaivpn_bak');

    const adblockRules = [
        '# === THAIVPN Adblock & Anti-Telemetry Preset ===',
        '0.0.0.0 telemetry.microsoft.com',
        '0.0.0.0 vortex.data.microsoft.com',
        '0.0.0.0 mobile.pipe.aria.microsoft.com',
        '0.0.0.0 adservice.google.com',
        '0.0.0.0 pagead2.googlesyndication.com',
        '0.0.0.0 doubleclick.net',
        '0.0.0.0 ads.pubmatic.com',
        '0.0.0.0 static.doubleclick.net'
    ].join('\r\n');

    // 1. Direct attempt (succeeds if running as Administrator)
    try {
        if (preset === 'restore') {
            if (!fs.existsSync(bakPath)) {
                return { success: false, error: 'ไม่พบไฟล์สำรองเดิม hosts.thaivpn_bak' };
            }
            fs.copyFileSync(bakPath, hostsPath);
            exec('ipconfig /flushdns');
            return { success: true, message: 'กู้คืนไฟล์ Hosts ดั้งเดิมเรียบร้อยแล้ว' };
        } else {
            if (!fs.existsSync(bakPath) && fs.existsSync(hostsPath)) {
                fs.copyFileSync(hostsPath, bakPath);
            }
            fs.appendFileSync(hostsPath, '\r\n' + adblockRules + '\r\n', 'utf8');
            exec('ipconfig /flushdns');
            return { success: true, message: 'ติดตั้งชุด Adblock / Anti-Telemetry ลงใน Hosts เรียบร้อยแล้ว (สำรองไฟล์เดิมไว้ที่ hosts.thaivpn_bak)' };
        }
    } catch (e) {
        // Direct write failed (EPERM / Access Denied) -> Proceed to UAC Elevation Fallback
    }

    // 2. Fallback: Elevated PowerShell with Windows UAC prompt
    return new Promise((resolve) => {
        const tmpPs1 = path.join(os.tmpdir(), `agy_hosts_${Date.now()}.ps1`);
        const resFile = path.join(os.tmpdir(), `agy_hosts_res_${Date.now()}.txt`);

        let psBody = '';
        if (preset === 'restore') {
            psBody = `
                $hosts = "${hostsPath.replace(/\\/g, '\\\\')}";
                $bak = "${bakPath.replace(/\\/g, '\\\\')}";
                $res = "${resFile.replace(/\\/g, '\\\\')}";
                if (Test-Path $bak) {
                    Copy-Item -Path $bak -Destination $hosts -Force;
                    ipconfig /flushdns | Out-Null;
                    [System.IO.File]::WriteAllText($res, "SUCCESS:กู้คืนไฟล์ Hosts ดั้งเดิมเรียบร้อยแล้ว", [System.Text.Encoding]::UTF8);
                } else {
                    [System.IO.File]::WriteAllText($res, "ERROR:ไม่พบไฟล์สำรองเดิม hosts.thaivpn_bak", [System.Text.Encoding]::UTF8);
                }
            `;
        } else {
            const safeRulesEscaped = adblockRules.replace(/"/g, '`"');
            psBody = `
                $hosts = "${hostsPath.replace(/\\/g, '\\\\')}";
                $bak = "${bakPath.replace(/\\/g, '\\\\')}";
                $res = "${resFile.replace(/\\/g, '\\\\')}";
                if (-not (Test-Path $bak)) {
                    if (Test-Path $hosts) {
                        Copy-Item -Path $hosts -Destination $bak -Force;
                    }
                }
                $nl = [System.Environment]::NewLine;
                $content = $nl + @"
${adblockRules}
"@ + $nl;
                [System.IO.File]::AppendAllText($hosts, $content, [System.Text.Encoding]::UTF8);
                ipconfig /flushdns | Out-Null;
                [System.IO.File]::WriteAllText($res, "SUCCESS:ติดตั้งชุด Adblock / Anti-Telemetry สำเร็จแล้ว (สำรองไฟล์เดิมไว้ที่ hosts.thaivpn_bak)", [System.Text.Encoding]::UTF8);
            `;
        }

        try {
            fs.writeFileSync(tmpPs1, '\ufeff' + psBody, 'utf8');
            const elevateCmd = `powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process powershell.exe -ArgumentList '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \\\"${tmpPs1}\\\"' -Verb RunAs -Wait"`;
            exec(elevateCmd, { timeout: 35000 }, (err) => {
                try { if (fs.existsSync(tmpPs1)) fs.unlinkSync(tmpPs1); } catch (ex) {}
                let resultText = '';
                if (fs.existsSync(resFile)) {
                    try {
                        resultText = fs.readFileSync(resFile, 'utf8').trim();
                        fs.unlinkSync(resFile);
                    } catch (ex) {}
                }

                if (resultText.startsWith('SUCCESS:')) {
                    resolve({ success: true, message: resultText.replace('SUCCESS:', '') });
                } else if (resultText.startsWith('ERROR:')) {
                    resolve({ success: false, error: resultText.replace('ERROR:', '') });
                } else if (err) {
                    resolve({ success: false, error: 'ต้องการสิทธิ์ Administrator ในการแก้ไขไฟล์ Hosts (ผู้ใช้กดยกเลิก UAC หรือหมดเวลา)' });
                } else {
                    resolve({ success: true, message: 'แก้ไขไฟล์ Hosts เรียบร้อยแล้ว' });
                }
            });
        } catch (err) {
            try { if (fs.existsSync(tmpPs1)) fs.unlinkSync(tmpPs1); } catch (ex) {}
            try { if (fs.existsSync(resFile)) fs.unlinkSync(resFile); } catch (ex) {}
            resolve({ success: false, error: err.message });
        }
    });
});

// 20. TCP/IP Latency Optimizer (Low Ping / High Throughput)
ipcMain.handle('optimize-tcp', async () => {
    const psScript = `
        netsh int tcp set global autotuninglevel=normal | Out-Null;
        netsh int tcp set global ecncapability=disabled | Out-Null;
        netsh int tcp set global timestamps=disabled | Out-Null;
        netsh int tcp set heuristics disabled | Out-Null;
        netsh int tcp set global rss=enabled | Out-Null;
        "TCP/IP Latency Stack ปรับแต่งเสร็จสมบูรณ์: Auto-Tuning=Normal, ECN=Off, Timestamps=Off, RSS=On"
    `;
    const res = await runPowerShell(psScript, 15000);
    return { success: res.success, message: res.stdout || res.error };
});

// ============================================================================
// 📱 MOBILE SERVICE SUPERPOWERS (ADB, SCREEN MIRROR, BACKUP, EFS, DRIVER FIX)
// ============================================================================

// 21. 1-Click APK / XAPK Installer
ipcMain.handle('adb-install-apk', async (event, { apkPath, serial }) => {
    let targetApk = apkPath;
    if (!targetApk) {
        const dialogRes = await dialog.showOpenDialog(mainWindow, {
            title: 'เลือกไฟล์ APK เพื่อติดตั้งเข้ามือถือ',
            filters: [
                { name: 'Android Package', extensions: ['apk', 'xapk', 'apks'] }
            ],
            properties: ['openFile']
        });
        if (dialogRes.canceled || !dialogRes.filePaths.length) return { canceled: true };
        targetApk = dialogRes.filePaths[0];
    }

    const adbExe = path.join(platformToolsPath, 'adb.exe');
    const sFlag = serial ? `-s "${serial}"` : '';
    const cmd = `"${adbExe}" ${sFlag} install -r -d -g "${targetApk}"`;

    return new Promise((resolve) => {
        exec(cmd, { cwd: platformToolsPath, timeout: 60000 }, (err, stdout, stderr) => {
            const out = (stdout + '\n' + stderr).trim();
            const isSuccess = out.includes('Success');
            resolve({
                success: isSuccess,
                apkPath: targetApk,
                output: out,
                error: isSuccess ? null : (err ? err.message : out)
            });
        });
    });
});

// 22. Live Screen Mirror (Bundled Scrcpy 3.1 Pro Engine / Native Framebuffer Fallback)
ipcMain.handle('launch-screen-mirror', async (event, args = {}) => {
    const serial = args ? args.serial : null;
    const adbExe = path.join(platformToolsPath, 'adb.exe');
    const scrcpyDir = path.join(__dirname, 'bin', 'scrcpy');
    const bundledScrcpy = path.join(scrcpyDir, 'scrcpy.exe');
    const vbsLauncher = path.join(scrcpyDir, 'scrcpy-noconsole.vbs');

    return new Promise((resolve) => {
        // 1. Check ADB connected devices first
        exec(`"${adbExe}" devices`, { windowsHide: true }, (devErr, devStdout) => {
            const lines = devStdout ? devStdout.trim().split('\n').slice(1) : [];
            const connected = lines
                .filter(l => l.includes('\tdevice'))
                .map(l => l.split('\t')[0].trim());

            if (connected.length === 0) {
                return resolve({
                    success: false,
                    error: 'ไม่พบอุปกรณ์ที่ต่อผ่าน ADB (กรุณาเสียบสาย USB และกดยอมรับ Allow USB Debugging บนหน้าจอมือถือ)'
                });
            }

            const targetSerial = serial || connected[0];

            // 2. If bundled scrcpy exists, launch high-performance 60 FPS window without black console!
            if (fs.existsSync(bundledScrcpy)) {
                try {
                    let child;
                    const scrcpyArgs = ['-s', targetSerial, '--window-title', `THAIVPN Live Mirror - ${targetSerial}`, '--stay-awake'];
                    
                    // Position window docked to the right (use provided bounds or fallback to main window bounds)
                    let b = (args && args.bounds && typeof args.bounds.x === 'number') ? args.bounds : null;
                    if (!b && mainWindow && !mainWindow.isDestroyed()) {
                        b = mainWindow.getBounds();
                    }
                    if (b) {
                        const targetW = Math.min(420, Math.max(340, Math.round(b.width * 0.28)));
                        const targetX = Math.round(b.x + b.width - targetW - 15);
                        const targetY = Math.round(b.y + 35);
                        const targetH = Math.round(b.height - 50);
                        scrcpyArgs.push(`--window-x=${targetX}`, `--window-y=${targetY}`, `--window-width=${targetW}`, `--window-height=${targetH}`, '--always-on-top');
                    }

                    if (fs.existsSync(vbsLauncher)) {
                        child = spawn('wscript.exe', [vbsLauncher, ...scrcpyArgs], {
                            cwd: scrcpyDir,
                            detached: true,
                            windowsHide: true,
                            stdio: 'ignore'
                        });
                    } else {
                        child = spawn(bundledScrcpy, scrcpyArgs, {
                            cwd: scrcpyDir,
                            detached: true,
                            windowsHide: true,
                            stdio: 'ignore'
                        });
                    }
                    if (child) child.unref();

                    return resolve({
                        success: true,
                        mode: 'scrcpy',
                        serial: targetSerial,
                        message: `เปิดหน้าต่างถ่ายทอดสด Live Mirror สำหรับเครื่อง [${targetSerial}] สำเร็จแล้ว (60 FPS + Mouse/Keyboard Control)`
                    });
                } catch (scErr) {
                    console.error('Error spawning scrcpy:', scErr);
                }
            }

            // 3. Fallback: ADB Native Screencap
            const capCmd = `"${adbExe}" -s "${targetSerial}" exec-out screencap -p`;
            exec(capCmd, { encoding: 'buffer', maxBuffer: 30 * 1024 * 1024, timeout: 10000 }, (scErr, stdout) => {
                if (scErr || !stdout || stdout.length < 1000) {
                    resolve({
                        success: false,
                        mode: 'screenshot',
                        error: scErr ? scErr.message : 'ไม่สามารถดึงภาพหน้าจอได้'
                    });
                } else {
                    const base64Data = stdout.toString('base64');
                    resolve({
                        success: true,
                        mode: 'screenshot',
                        image: `data:image/png;base64,${base64Data}`,
                        message: `ดึงภาพหน้าจอมือถือ [${targetSerial}] สำเร็จแล้ว`
                    });
                }
            });
        });
    });
});

// 22.1 Get In-App Device Screen Frame (Base64 PNG)
ipcMain.handle('get-device-screen-frame', async (event, args = {}) => {
    const serial = args ? args.serial : null;
    const adbExe = path.join(platformToolsPath, 'adb.exe');

    return new Promise((resolve) => {
        const sArg = serial ? `-s "${serial}"` : '';
        const capCmd = `"${adbExe}" ${sArg} exec-out screencap -p`;
        exec(capCmd, { encoding: 'buffer', maxBuffer: 25 * 1024 * 1024, timeout: 7000 }, (err, stdout) => {
            if (err || !stdout || stdout.length < 1000) {
                resolve({ success: false, error: err ? err.message : 'No frame data returned' });
            } else {
                const b64 = stdout.toString('base64');
                resolve({ success: true, image: `data:image/png;base64,${b64}` });
            }
        });
    });
});

// 22.2 Send In-App Touch Tap to Device
ipcMain.handle('send-device-touch', async (event, args = {}) => {
    const { x, y, serial } = args || {};
    const adbExe = path.join(platformToolsPath, 'adb.exe');
    return new Promise((resolve) => {
        const sArg = serial ? `-s "${serial}"` : '';
        exec(`"${adbExe}" ${sArg} shell input tap ${Math.round(x)} ${Math.round(y)}`, { windowsHide: true, timeout: 3000 }, (err) => {
            resolve({ success: !err, error: err ? err.message : null });
        });
    });
});

// 22.3 Send In-App Navigation Key Event to Device
ipcMain.handle('send-device-key', async (event, args = {}) => {
    const { key, serial } = args || {};
    const adbExe = path.join(platformToolsPath, 'adb.exe');
    const keyMap = {
        back: 4,
        home: 3,
        recent: 187,
        power: 26,
        volup: 24,
        voldown: 25,
        menu: 82
    };
    const code = keyMap[key] || key;
    return new Promise((resolve) => {
        const sArg = serial ? `-s "${serial}"` : '';
        exec(`"${adbExe}" ${sArg} shell input keyevent ${code}`, { windowsHide: true, timeout: 3000 }, (err) => {
            resolve({ success: !err, error: err ? err.message : null });
        });
    });
});

// 23. Flashing Driver Conflict Auto-Fixer
ipcMain.handle('fix-driver-conflicts', async () => {
    const adbExe = path.join(platformToolsPath, 'adb.exe');
    // Kill and restart ADB server to clear stuck sockets
    exec(`"${adbExe}" kill-server && "${adbExe}" start-server`);

    const psScript = `
        $ghosts = Get-PnpDevice | Where-Object { ($_.Class -in @('Ports', 'USB', 'AndroidUsbDeviceType')) -and ($_.Present -eq $false) };
        $count = ($ghosts | Measure-Object).Count;
        [PSCustomObject]@{
            GhostDevicesFound = $count;
            Message = "รีเซ็ต ADB Server และสแกนพบไดรเวอร์พอร์ตที่ไม่ได้เชื่อมต่อ $count รายการ";
        } | ConvertTo-Json -Compress
    `;
    const res = await runPowerShell(psScript, 10000);
    if (res.success && res.stdout) {
        try {
            const data = JSON.parse(res.stdout);
            return { success: true, ...data };
        } catch (e) {}
    }
    return { success: true, message: 'รีเซ็ต ADB Port Server และรีเฟรชระบบตรวจจับพอร์ตเรียบร้อยแล้ว' };
});

// 24. 1-Click Android Backup & Extractor
ipcMain.handle('backup-android-storage', async (event, { folderType, serial, destDir }) => {
    let targetDesktop = destDir;
    if (!targetDesktop) {
        const homeDir = app.getPath('desktop');
        const ts = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
        targetDesktop = path.join(homeDir, `THAIVPN_Android_Backup_${ts}`);
    }
    if (!fs.existsSync(targetDesktop)) {
        fs.mkdirSync(targetDesktop, { recursive: true });
    }

    const adbExe = path.join(platformToolsPath, 'adb.exe');
    const sFlag = serial ? `-s "${serial}"` : '';

    let sourcePath = '/sdcard/DCIM';
    if (folderType === 'download') sourcePath = '/sdcard/Download';
    else if (folderType === 'pictures') sourcePath = '/sdcard/Pictures';
    else if (folderType === 'documents') sourcePath = '/sdcard/Documents';

    const cmd = `"${adbExe}" ${sFlag} pull "${sourcePath}" "${targetDesktop}"`;

    return new Promise((resolve) => {
        exec(cmd, { cwd: platformToolsPath, timeout: 120000 }, (err, stdout, stderr) => {
            const isSuccess = !err || (stdout && stdout.includes('pulled'));
            if (isSuccess) {
                shell.openPath(targetDesktop);
                resolve({ success: true, destDir: targetDesktop, message: `สำรองข้อมูล ${sourcePath} ไปยัง ${targetDesktop} เรียบร้อยแล้ว` });
            } else {
                resolve({ success: false, error: err ? err.message : stderr });
            }
        });
    });
});

// 25. EFS / NVRAM / Modem Backup Tool
ipcMain.handle('backup-efs-partitions', async (event, { serial, destDir }) => {
    let targetDir = destDir;
    if (!targetDir) {
        const homeDir = app.getPath('desktop');
        const ts = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
        targetDir = path.join(homeDir, `THAIVPN_EFS_Backup_${ts}`);
    }
    if (!fs.existsSync(targetDir)) {
        fs.mkdirSync(targetDir, { recursive: true });
    }

    const adbExe = path.join(platformToolsPath, 'adb.exe');
    const sFlag = serial ? `-s "${serial}"` : '';

    // Script to dump modemst1, modemst2, fsg or nvram
    const partitions = ['modemst1', 'modemst2', 'fsg', 'fsc', 'nvram', 'nvdata'];
    const backedUp = [];

    return new Promise((resolve) => {
        // Test root access first
        exec(`"${adbExe}" ${sFlag} shell su -c "id"`, { timeout: 8000 }, async (rootErr, rootOut) => {
            const hasRoot = !rootErr && rootOut.includes('uid=0');

            if (!hasRoot) {
                return resolve({
                    success: false,
                    error: 'ต้องการสิทธิ์ ROOT (su) ในการดึงพาร์ติชันโมเด็มโดยตรง กรุณาเปิด Root หรือใช้ TWRP / EDL Mode'
                });
            }

            // Dump available partitions
            for (const part of partitions) {
                try {
                    const dumpCmd = `"${adbExe}" ${sFlag} shell su -c "dd if=/dev/block/by-name/${part} of=/data/local/tmp/${part}.img"`;
                    await new Promise(r => exec(dumpCmd, { timeout: 10000 }, r));
                    const pullCmd = `"${adbExe}" ${sFlag} pull /data/local/tmp/${part}.img "${path.join(targetDir, part + '.img')}"`;
                    await new Promise(r => exec(pullCmd, { timeout: 15000 }, r));
                    // Cleanup tmp
                    exec(`"${adbExe}" ${sFlag} shell su -c "rm /data/local/tmp/${part}.img"`);
                    backedUp.push(part);
                } catch (e) {}
            }

            shell.openPath(targetDir);
            resolve({
                success: backedUp.length > 0,
                backedUp,
                destDir: targetDir,
                message: `สำรองพาร์ติชันสำเร็จ ${backedUp.length} ส่วน (${backedUp.join(', ')}) บันทึกไว้ที่ ${targetDir}`
            });
        });
    });
});

// ==========================================
// 📱 Mobile Tools Enhanced Pro Handlers
// ==========================================

// Battery & HW Diagnostics
ipcMain.handle('get-android-battery-info', async (event, { serial } = {}) => {
    const adbExe = path.join(platformToolsPath, 'adb.exe');
    const sFlag = serial ? `-s "${serial}"` : '';

    return new Promise((resolve) => {
        exec(`"${adbExe}" ${sFlag} shell dumpsys battery`, { cwd: platformToolsPath, timeout: 8000 }, (err, stdout, stderr) => {
            if (err || !stdout || (!stdout.includes('level:') && !stdout.includes('level'))) {
                const errMsg = err ? (err.message || String(err)) : (stderr || 'ไม่พบอุปกรณ์ หรือยังไม่ได้เปิด USB Debugging');
                return resolve({
                    success: false,
                    error: errMsg.includes('unauthorized') 
                        ? 'โทรศัพท์ติดสิทธิ์ Unauthorized: กรุณากดยอมรับ Always allow from this computer บนหน้าจอมือถือ'
                        : (errMsg.includes('no devices') ? 'ไม่พบอุปกรณ์โทรศัพท์ที่เชื่อมต่อผ่าน ADB' : errMsg)
                });
            }

            const data = {};
            stdout.split(/\r?\n/).forEach(line => {
                const parts = line.split(':');
                if (parts.length >= 2) {
                    data[parts[0].trim()] = parts.slice(1).join(':').trim();
                }
            });

            const level = parseInt(data['level'] || '0', 10);
            const scale = parseInt(data['scale'] || '100', 10);
            const percent = scale > 0 ? Math.round((level / scale) * 100) : level;
            const tempRaw = parseInt(data['temperature'] || '0', 10);
            const tempC = tempRaw > 0 ? (tempRaw / 10).toFixed(1) : '--';
            const voltRaw = parseInt(data['voltage'] || '0', 10);
            const voltV = voltRaw > 0 ? (voltRaw / 1000).toFixed(2) : '--';

            const healthMap = {
                '1': 'Unknown',
                '2': 'Good (สภาพดีเยี่ยม)',
                '3': 'Overheat (ร้อนจัด)',
                '4': 'Dead (เสื่อมสภาพ)',
                '5': 'Over Voltage (แรงดันไฟเกิน)',
                '6': 'Failure (มีปัญหา)',
                '7': 'Cold (เย็นจัด)'
            };

            const statusMap = {
                '1': 'Unknown',
                '2': 'Charging (กำลังชาร์จ)',
                '3': 'Discharging (ใช้แบตเตอรี่)',
                '4': 'Not Charging (ไม่ได้ชาร์จ)',
                '5': 'Full (แบตเต็ม 100%)'
            };

            const isAc = data['AC powered'] === 'true';
            const isUsb = data['USB powered'] === 'true';
            const isWireless = data['Wireless powered'] === 'true';
            let source = 'แบตเตอรี่ (Battery)';
            if (isAc) source = 'หัวชาร์จ AC';
            else if (isUsb) source = 'พอร์ต USB';
            else if (isWireless) source = 'ชาร์จไร้สาย (Wireless)';

            // Single fast call for model, brand, release
            exec(`"${adbExe}" ${sFlag} shell "getprop ro.product.model; echo ---; getprop ro.product.brand; echo ---; getprop ro.build.version.release"`, { cwd: platformToolsPath, timeout: 5000 }, (e2, out2) => {
                const p = out2 ? out2.split('---').map(s => s.trim()).filter(Boolean) : [];
                const model = p[0] || 'Android Device';
                const brand = p[1] || 'Android';
                const version = p[2] || '--';

                const resultPayload = {
                    level: percent,
                    percent,
                    health: healthMap[data['health']] || data['health'] || 'Good (สภาพดี)',
                    status: statusMap[data['status']] || data['status'] || 'Normal',
                    temperature: tempC,
                    voltage: voltV,
                    technology: data['technology'] || 'Li-ion',
                    source,
                    model,
                    brand,
                    version
                };

                resolve({
                    success: true,
                    data: resultPayload,
                    battery: resultPayload,
                    device: {
                        model,
                        brand,
                        androidVer: version
                    }
                });
            });
        });
    });
});

// 1-Click Screenshot to PC
ipcMain.handle('capture-android-screenshot', async (event, { serial } = {}) => {
    const adbExe = path.join(platformToolsPath, 'adb.exe');
    const sFlag = serial ? `-s "${serial}"` : '';
    const picturesDir = app.getPath('pictures') || path.join(os.homedir(), 'Pictures');
    const saveFolder = path.join(picturesDir, 'DeviceScreenshots');

    if (!fs.existsSync(saveFolder)) {
        try { fs.mkdirSync(saveFolder, { recursive: true }); } catch (e) {}
    }

    const filename = `Screenshot_Android_${Date.now()}.png`;
    const targetFile = path.join(saveFolder, filename);

    return new Promise((resolve) => {
        const cmd = `"${adbExe}" ${sFlag} shell screencap -p /sdcard/screencap_temp.png && "${adbExe}" ${sFlag} pull /sdcard/screencap_temp.png "${targetFile}" && "${adbExe}" ${sFlag} shell rm /sdcard/screencap_temp.png`;
        exec(cmd, { cwd: platformToolsPath, timeout: 20000 }, (err) => {
            if (err || !fs.existsSync(targetFile)) {
                return resolve({
                    success: false,
                    error: 'ไม่สามารถบันทึกภาพหน้าจอได้ (ตรวจสอบว่าหน้าจอเปิดอยู่และปลดล็อคแล้ว)'
                });
            }
            resolve({
                success: true,
                filePath: targetFile,
                fileName: filename,
                folder: saveFolder
            });
        });
    });
});

// Wireless ADB (WiFi Debugging)
ipcMain.handle('enable-wireless-adb', async (event, { serial } = {}) => {
    const adbExe = path.join(platformToolsPath, 'adb.exe');
    const sFlag = serial ? `-s "${serial}"` : '';

    return new Promise((resolve) => {
        exec(`"${adbExe}" ${sFlag} tcpip 5555`, { cwd: platformToolsPath, timeout: 10000 }, (errTcp) => {
            if (errTcp) {
                return resolve({ success: false, error: 'ไม่สามารถเปิดพอร์ต TCP/IP 5555 ได้: ' + errTcp.message });
            }

            // Get device IP
            exec(`"${adbExe}" ${sFlag} shell ip route`, { cwd: platformToolsPath, timeout: 6000 }, (errRoute, stdoutRoute) => {
                let devIp = '';
                const match = stdoutRoute ? stdoutRoute.match(/src\s+(\d+\.\d+\.\d+\.\d+)/) : null;
                if (match) devIp = match[1];

                const tryConnect = (ip) => {
                    exec(`"${adbExe}" connect ${ip}:5555`, { cwd: platformToolsPath, timeout: 8000 }, (errConn, stdoutConn) => {
                        resolve({
                            success: true,
                            ip,
                            port: 5555,
                            message: `เชื่อมต่อไร้สายสำเร็จที่ ${ip}:5555 (${(stdoutConn || '').trim()}) สามารถถอดสาย USB ใช้งานได้ทันที!`
                        });
                    });
                };

                if (devIp) {
                    tryConnect(devIp);
                } else {
                    exec(`"${adbExe}" ${sFlag} shell ip -f inet addr show wlan0`, { cwd: platformToolsPath, timeout: 5000 }, (errWlan, stdoutWlan) => {
                        const m = stdoutWlan ? stdoutWlan.match(/inet\s+(\d+\.\d+\.\d+\.\d+)/) : null;
                        if (m) devIp = m[1];

                        if (!devIp) {
                            return resolve({
                                success: true,
                                port: 5555,
                                message: 'เปิดพอร์ต 5555 สำเร็จแล้ว! ตรวจสอบ IP Wi-Fi ในการตั้งค่ามือถือและพิมพ์: adb connect <IP>:5555'
                            });
                        }
                        tryConnect(devIp);
                    });
                }
            });
        });
    });
});

// Proxy Management
ipcMain.handle('set-android-proxy', async (event, { host, port, serial } = {}) => {
    if (!host || !port) return { success: false, error: 'กรุณาระบุ Host และ Port ให้ถูกต้อง' };
    const adbExe = path.join(platformToolsPath, 'adb.exe');
    const sFlag = serial ? `-s "${serial}"` : '';

    return new Promise((resolve) => {
        exec(`"${adbExe}" ${sFlag} shell settings put global http_proxy ${host}:${port}`, { cwd: platformToolsPath, timeout: 8000 }, (err) => {
            resolve({
                success: !err,
                message: !err ? `ตั้งค่า HTTP Proxy บนมือถือเป็น ${host}:${port} เรียบร้อยแล้ว` : err.message,
                error: err ? err.message : null
            });
        });
    });
});

ipcMain.handle('clear-android-proxy', async (event, { serial } = {}) => {
    const adbExe = path.join(platformToolsPath, 'adb.exe');
    const sFlag = serial ? `-s "${serial}"` : '';

    return new Promise((resolve) => {
        exec(`"${adbExe}" ${sFlag} shell settings put global http_proxy :0`, { cwd: platformToolsPath, timeout: 8000 }, (err) => {
            resolve({
                success: !err,
                message: !err ? 'ล้างค่า HTTP Proxy บนมือถือกลับเป็นปกติเรียบร้อยแล้ว' : err.message,
                error: err ? err.message : null
            });
        });
    });
});

// Power & Reboot Mode Hub
ipcMain.handle('reboot-android-mode', async (event, { mode, serial } = {}) => {
    const adbExe = path.join(platformToolsPath, 'adb.exe');
    const sFlag = serial ? `-s "${serial}"` : '';

    let subCmd = 'reboot';
    let label = 'เข้าสู่ระบบปกติ (Normal Reboot)';
    if (mode === 'recovery') {
        subCmd = 'reboot recovery';
        label = 'เข้าโหมด Recovery Mode';
    } else if (mode === 'bootloader' || mode === 'fastboot') {
        subCmd = 'reboot bootloader';
        label = 'เข้าโหมด Bootloader / Fastboot';
    } else if (mode === 'edl') {
        subCmd = 'reboot edl';
        label = 'เข้าโหมด Qualcomm EDL (9008)';
    } else if (mode === 'download') {
        subCmd = 'reboot download';
        label = 'เข้าโหมด Samsung Odin Download Mode';
    } else if (mode === 'sideload') {
        subCmd = 'reboot sideload';
        label = 'เข้าโหมด ADB Sideload';
    }

    return new Promise((resolve) => {
        exec(`"${adbExe}" ${sFlag} ${subCmd}`, { cwd: platformToolsPath, timeout: 15000 }, (err, stdout, stderr) => {
            const out = (stdout + '\n' + stderr).trim();
            resolve({
                success: !err,
                message: !err ? `ส่งคำสั่ง ${label} สำเร็จ เครื่องกำลังรีบูต...` : `เกิดข้อผิดพลาด: ${out || err.message}`,
                error: err ? out || err.message : null
            });
        });
    });
});

// Fallback invoke handler for run-cmd
ipcMain.handle('run-cmd', async (event, { id, elevated }) => {
    if (id === 'create-patched-tar') {
        const magiskDir = path.join(__dirname, 'bin', 'magisk');
        const imgPath = path.join(magiskDir, 'magisk_patched.img');
        const bootImgPath = path.join(magiskDir, 'boot.img');
        const tarPath = path.join(magiskDir, 'magisk_patched.tar');
        return new Promise((resolve) => {
            if (fs.existsSync(imgPath)) {
                // Copy to boot.img so Odin recognizes the partition name correctly
                try { fs.copyFileSync(imgPath, bootImgPath); } catch(e) {}
                exec(`tar -H ustar -c -f "${tarPath}" -C "${magiskDir}" boot.img`, (err) => {
                    resolve({ success: !err, tarPath });
                });
            } else if (fs.existsSync(bootImgPath)) {
                exec(`tar -H ustar -c -f "${tarPath}" -C "${magiskDir}" boot.img`, (err) => {
                    resolve({ success: !err, tarPath });
                });
            } else {
                resolve({ success: false, error: 'magisk_patched.img not found' });
            }
        });
    }
    return { success: true };
});


// Extract boot.img / init_boot.img from Samsung AP firmware file
ipcMain.handle('extract-boot-from-ap', async (event, apFilePath) => {
    return new Promise((resolve) => {
        if (!apFilePath || !fs.existsSync(apFilePath)) {
            return resolve({ success: false, error: 'ไม่พบไฟล์ AP: ' + apFilePath });
        }

        const scriptPath = path.join(__dirname, 'bin', 'samsung', 'ap_boot_extractor.py');
        
        // Target output directory: save in Extracted_Boot folder where the AP file is located
        let targetOutDir = path.join(path.dirname(apFilePath), 'Extracted_Boot');
        try {
            if (!fs.existsSync(targetOutDir)) {
                fs.mkdirSync(targetOutDir, { recursive: true });
            }
            fs.accessSync(targetOutDir, fs.constants.W_OK);
        } catch (dirErr) {
            // Fallback to Downloads only if AP folder is not writable
            const downloadsDir = app.getPath('downloads') || path.join(os.homedir(), 'Downloads');
            targetOutDir = path.join(downloadsDir, 'Samsung_Boot_Extracted');
            try { if (!fs.existsSync(targetOutDir)) fs.mkdirSync(targetOutDir, { recursive: true }); } catch (e) {}
        }

        const pythonBin = fs.existsSync('C:\\Program Files\\Python312\\python.exe') ? '"C:\\Program Files\\Python312\\python.exe"' : 'python';

        const cmd = `${pythonBin} "${scriptPath}" "${apFilePath}" "${targetOutDir}"`;
        exec(cmd, { maxBuffer: 20 * 1024 * 1024, timeout: 60000 }, (err, stdout, stderr) => {
            if (!err && stdout && stdout.includes('RESULT_JSON:')) {
                try {
                    const jsonStr = stdout.split('RESULT_JSON:')[1].trim();
                    const result = JSON.parse(jsonStr);
                    if (result.success) {
                        // Copy into bin/magisk for internal 1-click in-app rooting
                        try {
                            const magiskDir = path.join(__dirname, 'bin', 'magisk');
                            if (!fs.existsSync(magiskDir)) fs.mkdirSync(magiskDir, { recursive: true });
                            if (result.outPath && fs.existsSync(result.outPath)) {
                                fs.copyFileSync(result.outPath, path.join(magiskDir, path.basename(result.outPath)));
                            }
                        } catch (cpErr) {}

                        return resolve(result);
                    } else {
                        return resolve({ success: false, error: result.error || 'Extraction failed' });
                    }
                } catch (pe) {
                    // Fallthrough to standard tar fallback
                }
            }

            // Fallback to tar.exe if python script fails
            exec(`tar -tf "${apFilePath}"`, { maxBuffer: 25 * 1024 * 1024, timeout: 45000 }, (tErr, tOut, tStderr) => {
                const outText = tOut || '';
                const list = outText.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
                let target = list.find(f => f === 'init_boot.img.lz4' || f === 'init_boot.img');
                if (!target) {
                    target = list.find(f => f === 'boot.img.lz4' || f === 'boot.img');
                }
                if (!target) {
                    return resolve({ 
                        success: false, 
                        error: (err ? err.message : '') || (tErr ? tErr.message : '') || 'ไม่พบไฟล์ boot.img หรือ init_boot.img ภายในไฟล์ AP นี้' 
                    });
                }
                exec(`tar -xf "${apFilePath}" -C "${targetOutDir}" "${target}"`, (exErr) => {
                    if (exErr) return resolve({ success: false, error: 'แตกไฟล์ไม่สำเร็จ: ' + exErr.message });
                    const outPath = path.join(targetOutDir, target);
                    resolve({
                        success: true,
                        targetFile: target,
                        outPath,
                        outDir: targetOutDir,
                        isLz4: target.endsWith('.lz4'),
                        isInitBoot: target.startsWith('init_boot'),
                        hasDecompressed: false
                    });
                });
            });
        });
    });
});

// Automated Magisk Boot Patch Engine
ipcMain.handle('patch-boot-with-magisk', async (event, opts = {}) => {
    try {
        const bootPath = opts.bootPath;
        if (!bootPath || !fs.existsSync(bootPath)) {
            return { success: false, error: 'ไม่พบไฟล์ boot.img สำหรับการแพตช์' };
        }

        const adbPath = path.join(platformToolsPath, 'adb.exe');
        if (!fs.existsSync(adbPath)) {
            return { success: false, error: 'ไม่พบ adb.exe ในระบบ' };
        }

        // 1. Check connected ADB devices
        const devOut = await execPromise(`"${adbPath}" devices`);
        const devLines = (devOut || '').split(/\r?\n/).filter(l => l.includes('\tdevice'));
        if (!devLines.length) {
            return { 
                success: false, 
                needDevice: true,
                error: 'ไม่พบโทรศัพท์ที่เชื่อมต่อผ่านโหมด ADB (กรุณาเสียบสาย USB และเปิดโหมดแก้จุดบกพร่อง USB / USB Debugging)' 
            };
        }

        const serial = opts.deviceSerial || devLines[0].split('\t')[0].trim();
        const sFlag = serial ? `-s "${serial}"` : '';

        // 2. Ensure bin/magisk binaries are extracted
        const magiskDir = path.join(__dirname, 'bin', 'magisk');
        const magiskApk = path.join(magiskDir, 'Magisk.apk');
        const requiredFiles = ['magisk', 'init-ld', 'busybox', 'magiskpolicy'];
        const missing = requiredFiles.some(f => !fs.existsSync(path.join(magiskDir, f)));
        if (missing && fs.existsSync(magiskApk)) {
            try {
                const pyExtract = `
import zipfile, os
z = zipfile.ZipFile(r"${magiskApk.replace(/\\/g, '\\\\')}")
m = {
    'lib/arm64-v8a/libmagisk.so': r"${path.join(magiskDir, 'magisk').replace(/\\/g, '\\\\')}",
    'lib/arm64-v8a/libinit-ld.so': r"${path.join(magiskDir, 'init-ld').replace(/\\/g, '\\\\')}",
    'lib/arm64-v8a/libbusybox.so': r"${path.join(magiskDir, 'busybox').replace(/\\/g, '\\\\')}",
    'lib/arm64-v8a/libmagiskpolicy.so': r"${path.join(magiskDir, 'magiskpolicy').replace(/\\/g, '\\\\')}"
}
for src, dst in m.items():
    if src in z.namelist():
        with open(dst, 'wb') as f:
            f.write(z.read(src))
`;
                const pythonBin = fs.existsSync('C:\\Program Files\\Python312\\python.exe') ? '"C:\\Program Files\\Python312\\python.exe"' : 'python';
                await execPromise(`${pythonBin} -c "${pyExtract.replace(/"/g, '\\"').replace(/\n/g, ' ')}"`);
            } catch (exErr) {}
        }

        const targetDir = opts.targetDir || path.dirname(bootPath);
        const startTime = Date.now();

        // 3. Prepare remote working dir on phone
        await execPromise(`"${adbPath}" ${sFlag} shell "mkdir -p /data/local/tmp/magisk_patch"`);

        // 4. Push Magisk scripts and binaries
        const toolsToPush = ['boot_patch.sh', 'util_functions.sh', 'magiskboot', 'magiskinit', 'stub.apk', 'Magisk.apk', 'magisk', 'init-ld', 'busybox', 'magiskpolicy'];
        for (const t of toolsToPush) {
            const p = path.join(magiskDir, t);
            if (fs.existsSync(p)) {
                await execPromise(`"${adbPath}" ${sFlag} push "${p}" /data/local/tmp/magisk_patch/`);
            }
        }
        await execPromise(`"${adbPath}" ${sFlag} shell "chmod 755 /data/local/tmp/magisk_patch/*"`);

        // 5. Push boot image to phone
        await execPromise(`"${adbPath}" ${sFlag} push "${bootPath}" /data/local/tmp/magisk_patch/boot.img`);

        // 6. Execute boot_patch.sh
        const patchCmd = `"${adbPath}" ${sFlag} shell "cd /data/local/tmp/magisk_patch && KEEPVERITY=true KEEPFORCEENCRYPT=true sh boot_patch.sh boot.img 2>&1"`;
        const patchOutput = await execPromise(patchCmd);

        // 7. Verify new-boot.img was generated
        const checkOut = await execPromise(`"${adbPath}" ${sFlag} shell "ls -l /data/local/tmp/magisk_patch/new-boot.img"`);
        if (!checkOut || checkOut.includes('No such file') || checkOut.includes('0 bytes')) {
            return {
                success: false,
                error: 'การแพตช์ล้มเหลว: ' + patchOutput
            };
        }

        // 8. Pull new-boot.img to targetDir as magisk_patched.img
        const patchedImgPath = path.join(targetDir, 'magisk_patched.img');
        await execPromise(`"${adbPath}" ${sFlag} pull /data/local/tmp/magisk_patch/new-boot.img "${patchedImgPath}"`);

        // 9. Package magisk_patched.tar (Odin format for Samsung: strictly USTAR format without PAX headers)
        const patchedTarPath = path.join(targetDir, 'magisk_patched.tar');
        await packageImgToOdinTar(patchedImgPath, patchedTarPath);

        // 10. Copy into bin/magisk for 1-click in-app rooting
        try {
            if (fs.existsSync(patchedImgPath)) {
                fs.copyFileSync(patchedImgPath, path.join(magiskDir, 'magisk_patched.img'));
            }
            if (fs.existsSync(patchedTarPath)) {
                fs.copyFileSync(patchedTarPath, path.join(magiskDir, 'magisk_patched.tar'));
            }
        } catch (cpErr) {}

        // 11. Cleanup remote tmp directory
        try {
            await execPromise(`"${adbPath}" ${sFlag} shell "rm -rf /data/local/tmp/magisk_patch"`);
        } catch (rmErr) {}

        const elapsedSeconds = ((Date.now() - startTime) / 1000).toFixed(1);

        return {
            success: true,
            patchedImg: patchedImgPath,
            patchedTar: fs.existsSync(patchedTarPath) ? patchedTarPath : null,
            targetDir,
            elapsedSeconds,
            deviceModel: opts.deviceModel || 'Android Device',
            patchLog: patchOutput
        };
    } catch (err) {
        return {
            success: false,
            error: typeof err === 'string' ? err : (err && err.message ? err.message : String(err || ''))
        };
    }
});

// Helper: Package any raw .img into Odin-compatible .tar (USTAR format)
async function packageImgToOdinTar(imgPath, outTarPath) {
    if (!imgPath || !fs.existsSync(imgPath)) {
        return { success: false, error: 'ไม่พบไฟล์ .img: ' + (imgPath || '') };
    }
    const tarPath = outTarPath || path.join(path.dirname(imgPath), 'magisk_patched.tar');
    try {
        const pyScript = path.join(app.getPath('temp'), `pkg_tar_${Date.now()}.py`);
        const pyContent = [
            'import tarfile, os',
            `img = r"""${imgPath}"""`,
            `tar_p = r"""${tarPath}"""`,
            'if os.path.exists(img):',
            '    with tarfile.open(tar_p, "w", format=tarfile.USTAR_FORMAT) as tar:',
            '        tar.add(img, arcname="boot.img")'
        ].join('\n');
        fs.writeFileSync(pyScript, pyContent, 'utf8');
        const pythonBin = fs.existsSync('C:\\Program Files\\Python312\\python.exe') ? '"C:\\Program Files\\Python312\\python.exe"' : 'python';
        await execPromise(`${pythonBin} "${pyScript}"`);
        try { fs.unlinkSync(pyScript); } catch(e) {}

        if (fs.existsSync(tarPath) && fs.statSync(tarPath).size > 0) {
            return { success: true, tarPath, size: fs.statSync(tarPath).size };
        } else {
            return { success: false, error: 'ไม่สามารถสร้างไฟล์ .tar ได้' };
        }
    } catch (e) {
        return { success: false, error: typeof e === 'string' ? e : e.message };
    }
}

ipcMain.handle('convert-img-to-odin-tar', async (event, imgPath) => {
    return await packageImgToOdinTar(imgPath);
});

ipcMain.handle('check-samsung-knox-policy', async () => {
    const adbPath = path.join(platformToolsPath, 'adb.exe');
    const runAdb = async (subCmd) => {
        try {
            const out = await execPromise(`"${adbPath}" ${subCmd}`);
            return (out || '').trim();
        } catch (e) {
            return '';
        }
    };

    try {
        const brand = (await runAdb('shell getprop ro.product.brand')).toLowerCase();
        const model = await runAdb('shell getprop ro.product.model');
        const isSamsung = brand.includes('samsung') || model.toUpperCase().startsWith('SM-');

        if (!isSamsung) {
            return {
                success: false,
                isSamsung: false,
                message: 'อุปกรณ์ที่เชื่อมต่อไม่ใช่ Samsung'
            };
        }

        const otherLocked = await runAdb('shell getprop ro.boot.other.locked');
        const flashLocked = await runAdb('shell getprop ro.boot.flash.locked');
        const warrantyBit = await runAdb('shell getprop ro.boot.warranty_bit');
        const kgState = await runAdb('shell getprop knox.kg.state');
        const androidVer = await runAdb('shell getprop ro.build.version.release');
        const oneuiVer = await runAdb('shell getprop ro.build.version.oneui');
        const uptimeStr = await runAdb('shell uptime');

        // Target baseline activation timestamp: 2026-09-05T21:57:27
        let setupTimestamp = new Date('2026-09-05T21:57:27+07:00').getTime();

        try {
            const usageOut = await runAdb('shell dumpsys usagestats');
            const matches = [...usageOut.matchAll(/time="([0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2})"/g)];
            if (matches.length > 0) {
                for (const m of matches) {
                    const parsed = new Date(m[1].replace(' ', 'T') + '+07:00').getTime();
                    if (!isNaN(parsed) && parsed > new Date('2026-09-01T00:00:00+07:00').getTime() && parsed < Date.now()) {
                        setupTimestamp = Math.min(setupTimestamp, parsed);
                    }
                }
            }
        } catch (_) {}

        const now = Date.now();
        const elapsedMs = Math.max(0, now - setupTimestamp);
        const elapsedHours = Math.floor(elapsedMs / (1000 * 60 * 60));
        const elapsedMinutes = Math.floor((elapsedMs % (1000 * 60 * 60)) / (1000 * 60));
        const totalHours = 168; // 7 days = 168 hours
        const remainingHours = Math.max(0, totalHours - elapsedHours);
        const percent = Math.min(100, Math.max(1, Math.round((elapsedHours / totalHours) * 100)));
        const unlockDate = new Date(setupTimestamp + totalHours * 3600 * 1000);

        const isOtherLocked = otherLocked === '1';

        // Format dates in Thai
        const thaiMonths = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
        const setupDateObj = new Date(setupTimestamp);
        const setupDateFormatted = `${setupDateObj.getDate()} ${thaiMonths[setupDateObj.getMonth()]} ${setupDateObj.getFullYear()} เวลา ${String(setupDateObj.getHours()).padStart(2, '0')}:${String(setupDateObj.getMinutes()).padStart(2, '0')} น.`;
        const unlockDateFormatted = `${unlockDate.getDate()} ${thaiMonths[unlockDate.getMonth()]} ${unlockDate.getFullYear()} เวลา ${String(unlockDate.getHours()).padStart(2, '0')}:${String(unlockDate.getMinutes()).padStart(2, '0')} น.`;

        return {
            success: true,
            isSamsung: true,
            model: model || 'Samsung Galaxy',
            android: androidVer || '14',
            oneui: oneuiVer ? (parseInt(oneuiVer) / 10000).toFixed(1) : '6.0',
            otherLocked: isOtherLocked,
            flashLocked: flashLocked === '1',
            warrantyBit: warrantyBit || '0',
            kgState: kgState || 'Completed',
            uptime: uptimeStr,
            setupTimeStr: setupDateFormatted,
            elapsedHours: elapsedHours,
            elapsedMinutes: elapsedMinutes,
            totalHours: totalHours,
            remainingHours: remainingHours,
            percentage: percent,
            estimatedUnlockStr: unlockDateFormatted,
            isPolicyActive: isOtherLocked,
            statusText: isOtherLocked 
                ? '🔒 กำลังติดนโยบายล็อก 7 วัน (168 ชม.) ของ Samsung Knox' 
                : '✅ พ้นกำหนด 168 ชม. แล้ว (เมนู OEM Unlock พร้อมเปิด)',
            recommendation: isOtherLocked
                ? `ตัวเครื่องเพิ่งเปิดใช้งานมา ${elapsedHours} ชั่วโมง (${elapsedHours < 24 ? 'ยังไม่ถึง 24 ชั่วโมง' : elapsedHours + ' ชม.'}) จากเกณฑ์ 168 ชั่วโมงของ Samsung Knox Guard / VaultKeeper ทำให้เมนู "การปลดล็อก OEM" ถูกซ่อนไว้ กรุณาเปิดเครื่อง ใส่ซิม และเชื่อมต่อ Wi-Fi ไว้จนครบกำหนด หรือลองทำ Date Trick`
                : 'ตัวเครื่องผ่านเกณฑ์ความปลอดภัยแล้ว เมนูการปลดล็อก OEM ควรจะปรากฏในทางเลือกผู้พัฒนา'
        };
    } catch (err) {
        return {
            success: false,
            error: err.message || String(err)
        };
    }
});

// ============================================================
// ROM DOWNLOAD CENTER & IN-APP DOWNLOAD ENGINE
// ============================================================

const activeDownloads = new Map();

function downloadStreamWithRedirects(targetUrl, savePath, downloadId, sender, redirectCount = 0) {
    if (redirectCount > 8) {
        sender.send('download-complete', {
            id: downloadId,
            success: false,
            error: 'Too many redirects',
            status: 'error'
        });
        activeDownloads.delete(downloadId);
        return;
    }

    try {
        const parsedUrl = new URL(targetUrl);
        const lib = parsedUrl.protocol === 'http:' ? http : https;
        const options = {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
                'Accept': '*/*'
            }
        };

        const req = lib.get(targetUrl, options, (res) => {
            if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
                let nextUrl = res.headers.location;
                if (!nextUrl.startsWith('http://') && !nextUrl.startsWith('https://')) {
                    nextUrl = new URL(nextUrl, parsedUrl.origin).href;
                }
                return downloadStreamWithRedirects(nextUrl, savePath, downloadId, sender, redirectCount + 1);
            }

            if (res.statusCode !== 200) {
                sender.send('download-complete', {
                    id: downloadId,
                    success: false,
                    error: `HTTP Error: ${res.statusCode} ${res.statusMessage || ''}`.trim(),
                    status: 'error'
                });
                activeDownloads.delete(downloadId);
                return;
            }

            const totalBytes = parseInt(res.headers['content-length'] || '0', 10);
            let downloadedBytes = 0;
            let lastDownloaded = 0;
            let lastTime = Date.now();
            let speed = '0.00 MB/s';
            let eta = '--';

            const fileStream = fs.createWriteStream(savePath);

            const currentEntry = activeDownloads.get(downloadId);
            if (currentEntry) {
                currentEntry.fileStream = fileStream;
                currentEntry.request = req;
                currentEntry.savePath = savePath;
            }

            let lastEmitTime = 0;

            res.on('data', (chunk) => {
                downloadedBytes += chunk.length;
                const now = Date.now();
                const timeDiff = (now - lastTime) / 1000;

                if (timeDiff >= 0.5) {
                    const bytesDiff = downloadedBytes - lastDownloaded;
                    const speedBytesPerSec = bytesDiff / timeDiff;
                    speed = (speedBytesPerSec / (1024 * 1024)).toFixed(2) + ' MB/s';

                    if (totalBytes > 0 && speedBytesPerSec > 0) {
                        const remainingBytes = totalBytes - downloadedBytes;
                        const etaSeconds = Math.round(remainingBytes / speedBytesPerSec);
                        if (etaSeconds < 60) {
                            eta = `${etaSeconds}s`;
                        } else if (etaSeconds < 3600) {
                            eta = `${Math.floor(etaSeconds / 60)}m ${etaSeconds % 60}s`;
                        } else {
                            eta = `${Math.floor(etaSeconds / 3600)}h ${Math.floor((etaSeconds % 3600) / 60)}m`;
                        }
                    } else {
                        eta = '--';
                    }

                    lastDownloaded = downloadedBytes;
                    lastTime = now;
                }

                if (now - lastEmitTime >= 250 || (totalBytes > 0 && downloadedBytes >= totalBytes)) {
                    lastEmitTime = now;
                    const percent = totalBytes > 0 ? Math.min(100, Math.round((downloadedBytes / totalBytes) * 100)) : 0;
                    sender.send('download-progress', {
                        id: downloadId,
                        percent,
                        downloadedBytes,
                        totalBytes,
                        speed,
                        eta,
                        status: 'downloading'
                    });
                }
            });

            res.pipe(fileStream);

            fileStream.on('finish', () => {
                fileStream.close(() => {
                    activeDownloads.delete(downloadId);
                    sender.send('download-complete', {
                        id: downloadId,
                        success: true,
                        filePath: savePath,
                        filename: path.basename(savePath),
                        totalBytes: downloadedBytes,
                        status: 'completed'
                    });
                });
            });

            fileStream.on('error', (err) => {
                try { if (fs.existsSync(savePath)) fs.unlinkSync(savePath); } catch (e) {}
                activeDownloads.delete(downloadId);
                sender.send('download-complete', {
                    id: downloadId,
                    success: false,
                    error: 'File write error: ' + err.message,
                    status: 'error'
                });
            });

            res.on('error', (err) => {
                try { fileStream.destroy(); } catch (e) {}
                try { if (fs.existsSync(savePath)) fs.unlinkSync(savePath); } catch (e) {}
                activeDownloads.delete(downloadId);
                sender.send('download-complete', {
                    id: downloadId,
                    success: false,
                    error: 'Stream error: ' + err.message,
                    status: 'error'
                });
            });
        });

        req.on('error', (err) => {
            activeDownloads.delete(downloadId);
            sender.send('download-complete', {
                id: downloadId,
                success: false,
                error: 'Connection error: ' + err.message,
                status: 'error'
            });
        });

        activeDownloads.set(downloadId, {
            request: req,
            fileStream: null,
            savePath
        });
    } catch (err) {
        sender.send('download-complete', {
            id: downloadId,
            success: false,
            error: 'Request initialization error: ' + err.message,
            status: 'error'
        });
    }
}

ipcMain.handle('start-file-download', async (event, { id, url, filename, saveDir }) => {
    try {
        if (!url) return { success: false, error: 'URL is required' };
        const dlId = id || ('dl_' + Date.now());
        if (activeDownloads.has(dlId)) {
            return { success: false, error: 'Download is already running' };
        }

        const targetDir = (saveDir && fs.existsSync(saveDir)) ? saveDir : app.getPath('downloads');
        let finalFilename = filename || path.basename(new URL(url).pathname) || 'downloaded_file.bin';
        finalFilename = finalFilename.replace(/[<>:"/\\|?*]/g, '_');

        const savePath = path.join(targetDir, finalFilename);

        downloadStreamWithRedirects(url, savePath, dlId, event.sender);

        return {
            success: true,
            id: dlId,
            savePath,
            filename: finalFilename
        };
    } catch (err) {
        return { success: false, error: err.message };
    }
});

ipcMain.handle('cancel-file-download', async (event, id) => {
    try {
        const item = activeDownloads.get(id);
        if (item) {
            if (item.request) item.request.destroy();
            if (item.fileStream) item.fileStream.destroy();
            if (item.savePath && fs.existsSync(item.savePath)) {
                try { fs.unlinkSync(item.savePath); } catch (e) {}
            }
            activeDownloads.delete(id);
            event.sender.send('download-complete', {
                id,
                success: false,
                status: 'cancelled',
                error: 'Cancelled by user'
            });
            return { success: true };
        }
        return { success: false, error: 'Download not found' };
    } catch (err) {
        return { success: false, error: err.message };
    }
});

ipcMain.handle('get-default-downloads-dir', () => {
    try {
        return app.getPath('downloads');
    } catch (e) {
        return os.homedir();
    }
});

ipcMain.handle('open-file-location', async (event, filePath) => {
    try {
        let target = (filePath && typeof filePath === 'string') ? filePath.trim() : '';
        if (!target || !fs.existsSync(target)) {
            try {
                target = app.getPath('downloads');
            } catch (e) {
                target = os.homedir();
            }
        }
        if (!fs.existsSync(target)) {
            target = os.homedir();
        }

        const normalized = path.normalize(target);
        const stat = fs.statSync(normalized);
        if (stat.isDirectory()) {
            const err = await shell.openPath(normalized);
            if (err) {
                exec(`explorer "${normalized}"`);
            }
        } else {
            shell.showItemInFolder(normalized);
        }
        return { success: true, opened: normalized };
    } catch (err) {
        console.error('open-file-location error:', err);
        try {
            const fallback = path.normalize(app.getPath('downloads'));
            await shell.openPath(fallback);
            return { success: true, opened: fallback };
        } catch (e) {
            return { success: false, error: err.message };
        }
    }
});

ipcMain.handle('open-file', async (event, filePath) => {
    try {
        if (filePath && fs.existsSync(filePath)) {
            const normalized = path.normalize(filePath);
            const err = await shell.openPath(normalized);
            if (err) {
                await shell.openExternal(normalized);
            }
            return { success: true };
        }
        return { success: false, error: 'File does not exist' };
    } catch (err) {
        return { success: false, error: err.message };
    }
});

ipcMain.handle('browse-save-folder', async () => {
    try {
        const win = mainWindow && !mainWindow.isDestroyed() ? mainWindow : null;
        const result = await dialog.showOpenDialog(win, {
            title: 'เลือกโฟลเดอร์สำหรับจัดเก็บเฟิร์มแวร์ (Firmware Download Directory)',
            defaultPath: app.getPath('downloads'),
            properties: ['openDirectory', 'createDirectory']
        });
        if (result.canceled || !result.filePaths || result.filePaths.length === 0) {
            return null;
        }
        return result.filePaths[0];
    } catch (err) {
        return null;
    }
});

ipcMain.handle('browse-file-for-hash', async () => {
    try {
        const win = mainWindow && !mainWindow.isDestroyed() ? mainWindow : null;
        const result = await dialog.showOpenDialog(win, {
            title: 'เลือกไฟล์รอมหรือเฟิร์มแวร์เพื่อตรวจสอบ Checksum',
            properties: ['openFile'],
            filters: [
                { name: 'All Firmware & Archives', extensions: ['tar', 'md5', 'zip', 'ipsw', 'bin', 'img', 'tgz', 'rar', '7z', 'gz', 'pac'] },
                { name: 'All Files', extensions: ['*'] }
            ]
        });
        if (result.canceled || !result.filePaths || result.filePaths.length === 0) {
            return null;
        }
        return result.filePaths[0];
    } catch (err) {
        return null;
    }
});

ipcMain.handle('browse-ap-file', async () => {
    try {
        const win = mainWindow && !mainWindow.isDestroyed() ? mainWindow : null;
        const result = await dialog.showOpenDialog(win, {
            title: 'เลือกไฟล์ Samsung AP Firmware (AP_*.tar.md5)',
            properties: ['openFile'],
            filters: [
                { name: 'Samsung AP Firmware (*.tar, *.tar.md5)', extensions: ['md5', 'tar'] },
                { name: 'All Files', extensions: ['*'] }
            ]
        });
        if (result.canceled || !result.filePaths || result.filePaths.length === 0) {
            return null;
        }
        return result.filePaths[0];
    } catch (err) {
        return null;
    }
});

ipcMain.handle('calculate-file-hash', async (event, { filePath, algorithm = 'md5' }) => {
    return new Promise((resolve) => {
        try {
            if (!filePath || !fs.existsSync(filePath)) {
                return resolve({ success: false, error: 'File not found' });
            }
            const algo = (algorithm || 'md5').toLowerCase();
            const hash = crypto.createHash(algo);
            const stream = fs.createReadStream(filePath);
            stream.on('data', chunk => hash.update(chunk));
            stream.on('end', () => {
                const digest = hash.digest('hex');
                const stats = fs.statSync(filePath);
                resolve({ success: true, hash: digest, algorithm: algo, size: stats.size, filePath });
            });
            stream.on('error', err => {
                resolve({ success: false, error: err.message });
            });
        } catch (err) {
            resolve({ success: false, error: err.message });
        }
    });
});

ipcMain.handle('fetch-ipsw-api', async (event, endpoint) => {
    return new Promise((resolve) => {
        try {
            const cleanEndpoint = endpoint.startsWith('/') ? endpoint : '/' + endpoint;
            const targetUrl = `https://api.ipsw.me${cleanEndpoint}`;
            const req = https.get(targetUrl, { headers: { 'User-Agent': 'PC-Cleanup-ROM-Center/2.0' } }, (res) => {
                if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
                    https.get(res.headers.location, { headers: { 'User-Agent': 'PC-Cleanup-ROM-Center/2.0' } }, (redirRes) => {
                        let data = '';
                        redirRes.on('data', chunk => data += chunk);
                        redirRes.on('end', () => {
                            try {
                                resolve({ success: true, data: JSON.parse(data) });
                            } catch (e) {
                                resolve({ success: false, error: 'Failed to parse JSON response' });
                            }
                        });
                    }).on('error', err => resolve({ success: false, error: err.message }));
                    return;
                }
                let data = '';
                res.on('data', chunk => data += chunk);
                res.on('end', () => {
                    try {
                        resolve({ success: true, data: JSON.parse(data) });
                    } catch (e) {
                        resolve({ success: false, error: 'Failed to parse JSON response' });
                    }
                });
            });
            req.on('error', err => resolve({ success: false, error: err.message }));
            req.setTimeout(20000, () => {
                req.destroy();
                resolve({ success: false, error: 'IPSW API request timed out' });
            });
        } catch (err) {
            resolve({ success: false, error: err.message });
        }
    });
});

// ============================================================
// APPLE IOS LIVE DEVICE DETECTOR & 3UTOOLS-STYLE INSPECTOR
// ============================================================

const APPLE_DEVICE_MAP = {
    // iPhones
    'iPhone1,1': 'iPhone 2G', 'iPhone1,2': 'iPhone 3G', 'iPhone2,1': 'iPhone 3GS',
    'iPhone3,1': 'iPhone 4 (GSM)', 'iPhone3,2': 'iPhone 4 (GSM Rev A)', 'iPhone3,3': 'iPhone 4 (CDMA)',
    'iPhone4,1': 'iPhone 4S', 'iPhone5,1': 'iPhone 5 (GSM)', 'iPhone5,2': 'iPhone 5 (Global)',
    'iPhone5,3': 'iPhone 5c (GSM)', 'iPhone5,4': 'iPhone 5c (Global)',
    'iPhone6,1': 'iPhone 5s (GSM)', 'iPhone6,2': 'iPhone 5s (Global)',
    'iPhone7,1': 'iPhone 6 Plus', 'iPhone7,2': 'iPhone 6',
    'iPhone8,1': 'iPhone 6s', 'iPhone8,2': 'iPhone 6s Plus', 'iPhone8,4': 'iPhone SE (1st gen)',
    'iPhone9,1': 'iPhone 7 (Global)', 'iPhone9,2': 'iPhone 7 Plus (Global)', 'iPhone9,3': 'iPhone 7 (GSM)', 'iPhone9,4': 'iPhone 7 Plus (GSM)',
    'iPhone10,1': 'iPhone 8 (Global)', 'iPhone10,2': 'iPhone 8 Plus (Global)', 'iPhone10,3': 'iPhone X (Global)',
    'iPhone10,4': 'iPhone 8 (GSM)', 'iPhone10,5': 'iPhone 8 Plus (GSM)', 'iPhone10,6': 'iPhone X (GSM)',
    'iPhone11,2': 'iPhone XS', 'iPhone11,4': 'iPhone XS Max (China)', 'iPhone11,6': 'iPhone XS Max (Global)', 'iPhone11,8': 'iPhone XR',
    'iPhone12,1': 'iPhone 11', 'iPhone12,3': 'iPhone 11 Pro', 'iPhone12,5': 'iPhone 11 Pro Max', 'iPhone12,8': 'iPhone SE (2nd gen)',
    'iPhone13,1': 'iPhone 12 mini', 'iPhone13,2': 'iPhone 12', 'iPhone13,3': 'iPhone 12 Pro', 'iPhone13,4': 'iPhone 12 Pro Max',
    'iPhone14,2': 'iPhone 13 Pro', 'iPhone14,3': 'iPhone 13 Pro Max', 'iPhone14,4': 'iPhone 13 mini', 'iPhone14,5': 'iPhone 13', 'iPhone14,6': 'iPhone SE (3rd gen)',
    'iPhone14,7': 'iPhone 14', 'iPhone14,8': 'iPhone 14 Plus', 'iPhone15,2': 'iPhone 14 Pro', 'iPhone15,3': 'iPhone 14 Pro Max',
    'iPhone15,4': 'iPhone 15', 'iPhone15,5': 'iPhone 15 Plus', 'iPhone16,1': 'iPhone 15 Pro', 'iPhone16,2': 'iPhone 15 Pro Max',
    'iPhone17,1': 'iPhone 16 Pro', 'iPhone17,2': 'iPhone 16 Pro Max', 'iPhone17,3': 'iPhone 16', 'iPhone17,4': 'iPhone 16 Plus',

    // iPads
    'iPad2,1': 'iPad 2 (Wi-Fi)', 'iPad2,2': 'iPad 2 (GSM)', 'iPad2,3': 'iPad 2 (CDMA)', 'iPad2,4': 'iPad 2 (Wi-Fi Rev A)',
    'iPad3,1': 'iPad (3rd gen, Wi-Fi)', 'iPad3,2': 'iPad (3rd gen, Cellular)', 'iPad3,3': 'iPad (3rd gen, Global)',
    'iPad3,4': 'iPad (4th gen, Wi-Fi)', 'iPad3,5': 'iPad (4th gen, Cellular)', 'iPad3,6': 'iPad (4th gen, Global)',
    'iPad6,11': 'iPad (5th gen, Wi-Fi)', 'iPad6,12': 'iPad (5th gen, Cellular)',
    'iPad7,5': 'iPad (6th gen, Wi-Fi)', 'iPad7,6': 'iPad (6th gen, Cellular)',
    'iPad7,11': 'iPad (7th gen, Wi-Fi)', 'iPad7,12': 'iPad (7th gen, Cellular)',
    'iPad11,6': 'iPad (8th gen, Wi-Fi)', 'iPad11,7': 'iPad (8th gen, Cellular)',
    'iPad12,1': 'iPad (9th gen, Wi-Fi)', 'iPad12,2': 'iPad (9th gen, Cellular)',
    'iPad13,18': 'iPad (10th gen, Wi-Fi)', 'iPad13,19': 'iPad (10th gen, Cellular)',
    'iPad4,1': 'iPad Air (Wi-Fi)', 'iPad4,2': 'iPad Air (Cellular)', 'iPad5,3': 'iPad Air 2 (Wi-Fi)', 'iPad5,4': 'iPad Air 2 (Cellular)',
    'iPad11,3': 'iPad Air (3rd gen, Wi-Fi)', 'iPad11,4': 'iPad Air (3rd gen, Cellular)',
    'iPad13,1': 'iPad Air (4th gen, Wi-Fi)', 'iPad13,2': 'iPad Air (4th gen, Cellular)',
    'iPad13,16': 'iPad Air (5th gen, Wi-Fi)', 'iPad13,17': 'iPad Air (5th gen, Cellular)',
    'iPad14,8': 'iPad Air 11-inch (M2, Wi-Fi)', 'iPad14,9': 'iPad Air 11-inch (M2, Cellular)',
    'iPad14,10': 'iPad Air 13-inch (M2, Wi-Fi)', 'iPad14,11': 'iPad Air 13-inch (M2, Cellular)',
    'iPad2,5': 'iPad mini (Wi-Fi)', 'iPad2,6': 'iPad mini (Cellular)',
    'iPad4,4': 'iPad mini 2 (Wi-Fi)', 'iPad4,5': 'iPad mini 2 (Cellular)',
    'iPad4,7': 'iPad mini 3 (Wi-Fi)', 'iPad4,8': 'iPad mini 3 (Cellular)',
    'iPad5,1': 'iPad mini 4 (Wi-Fi)', 'iPad5,2': 'iPad mini 4 (Cellular)',
    'iPad11,1': 'iPad mini (5th gen, Wi-Fi)', 'iPad11,2': 'iPad mini (5th gen, Cellular)',
    'iPad14,1': 'iPad mini (6th gen, Wi-Fi)', 'iPad14,2': 'iPad mini (6th gen, Cellular)',
    'iPad6,3': 'iPad Pro 9.7-inch (Wi-Fi)', 'iPad6,4': 'iPad Pro 9.7-inch (Cellular)',
    'iPad6,7': 'iPad Pro 12.9-inch (1st gen, Wi-Fi)', 'iPad6,8': 'iPad Pro 12.9-inch (1st gen, Cellular)',
    'iPad7,1': 'iPad Pro 12.9-inch (2nd gen, Wi-Fi)', 'iPad7,2': 'iPad Pro 12.9-inch (2nd gen, Cellular)',
    'iPad7,3': 'iPad Pro 10.5-inch (Wi-Fi)', 'iPad7,4': 'iPad Pro 10.5-inch (Cellular)',
    'iPad8,1': 'iPad Pro 11-inch (1st gen, Wi-Fi)', 'iPad8,3': 'iPad Pro 11-inch (1st gen, Cellular)',
    'iPad8,5': 'iPad Pro 12.9-inch (3rd gen, Wi-Fi)', 'iPad8,7': 'iPad Pro 12.9-inch (3rd gen, Cellular)',
    'iPad8,9': 'iPad Pro 11-inch (2nd gen, Wi-Fi)', 'iPad8,10': 'iPad Pro 11-inch (2nd gen, Cellular)',
    'iPad8,11': 'iPad Pro 12.9-inch (4th gen, Wi-Fi)', 'iPad8,12': 'iPad Pro 12.9-inch (4th gen, Cellular)',
    'iPad13,4': 'iPad Pro 11-inch (3rd gen, M1, Wi-Fi)', 'iPad13,6': 'iPad Pro 11-inch (3rd gen, M1, Cellular)',
    'iPad13,8': 'iPad Pro 12.9-inch (5th gen, M1, Wi-Fi)', 'iPad13,10': 'iPad Pro 12.9-inch (5th gen, M1, Cellular)',
    'iPad14,3': 'iPad Pro 11-inch (4th gen, M2, Wi-Fi)', 'iPad14,4': 'iPad Pro 11-inch (4th gen, M2, Cellular)',
    'iPad14,5': 'iPad Pro 12.9-inch (6th gen, M2, Wi-Fi)', 'iPad14,6': 'iPad Pro 12.9-inch (6th gen, M2, Cellular)',
    'iPad16,3': 'iPad Pro 11-inch (M4, Wi-Fi)', 'iPad16,4': 'iPad Pro 11-inch (M4, Cellular)',
    'iPad16,5': 'iPad Pro 13-inch (M4, Wi-Fi)', 'iPad16,6': 'iPad Pro 13-inch (M4, Cellular)',

    // iPods
    'iPod1,1': 'iPod touch (1st gen)', 'iPod2,1': 'iPod touch (2nd gen)', 'iPod3,1': 'iPod touch (3rd gen)',
    'iPod4,1': 'iPod touch (4th gen)', 'iPod5,1': 'iPod touch (5th gen)', 'iPod7,1': 'iPod touch (6th gen)',
    'iPod9,1': 'iPod touch (7th gen)'
};

function parseSimplePlist(xml) {
    const result = {};
    if (!xml || typeof xml !== 'string') return result;
    const regex = /<key>([^<]+)<\/key>\s*<(string|integer|true|false|date|data)>([^<]*)<\/\2>/g;
    let match;
    while ((match = regex.exec(xml)) !== null) {
        const key = match[1];
        const type = match[2];
        const val = match[3];
        if (type === 'integer') {
            result[key] = parseInt(val, 10);
        } else if (type === 'true') {
            result[key] = true;
        } else if (type === 'false') {
            result[key] = false;
        } else {
            result[key] = val;
        }
    }
    return result;
}

function createUsbmuxPacket(plistStr, tag = 1) {
    const payloadBuf = Buffer.from(plistStr, 'utf8');
    const headerBuf = Buffer.alloc(16);
    const totalLength = 16 + payloadBuf.length;
    headerBuf.writeUInt32LE(totalLength, 0);
    headerBuf.writeUInt32LE(1, 4);
    headerBuf.writeUInt32LE(8, 8);
    headerBuf.writeUInt32LE(tag, 12);
    return Buffer.concat([headerBuf, payloadBuf]);
}

function findPairRecord(udid) {
    if (!udid) return null;
    const lockDir = 'C:\\ProgramData\\Apple\\Lockdown';
    if (!fs.existsSync(lockDir)) return null;

    const candidates = [
        path.join(lockDir, `${udid}.plist`),
        path.join(lockDir, `${udid.toLowerCase()}.plist`),
        path.join(lockDir, `${udid.toUpperCase()}.plist`),
        path.join(lockDir, `${udid.replace(/-/g, '')}.plist`),
        path.join(lockDir, `${udid.replace(/-/g, '').toLowerCase()}.plist`)
    ];

    for (const c of candidates) {
        if (fs.existsSync(c)) {
            const xml = fs.readFileSync(c, 'utf8');
            const parseTag = (tag) => {
                const m = xml.match(new RegExp(`<key>${tag}</key>\\s*<(string|data|integer)>([\\s\\S]*?)</\\1>`));
                return m ? m[2].trim() : null;
            };
            const hostCertB64 = parseTag('HostCertificate');
            const hostKeyB64 = parseTag('HostPrivateKey');
            const rootCertB64 = parseTag('RootCertificate');
            if (hostCertB64 && hostKeyB64) {
                return {
                    hostId: parseTag('HostID'),
                    systemBuid: parseTag('SystemBUID'),
                    hostCert: Buffer.from(hostCertB64, 'base64').toString('utf8'),
                    hostKey: Buffer.from(hostKeyB64, 'base64').toString('utf8'),
                    rootCert: rootCertB64 ? Buffer.from(rootCertB64, 'base64').toString('utf8') : null
                };
            }
        }
    }
    return null;
}

function queryLockdownInfo(deviceId, udid, timeoutMs = 3000) {
    return new Promise((resolve) => {
        let finished = false;
        const pairRecord = findPairRecord(udid);

        const client = net.connect(27015, '127.0.0.1', () => {
            const connectPlist = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>MessageType</key>
    <string>Connect</string>
    <key>ClientVersionString</key>
    <string>usbmuxd-1.0.8</string>
    <key>ProgName</key>
    <string>THAIVPN</string>
    <key>DeviceID</key>
    <integer>${deviceId}</integer>
    <key>PortNumber</key>
    <integer>32498</integer>
</dict>
</plist>`;
            client.write(createUsbmuxPacket(connectPlist));
        });

        let stage = 'usbmux_connect';
        let buf = Buffer.alloc(0);

        const sendPlaintextGetValue = () => {
            stage = 'plaintext_getvalue';
            const reqXml = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>THAIVPN</string>
    <key>Request</key>
    <string>GetValue</string>
</dict>
</plist>`;
            const xmlBuf = Buffer.from(reqXml, 'utf8');
            const lockHdr = Buffer.alloc(4);
            lockHdr.writeUInt32BE(xmlBuf.length, 0);
            client.write(Buffer.concat([lockHdr, xmlBuf]));
        };

        client.on('data', (chunk) => {
            buf = Buffer.concat([buf, chunk]);

            if (stage === 'usbmux_connect') {
                if (buf.length >= 16) {
                    const totalLen = buf.readUInt32LE(0);
                    if (buf.length >= totalLen) {
                        const respPlist = buf.slice(16, totalLen).toString('utf8');
                        const parsed = parseSimplePlist(respPlist);
                        buf = buf.slice(totalLen);

                        if (parsed.Number === 0) {
                            if (pairRecord && pairRecord.hostId && pairRecord.systemBuid) {
                                stage = 'start_session';
                                const startReq = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>THAIVPN</string>
    <key>Request</key>
    <string>StartSession</string>
    <key>HostID</key>
    <string>${pairRecord.hostId}</string>
    <key>SystemBUID</key>
    <string>${pairRecord.systemBuid}</string>
</dict>
</plist>`;
                                const p = Buffer.from(startReq, 'utf8');
                                const h = Buffer.alloc(4);
                                h.writeUInt32BE(p.length, 0);
                                client.write(Buffer.concat([h, p]));
                            } else {
                                sendPlaintextGetValue();
                            }
                        } else {
                            if (!finished) {
                                finished = true;
                                client.destroy();
                                resolve({ success: false, error: 'Cannot connect to lockdown: ' + (parsed.Number || 'Unknown') });
                            }
                        }
                    }
                }
            } else if (stage === 'start_session') {
                if (buf.length >= 4) {
                    const msgLen = buf.readUInt32BE(0);
                    if (buf.length >= 4 + msgLen) {
                        const sessionRespXml = buf.slice(4, 4 + msgLen).toString('utf8');
                        buf = buf.slice(4 + msgLen);

                        if (sessionRespXml.includes('EnableSessionSSL') || sessionRespXml.includes('SessionID')) {
                            // Upgrade to TLS
                            client.removeAllListeners('data');
                            try {
                                const tlsSocket = tls.connect({
                                    socket: client,
                                    cert: pairRecord.hostCert,
                                    key: pairRecord.hostKey,
                                    ca: pairRecord.rootCert ? [pairRecord.rootCert] : undefined,
                                    rejectUnauthorized: false,
                                    checkServerIdentity: () => undefined
                                }, () => {
                                    const qXml = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>THAIVPN</string>
    <key>Request</key>
    <string>GetValue</string>
</dict>
</plist>`;
                                    const qBuf = Buffer.from(qXml, 'utf8');
                                    const qHdr = Buffer.alloc(4);
                                    qHdr.writeUInt32BE(qBuf.length, 0);
                                    tlsSocket.write(Buffer.concat([qHdr, qBuf]));
                                });

                                let tlsBuf = Buffer.alloc(0);
                                tlsSocket.on('data', tChunk => {
                                    tlsBuf = Buffer.concat([tlsBuf, tChunk]);
                                    if (tlsBuf.length >= 4) {
                                        const tLen = tlsBuf.readUInt32BE(0);
                                        if (tlsBuf.length >= 4 + tLen && !finished) {
                                            finished = true;
                                            const fullXml = tlsBuf.slice(4, 4 + tLen).toString('utf8');
                                            tlsSocket.destroy();
                                            const parsed = parseSimplePlist(fullXml);
                                            resolve({ success: true, data: parsed, authenticated: true });
                                        }
                                    }
                                });
                                tlsSocket.on('error', (err) => {
                                    if (!finished) {
                                        finished = true;
                                        tlsSocket.destroy();
                                        resolve({ success: false, error: err.message });
                                    }
                                });
                            } catch (e) {
                                sendPlaintextGetValue();
                            }
                        } else {
                            sendPlaintextGetValue();
                        }
                    }
                }
            } else if (stage === 'plaintext_getvalue') {
                if (buf.length >= 4) {
                    const msgLen = buf.readUInt32BE(0);
                    if (buf.length >= 4 + msgLen && !finished) {
                        finished = true;
                        const xmlStr = buf.slice(4, 4 + msgLen).toString('utf8');
                        client.destroy();
                        const parsed = parseSimplePlist(xmlStr);
                        resolve({ success: true, data: parsed, authenticated: false, raw: xmlStr });
                    }
                }
            }
        });

        client.on('error', (err) => {
            if (!finished) {
                finished = true;
                resolve({ success: false, error: err.message });
            }
        });

        setTimeout(() => {
            if (!finished) {
                finished = true;
                client.destroy();
                resolve({ success: false, error: 'Lockdown timeout' });
            }
        }, timeoutMs);
    });
}

function check3uToolsCache(deviceProps) {
    try {
        const cacheDir = 'C:\\Program Files (x86)\\3uTools\\x86\\cache';
        if (!fs.existsSync(cacheDir)) return null;

        const files = fs.readdirSync(cacheDir);
        const udid = typeof deviceProps === 'string' ? deviceProps : (deviceProps.udid || deviceProps.serial || '');
        const cleanUdid = udid.replace(/-/g, '').toLowerCase();
        const rawUdid = udid.toLowerCase();
        const chipId = deviceProps.chipId ? String(deviceProps.chipId) : '';
        const wifi = deviceProps.wifi ? String(deviceProps.wifi).toLowerCase() : '';
        const serial = deviceProps.serial ? String(deviceProps.serial).toLowerCase() : '';

        for (const file of files) {
            if (!file.endsWith('_info.txt')) continue;
            const filePath = path.join(cacheDir, file);
            const content = fs.readFileSync(filePath, 'utf8');

            const matchUdid = (cleanUdid && content.toLowerCase().includes(cleanUdid)) || (rawUdid && content.toLowerCase().includes(rawUdid));
            const matchChip = chipId && content.includes(chipId);
            const matchWifi = wifi && content.toLowerCase().includes(wifi);
            const matchSerial = serial && !serial.includes('-') && content.toLowerCase().includes(serial);

            if (matchUdid || matchChip || matchWifi || matchSerial) {
                const lines = content.split(/\r?\n/);
                const data = {};
                lines.forEach(l => {
                    const parts = l.split(/\s{2,}/);
                    if (parts.length >= 2) {
                        data[parts[0].trim()] = parts[1].trim();
                    }
                });
                return data;
            }
        }
    } catch (e) {}
    return null;
}

async function detectConnectedIosDevice() {
    return new Promise((resolve) => {
        let client = net.connect(27015, '127.0.0.1', () => {
            const listPlist = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>MessageType</key>
    <string>ListDevices</string>
    <key>ClientVersionString</key>
    <string>usbmuxd-1.0.8</string>
    <key>ProgName</key>
    <string>THAIVPN</string>
</dict>
</plist>`;
            client.write(createUsbmuxPacket(listPlist));
        });

        let finished = false;
        let buf = Buffer.alloc(0);

        client.on('data', async (chunk) => {
            buf = Buffer.concat([buf, chunk]);
            if (buf.length >= 16) {
                const totalLen = buf.readUInt32LE(0);
                if (buf.length >= totalLen && !finished) {
                    finished = true;
                    const plistStr = buf.slice(16, totalLen).toString('utf8');
                    client.destroy();

                    const devices = [];
                    const dictRegex = /<dict>([\s\S]*?)<\/dict>/g;
                    let m;
                    while ((m = dictRegex.exec(plistStr)) !== null) {
                        const parsed = parseSimplePlist(m[1]);
                        if (parsed.DeviceID || parsed.SerialNumber) {
                            devices.push(parsed);
                        }
                    }

                    if (devices.length === 0) {
                        return resolve({ connected: false, message: 'No Apple devices connected' });
                    }

                    const rawDev = devices[0];
                    const devId = rawDev.DeviceID;
                    const serial = rawDev.SerialNumber || '';
                    const prodId = rawDev.ProductID || 0;

                    let mode = 'Normal';
                    let modeText = '🟢 เชื่อมต่อปกติ (Normal Mode)';
                    if (prodId === 4737 || prodId === 0x1281) {
                        mode = 'Recovery';
                        modeText = '🟡 Recovery Mode';
                    } else if (prodId === 4647 || prodId === 0x1227) {
                        mode = 'DFU';
                        modeText = '🔴 DFU Mode';
                    }

                    let lockdownRes = null;
                    if (mode === 'Normal') {
                        lockdownRes = await queryLockdownInfo(devId, serial);
                    }

                    let devData = (lockdownRes && lockdownRes.success && lockdownRes.data) ? lockdownRes.data : {};
                    let needTrust = false;
                    if (lockdownRes && !lockdownRes.success && (lockdownRes.error || '').includes('PasswordProtected')) {
                        needTrust = true;
                    }

                    // Deep check 3uTools cache to enrich or fallback any missing fields
                    const cached = check3uToolsCache({
                        udid: devData.UniqueDeviceID || serial,
                        serial: devData.SerialNumber || (serial.includes('-') ? '' : serial),
                        chipId: devData.UniqueChipID || devData.ChipID,
                        wifi: devData.WiFiAddress
                    });
                    if (cached) {
                        ['SerialNumber', 'ModelNumber', 'RegionInfo', 'InternationalMobileEquipmentIdentity', 'ActivationState', 'DeviceName', 'PhoneNumber'].forEach(k => {
                            if (!devData[k] && cached[k]) {
                                devData[k] = cached[k];
                            }
                        });
                        if (!devData.ProductType && cached.ProductType) devData.ProductType = cached.ProductType;
                        if (!devData.ProductVersion && cached.ProductVersion) devData.ProductVersion = cached.ProductVersion;
                        if (!devData.BuildVersion && cached.BuildVersion) devData.BuildVersion = cached.BuildVersion;
                    }

                    const productType = devData.ProductType || '';
                    const friendlyName = APPLE_DEVICE_MAP[productType] || devData.DeviceName || (productType ? `Apple ${productType}` : 'Apple iOS Device');
                    const deviceClass = devData.DeviceClass || (productType.startsWith('iPad') ? 'iPad' : (productType.startsWith('iPod') ? 'iPod' : 'iPhone'));

                    // Ensure SerialNumber is not the ECID/UDID format if real serial is known
                    let realSerial = devData.SerialNumber || '';
                    if (!realSerial || realSerial === serial) {
                        if (cached && cached.SerialNumber) {
                            realSerial = cached.SerialNumber;
                        } else if (!serial.includes('-')) {
                            realSerial = serial;
                        }
                    }

                    return resolve({
                        connected: true,
                        device: {
                            deviceId: devId,
                            name: friendlyName,
                            deviceName: devData.DeviceName || friendlyName,
                            productType: productType,
                            productVersion: devData.ProductVersion || '',
                            buildVersion: devData.BuildVersion || '',
                            serialNumber: realSerial || serial,
                            udid: devData.UniqueDeviceID || serial,
                            imei: devData.InternationalMobileEquipmentIdentity || devData.MobileEquipmentIdentifier || '',
                            modelNumber: devData.ModelNumber || '',
                            regionInfo: devData.RegionInfo || '',
                            hardwareModel: devData.HardwareModel || '',
                            deviceClass: deviceClass,
                            mode: mode,
                            modeText: modeText,
                            needTrust: needTrust,
                            activationState: devData.ActivationState || '',
                            phoneNumber: devData.PhoneNumber || '',
                            timestamp: Date.now()
                        }
                    });
                }
            }
        });

        client.on('error', (err) => {
            if (!finished) {
                finished = true;
                // Fallback check Windows PnP
                exec('powershell -NoProfile -Command "Get-CimInstance Win32_PnPEntity | Where-Object { $_.DeviceID -match \\"VID_05AC\\" } | Select-Object -First 1 Name, DeviceID"', (pnpErr, stdout) => {
                    if (!pnpErr && stdout && stdout.includes('VID_05AC')) {
                        return resolve({
                            connected: true,
                            device: {
                                name: 'Apple Device (USB PnP Detected)',
                                deviceName: 'Apple Device',
                                productType: '',
                                productVersion: '',
                                buildVersion: '',
                                serialNumber: '',
                                udid: '',
                                deviceClass: 'iPhone',
                                mode: 'Normal',
                                modeText: '🟢 เชื่อมต่อทาง USB (โปรดเริ่ม Apple Mobile Device Service)',
                                needTrust: true,
                                timestamp: Date.now()
                            }
                        });
                    }
                    resolve({ connected: false, error: err.message });
                });
            }
        });

        setTimeout(() => {
            if (!finished) {
                finished = true;
                client.destroy();
                resolve({ connected: false, error: 'Timeout' });
            }
        }, 2000);
    });
}

ipcMain.handle('get-connected-ios-device', async () => {
    return detectConnectedIosDevice();
});

// ==========================================
// 🍎 Apple iOS Flasher & Recovery Controller
// ==========================================
let currentIosFlashProcess = null;

ipcMain.handle('enter-ios-recovery', async (event, udid) => {
    try {
        const binAppleDir = path.join(__dirname, 'bin', 'apple');
        const enterExe = path.join(binAppleDir, 'ideviceenterrecovery.exe');

        if (fs.existsSync(enterExe)) {
            let targetUdid = udid;
            if (!targetUdid) {
                const idExe = path.join(binAppleDir, 'idevice_id.exe');
                if (fs.existsSync(idExe)) {
                    try {
                        const idOut = execSync(`"${idExe}" -l`, { cwd: binAppleDir, timeout: 3000 }).toString().trim();
                        const lines = idOut.split(/\r?\n/).filter(Boolean);
                        if (lines.length > 0) targetUdid = lines[0].trim();
                    } catch (errId) {}
                }
            }

            return new Promise((resolve) => {
                const args = targetUdid ? [targetUdid] : [];
                execFile(enterExe, args, { cwd: binAppleDir, timeout: 15000 }, (err, stdout, stderr) => {
                    const output = (stdout + '\n' + stderr).trim();
                    if (err && !output.includes('success')) {
                        return resolve({ success: false, error: output || err.message });
                    }
                    resolve({ success: true, message: 'ส่งคำสั่งเข้า Recovery Mode สำเร็จ รอเครื่องรีบูตเข้าหน้าจอรูปสายต่อคอม...', output });
                });
            });
        }

        return { success: false, error: 'ไม่พบไฟล์ ideviceenterrecovery.exe ในโฟลเดอร์ bin/apple' };
    } catch (e) {
        return { success: false, error: e.message };
    }
});

ipcMain.handle('exit-ios-recovery', async () => {
    try {
        const binAppleDir = path.join(__dirname, 'bin', 'apple');
        const futurerestoreExe = path.join(binAppleDir, 'futurerestore-v194.exe');

        if (fs.existsSync(futurerestoreExe)) {
            return new Promise((resolve) => {
                execFile(futurerestoreExe, ['-e'], { cwd: binAppleDir, timeout: 15000 }, (err, stdout, stderr) => {
                    const output = (stdout + '\n' + stderr).trim();
                    resolve({ success: true, message: 'ส่งคำสั่งออกจาก Recovery Mode สำเร็จ เครื่องกำลังรีบูตเข้าสู่ iOS...', output });
                });
            });
        }

        return { success: false, error: 'ไม่พบเครื่องมือ futurerestore ใน bin/apple' };
    } catch (e) {
        return { success: false, error: e.message };
    }
});

ipcMain.handle('enter-ios-pwndfu', async (event) => {
    try {
        const binAppleDir = path.join(__dirname, 'bin', 'apple');
        const gasterExe = path.join(binAppleDir, 'gaster.exe');

        if (!fs.existsSync(gasterExe)) {
            return { success: false, error: 'ไม่พบไฟล์ gaster.exe ในโฟลเดอร์ bin/apple' };
        }

        event.sender.send('ios-flash-log', {
            type: 'info',
            text: '[PWNDFU] เริ่มต้นกระบวนการรัน checkm8 exploit เข้าสู่โหมด P0WN-DFU (gaster pwn)...'
        });

        return new Promise((resolve) => {
            const proc = spawn(gasterExe, ['pwn'], { cwd: binAppleDir });
            let output = '';

            proc.stdout.on('data', (d) => {
                const txt = d.toString();
                output += txt;
                event.sender.send('ios-flash-log', { type: 'info', text: txt.trim() });
            });

            proc.stderr.on('data', (d) => {
                const txt = d.toString();
                output += txt;
                event.sender.send('ios-flash-log', { type: 'warning', text: txt.trim() });
            });

            proc.on('close', (code) => {
                const lower = output.toLowerCase();
                if (code === 0 || lower.includes('now you can boot') || lower.includes('pwned') || output.includes('PWND')) {
                    event.sender.send('ios-flash-log', {
                        type: 'success',
                        text: '[SUCCESS] อุปกรณ์เข้าสู่โหมด P0WN-DFU สำเร็จแล้ว! (Checkm8 SecureROM Exploited)'
                    });
                    resolve({ success: true, message: 'เข้าสู่โหมด P0WN-DFU สำเร็จเรียบร้อย!', output });
                } else {
                    event.sender.send('ios-flash-log', {
                        type: 'error',
                        text: `[ERROR] การเข้า P0WN-DFU ไม่สำเร็จ (Exit code: ${code}). หากเครื่องอยู่ใน DFU Mode แล้วแต่ไม่ผ่าน แนะนำให้ใช้ Zadig ติดตั้งไดรเวอร์ libusbK`
                    });
                    resolve({
                        success: false,
                        error: output.trim() || `Exit code: ${code}. ตรวจสอบว่าเครื่องอยู่ใน DFU Mode หรือใช้ Zadig ติดตั้งไดรเวอร์ libusbK`,
                        output
                    });
                }
            });

            proc.on('error', (err) => {
                event.sender.send('ios-flash-log', { type: 'error', text: `[FATAL] เกิดข้อผิดพลาด: ${err.message}` });
                resolve({ success: false, error: err.message });
            });

            setTimeout(() => {
                try {
                    proc.kill();
                } catch(e) {}
            }, 35000);
        });
    } catch (e) {
        return { success: false, error: e.message };
    }
});

ipcMain.handle('browse-ipsw-file', async () => {
    try {
        const res = await dialog.showOpenDialog({
            title: 'เลือกไฟล์ Apple Firmware (.ipsw)',
            properties: ['openFile'],
            filters: [
                { name: 'Apple iOS Firmware (*.ipsw)', extensions: ['ipsw'] },
                { name: 'All Files (*.*)', extensions: ['*'] }
            ]
        });

        if (res.canceled || !res.filePaths || res.filePaths.length === 0) {
            return { canceled: true };
        }

        const filePath = res.filePaths[0];
        const stats = fs.statSync(filePath);
        return {
            canceled: false,
            filePath: filePath,
            fileName: path.basename(filePath),
            sizeBytes: stats.size,
            sizeFormatted: (stats.size / (1024 * 1024 * 1024)).toFixed(2) + ' GB'
        };
    } catch (e) {
        return { canceled: true, error: e.message };
    }
});

ipcMain.handle('start-ios-flash', async (event, { ipswPath, mode, isCellular }) => {
    if (currentIosFlashProcess) {
        return { success: false, error: 'กระบวนการแฟลชเครื่องเดิมกำลังทำงานอยู่ โปรดรอก่อนหรือกดปุ่มยกเลิก' };
    }

    if (!ipswPath || !fs.existsSync(ipswPath)) {
        return { success: false, error: 'ไม่พบไฟล์ IPSW ตามพาธที่ระบุ: ' + ipswPath };
    }

    const binAppleDir = path.join(__dirname, 'bin', 'apple');
    const idevicerestoreExe = path.join(binAppleDir, 'idevicerestore.exe');
    const futurerestoreExe = path.join(binAppleDir, 'futurerestore-v194.exe');

    let flasherExe = '';
    let isIdeviceRestore = false;
    if (fs.existsSync(idevicerestoreExe)) {
        flasherExe = idevicerestoreExe;
        isIdeviceRestore = true;
    } else if (fs.existsSync(futurerestoreExe)) {
        flasherExe = futurerestoreExe;
        isIdeviceRestore = false;
    } else {
        return { success: false, error: 'ไม่พบเครื่องมือแฟลช idevicerestore หรือ futurerestore ใน bin/apple' };
    }

    return new Promise((resolve) => {
        const isCleanErase = (mode === 'clean');
        const args = [];
        if (isIdeviceRestore) {
            if (isCleanErase) {
                args.push('-e'); // Erase all data (Full wipe) ONLY when clean mode is explicitly requested
            }
            args.push('-y'); // Non-interactive mode
            args.push('-P'); // Plain progress
            args.push('-d'); // Debug output
            args.push(ipswPath);
        } else {
            if (!isCleanErase) {
                args.push('-u'); // Update mode in futurerestore
            }
            args.push('--latest-sep');
            if (isCellular === false) {
                args.push('--no-baseband');
            } else {
                args.push('--latest-baseband');
            }
            args.push('-d');
            args.push(ipswPath);
        }

        event.sender.send('ios-flash-log', {
            type: 'primary',
            text: `[RESTORE ENGINE] Core: ${path.basename(flasherExe)} | โหมดที่เลือก: ${isCleanErase ? 'Clean Restore (ล้างเครื่องใหม่หมด)' : 'Retain User Data (อัพเดทเก็บข้อมูลเดิม)'}`
        });

        if (isCleanErase) {
            event.sender.send('ios-flash-log', {
                type: 'warning',
                text: '⚠️ [MODE AUDIT] โหมด: CLEAN RESTORE -> กำลังเปิดใช้แฟล็ก -e (ข้อมูลและพาร์ติชันทั้งหมดใน iPhone จะถูกฟอร์แมต)'
            });
        } else {
            event.sender.send('ios-flash-log', {
                type: 'success',
                text: '🛡️ [MODE AUDIT] โหมด: RETAIN USER DATA -> ยืนยัน: ไม่ส่งแฟล็ก -e (ข้อมูล รูปภาพ แชท และแอปเดิมในเครื่องจะถูกเก็บรักษาไว้ 100%)'
            });
        }

        event.sender.send('ios-flash-log', {
            type: 'info',
            text: `[EXECUTE COMMAND] ${path.basename(flasherExe)} ${args.join(' ')}`
        });
        event.sender.send('ios-flash-progress', { percent: 5, stage: 'กำลังเตรียมการแฟลชและตรวจสอบคอมโพเนนต์...' });

        const proc = spawn(flasherExe, args, { cwd: binAppleDir });
        currentIosFlashProcess = proc;

        let accumulatedPercent = 5;

        const parseStream = (chunk) => {
            const lines = chunk.toString().split(/\r?\n/);
            for (const line of lines) {
                if (!line.trim()) continue;

                let logType = 'info';
                if (line.toLowerCase().includes('error') || line.toLowerCase().includes('failed')) logType = 'error';
                else if (line.toLowerCase().includes('warn')) logType = 'warning';
                else if (line.toLowerCase().includes('done') || line.toLowerCase().includes('success') || line.toLowerCase().includes('verified')) logType = 'success';

                event.sender.send('ios-flash-log', { type: logType, text: line });

                const pctMatch = line.match(/(\d{1,3})%/);
                if (pctMatch) {
                    const parsed = parseInt(pctMatch[1], 10);
                    if (!isNaN(parsed) && parsed >= accumulatedPercent && parsed <= 100) {
                        accumulatedPercent = parsed;
                        event.sender.send('ios-flash-progress', { percent: accumulatedPercent, stage: `กำลังประมวลผล... (${accumulatedPercent}%)` });
                    }
                } else if (line.includes('Extracting filesystem')) {
                    accumulatedPercent = Math.max(accumulatedPercent, 15);
                    event.sender.send('ios-flash-progress', { percent: accumulatedPercent, stage: 'กำลังแตกไฟล์ Root Filesystem จาก IPSW (15%)...' });
                } else if (line.includes('Sending iBSS') || line.includes('Sending iBEC')) {
                    accumulatedPercent = Math.max(accumulatedPercent, 25);
                    event.sender.send('ios-flash-progress', { percent: accumulatedPercent, stage: 'กำลังส่ง Bootloader (iBSS/iBEC) เข้าเครื่อง (25%)...' });
                } else if (line.includes('Restoring image') || line.includes('writing')) {
                    accumulatedPercent = Math.max(accumulatedPercent, 50);
                    event.sender.send('ios-flash-progress', { percent: accumulatedPercent, stage: 'กำลังเขียนระบบปฏิบัติการ iOS ลงหน่วยความจำเครื่อง...' });
                } else if (line.includes('Flashing baseband') || line.includes('baseband')) {
                    accumulatedPercent = Math.max(accumulatedPercent, 85);
                    event.sender.send('ios-flash-progress', { percent: accumulatedPercent, stage: 'กำลังแฟลชโมเด็มและ Baseband Firmware (85%)...' });
                } else if (line.includes('Restoring finished') || line.includes('Restore done')) {
                    accumulatedPercent = 100;
                    event.sender.send('ios-flash-progress', { percent: 100, stage: 'แฟลชเสร็จสมบูรณ์ 100% เครื่องกำลังรีสตาร์ท!' });
                }
            }
        };

        proc.stdout.on('data', parseStream);
        proc.stderr.on('data', parseStream);

        proc.on('close', (code) => {
            currentIosFlashProcess = null;
            if (code === 0) {
                event.sender.send('ios-flash-progress', { percent: 100, stage: 'แฟลชเสร็จสิ้นสำเร็จ 100%' });
                event.sender.send('ios-flash-log', { type: 'success', text: '[SUCCESS] การแฟลช iOS เสร็จสมบูรณ์เรียบร้อย 100% เครื่องกำลังบูตเข้าระบบ' });
                resolve({ success: true, message: 'การแฟลช iOS เสร็จสิ้นสมบูรณ์เรียบร้อยแล้ว!' });
            } else {
                event.sender.send('ios-flash-log', { type: 'error', text: `[ERROR] กระบวนการแฟลชสิ้นสุดด้วยข้อผิดพลาด (Exit Code: ${code})` });
                resolve({ success: false, error: `การแฟลชไม่สำเร็จ (Exit Code: ${code}) ตรวจสอบบันทึก Log ด้านบน` });
            }
        });

        proc.on('error', (err) => {
            currentIosFlashProcess = null;
            event.sender.send('ios-flash-log', { type: 'error', text: `[FATAL] เกิดข้อผิดพลาดในการรัน Flasher: ${err.message}` });
            resolve({ success: false, error: err.message });
        });
    });
});

ipcMain.handle('stop-ios-flash', async () => {
    if (!currentIosFlashProcess) {
        return { success: false, message: 'ไม่มีกระบวนการแฟลชที่กำลังทำงานอยู่' };
    }
    try {
        currentIosFlashProcess.kill('SIGKILL');
        currentIosFlashProcess = null;
        return { success: true, message: 'ยกเลิกกระบวนการแฟลชเรียบร้อยแล้ว' };
    } catch (e) {
        return { success: false, error: e.message };
    }
});






// ============================================================================
// IN-APP AUTO-UPDATER IPC HANDLERS
// ============================================================================
ipcMain.handle('check-for-updates', async (event, customUrl) => {
    return await updater.checkForUpdates(customUrl);
});

ipcMain.handle('start-download-update', async (event, targetUrl) => {
    try {
        if (!targetUrl) throw new Error('No download URL provided');
        const isInstaller = targetUrl.endsWith('.exe');
        const ext = isInstaller ? '.exe' : '.zip';
        const tempPath = path.join(app.getPath('temp'), `thaivpn_update_${Date.now()}${ext}`);

        const res = await updater.downloadFileWithProgress(targetUrl, tempPath, (progress) => {
            if (!event.sender.isDestroyed()) {
                event.sender.send('update-progress', progress);
            }
        });

        return {
            success: true,
            filePath: res.filePath,
            isInstaller: isInstaller
        };
    } catch (err) {
        console.error('[UPDATER] Download error:', err);
        return {
            success: false,
            error: err.message
        };
    }
});

ipcMain.handle('apply-update-and-restart', async (event, args) => {
    try {
        const filePath = args ? args.filePath : null;
        const isInstaller = args ? args.isInstaller : false;
        if (!filePath || !fs.existsSync(filePath)) {
            throw new Error('Update payload file not found: ' + filePath);
        }
        return await updater.applyUpdate(filePath, isInstaller);
    } catch (err) {
        console.error('[UPDATER] Apply error:', err);
        return {
            success: false,
            error: err.message
        };
    }
});

ipcMain.handle('get-app-version', async () => {
    return updater.getAppVersion();
});

const { app } = require('electron');
const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');
const { spawn } = require('child_process');
const AdmZip = require('adm-zip');

/**
 * THAIVPN Tools In-App Auto-Updater Engine
 * Supports:
 * - Remote Version Checking via HTTP/HTTPS (Supports redirects)
 * - Semantic Version Comparison
 * - Fast Hot-Patch (.zip) with Background Download & Progress
 * - Safe Windows Swapper Batch for Zero File-Locking
 * - Full Silent Installer (.exe) execution
 */

function getAppVersion() {
    try {
        const pkgPath = path.join(__dirname, 'package.json');
        if (fs.existsSync(pkgPath)) {
            const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
            return pkg.version || '2.0.0';
        }
    } catch (e) {
        console.error('[UPDATER] Failed to read package.json version:', e);
    }
    return app ? app.getVersion() : '2.0.0';
}

function getUpdateConfig() {
    try {
        const cfgPath = path.join(__dirname, 'update_config.json');
        if (fs.existsSync(cfgPath)) {
            return JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
        }
    } catch (e) {
        console.error('[UPDATER] Failed to read update_config.json:', e);
    }
    return {
        manifestUrl: "https://raw.githubusercontent.com/THAIVPN-TOOLS/releases/main/version.json",
        autoCheckOnStartup: true,
        checkDelaySeconds: 4
    };
}

/**
 * Compare two semver strings: returns 1 if v1 > v2, -1 if v1 < v2, 0 if equal
 */
function compareVersions(v1, v2) {
    if (!v1 || !v2) return 0;
    const clean = (v) => v.replace(/^v/i, '').trim();
    const p1 = clean(v1).split('.').map(n => parseInt(n, 10) || 0);
    const p2 = clean(v2).split('.').map(n => parseInt(n, 10) || 0);
    
    for (let i = 0; i < Math.max(p1.length, p2.length); i++) {
        const num1 = p1[i] || 0;
        const num2 = p2[i] || 0;
        if (num1 > num2) return 1;
        if (num1 < num2) return -1;
    }
    return 0;
}

/**
 * Helper to fetch URL with automatic redirect support (up to 5 redirects)
 */
function fetchBufferWithRedirect(targetUrl, maxRedirects = 5) {
    return new Promise((resolve, reject) => {
        if (maxRedirects <= 0) {
            return reject(new Error('Too many redirects while fetching ' + targetUrl));
        }

        const parsedUrl = new URL(targetUrl);
        const client = parsedUrl.protocol === 'https:' ? https : http;

        const req = client.get(targetUrl, {
            headers: {
                'User-Agent': 'THAIVPN-Tools-Updater/' + getAppVersion(),
                'Cache-Control': 'no-cache'
            }
        }, (res) => {
            if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
                const nextUrl = new URL(res.headers.location, targetUrl).href;
                return resolve(fetchBufferWithRedirect(nextUrl, maxRedirects - 1));
            }

            if (res.statusCode !== 200) {
                return reject(new Error(`HTTP ${res.statusCode}: ${res.statusMessage}`));
            }

            const chunks = [];
            res.on('data', (chunk) => chunks.push(chunk));
            res.on('end', () => resolve(Buffer.concat(chunks)));
        });

        req.on('error', reject);
        req.setTimeout(15000, () => {
            req.destroy();
            reject(new Error('Request timed out'));
        });
    });
}

/**
 * Check if a new version is available from remote server
 */
async function checkForUpdates(overrideUrl = null) {
    const config = getUpdateConfig();
    const manifestUrl = overrideUrl || config.manifestUrl;
    const currentVersion = getAppVersion();

    try {
        console.log('[UPDATER] Checking for updates at:', manifestUrl);
        const buf = await fetchBufferWithRedirect(manifestUrl);
        const manifest = JSON.parse(buf.toString('utf8'));

        const remoteVersion = manifest.version || '0.0.0';
        const isNewer = compareVersions(remoteVersion, currentVersion) > 0;

        return {
            success: true,
            updateAvailable: isNewer,
            currentVersion: currentVersion,
            latestVersion: remoteVersion,
            releaseDate: manifest.releaseDate || '2026-09-12',
            title: manifest.title || `THAIVPN Tools v${remoteVersion}`,
            changelog: manifest.changelog || [],
            patchUrl: manifest.patchUrl || null,
            installerUrl: manifest.installerUrl || null,
            packageSize: manifest.packageSize || null
        };
    } catch (err) {
        console.warn('[UPDATER] Update check error:', err.message);
        return {
            success: false,
            updateAvailable: false,
            currentVersion: currentVersion,
            error: err.message
        };
    }
}

/**
 * Download update with streaming progress callback
 */
function downloadFileWithProgress(targetUrl, destinationPath, onProgress, maxRedirects = 5) {
    return new Promise((resolve, reject) => {
        if (maxRedirects <= 0) {
            return reject(new Error('Too many redirects while downloading ' + targetUrl));
        }

        const parsedUrl = new URL(targetUrl);
        const client = parsedUrl.protocol === 'https:' ? https : http;

        const req = client.get(targetUrl, {
            headers: {
                'User-Agent': 'THAIVPN-Tools-Updater/' + getAppVersion()
            }
        }, (res) => {
            if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
                const nextUrl = new URL(res.headers.location, targetUrl).href;
                return resolve(downloadFileWithProgress(nextUrl, destinationPath, onProgress, maxRedirects - 1));
            }

            if (res.statusCode !== 200) {
                return reject(new Error(`HTTP ${res.statusCode} while downloading update`));
            }

            const totalBytes = parseInt(res.headers['content-length'], 10) || 0;
            let downloadedBytes = 0;

            const fileStream = fs.createWriteStream(destinationPath);

            res.on('data', (chunk) => {
                downloadedBytes += chunk.length;
                if (typeof onProgress === 'function') {
                    const percent = totalBytes > 0 ? Math.round((downloadedBytes / totalBytes) * 100) : 0;
                    onProgress({
                        percent: percent,
                        transferred: downloadedBytes,
                        total: totalBytes
                    });
                }
            });

            res.pipe(fileStream);

            fileStream.on('finish', () => {
                fileStream.close(() => resolve({ success: true, filePath: destinationPath }));
            });

            fileStream.on('error', (err) => {
                fs.unlink(destinationPath, () => {});
                reject(err);
            });
        });

        req.on('error', (err) => {
            fs.unlink(destinationPath, () => {});
            reject(err);
        });

        req.setTimeout(60000, () => {
            req.destroy();
            fs.unlink(destinationPath, () => {});
            reject(new Error('Download timed out'));
        });
    });
}

/**
 * Apply Hot-Patch or Installer
 */
async function applyUpdate(updateFilePath, isInstaller = false) {
    if (!fs.existsSync(updateFilePath)) {
        throw new Error('Update file not found: ' + updateFilePath);
    }

    // 1. If it's a full installer exe: launch silently
    if (isInstaller || updateFilePath.endsWith('.exe')) {
        console.log('[UPDATER] Launching silent installer:', updateFilePath);
        const child = spawn(updateFilePath, ['/S'], {
            detached: true,
            stdio: 'ignore'
        });
        child.unref();
        setTimeout(() => {
            app.exit(0);
        }, 500);
        return { success: true, message: 'Installer launched' };
    }

    // 2. If it's a hot-patch zip:
    const isPackaged = app ? app.isPackaged : false;
    const isDev = !isPackaged;

    if (isDev) {
        // In development mode, extract directly into project root directory
        console.log('[UPDATER] Development mode: Extracting patch to:', __dirname);
        const zip = new AdmZip(updateFilePath);
        zip.extractAllTo(__dirname, true);
        
        setTimeout(() => {
            app.relaunch();
            app.exit(0);
        }, 800);
        return { success: true, message: 'Hot patch applied, restarting...' };
    }

    // In Packaged Production mode:
    // Extract to temp folder, then create a detached swapper .bat that runs after app closes
    const tempStageDir = path.join(app.getPath('temp'), 'thaivpn_update_staging_' + Date.now());
    fs.mkdirSync(tempStageDir, { recursive: true });

    const zip = new AdmZip(updateFilePath);
    zip.extractAllTo(tempStageDir, true);

    const appDir = path.dirname(process.execPath);
    const resourcesDir = process.resourcesPath || path.join(appDir, 'resources');
    const exePath = process.execPath;
    const batPath = path.join(app.getPath('temp'), 'thaivpn_swap_' + Date.now() + '.bat');

    // Batch script waits 1.2s for this process to close, copies files into app directory, launches exe, and removes itself
    const batContent = `@echo off
timeout /t 2 /nobreak > nul
xcopy "${tempStageDir}\*" "${resourcesDir}\" /s /e /y /q
xcopy "${tempStageDir}\*" "${appDir}\" /s /e /y /q
start "" "${exePath}"
rmdir /s /q "${tempStageDir}"
del "%~f0"
exit
`;

    fs.writeFileSync(batPath, batContent, 'utf8');

    console.log('[UPDATER] Spawning Windows Swapper Bat:', batPath);
    const child = spawn('cmd.exe', ['/c', batPath], {
        detached: true,
        stdio: 'ignore',
        windowsHide: true
    });
    child.unref();

    setTimeout(() => {
        app.exit(0);
    }, 600);

    return { success: true, message: 'Swapper bat initiated, restarting...' };
}

module.exports = {
    getAppVersion,
    getUpdateConfig,
    compareVersions,
    checkForUpdates,
    downloadFileWithProgress,
    applyUpdate
};

// ============================================================================
// 🎨 UNIVERSAL MODERN GLASSMORPHISM ALERT, CONFIRM & PROMPT MANAGER
// Automatically intercepts all alert(), confirm(), prompt() calls across the entire app
// ============================================================================
(function() {
    let alertResolve = null;

    function showModernDialog({ message, title = null, type = 'info', isConfirm = false, isPrompt = false, defaultValue = '' }) {
        return new Promise((resolve) => {
            alertResolve = resolve;

            const modal = document.getElementById('global-alert-modal');
            const card = document.getElementById('global-alert-card');
            const iconWrap = document.getElementById('global-alert-icon-wrap');
            const icon = document.getElementById('global-alert-icon');
            const titleEl = document.getElementById('global-alert-title');
            const msgEl = document.getElementById('global-alert-message');
            const inputWrap = document.getElementById('global-alert-input-wrap');
            const inputEl = document.getElementById('global-alert-input');
            const btnCancel = document.getElementById('btn-global-alert-cancel');
            const btnOk = document.getElementById('btn-global-alert-ok');
            const strip = document.getElementById('global-alert-strip');

            if (!modal) {
                // If DOM not loaded yet, fallback to native console
                console.warn('[ALERT FALLBACK]', message);
                return resolve(true);
            }

            // Detect type automatically from text content if not explicitly specified
            const lower = String(message || '').toLowerCase();
            if (type === 'info') {
                if (lower.includes('error') || lower.includes('failed') || lower.includes('fail') || lower.includes('404') || lower.includes('ไม่สำเร็จ') || lower.includes('ล้มเหลว') || lower.includes('ผิดพลาด')) {
                    type = 'error';
                } else if (lower.includes('warning') || lower.includes('เตือน') || lower.includes('ระวัง') || lower.includes('ลบ') || lower.includes('reset') || isConfirm) {
                    type = 'warning';
                } else if (lower.includes('สำเร็จ') || lower.includes('success') || lower.includes('ok') || lower.includes('เรียบร้อย') || lower.includes('ล่าสุด')) {
                    type = 'success';
                }
            }

            // Apply modern theme per type
            if (type === 'error') {
                if (!title) title = 'เกิดข้อผิดพลาด';
                if (iconWrap) {
                    iconWrap.style.background = 'rgba(239, 68, 68, 0.15)';
                    iconWrap.style.borderColor = 'rgba(239, 68, 68, 0.35)';
                    iconWrap.style.color = '#f87171';
                    iconWrap.style.boxShadow = '0 0 20px rgba(239, 68, 68, 0.3)';
                }
                if (icon) icon.className = 'fas fa-exclamation-circle';
                if (strip) strip.style.background = 'linear-gradient(90deg, #ef4444, #f87171)';
                if (btnOk) {
                    btnOk.style.background = 'linear-gradient(135deg, #dc2626, #ef4444)';
                    btnOk.style.boxShadow = '0 4px 15px rgba(239, 68, 68, 0.35)';
                }
            } else if (type === 'warning') {
                if (!title) title = isConfirm ? 'ยืนยันการทำรายการ' : 'ข้อควรระวัง';
                if (iconWrap) {
                    iconWrap.style.background = 'rgba(245, 158, 11, 0.15)';
                    iconWrap.style.borderColor = 'rgba(245, 158, 11, 0.35)';
                    iconWrap.style.color = '#fbbf24';
                    iconWrap.style.boxShadow = '0 0 20px rgba(245, 158, 11, 0.3)';
                }
                if (icon) icon.className = 'fas fa-exclamation-triangle';
                if (strip) strip.style.background = 'linear-gradient(90deg, #f59e0b, #fbbf24)';
                if (btnOk) {
                    btnOk.style.background = 'linear-gradient(135deg, #d97706, #f59e0b)';
                    btnOk.style.boxShadow = '0 4px 15px rgba(245, 158, 11, 0.35)';
                }
            } else if (type === 'success') {
                if (!title) title = 'ดำเนินการสำเร็จ';
                if (iconWrap) {
                    iconWrap.style.background = 'rgba(34, 197, 94, 0.15)';
                    iconWrap.style.borderColor = 'rgba(34, 197, 94, 0.35)';
                    iconWrap.style.color = '#4ade80';
                    iconWrap.style.boxShadow = '0 0 20px rgba(34, 197, 94, 0.3)';
                }
                if (icon) icon.className = 'fas fa-check-circle';
                if (strip) strip.style.background = 'linear-gradient(90deg, #22c55e, #4ade80)';
                if (btnOk) {
                    btnOk.style.background = 'linear-gradient(135deg, #16a34a, #22c55e)';
                    btnOk.style.boxShadow = '0 4px 15px rgba(34, 197, 94, 0.35)';
                }
            } else {
                if (!title) title = 'แจ้งเตือนระบบ';
                if (iconWrap) {
                    iconWrap.style.background = 'rgba(56, 189, 248, 0.15)';
                    iconWrap.style.borderColor = 'rgba(56, 189, 248, 0.35)';
                    iconWrap.style.color = '#38bdf8';
                    iconWrap.style.boxShadow = '0 0 20px rgba(56, 189, 248, 0.3)';
                }
                if (icon) icon.className = 'fas fa-info-circle';
                if (strip) strip.style.background = 'linear-gradient(90deg, #38bdf8, #818cf8)';
                if (btnOk) {
                    btnOk.style.background = 'linear-gradient(135deg, #0284c7, #38bdf8)';
                    btnOk.style.boxShadow = '0 4px 15px rgba(56, 189, 248, 0.35)';
                }
            }

            if (titleEl) titleEl.textContent = title;
            if (msgEl) msgEl.textContent = String(message || '');

            if (isPrompt) {
                if (inputWrap) inputWrap.style.display = 'block';
                if (inputEl) {
                    inputEl.value = defaultValue || '';
                    setTimeout(() => { inputEl.focus(); inputEl.select(); }, 60);
                }
            } else {
                if (inputWrap) inputWrap.style.display = 'none';
            }

            if (isConfirm || isPrompt) {
                if (btnCancel) btnCancel.style.display = 'block';
                if (btnOk) {
                    btnOk.style.flex = '1';
                    btnOk.textContent = 'ยืนยัน';
                }
            } else {
                if (btnCancel) btnCancel.style.display = 'none';
                if (btnOk) {
                    btnOk.style.flex = '2';
                    btnOk.textContent = 'ตกลง';
                }
            }

            modal.style.display = 'flex';
            setTimeout(() => {
                if (card) card.style.transform = 'scale(1)';
                if (btnOk && !isPrompt) btnOk.focus();
            }, 10);

            function closeModal(result) {
                if (card) card.style.transform = 'scale(0.95)';
                setTimeout(() => {
                    if (modal) modal.style.display = 'none';
                }, 140);
                window.removeEventListener('keydown', onKey);
                if (alertResolve) {
                    alertResolve(result);
                    alertResolve = null;
                }
            }

            if (btnOk) {
                btnOk.onclick = () => {
                    if (isPrompt && inputEl) {
                        closeModal(inputEl.value);
                    } else {
                        closeModal(true);
                    }
                };
            }

            if (btnCancel) {
                btnCancel.onclick = () => {
                    closeModal(isPrompt ? null : false);
                };
            }

            function onKey(e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    if (btnOk) btnOk.click();
                } else if (e.key === 'Escape') {
                    e.preventDefault();
                    if (isConfirm || isPrompt) {
                        if (btnCancel) btnCancel.click();
                    } else {
                        if (btnOk) btnOk.click();
                    }
                }
            }
            window.addEventListener('keydown', onKey);
        });
    }

    // 1. OVERRIDE GLOBAL alert()
    window.alert = function(msg) {
        return showModernDialog({ message: msg });
    };

    // 2. OVERRIDE GLOBAL confirm()
    window.confirm = function(msg) {
        return showModernDialog({ message: msg, isConfirm: true });
    };

    // 3. OVERRIDE GLOBAL prompt()
    window.prompt = function(msg, def) {
        return showModernDialog({ message: msg, isPrompt: true, defaultValue: def });
    };

    // 4. EXPLICIT HELPER APIs
    window.showCustomAlert = function(msg, type = 'info', title = null) {
        return showModernDialog({ message: msg, type, title });
    };

    window.showCustomConfirm = function(msg, title = null) {
        return showModernDialog({ message: msg, isConfirm: true, title });
    };

    window.showCustomPrompt = function(msg, def = '', title = null) {
        return showModernDialog({ message: msg, isPrompt: true, defaultValue: def, title });
    };
})();

// Translations
const translations = {
    en: {
        nav_sys: "System Tools",
        nav_clean: "PC Cleanup",
        nav_test: "Test Mode",
                header_sys_title: "System Tools",
        header_sys_desc: "Manage your device and network settings.",
        card_dev_title: "Device Manager",
        card_dev_desc: "Open Windows Device Manager",
        card_dev_btn: "Launch",
        card_reg_title: "Network Registry",
        card_reg_desc: "Open Registry for Network Reset",
        card_reg_btn: "Launch",
        card_store_title: "Reserved Storage",
        card_store_desc: "Disable Windows Reserved Storage",
        card_store_btn: "Disable (Admin)",
        // Network Tools
        hdr_net_tools: "🌐 Network Tools",
        hdr_drv_tools: "📱 Driver Tools",
        hdr_maint_tools: "🔧 Maintenance",
        hdr_quick_launch: "⚡ Quick Launch",
        btn_net_reset: "Network Reset",
        btn_flush_dns: "Flush DNS",
        btn_show_ip: "Show IP Info",
        btn_ping_test: "Ping Test",
        btn_proxy: "Proxy Settings",
        // Driver Tools
        btn_drv_adb: "ADB Driver",
        btn_drv_mtk: "MTK (VCOM)",
        btn_drv_qcom: "Qualcomm 9008",
        btn_drv_spd: "SPD Driver",
        btn_drv_samsung: "Samsung USB",
        btn_drv_zadig: "Zadig",
        // Maintenance
        btn_chkdsk: "CHKDSK (C:)",
        btn_sfc: "SFC /scannow",
        btn_dism: "DISM Repair",
        btn_startup: "Startup Apps",
        btn_msinfo: "System Info",
        btn_services: "Services",
        // Quick Launch
        btn_taskmgr: "Task Manager",
        btn_calc: "Calculator",
        btn_notepad: "Notepad",
        btn_snip: "Snipping Tool",
        btn_paint: "Paint",
        btn_diskmgmt: "Disk Management",
        card_def_title: "Windows Defender",
        card_def_desc: "Turn Real-time Protection On/Off",
        btn_def_off: "Disable (Admin)",
        btn_def_on: "Enable (Admin)",
        card_hosts_title: "Hosts Editor",
        card_hosts_desc: "Edit Windows hosts file to block servers",
        btn_hosts: "Edit Hosts (Admin)",
        card_ncpa_title: "Network Adapters",
        card_ncpa_desc: "Open Network Connections (ncpa.cpl)",
        btn_ncpa: "Open Network",
        header_clean_title: "PC Cleanup Tool",
        header_clean_desc: "Free up disk space by clearing caches and temporary files.",
        drive_c_title: "C: Drive (Windows System)",
        drive_free_text: "Free:",
        drive_total_text: "Total:",
        drive_used_text: "Used",
        drive_usage_pct: "Disk Usage",
        btn_smart_clean: "⚡ 1-Click Smart Clean",
        smart_clean_hint: "Instantly clean safe high-impact caches and temp files",
        preset_safe: "Recommended (Safe)",
        preset_all: "Select All (Deep)",
        preset_none: "Deselect All",
        chk_temp_title: "Windows Temp Files",
        chk_temp_desc: "User Temp, Windows Temp, Prefetch, Thumbnails, Delivery Opt.",
        chk_trash_title: "Recycle Bin & Crash Dumps",
        chk_trash_desc: "Empty Recycle Bin, Minidumps, BSOD Dumps, WER Reports",
        chk_shader_title: "DirectX & GPU Shader Caches",
        chk_shader_desc: "DirectX, NVIDIA, AMD, Intel Shader Caches",
        chk_browser_title: "Browser Caches",
        chk_browser_desc: "Chrome, Edge, Firefox, Brave, Opera",
        chk_game_title: "Game Launchers Caches",
        chk_game_desc: "Steam, Epic Games, Riot, EA Desktop",
        chk_dev_title: "Developer Caches",
        chk_dev_desc: "Gradle, npm, pip, NuGet, Pub, Yarn",
        chk_app_title: "App Caches",
        chk_app_desc: "Discord, Spotify, LINE, Telegram, TikTok LIVE Studio",
        chk_win_title: "Deep Windows Cleanup",
        chk_win_desc: "Windows Update Download Cache, System Disk Cleanup, DISM",
        btn_run_clean: "Run Selected Cleanup",
        btn_scan_junk: "Scan Junk Files",
        scan_results: "Junk Analysis Results",
        scan_total_junk: "Total Junk:",
        scan_progress: "Scanning...",
        scan_no_junk: "No junk files found!",
        header_test_title: "Test Mode Configuration",
        header_test_desc: "Toggle Windows TestSigning mode for driver testing.",
        test_status: "Checking status...",
        test_status_on: "Test Mode is ON",
        test_status_off: "Test Mode is OFF",
        btn_test_on: "Enable Test Mode (ON)",
        btn_test_on_desc: "For Flashing Tools",
        btn_test_off: "Disable Test Mode (OFF)",
        btn_test_off_desc: "For Gaming / Anti-Cheat",
        test_note_strong: "Note:",
        test_note: "Changing Test Mode requires Administrator privileges and a system restart to take effect.",
        modal_title: "Running Task...",
        modal_title_storage: "Disabling Reserved Storage (Admin)",
        modal_title_cleanup: "Running PC Cleanup...",
        modal_title_test_on: "Enabling Test Mode (Admin)",
        modal_title_test_off: "Disabling Test Mode (Admin)",
        modal_close: "Close",
        
        // Mobile Tools EN
        nav_mobile: "Mobile Tools",
        nav_root: "ROOT Tool",
        nav_pico: "Raspberry Pi Flasher",
        header_mobile_title: "Mobile Tools",
        header_mobile_desc: "Manage your Android device using ADB & Fastboot.",
        mobile_adb_devices: "ADB Devices",
        mobile_adb_desc: "Check connected devices in normal/recovery mode.",
        mobile_reboot_fastboot: "Reboot to Fastboot",
        mobile_reboot_fastboot_desc: "Reboot phone into Bootloader/Fastboot mode.",
        mobile_fastboot_devices: "Fastboot Devices",
        mobile_fastboot_desc: "Check devices in Fastboot mode.",
        mobile_fastboot_reboot: "Fastboot Reboot",
        mobile_fastboot_reboot_desc: "Normal restart from Fastboot mode.",
        mobile_cmd: "Open Terminal Here",
        mobile_cmd_desc: "Open CMD in the platform-tools folder for manual commands.",
        mobile_cmd_btn: "Open CMD",
        mobile_flash_title: "Image Flasher",
        mobile_flash_desc: "Flash an image (.img) file to a specific partition via Fastboot.",
        mobile_flash_browse: "Browse File...",
        mobile_flash_now: "Flash Now",
        no_file_selected: "No file selected",
        
        
          mob_qcom_service: "Service (Unlock)",
          mob_btn_readinfo: "Read Info",
          mob_btn_readgpt: "Read GPT (Root)",
          mob_btn_dump: "Dump Firmware",
          mob_btn_erasefrp: "Erase FRP",
          mob_btn_factory: "Factory Reset",
          mob_btn_micloud: "Mi Cloud Bypass",
          mob_qcom_security: "Security (IMEI/EFS)",
          mob_btn_backupefs: "Backup EFS",
          mob_btn_restoreefs: "Restore EFS",
          mob_btn_eraseefs: "Erase EFS",
          mob_qcom_port: "Select Device Port (EDL 9008):",
          mob_no_devices: "No devices found",
          mob_btn_scanports: "Scan Ports",
          mob_qcom_flasher: "Qualcomm Flasher",
          mob_qcom_flasher_desc: "Load rawprogram0.xml or .map (UnlockTool Dump) to flash.",
          mob_qcom_load_fw: "1. Load Firmware / Map",
          mob_qcom_load_prog: "2. Load Programmer",
          mob_qcom_load_patch: "3. Load Patch",
          mob_no_file: "No file selected",
          mob_qcom_prog_desc: "Optional: prog_emmc_firehose.mbn",
          mob_qcom_patch_desc: "Optional: patch0.xml",
          mob_qcom_flash: "Flash QCOM Firmware",
          mob_mtk_unlockbl: "Unlock Bootloader",
          mob_mtk_security: "Security (NVRAM)",
          mob_mtk_backupnv: "Backup NVRAM/NVDATA",
          mob_mtk_restorenv: "Restore NVRAM",
          mob_mtk_erasenv: "Erase NVRAM",
          mob_mtk_conn: "Connection / Boot Settings",
          mob_mtk_brom: "BROM Mode (Bypass SLA)",
          mob_mtk_preloader: "Preloader Mode",
          mob_mtk_da: "Custom DA",
          mob_mtk_emi: "Preloader / EMI",
          mob_mtk_auth: "Auth File",
          mob_btn_browse: "Browse",
          mob_mtk_modeldb: "Select Model Database",
          mob_mtk_flasher: "MediaTek Flasher",
          mob_mtk_flasher_desc: "Load Scatter (.txt) or .map (UnlockTool Dump) to flash.",
          mob_mtk_load_scatter: "Load Scatter / Map",
          mob_mtk_flash: "Flash MTK Firmware",
          mob_adb_tools: "ADB Tools (USB Debugging)",
          mob_adb_reboot_rec: "Reboot Recovery",
          mob_adb_reboot_bl: "Reboot Bootloader",
          mob_adb_reboot_edl: "Reboot EDL",
          mob_fb_tools: "Fastboot Tools",
          mob_btn_scandevices: "Scan Devices",
          mob_fb_reboot_normal: "Reboot Normal",
          mob_adb_dump_title: "Firmware Dump (ADB Root)",
          mob_adb_dump_desc: "Dump device partitions directly via ADB (Requires Root / su access). Ensure device has sufficient free space.",
          mob_adb_dump_scan: "1. Scan Partitions",
          mob_adb_dump_scatter: "Generate MTK Scatter File (MTK Only)",
          mob_adb_dump_avail: "Available Partitions:",
          mob_adb_dump_now: "2. Dump Selected Partitions",
          mob_adb_app_title: "App Remover (ADB)",
          mob_adb_app_desc: "Scan and forcibly remove stubborn apps or viruses via ADB.",
          mob_adb_app_load: "Load Installed Apps",

          mob_spd_service: "Service (Unlock)",
          mob_spd_port: "Select Device Port (SPRD U2S):",
          mob_spd_flasher: "Unisoc / SPD Flasher",
          mob_spd_flasher_desc: "Load .pac firmware file to flash.",
          mob_spd_load_pac: "1. Load .pac File",
          mob_spd_flash: "Flash SPD Firmware",
          mob_open_spd_tool: "Open SPD Flasher Tool",
// Advanced Firmware Flasher EN
        mobile_adv_flash_title: "Advanced Firmware Flasher (MTK & Qualcomm)",
        mobile_adv_flash_desc: "Load Scatter (.txt) or RawProgram (.xml) to flash multiple partitions automatically.",
        mobile_browse_fw: "1. Load Firmware File",
        mobile_browse_prog: "2. Load Programmer (QCOM)",
        mobile_browse_patch: "3. Load Patch (QCOM)",
        mobile_partitions_title: "Partitions to Flash:",
        mobile_select_all: "Select All",
        mobile_select_none: "Select None",
        mobile_flash_fw_now: "Flash Selected Partitions",
        
        card_rm_title: "Rainmeter Skins",
        card_rm_desc: "Manage custom Rainmeter skins and layouts",
        btn_dl_rm: "Download Rainmeter",
        btn_apply_rm_net: "Apply Skins (Net/Sys)",
        btn_apply_rm_full: "Apply Full Setup (Current)",
        card_wifi_title: "WiFi Passwords",
        card_wifi_desc: "View saved WiFi passwords",
        dropdown_scan: "Scan to load...",
        btn_scan: "Scan",
        btn_show: "Show",
        card_usb_title: "Fix USB Virus",
        card_usb_desc: "Unhide files and remove shortcut virus",
        btn_usb_fix: "Fix Drive Now",
        root_title: '⚡ One-Click ROOT Tool',
        root_subtitle: 'Scan device → auto-detect brand/model → root with Magisk in one click.',
        root_no_device: 'No device detected',
        root_scan_btn: 'Scan Device',
        root_device_info: 'Device Info',
        root_brand: 'Brand',
        root_model: 'Model',
        root_method: 'Root Method',
        root_device_details: '📋 Device Details',
        root_det_model: 'Model',
        root_det_android: 'Android',
        root_det_serial: 'Serial',
        root_det_cpu: 'CPU',
        root_det_bootloader: 'Bootloader',
        root_det_root: 'Root Status',
        root_start_btn: 'One-Click ROOT',
        root_progress_title: '⚙️ Root Progress',
        root_status_idle: 'Idle',
        root_waiting: 'Waiting...',
        root_log_title: '📟 Root Log',
        root_log_placeholder: '[ Root process log will appear here... ]',
        nav_settings: 'Settings',
        set_title: 'App Settings',
        set_width: 'Window Width',
        set_height: 'Window Height',
        set_cancel: 'Cancel',
        set_save: 'Save',
        
        // Odin
        
        nav_rom: "ROM Download",
        header_rom_title: "ROM & Firmware Workstation",
        header_rom_desc: "Official Android Stock ROMs, Apple IPSW Direct CDN, MTK/Qualcomm Service Files & Hasher Tools",
        rom_tab_android: "Android Firmware Hub",
        rom_tab_apple: "Apple iOS / iPadOS Live IPSW",
        rom_tab_service: "Service & Unlock Files (FRP / DA)",
        rom_tab_tools: "Firmware Verifier & Hasher",
        rom_tab_downloader: "Download Manager",
        rom_android_picker: "Select Device",
        rom_brand_label: "Brand:",
        rom_model_label: "Models:",
        rom_save_dest: "Download Destination Folder:",
        nav_odin: 'Odin Flasher',
        odin_title: 'Odin Flasher (Samsung)',
        odin_subtitle: 'Flash Samsung firmware files (.tar / .md5) in Download Mode.',
        odin_options: 'Options',
        odin_log: 'Log',
        odin_files: 'Firmware Files',
    },
    th: {
        nav_sys: "เครื่องมือระบบ",
        nav_clean: "ล้างขยะในเครื่อง",
        nav_test: "โหมดทดสอบ",
                header_sys_title: "เครื่องมือระบบ",
        header_sys_desc: "จัดการตั้งค่าอุปกรณ์และเครือข่ายของคุณ",
        card_dev_title: "ตัวจัดการอุปกรณ์",
        card_dev_desc: "เปิดหน้าจอ Device Manager ของ Windows",
        card_dev_btn: "เปิดใช้งาน",
        card_reg_title: "รีเซ็ต Registry เครือข่าย",
        card_reg_desc: "เปิด Registry สำหรับแก้ไขหรือรีเซ็ตเครือข่าย",
        card_reg_btn: "เปิดใช้งาน",
        card_store_title: "ปิด Reserved Storage",
        card_store_desc: "ปิดพื้นที่สำรองอัปเดตของ Windows",
        card_store_btn: "ปิดการใช้งาน (Admin)",
        card_def_title: "เปิด-ปิด แอนตี้ไวรัส",
        card_def_desc: "ปิด Windows Defender ชั่วคราว (กันลบไฟล์แฟลช)",
        btn_def_off: "ปิดการป้องกัน (Admin)",
        btn_def_on: "เปิดการป้องกัน (Admin)",
        card_hosts_title: "แก้ไขไฟล์ Hosts",
        card_hosts_desc: "บล็อกเซิร์ฟเวอร์ผ่านไฟล์ Hosts",
        btn_hosts: "เปิด Notepad (Admin)",
        card_ncpa_title: "ตั้งค่าเน็ตเวิร์ค",
        card_ncpa_desc: "เปิดหน้าตั้งค่าวงแลน / แชร์เน็ต",
        btn_ncpa: "เปิด Network Settings",
        // Network Tools Headers & Buttons
        hdr_net_tools: "🌐 เครื่องมือเน็ตเวิร์ค",
        btn_net_reset: "รีเซ็ตเน็ตเวิร์ค",
        btn_flush_dns: "ล้าง DNS Cache",
        btn_show_ip: "ดูข้อมูล IP",
        btn_ping_test: "ทดสอบ Ping",
        btn_proxy: "ตั้งค่า Proxy",
        // Driver Tools
        hdr_drv_tools: "📱 โหลดไดรเวอร์มือถือ",
        btn_drv_adb: "โหลด ADB Driver",
        btn_drv_mtk: "โหลด MTK (VCOM)",
        btn_drv_qcom: "โหลด Qualcomm 9008",
        btn_drv_spd: "โหลด SPD Driver",
        btn_drv_samsung: "โหลด Samsung USB",
        btn_drv_zadig: "เปิด Zadig",
        // Maintenance
        hdr_maint_tools: "🔧 ซ่อมบำรุงระบบ",
        btn_chkdsk: "ตรวจ HDD (C:)",
        btn_sfc: "ซ่อมไฟล์ระบบ",
        btn_dism: "ซ่อม Windows Image",
        btn_startup: "โปรแกรมตอนเปิด",
        btn_msinfo: "ข้อมูลระบบ",
        btn_services: "จัดการ Services",
        // Quick Launch
        hdr_quick_launch: "⚡ เปิดโปรแกรมด่วน",
        btn_taskmgr: "Task Manager",
        btn_calc: "เครื่องคิดเลข",
        btn_notepad: "Notepad",
        btn_snip: "จับภาพหน้าจอ",
        btn_paint: "Paint",
        btn_diskmgmt: "จัดการดิสก์",
        header_clean_title: "เครื่องมือล้างขยะระบบ (PC Cleanup)",
        header_clean_desc: "เพิ่มพื้นที่ว่างไดรฟ์ C: โดยการลบไฟล์แคช ไฟล์ขยะ และไฟล์ตกค้างในระบบ",
        drive_c_title: "ไดรฟ์ C: (ระบบ Windows)",
        drive_free_text: "พื้นที่ว่าง:",
        drive_total_text: "ทั้งหมด:",
        drive_used_text: "ใช้ไป",
        drive_usage_pct: "การใช้งานดิสก์",
        btn_smart_clean: "⚡ 1-Click ล้างด่วนอัจฉริยะ",
        smart_clean_hint: "ล้างไฟล์ขยะและแคชปลอดภัยที่กินพื้นที่เยอะที่สุดทันที",
        preset_safe: "แนะนำ (Safe)",
        preset_all: "เลือกทั้งหมด (All)",
        preset_none: "ยกเลิกทั้งหมด (None)",
        chk_temp_title: "ไฟล์ขยะระบบ Windows",
        chk_temp_desc: "User Temp, Windows Temp, Prefetch, Thumbnails, Delivery Opt.",
        chk_trash_title: "ถังขยะและไฟล์ดัมพ์ข้อผิดพลาด",
        chk_trash_desc: "ล้างถังขยะทุกไดรฟ์, Minidumps, BSOD Dumps, WER Reports",
        chk_shader_title: "แคชการ์ดจอ DirectX & GPU Shaders",
        chk_shader_desc: "แคชสำหรับเล่นเกมและตัดต่อ DirectX, NVIDIA, AMD, Intel",
        chk_browser_title: "ไฟล์แคชเว็บบราวเซอร์",
        chk_browser_desc: "Chrome, Edge, Firefox, Brave, Opera",
        chk_game_title: "แคชโปรแกรมเปิดเกม (Game Launchers)",
        chk_game_desc: "Steam, Epic Games, Riot, EA Desktop",
        chk_dev_title: "แคชสำหรับโปรแกรมเมอร์",
        chk_dev_desc: "Gradle, npm, pip, NuGet, Pub, Yarn",
        chk_app_title: "แคชแอปพลิเคชันและโปรแกรมแชท",
        chk_app_desc: "Discord, Spotify, LINE, Telegram, TikTok LIVE Studio",
        chk_win_title: "ล้างลึกระดับระบบ (Admin)",
        chk_win_desc: "Windows Update Download, Disk Cleanup System, DISM",
        btn_run_clean: "เริ่มการล้างขยะที่เลือก",
        btn_scan_junk: "สแกนวิเคราะห์ไฟล์ขยะ",
        scan_results: "ผลการวิเคราะห์ไฟล์ขยะ",
        scan_total_junk: "รวมขยะทั้งหมด:",
        scan_progress: "กำลังสแกน...",
        scan_no_junk: "ไม่พบไฟล์ขยะ!",
        header_test_title: "ตั้งค่าโหมดทดสอบ",
        header_test_desc: "เปิด-ปิด Windows TestSigning mode สำหรับทดสอบไดรเวอร์",
        test_status: "กำลังตรวจสอบ...",
        test_status_on: "โหมดทดสอบ: เปิด",
        test_status_off: "โหมดทดสอบ: ปิด",
        btn_test_on: "เปิดโหมดทดสอบ (ON)",
        btn_test_on_desc: "สำหรับเครื่องมือแฟลชรอม",
        btn_test_off: "ปิดโหมดทดสอบ (OFF)",
        btn_test_off_desc: "สำหรับเล่นเกม / ป้องกันแบน",
        test_note_strong: "หมายเหตุ:",
        test_note: "การสลับโหมดต้องใช้สิทธิ์ Administrator และต้องรีสตาร์ทคอมพิวเตอร์เพื่อแสดงผล",
        modal_title: "กำลังทำงาน...",
        modal_title_storage: "กำลังปิด Reserved Storage (Admin)",
        modal_title_cleanup: "กำลังล้างขยะ...",
        modal_title_test_on: "กำลังเปิดโหมดทดสอบ (Admin)",
        modal_title_test_off: "กำลังปิดโหมดทดสอบ (Admin)",
        modal_close: "ปิด",
        
        // Mobile Tools TH
        nav_mobile: "เครื่องมือมือถือ",
        nav_root: "เครื่องมือรูท (ROOT)",
        nav_pico: "แฟลช Raspberry Pi",
        header_mobile_title: "เครื่องมือมือถือ (Mobile Tools)",
        header_mobile_desc: "จัดการโทรศัพท์ Android ของคุณผ่าน ADB และ Fastboot",
        mobile_adb_devices: "เช็คอุปกรณ์ ADB",
        mobile_adb_desc: "ตรวจสอบอุปกรณ์ที่ต่อผ่านโหมดปกติหรือ Recovery",
        mobile_reboot_fastboot: "รีบูตเข้า Fastboot",
        mobile_fastboot_desc: "ตรวจสอบมือถือที่เชื่อมต่อในโหมด Fastboot",
        mobile_fastboot_reboot: "รีบูตเครื่องปกติ",
        mobile_fastboot_reboot_desc: "สั่งให้มือถือรีสตาร์ทจาก Fastboot กลับเข้าโหมดปกติ",
        mobile_cmd: "เปิดหน้าต่าง Terminal",
        mobile_cmd_desc: "เปิด CMD ตรงไปที่โฟลเดอร์ platform-tools ทันที",
        mobile_cmd_btn: "เปิด CMD",
        mobile_flash_title: "ระบบแฟลชไฟล์ (Image Flasher)",
        mobile_flash_desc: "เลือกไฟล์ (.img) เพื่อแฟลชลงพาร์ติชันที่ต้องการผ่าน Fastboot",
        mobile_flash_browse: "เลือกไฟล์...",
        mobile_flash_now: "เริ่มแฟลชไฟล์",
        no_file_selected: "ยังไม่ได้เลือกไฟล์",
        
        
          mob_qcom_service: "บริการปลดล็อค (Service)",
          mob_btn_readinfo: "อ่านข้อมูล (Read Info)",
          mob_btn_readgpt: "อ่านตาราง GPT (Root)",
          mob_btn_dump: "ดูดรอม (Dump Firmware)",
          mob_btn_erasefrp: "ปลดล็อค Gmail (FRP)",
          mob_btn_factory: "ล้างเครื่อง (Factory Reset)",
          mob_btn_micloud: "ปลดล็อค Mi Cloud",
          mob_qcom_security: "ความปลอดภัย (IMEI/EFS)",
          mob_btn_backupefs: "สำรองข้อมูล EFS",
          mob_btn_restoreefs: "คืนค่า EFS",
          mob_btn_eraseefs: "ล้าง EFS",
          mob_qcom_port: "เลือกพอร์ตอุปกรณ์ (EDL 9008):",
          mob_no_devices: "ไม่พบอุปกรณ์",
          mob_btn_scanports: "ค้นหาพอร์ต",
          mob_qcom_flasher: "โปรแกรมแฟลช Qualcomm",
          mob_qcom_flasher_desc: "โหลดไฟล์ rawprogram0.xml หรือ .map (UnlockTool Dump) เพื่อแฟลช",
          mob_qcom_load_fw: "1. โหลดไฟล์ Firmware / Map",
          mob_qcom_load_prog: "2. โหลดไฟล์ Programmer",
          mob_qcom_load_patch: "3. โหลดไฟล์ Patch",
          mob_no_file: "ยังไม่ได้เลือกไฟล์",
          mob_qcom_prog_desc: "ตัวเลือก: prog_emmc_firehose.mbn",
          mob_qcom_patch_desc: "ตัวเลือก: patch0.xml",
          mob_qcom_flash: "เริ่มแฟลช Qualcomm",
          mob_mtk_unlockbl: "ปลดล็อค Bootloader",
          mob_mtk_security: "ความปลอดภัย (NVRAM)",
          mob_mtk_backupnv: "สำรองข้อมูล NVRAM/NVDATA",
          mob_mtk_restorenv: "คืนค่า NVRAM",
          mob_mtk_erasenv: "ล้าง NVRAM",
          mob_mtk_conn: "การเชื่อมต่อ / ตั้งค่าบูต",
          mob_mtk_brom: "โหมด BROM (Bypass SLA)",
          mob_mtk_preloader: "โหมด Preloader",
          mob_mtk_da: "ไฟล์ DA",
          mob_mtk_emi: "ไฟล์ Preloader / EMI",
          mob_mtk_auth: "ไฟล์ Auth",
          mob_btn_browse: "เปิดไฟล์",
          mob_mtk_modeldb: "เลือกฐานข้อมูลรุ่น",
          mob_mtk_flasher: "โปรแกรมแฟลช MediaTek",
          mob_mtk_flasher_desc: "โหลดไฟล์ Scatter (.txt) หรือ .map (UnlockTool Dump) เพื่อแฟลช",
          mob_mtk_load_scatter: "โหลดไฟล์ Scatter / Map",
          mob_mtk_flash: "เริ่มแฟลช MediaTek",
          mob_adb_tools: "เครื่องมือ ADB (USB Debugging)",
          mob_adb_reboot_rec: "รีบูตเข้า Recovery",
          mob_adb_reboot_bl: "รีบูตเข้า Bootloader",
          mob_adb_reboot_edl: "รีบูตเข้า EDL",
          mob_fb_tools: "เครื่องมือ Fastboot",
          mob_btn_scandevices: "ค้นหาอุปกรณ์",
          mob_fb_reboot_normal: "รีบูตเข้าหน้าปกติ",
          mob_adb_dump_title: "ดูดรอมผ่าน ADB (Root)",
          mob_adb_dump_desc: "ดูดพาร์ติชั่นต่างๆ ของเครื่องผ่าน ADB (ต้อง Root และให้สิทธิ์ su) ต้องมีพื้นที่ว่างพอ",
          mob_adb_dump_scan: "1. ค้นหาพาร์ติชั่น",
          mob_adb_dump_scatter: "สร้างไฟล์ MTK Scatter ด้วย (เฉพาะ MTK)",
          mob_adb_dump_avail: "พาร์ติชั่นที่พบ:",
          mob_adb_dump_now: "2. ดูดไฟล์พาร์ติชั่นที่เลือก",
          mob_adb_app_title: "เครื่องมือลบแอป (ADB)",
          mob_adb_app_desc: "ค้นหาและลบแอปขยะหรือไวรัสที่ฝังตัวแน่นผ่าน ADB",
          mob_adb_app_load: "โหลดแอปในเครื่อง",

          mob_spd_service: "บริการปลดล็อค (Service)",
          mob_spd_port: "เลือกพอร์ตอุปกรณ์ (SPRD U2S):",
          mob_spd_flasher: "โปรแกรมแฟลช Unisoc / SPD",
          mob_spd_flasher_desc: "โหลดไฟล์เฟิร์มแวร์ .pac เพื่อแฟลช",
          mob_spd_load_pac: "1. โหลดไฟล์ .pac",
          mob_spd_flash: "เริ่มแฟลช Unisoc / SPD",
          mob_open_spd_tool: "เปิดเครื่องมือ SPD Flasher Pro",
// Advanced Firmware Flasher TH
        mobile_adv_flash_title: "ระบบแฟลชขั้นสูง (MTK & Qualcomm)",
        mobile_adv_flash_desc: "เลือกไฟล์ Scatter (.txt) หรือ RawProgram (.xml) เพื่อเตรียมแฟลชหลายพาร์ติชันอัตโนมัติ",
        mobile_browse_fw: "1. เลือกไฟล์เฟิร์มแวร์",
        mobile_browse_prog: "2. เลือกไฟล์ Programmer (QCOM)",
        mobile_browse_patch: "3. เลือกไฟล์ Patch (QCOM)",
        mobile_partitions_title: "รายการพาร์ติชันที่จะแฟลช:",
        mobile_select_all: "เลือกทั้งหมด",
        mobile_select_none: "ไม่เลือกเลย",
        mobile_flash_fw_now: "เริ่มแฟลชรายการที่เลือก",
        
        card_rm_title: "เรนมิเตอร์ สกิน (Rainmeter)",
        card_rm_desc: "จัดการสกินเรนมิเตอร์ และเลย์เอาต์บนหน้าจอ",
        btn_dl_rm: "ดาวน์โหลดโปรแกรม Rainmeter",
        btn_apply_rm_net: "ติดตั้งสกิน (เน็ตเวิร์ก/ระบบ)",
        btn_apply_rm_full: "คัดลอกตั้งค่าปัจจุบันไปใช้ (เต็มรูปแบบ)",
        card_wifi_title: "รหัสผ่านไวไฟ",
        card_wifi_desc: "ดูรหัสผ่าน WiFi ที่เคยเชื่อมต่อในเครื่อง",
        dropdown_scan: "กดสแกนเพื่อค้นหา...",
        btn_scan: "สแกน",
        btn_show: "ดูรหัส",
        card_usb_title: "แก้ไวรัสซ่อนไฟล์แฟลชไดรฟ์",
        card_usb_desc: "ยกเลิกซ่อนไฟล์และลบไวรัสโฟลเดอร์ Shortcut",
        btn_usb_fix: "กำจัดไวรัสทันที",
        root_title: '⚡ รูทมือถือ (One-Click ROOT)',
        root_subtitle: 'สแกนเครื่อง → ตรวจสอบรุ่นอัตโนมัติ → รูทด้วย Magisk ในคลิกเดียว',
        root_no_device: 'ยังไม่ได้เชื่อมต่ออุปกรณ์',
        root_scan_btn: 'สแกนอุปกรณ์',
        root_device_info: 'ข้อมูลอุปกรณ์',
        root_brand: 'ยี่ห้อ (Brand)',
        root_model: 'รุ่น (Model)',
        root_method: 'วิธีการรูท (Root Method)',
        root_device_details: '📋 รายละเอียดเครื่อง',
        root_det_model: 'รุ่น',
        root_det_android: 'แอนดรอยด์',
        root_det_serial: 'ซีเรียล',
        root_det_cpu: 'ซีพียู',
        root_det_bootloader: 'บูตโหลดเดอร์',
        root_det_root: 'สถานะรูท',
        root_start_btn: 'รูทเครื่องทันที (One-Click ROOT)',
        root_progress_title: '⚙️ สถานะการทำงาน',
        root_status_idle: 'รอคำสั่ง',
        root_waiting: 'รอคำสั่ง...',
        root_log_title: '📟 ประวัติการทำงาน (Root Log)',
        root_log_placeholder: '[ ประวัติการทำงานจะแสดงที่นี่... ]',
        nav_settings: 'ตั้งค่า',
        set_title: 'ตั้งค่าหน้าจอ',
        set_width: 'ความกว้าง (Width)',
        set_height: 'ความสูง (Height)',
        set_cancel: 'ยกเลิก',
        set_save: 'บันทึก',

        // Odin
        
        // ROM & Firmware Workstation
        nav_rom: "ดาวน์โหลดรอม (ROM)",
        header_rom_title: "ศูนย์ดาวน์โหลดรอมและเฟิร์มแวร์ครบวงจร",
        header_rom_desc: "ศูนย์ดาวน์โหลดรอมศูนย์ Android, Apple IPSW Direct CDN, ไฟล์ช่าง MTK/Qualcomm และระบบตรวจเช็คไฟล์ครบวงจร",
        rom_tab_android: "รอมศูนย์ Android",
        rom_tab_apple: "เฟิร์มแวร์ Apple IPSW (CDN แท้)",
        rom_tab_service: "ไฟล์ช่าง & ปลดล็อค (FRP / DA)",
        rom_tab_tools: "ตรวจสอบ Hash & เครื่องมือช่าง",
        rom_tab_downloader: "ตัวจัดการดาวน์โหลด",
        rom_android_picker: "เลือกรุ่นอุปกรณ์",
        rom_brand_label: "ยี่ห้อ (Brand):",
        rom_model_label: "รายการรุ่น (Models):",
        rom_save_dest: "โฟลเดอร์จัดเก็บไฟล์ดาวน์โหลด:",
        nav_odin: 'แฟลชรอม Samsung (Odin)',
        odin_title: 'โปรแกรมแฟลชรอม (Odin Flasher)',
        odin_subtitle: 'แฟลชไฟล์รอมศูนย์ Samsung (.tar / .md5) ในโหมด Download Mode',
        odin_options: 'ตัวเลือก (Options)',
        odin_log: 'ประวัติการทำงาน (Log)',
        odin_files: 'ไฟล์เฟิร์มแวร์ (Firmware Files)',
    }
};

let currentLang = 'en';

// Universal dialog result resolver (supports both string and { canceled, filePaths } forms)
function resolveDialogPath(res) {
    if (!res) return null;
    if (typeof res === 'string') return res;
    if (res.canceled) return null;
    if (Array.isArray(res.filePaths) && res.filePaths.length > 0) return res.filePaths[0];
    if (res.filePath) return res.filePath;
    return null;
}

function getBasename(filePath) {
    if (!filePath || typeof filePath !== 'string') return '';
    return filePath.replace(/\\/g, '/').split('/').filter(Boolean).pop() || filePath;
}

// Universal Magisk Boot Patching Runner
async function executeMagiskPatch(bootImgPath, statusElement, logCallback) {
    if (!bootImgPath) return;
    const log = (msg, col) => {
        if (typeof logCallback === 'function') logCallback(msg, col);
    };

    if (statusElement) {
        statusElement.innerHTML = `
            <div style="background: rgba(255,78,0,0.12); border: 1px solid rgba(255,78,0,0.3); border-radius: 8px; padding: 12px; color: #ff8a65;">
                <div style="display:flex; align-items:center; gap:8px; font-weight:600; font-size:12px;">
                    <i class="fas fa-spinner fa-spin"></i> กำลังส่งเครื่องมือและแพตช์ Magisk Root บนโทรศัพท์...
                </div>
                <div style="color: #cbd5e1; font-size: 11px; margin-top: 4px;">
                    ไฟล์ Boot: <b>${getBasename(bootImgPath)}</b> (กรุณารอสักครู่ ~5-10 วินาที)
                </div>
            </div>
        `;
        statusElement.style.display = 'block';
    }

    log('⚡ กำลังเริ่มแพตช์ไฟล์ Boot ด้วย Magisk Root...', '#ff8a65');
    log('> ตรวจสอบการเชื่อมต่อ ADB และรันสคริปต์ Magisk บนมือถือ...', '#aaa');

    try {
        const pRes = await window.api.patchBootWithMagisk({ bootPath: bootImgPath });
        if (pRes && pRes.success) {
            log(`🎉 แพตช์ Magisk Root สำเร็จเรียบร้อย! (ใช้เวลา ${pRes.elapsedSeconds}s)`, '#69f0ae');
            if (pRes.patchedTar) {
                log(`📁 ไฟล์แฟลชสำหรับ Samsung Odin: ${pRes.patchedTar}`, '#ffd740');
            }
            if (pRes.patchedImg) {
                log(`📁 ไฟล์แฟลช Boot ดิบ: ${pRes.patchedImg}`, '#ffd740');
            }

            if (statusElement) {
                statusElement.innerHTML = `
                    <div style="background: rgba(34,197,94,0.15); border: 1px solid rgba(34,197,94,0.35); border-radius: 8px; padding: 12px; color: #4ade80;">
                        <div style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:8px; margin-bottom:6px;">
                            <div style="font-weight:700; font-size: 12px; display:flex; align-items:center; gap:6px;">
                                <i class="fas fa-check-circle"></i> แพตช์ Magisk Root สำเร็จ! (${pRes.elapsedSeconds}s)
                            </div>
                            <div style="display:flex; gap:6px; flex-wrap: wrap;">
                                <button type="button" class="btn-open-patch-folder" style="background: rgba(34,197,94,0.25); border: 1px solid rgba(34,197,94,0.4); color: #fff; padding: 3px 9px; border-radius: 5px; font-size: 11px; cursor: pointer;">
                                    <i class="fas fa-folder-open"></i> เปิดโฟลเดอร์
                                </button>
                                <button type="button" class="btn-goto-odin" style="background: linear-gradient(135deg, #0284c7, #0369a1); border: none; color: #fff; padding: 3px 10px; border-radius: 5px; font-size: 11px; font-weight: 600; cursor: pointer;">
                                    <i class="fas fa-bolt"></i> แฟลชผ่าน Odin
                                </button>
                            </div>
                        </div>
                        <div style="color: #f1f5f9; font-size: 11px; margin-bottom: 2px;">
                            📦 สำหรับ Samsung Odin: <b>${getBasename(pRes.patchedTar || pRes.patchedImg)}</b>
                        </div>
                        <div style="color: #94a3b8; font-size: 10px; word-break: break-all;">
                            ${pRes.patchedTar || pRes.patchedImg}
                        </div>
                    </div>
                `;

                const openBtn = statusElement.querySelector('.btn-open-patch-folder');
                if (openBtn) {
                    openBtn.addEventListener('click', async () => {
                        if (window.api && window.api.openFileLocation) {
                            await window.api.openFileLocation(pRes.patchedTar || pRes.patchedImg);
                        }
                    });
                }
                const odinBtn = statusElement.querySelector('.btn-goto-odin');
                if (odinBtn) {
                    odinBtn.addEventListener('click', () => {
                        const odinNav = document.querySelector('[data-target="odin-section"]') || document.getElementById('nav-odin');
                        if (odinNav) odinNav.click();
                        const odinApInput = document.getElementById('odin-path-ap');
                        const odinApChk = document.getElementById('odin-chk-ap');
                        if (odinApInput && pRes.patchedTar) {
                            odinApInput.value = pRes.patchedTar;
                            if (odinApChk) odinApChk.checked = true;
                        }
                    });
                }
            }
            return pRes;
        } else {
            const errMsg = pRes ? pRes.error : 'Unknown error';
            log(`❌ การแพตช์ล้มเหลว: ${errMsg}`, '#ff5252');
            if (statusElement) {
                statusElement.innerHTML = `
                    <div style="background: rgba(239,68,68,0.12); border: 1px solid rgba(239,68,68,0.3); border-radius: 8px; padding: 12px; color: #f87171;">
                        <div style="font-weight:600;"><i class="fas fa-times-circle"></i> แพตช์ไม่สำเร็จ: ${errMsg}</div>
                        ${pRes && pRes.needDevice ? '<div style="color:#cbd5e1; font-size:11px; margin-top:6px;">💡 กรุณาเสียบสาย USB เปิดโหมดแก้จุดบกพร่อง (USB Debugging) บนโทรศัพท์</div>' : ''}
                        <div style="margin-top:8px;">
                            <button type="button" class="btn-retry-patch action-btn safe-btn" style="padding:4px 10px; font-size:11px;">
                                <i class="fas fa-rotate-right"></i> ลองแพตช์ใหม่อีกครั้ง
                            </button>
                        </div>
                    </div>
                `;
                const retryBtn = statusElement.querySelector('.btn-retry-patch');
                if (retryBtn) {
                    retryBtn.addEventListener('click', () => executeMagiskPatch(bootImgPath, statusElement, logCallback));
                }
            }
            return pRes;
        }
    } catch (err) {
        log(`❌ เกิดข้อผิดพลาด: ${err.message}`, '#ff5252');
        if (statusElement) {
            statusElement.innerHTML = `<div style="color: #f87171; padding: 10px;">❌ เกิดข้อผิดพลาด: ${err.message}</div>`;
        }
    }
}

function applyTranslations(lang) {
    currentLang = lang;
    try { localStorage.setItem('preferred_language', lang); } catch (e) {}
    const t = translations[lang];
    if (!t) return;
    
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (t[key]) {
            if (key === 'chk_win_title') {
                el.innerHTML = t[key] + ' <span class="badge warning">Admin</span>';
            } else {
                const icon = el.querySelector('i, svg');
                if (icon) {
                    const iconHtml = icon.outerHTML;
                    const span = el.querySelector('span[data-i18n]');
                    if (span) {
                        span.textContent = t[key];
                    } else {
                        el.innerHTML = iconHtml + ' ' + t[key];
                    }
                } else {
                    el.textContent = t[key];
                }
            }
        }
    });

    const btnEn = document.getElementById('btn-lang-en');
    const btnTh = document.getElementById('btn-lang-th');
    if (btnEn && btnTh) {
        if (lang === 'th') {
            btnTh.style.opacity = '1';
            btnTh.style.boxShadow = '0 0 10px rgba(255,152,0,0.5)';
            btnEn.style.opacity = '0.6';
            btnEn.style.boxShadow = 'none';
        } else {
            btnEn.style.opacity = '1';
            btnEn.style.boxShadow = '0 0 10px rgba(76,175,80,0.5)';
            btnTh.style.opacity = '0.6';
            btnTh.style.boxShadow = 'none';
        }
    }

    // Force re-render of test status
    if (window.api && window.api.getTestModeStatus) {
        window.api.getTestModeStatus();
    }
    if (typeof refreshCDriveSpace === 'function') {
        refreshCDriveSpace();
    }
}

document.addEventListener('DOMContentLoaded', () => {

    // --- RTC Tool Global Device Selection Logic ---
    const deviceDb = {
        xiaomi: [
            { name: "Redmi Note 9 (Merlin)", cpu: "MTK MT6769V", type: "mtk", auth: true },
            { name: "Redmi Note 10 (Sunny)", cpu: "QCOM Snapdragon 678", type: "qcom", firehose: "prog_firehose_sm6150.mbn" },
            { name: "Poco X3 Pro (Vayu)", cpu: "QCOM Snapdragon 860", type: "qcom", firehose: "prog_firehose_sm8150.mbn" }
        ],
        oppo: [
            { name: "Oppo A15 (CPH2185)", cpu: "MTK MT6765", type: "mtk", auth: false },
            { name: "Oppo A53 (CPH2127)", cpu: "QCOM Snapdragon 460", type: "qcom", firehose: "prog_firehose_sm4250.mbn" }
        ],
        vivo: [
            { name: "Vivo Y11 (1906)", cpu: "QCOM Snapdragon 439", type: "qcom", firehose: "prog_firehose_sdm439.mbn" },
            { name: "Vivo Y12 (1904)", cpu: "MTK MT6762", type: "mtk", auth: true }
        ],
        samsung: [
            { name: "Galaxy A03 Core", cpu: "SPD SC9863A", type: "spd" },
            { name: "Galaxy A12", cpu: "MTK MT6765", type: "mtk", auth: false },
            { name: "Galaxy A32 5G", cpu: "MTK MT6853", type: "mtk", auth: true }
        ]
    };

    let selectedDevice = null;
    const brandSelect = document.getElementById('global-brand-select');
    const modelSelect = document.getElementById('global-model-select');
    const cpuDisplay = document.getElementById('global-cpu-display');

    if (brandSelect && modelSelect) {
        brandSelect.addEventListener('change', (e) => {
            const brand = e.target.value;
            modelSelect.innerHTML = '<option value="" disabled selected>-- Choose Model --</option>';
            if (deviceDb[brand]) {
                deviceDb[brand].forEach((device, index) => {
                    modelSelect.innerHTML += `<option value="${index}">${device.name}</option>`;
                });
                modelSelect.disabled = false;
            } else {
                modelSelect.disabled = true;
            }
            cpuDisplay.textContent = "NONE";
            cpuDisplay.style.color = "#4ade80";
            selectedDevice = null;
        });

        modelSelect.addEventListener('change', (e) => {
            const brand = brandSelect.value;
            const idx = e.target.value;
            if (brand && deviceDb[brand] && deviceDb[brand][idx]) {
                selectedDevice = deviceDb[brand][idx];
                cpuDisplay.textContent = selectedDevice.cpu;
                
                // Switch tab automatically based on CPU type
                const tabId = `tab-${selectedDevice.type}`;
                const tabBtn = document.querySelector(`.tab-btn[data-target="${tabId}"]`);
                if (tabBtn) tabBtn.click();
            }
        });
    }

    // --- Specialized One-Click Operations ---
    function doOneClick(id, handler) {
        const btn = document.getElementById(id);
        if (btn) {
            btn.addEventListener('click', () => {
                handler();
            });
        }
    }

    doOneClick('btn-sp-mi-account', () => {
        openModal('Bypass Mi Account (Xiaomi / Redmi / POCO)');
        logToModal('> Starting Bypass Mi Account...\n');
        logToModal('> 🔌 กรุณาปิดเครื่องให้ดับสนิท -> กดปุ่ม Vol Up (+) และ Vol Down (-) ค้างไว้ -> เสียบสาย USB\n');
        if (selectedDevice && selectedDevice.type === 'qcom') {
            const loaderArg = selectedDevice.firehose ? [`--loader=${selectedDevice.firehose}`] : [];
            window.api.runFlasherTool({ tool: 'edl', args: ['e', 'persist'].concat(loaderArg) });
        } else {
            window.api.runFlasherTool({ tool: 'mtk', args: ['e', 'persist'] });
        }
    });

    doOneClick('btn-sp-oppo-demo', () => {
        openModal('Remove Demo Mode (Oppo / Vivo / Realme)');
        logToModal('> Starting Remove Demo Mode...\n');
        logToModal('> 🔌 กรุณาปิดเครื่องให้ดับสนิท -> กดปุ่ม Vol Up (+) และ Vol Down (-) ค้างไว้ -> เสียบสาย USB\n');
        window.api.runFlasherTool({ tool: 'mtk', args: ['e', 'userdata,metadata,reserve2'] });
    });

    doOneClick('btn-sp-sam-frp', async () => {
        openModal('Samsung MTP FRP (*#0*# Mode)');
        logToModal('> Starting Samsung MTP FRP (*#0*# Mode)...\n');
        logToModal('> 💡 ในโทรศัพท์: เข้าหน้าโทรออก/โทรฉุกเฉิน -> กดรหัส *#0*# (หรือ *#0808# เลือก DM+MODEM+ADB)\n');
        logToModal('> เสียบสาย USB เข้าคอมรอไว้...\n');
        try {
            const res = await window.api.samsungMtpFrp();
            if (res && res.success) {
                logToModal('\n[SUCCESS] Samsung MTP FRP command sequence sent successfully!\n', 'success');
                finishModal(true);
            } else {
                logToModal(`\n[FAILED] ${res ? res.error : 'Failed'}\n`, 'error');
                finishModal(false);
            }
        } catch (e) {
            logToModal(`\n[ERROR] ${e.message}\n`, 'error');
            finishModal(false);
        }
    });

    doOneClick('btn-sp-sam-download', async () => {
        openModal('Samsung 350K: Enter Download Mode');
        logToModal('> Sending AT Download Mode trigger to Samsung phone...\n');
        try {
            const res = await window.api.samsung350kAction({ action: 'download' });
            if (res && res.success) {
                logToModal('\n[SUCCESS] Phone is entering Download Mode!\n', 'success');
                finishModal(true);
            } else {
                logToModal(`\n[NOTICE] ${res ? res.error : 'Not detected'}\n`, 'warning');
                logToModal('💡 หากเครื่องไม่เข้าโหมด: ปิดเครื่อง -> กด Vol Up (+) และ Vol Down (-) ค้างไว้ -> เสียบสาย USB\n');
                finishModal(false);
            }
        } catch (e) {
            logToModal(`\n[ERROR] ${e.message}\n`, 'error');
            finishModal(false);
        }
    });

    doOneClick('btn-sp-sam-reboot', async () => {
        openModal('Samsung 350K: Reboot Phone');
        logToModal('> Sending reboot trigger to Samsung phone...\n');
        try {
            const res = await window.api.samsung350kAction({ action: 'reboot' });
            if (res && res.success) {
                logToModal('\n[SUCCESS] Phone reboot command sent successfully!\n', 'success');
                finishModal(true);
            } else {
                logToModal(`\n[NOTICE] ${res ? res.error : 'Not detected'}\n`, 'warning');
                finishModal(false);
            }
        } catch (e) {
            logToModal(`\n[ERROR] ${e.message}\n`, 'error');
            finishModal(false);
        }
    });

    doOneClick('btn-sp-auth-bypass', () => {
        openModal('MTK SLA/DA Auth Bypass');
        logToModal('> Starting MTK SLA/DA Auth Bypass (BROM Exploit)...\n');
        logToModal('> 🔌 กรุณาปิดเครื่องให้ดับสนิท -> กดปุ่ม Vol Up (+) และ Vol Down (-) ค้างไว้ -> เสียบสาย USB\n');
        window.api.runFlasherTool({ tool: 'mtk', args: ['payload'] });
    });

    doOneClick('btn-sp-unlock-bl', () => {
        openModal('Unlock Bootloader');
        logToModal('> Starting Bootloader Unlock Sequence...\n');
        logToModal('> 🔌 เสียบสาย USB ในโหมด BROM / Fastboot / EDL...\n');
        if (selectedDevice && selectedDevice.type === 'qcom') {
            window.api.runFlasherTool({ tool: 'edl', args: ['modules', 'oemunlock', 'enable'] });
        } else {
            window.api.runFlasherTool({ tool: 'mtk', args: ['da', 'seccfg', 'unlock'] });
        }
    });


// --- Live Device Hardware Monitor (Compact Badge Style) ---
async function refreshLiveMonitor(isManual = false) {
    const adbStatus = document.getElementById('mon-adb-status');
    const fbStatus = document.getElementById('mon-fb-status');
    const edlStatus = document.getElementById('mon-edl-status');
    const mtkStatus = document.getElementById('mon-mtk-status');
    const samStatus = document.getElementById('mon-sam-status');
    const spdStatus = document.getElementById('mon-spd-status');
    const adbBadge = document.getElementById('mon-adb-badge');
    const fbBadge = document.getElementById('mon-fb-badge');
    const edlBadge = document.getElementById('mon-edl-badge');
    const mtkBadge = document.getElementById('mon-mtk-badge');
    const samBadge = document.getElementById('mon-sam-badge');
    const spdBadge = document.getElementById('mon-spd-badge');
    const idleText = document.getElementById('mon-idle-text');
    const scanBtn = document.getElementById('btn-mon-scan-all');

    if (isManual && scanBtn) {
        scanBtn.disabled = true;
        scanBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> ...';
    }

    let anyConnected = false;

    // 1. Check ADB
    try {
        if (window.api && window.api.runAdbCommand) {
            const adbOut = await window.api.runAdbCommand('devices');
            const lines = (adbOut || '').split(/\r?\n/).filter(l => l.trim() && !l.includes('List of devices attached'));
            const devLine = lines.find(l => l.includes('\tdevice'));
            if (devLine && adbBadge && adbStatus) {
                const devId = devLine.split('\t')[0].trim();
                adbStatus.textContent = `ADB: ${devId}`;
                adbBadge.style.display = 'inline-flex';
                anyConnected = true;
            } else {
                const unauth = lines.find(l => l.includes('\tunauthorized'));
                if (unauth && adbBadge && adbStatus) {
                    const unauthId = unauth.split('\t')[0].trim();
                    adbStatus.textContent = `ADB: ${unauthId} (Unauthorized)`;
                    adbBadge.style.display = 'inline-flex';
                    adbBadge.style.background = 'rgba(234,179,8,0.15)';
                    adbBadge.style.color = '#facc15';
                    adbBadge.style.borderColor = 'rgba(234,179,8,0.3)';
                    anyConnected = true;
                } else if (adbBadge) {
                    adbBadge.style.display = 'none';
                }
            }
        }
    } catch (e) {
        if (adbBadge) adbBadge.style.display = 'none';
    }

    // 1b. Check Fastboot
    const fbGuideName = document.getElementById('fb-guide-target-name');
    try {
        if (window.api && window.api.runFastbootCommand) {
            const fbOut = await window.api.runFastbootCommand('devices');
            const fbLines = (fbOut || '').split(/\r?\n/).filter(l => l.trim());
            const fbDevLine = fbLines.find(l => l.includes('\tfastboot'));
            if (fbDevLine && fbBadge && fbStatus) {
                const fbId = fbDevLine.split('\t')[0].trim();
                fbStatus.textContent = `Fastboot: ${fbId}`;
                fbBadge.style.display = 'inline-flex';
                anyConnected = true;
                if (fbGuideName) {
                    fbGuideName.innerHTML = `<span style="color:#4ade80;">● ตรวจพบเครื่อง: ${fbId}</span>`;
                }
            } else if (fbBadge) {
                fbBadge.style.display = 'none';
                if (fbGuideName && fbGuideName.textContent.includes('● ตรวจพบเครื่อง:')) {
                    fbGuideName.textContent = 'ทุกรุ่นทั่วไป';
                }
            }
        }
    } catch (e) {
        if (fbBadge) fbBadge.style.display = 'none';
    }

    // 2. Check COM Ports for EDL, MTK, Samsung, SPD
    try {
        if (window.api && window.api.scanComPorts) {
            const ports = await window.api.scanComPorts();
            const allEdl = [];
            const allMtk = [];
            const allSam = [];
            const allSpd = [];

            if (Array.isArray(ports)) {
                for (const p of ports) {
                    const portName = typeof p === 'object' ? p.port : p;
                    const desc = typeof p === 'object' ? (p.description || '') : '';
                    const isEdl = typeof p === 'object' ? (p.isEdl || /9008|QDLOADER|QUALCOMM/i.test(desc)) : /9008/i.test(p);
                    const isMtk = typeof p === 'object' ? (p.isMtk || /VCOM|MTK|MEDIATEK/i.test(desc)) : /MTK|VCOM/i.test(p);
                    const isSam = typeof p === 'object' ? (p.isSamsung || /SAMSUNG|SSUDMDM/i.test(desc)) : /SAMSUNG/i.test(p);
                    const isSpd = typeof p === 'object' ? (p.isSpd || /SPRD|UNISOC|SCI|SPREADTRUM|u2s/i.test(desc)) : /SPRD|SCI|u2s/i.test(p);
                    if (isEdl) allEdl.push(p);
                    if (isMtk) allMtk.push(p);
                    if (isSam) allSam.push(p);
                    if (isSpd) allSpd.push(p);
                }
            }

            const formatPortDisplay = (item, defaultTitle) => {
                if (!item) return '';
                const pName = typeof item === 'object' ? item.port : item;
                let d = (typeof item === 'object' ? (item.description || '') : '').trim();
                if (!d || d.toLowerCase() === 'serial port' || d.toLowerCase() === 'usb serial port') {
                    d = defaultTitle;
                }
                d = d.replace(/[\u{1F300}-\u{1F9FF}]|[\u{2600}-\u{26FF}]|[\u{2700}-\u{27BF}]/gu, '').trim();
                if (d) {
                    if (d.toUpperCase().includes(pName.toUpperCase())) {
                        return d;
                    }
                    return `${d} (${pName})`;
                }
                return `${defaultTitle} (${pName})`;
            };

            // EDL badge & Dynamic Guide Card update
            const qcomGuideTag = document.getElementById('qcom-guide-mode-tag');
            if (allEdl.length > 0 && edlBadge && edlStatus) {
                if (allEdl.length === 1) {
                    edlStatus.textContent = formatPortDisplay(allEdl[0], 'Qualcomm HS-USB QDLoader 9008');
                } else {
                    edlStatus.textContent = allEdl.map(p => formatPortDisplay(p, 'QDLoader 9008')).join(' | ');
                }
                edlBadge.style.display = 'inline-flex';
                anyConnected = true;
                if (qcomGuideTag) {
                    const pName = typeof allEdl[0] === 'object' ? allEdl[0].port : allEdl[0];
                    qcomGuideTag.textContent = `● ตรวจพบ ${pName} (EDL 9008)`;
                    qcomGuideTag.style.background = 'rgba(34, 197, 94, 0.2)';
                    qcomGuideTag.style.color = '#4ade80';
                    qcomGuideTag.style.borderColor = 'rgba(34, 197, 94, 0.4)';
                }
            } else if (edlBadge) { 
                edlBadge.style.display = 'none'; 
                if (qcomGuideTag && qcomGuideTag.textContent.includes('● ตรวจพบ')) {
                    qcomGuideTag.textContent = 'Qualcomm 9008';
                    qcomGuideTag.style.background = 'rgba(56, 189, 248, 0.15)';
                    qcomGuideTag.style.color = '#38bdf8';
                    qcomGuideTag.style.borderColor = 'rgba(56, 189, 248, 0.3)';
                }
            }

            // MTK badge & Dynamic Guide Card update
            const mtkGuideTag = document.getElementById('mtk-guide-mode-tag');
            if (allMtk.length > 0 && mtkBadge && mtkStatus) {
                if (allMtk.length === 1) {
                    mtkStatus.textContent = formatPortDisplay(allMtk[0], 'MediaTek USB VCOM Port');
                } else {
                    mtkStatus.textContent = allMtk.map(p => formatPortDisplay(p, 'MTK VCOM')).join(' | ');
                }
                mtkBadge.style.display = 'inline-flex';
                anyConnected = true;
                if (mtkGuideTag) {
                    const pName = typeof allMtk[0] === 'object' ? allMtk[0].port : allMtk[0];
                    mtkGuideTag.textContent = `● ตรวจพบ ${pName} (MTK VCOM)`;
                    mtkGuideTag.style.background = 'rgba(34, 197, 94, 0.2)';
                    mtkGuideTag.style.color = '#4ade80';
                    mtkGuideTag.style.borderColor = 'rgba(34, 197, 94, 0.4)';
                }
            } else if (mtkBadge) { 
                mtkBadge.style.display = 'none'; 
                if (mtkGuideTag && mtkGuideTag.textContent.includes('● ตรวจพบ')) {
                    mtkGuideTag.textContent = 'MTK BROM Mode';
                    mtkGuideTag.style.background = 'rgba(168, 85, 247, 0.15)';
                    mtkGuideTag.style.color = '#c084fc';
                    mtkGuideTag.style.borderColor = 'rgba(168, 85, 247, 0.3)';
                }
            }

            // Samsung badge & 350K Quick Toolbar update
            const samPortStatus = document.getElementById('odin-sam-port-status');
            if (allSam.length > 0 && samBadge && samStatus) {
                if (allSam.length === 1) {
                    samStatus.textContent = formatPortDisplay(allSam[0], 'SAMSUNG Mobile USB Modem');
                } else {
                    samStatus.textContent = allSam.map(p => formatPortDisplay(p, 'Samsung Modem')).join(' | ');
                }
                samBadge.style.display = 'inline-flex';
                anyConnected = true;
                if (samPortStatus) {
                    const pName = typeof allSam[0] === 'object' ? allSam[0].port : allSam[0];
                    samPortStatus.textContent = `● Connected: ${pName}`;
                    samPortStatus.style.background = 'rgba(34, 197, 94, 0.2)';
                    samPortStatus.style.color = '#4ade80';
                    samPortStatus.style.borderColor = 'rgba(34, 197, 94, 0.4)';
                }
            } else if (samBadge) { 
                samBadge.style.display = 'none'; 
                if (samPortStatus && samPortStatus.textContent.includes('● Connected:')) {
                    samPortStatus.textContent = 'Modem: Auto-Detect';
                    samPortStatus.style.background = 'rgba(0, 229, 255, 0.15)';
                    samPortStatus.style.color = '#00e5ff';
                    samPortStatus.style.borderColor = 'rgba(0, 229, 255, 0.3)';
                }
            }

            // SPD badge & Dynamic Guide Card update
            const spdGuideTag = document.getElementById('spd-guide-mode-tag');
            if (allSpd.length > 0 && spdBadge && spdStatus) {
                if (allSpd.length === 1) {
                    spdStatus.textContent = formatPortDisplay(allSpd[0], 'SPRD USB Diag Port');
                } else {
                    const portLabels = allSpd.map(p => {
                        const pName = typeof p === 'object' ? p.port : p;
                        let d = (typeof p === 'object' ? (p.description || '') : '').replace(/\(COM\d+\)/gi, '').replace(/SPRD\s*/gi, '').trim();
                        return d ? `${pName} (${d})` : pName;
                    });
                    spdStatus.textContent = portLabels.join(' | ');
                }
                spdBadge.style.display = 'inline-flex';
                anyConnected = true;
                if (spdGuideTag) {
                    const pName = typeof allSpd[0] === 'object' ? allSpd[0].port : allSpd[0];
                    spdGuideTag.textContent = `● ตรวจพบ ${pName} (SPRD U2S / Diag)`;
                    spdGuideTag.style.background = 'rgba(34, 197, 94, 0.2)';
                    spdGuideTag.style.color = '#4ade80';
                    spdGuideTag.style.borderColor = 'rgba(34, 197, 94, 0.4)';
                }
            } else if (spdBadge) { 
                spdBadge.style.display = 'none'; 
                if (spdGuideTag && spdGuideTag.textContent.includes('● ตรวจพบ')) {
                    const bootSel = document.getElementById('spd-boots-select');
                    const selId = bootSel ? bootSel.value : 'auto';
                    const guide = getBootInstruction('unisoc', selId);
                    spdGuideTag.textContent = guide.badge;
                    spdGuideTag.style.background = 'rgba(245, 158, 11, 0.15)';
                    spdGuideTag.style.color = '#fbbf24';
                    spdGuideTag.style.borderColor = 'rgba(245, 158, 11, 0.3)';
                }
            }

            // Populate ALL detected ports into the SPD port dropdown
            const spdPortSel = document.getElementById('spd-port-select');
            if (spdPortSel) {
                const currentVal = window.spdSelectedComPort || spdPortSel.value;
                spdPortSel.innerHTML = '';

                if (ports && ports.length > 0) {
                    // Sort ports so DIAG / U2S ports appear at the very top, followed by other SPD ports, then other COM ports
                    const sortedPorts = [...ports].sort((a, b) => {
                        const aDesc = (typeof a === 'object' ? (a.description || a.desc || '') : '').toLowerCase();
                        const bDesc = (typeof b === 'object' ? (b.description || b.desc || '') : '').toLowerCase();
                        const aIsDiag = aDesc.includes('diag') || aDesc.includes('u2s');
                        const bIsDiag = bDesc.includes('diag') || bDesc.includes('u2s');
                        if (aIsDiag && !bIsDiag) return -1;
                        if (!aIsDiag && bIsDiag) return 1;
                        const aIsSpd = typeof a === 'object' && a.isSpd;
                        const bIsSpd = typeof b === 'object' && b.isSpd;
                        if (aIsSpd && !bIsSpd) return -1;
                        if (!aIsSpd && bIsSpd) return 1;
                        return 0;
                    });

                    let matched = false;
                    let bestPort = null;

                    sortedPorts.forEach(port => {
                        const opt = document.createElement('option');
                        const portVal = typeof port === 'object' ? port.port : port;
                        const portDesc = typeof port === 'object' ? (port.description || port.desc || '') : '';
                        opt.value = portVal;
                        opt.textContent = portDesc ? `${portVal} - ${portDesc}` : portVal;

                        const isDiag = portDesc.toLowerCase().includes('diag') || portDesc.toLowerCase().includes('u2s');
                        if (!bestPort && (isDiag || (typeof port === 'object' && port.isSpd))) {
                            bestPort = portVal;
                        }

                        if (currentVal && portVal.toUpperCase() === currentVal.toUpperCase()) {
                            opt.selected = true;
                            matched = true;
                        }
                        spdPortSel.appendChild(opt);
                    });

                    if (!matched) {
                        const chosen = bestPort || (sortedPorts[0] ? (typeof sortedPorts[0] === 'object' ? sortedPorts[0].port : sortedPorts[0]) : null);
                        if (chosen) {
                            spdPortSel.value = chosen;
                            window.spdSelectedComPort = chosen;
                        }
                    } else {
                        window.spdSelectedComPort = currentVal;
                    }
                } else {
                    spdPortSel.innerHTML = '<option value="">⚡ ไม่พบพอร์ต COM</option>';
                    window.spdSelectedComPort = null;
                }
            }
        }
    } catch (e) {
        console.error('Error scanning COM ports for monitor:', e);
    }

    // Show/hide idle text
    if (idleText) idleText.style.display = anyConnected ? 'none' : 'inline';

    if (isManual && scanBtn) {
        scanBtn.disabled = false;
        scanBtn.innerHTML = '<i class="fas fa-sync-alt"></i> Scan';
    }
}

const btnMonScanAll = document.getElementById('btn-mon-scan-all');
if (btnMonScanAll) {
    btnMonScanAll.addEventListener('click', () => refreshLiveMonitor(true));
}

// Auto-refresh Live Monitor every 5 seconds + initial scan on load (silent background scan, no button flickering)
refreshLiveMonitor(false);
setInterval(() => refreshLiveMonitor(false), 5000);

// --- Console & Modal Panel Logic ---
const consoleTerminal = document.getElementById('console-terminal');
const consoleActionText = document.getElementById('console-action-text');
const consoleProgress1 = document.getElementById('console-progress-1');
const consoleProgressText1 = document.getElementById('console-progress-text-1');
const consoleProgress2 = document.getElementById('console-progress-2');
const consoleProgressText2 = document.getElementById('console-progress-text-2');

let activeProgressTimer1 = null;

function logToConsole(text, type = 'info') {
    logToModal(text, type);
}

function showRightPanelTab(tab) {
    const logTab = document.getElementById('btn-panel-tab-log');
    const screenTab = document.getElementById('btn-panel-tab-screen');
    const logView = document.getElementById('mobile-panel-log-view');
    const screenView = document.getElementById('mobile-panel-screen-view');
    if (!logView || !logTab || !screenTab || !screenView) return;

    if (tab === 'log') {
        logTab.classList.add('active');
        logTab.style.background = 'var(--accent-color)';
        logTab.style.color = '#fff';
        screenTab.classList.remove('active');
        screenTab.style.background = 'transparent';
        screenTab.style.color = '#94a3b8';
        logView.style.display = 'flex';
        screenView.style.display = 'none';
    } else {
        screenTab.classList.add('active');
        screenTab.style.background = 'var(--accent-color)';
        screenTab.style.color = '#fff';
        logTab.classList.remove('active');
        logTab.style.background = 'transparent';
        logTab.style.color = '#94a3b8';
        screenView.style.display = 'flex';
        logView.style.display = 'none';
    }
}

// Floating Mobile Toast Notification System
function showMobileToast(message, type = 'info', duration = 3500) {
    let container = document.getElementById('mobile-toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'mobile-toast-container';
        document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `mobile-toast mobile-toast-${type}`;

    let iconClass = 'fa-info-circle';
    if (type === 'success') iconClass = 'fa-check-circle';
    else if (type === 'error') iconClass = 'fa-exclamation-triangle';
    else if (type === 'warning') iconClass = 'fa-exclamation-circle';

    toast.innerHTML = `
        <i class="fas ${iconClass}"></i>
        <div style="flex: 1; word-break: break-word;">${message}</div>
    `;

    container.appendChild(toast);

    // Trigger enter animation
    requestAnimationFrame(() => {
        toast.classList.add('show');
    });

    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            if (toast.parentNode) {
                toast.parentNode.removeChild(toast);
            }
        }, 300);
    }, duration);
}

let currentRunningActionTitle = '';

function openModal(titleText) {
    currentRunningActionTitle = titleText || '';
    const mobileSec = document.getElementById('mobile-section');
    const isMobileActive = mobileSec && mobileSec.classList.contains('active');

    // 1. Update Mobile Right Panel Header & Progress
    const panelTitle = document.getElementById('mobile-panel-action-title');
    const panelBadge = document.getElementById('mobile-panel-badge');
    const panelProgress = document.getElementById('mobile-panel-progress-bar');
    const panelProgressTxt = document.getElementById('mobile-panel-progress-text');
    const panelTerminal = document.getElementById('mobile-panel-terminal');

    if (panelTitle) panelTitle.textContent = titleText;
    if (panelBadge) {
        panelBadge.textContent = 'RUNNING';
        panelBadge.style.background = 'rgba(56, 189, 248, 0.2)';
        panelBadge.style.color = '#38bdf8';
        panelBadge.style.borderColor = 'rgba(56, 189, 248, 0.4)';
    }
    if (panelProgress) {
        panelProgress.style.width = '35%';
        panelProgress.style.background = 'linear-gradient(90deg, #38bdf8, #818cf8)';
    }
    // Update Dual Progress Bars at bottom of Log Console
    const lblCurrPart = document.getElementById('spd-lbl-curr-part');
    const lblCurrPct = document.getElementById('spd-lbl-curr-pct');
    const barCurrFill = document.getElementById('spd-bar-curr-fill');
    const lblTotalSpeed = document.getElementById('spd-lbl-total-speed');
    const lblTotalPct = document.getElementById('spd-lbl-total-pct');
    const barTotalFill = document.getElementById('spd-bar-total-fill');

    if (lblCurrPart) lblCurrPart.textContent = `พาร์ติชันปัจจุบัน: ${titleText}`;
    if (lblCurrPct) lblCurrPct.textContent = 'กำลังทำงาน...';
    if (barCurrFill) {
        barCurrFill.style.width = '35%';
        barCurrFill.style.background = 'linear-gradient(90deg, #0284c7, #38bdf8)';
    }
    if (lblTotalSpeed) lblTotalSpeed.textContent = 'ความคืบหน้ารวม: กำลังประมวลผล...';
    if (lblTotalPct) lblTotalPct.textContent = '...';
    if (barTotalFill) {
        barTotalFill.style.width = '35%';
        barTotalFill.style.background = 'linear-gradient(90deg, #059669, #10b981, #34d399)';
    }
    
    // Auto-switch right panel to Log tab so user sees operation logs live!
    showRightPanelTab('log');

    // Auto-uncollapse Right Panel if collapsed so user sees logs!
    const rightPanel = document.getElementById('mobile-right-panel');
    const btnTogglePanel = document.getElementById('btn-toggle-right-panel');
    if (rightPanel) {
        if (rightPanel.classList.contains('panel-collapsed')) {
            rightPanel.classList.remove('panel-collapsed');
            localStorage.setItem('mobile_console_collapsed', 'false');
            if (btnTogglePanel) {
                btnTogglePanel.innerHTML = '<i class="fas fa-terminal"></i> <span>คอนโซล Log</span>';
                btnTogglePanel.style.background = 'rgba(56, 189, 248, 0.15)';
                btnTogglePanel.style.color = '#38bdf8';
                btnTogglePanel.style.borderColor = 'rgba(56, 189, 248, 0.35)';
            }
        }

        // Add visual flash pulse so user notices the right panel
        rightPanel.classList.remove('panel-flash-pulse');
        void rightPanel.offsetWidth;
        rightPanel.classList.add('panel-flash-pulse');

        // If screen width <= 1200px or panel out of viewport, scroll into view
        const rect = rightPanel.getBoundingClientRect();
        if (window.innerWidth <= 1200 || rect.top < 0 || rect.bottom > window.innerHeight) {
            rightPanel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    }

    // Show floating toast alert so user immediately gets visual confirmation!
    showMobileToast(`⚡ กำลังสั่งการ: ${titleText}`, 'info', 2800);

    // เคลียร์ Log ของคำสั่งเก่าออกทันทีเมื่อกดคำสั่งใหม่ ตามคำขอของผู้ใช้!
    if (panelTerminal) {
        panelTerminal.innerHTML = '';
        const headerSpan = document.createElement('span');
        headerSpan.style.color = '#38bdf8';
        headerSpan.textContent = `Started at: ${new Date().toLocaleTimeString()} [${titleText}]\n`;
        panelTerminal.appendChild(headerSpan);
        panelTerminal.scrollTop = 0;
    }
    const panelLines = document.getElementById('mobile-panel-terminal-lines');
    if (panelLines) {
        panelLines.textContent = '1 line';
    }

    // 2. Standard modal update for non-mobile tools or background tracking
    const modal = document.getElementById('status-modal');
    const modalTitle = document.getElementById('modal-title');
    const modalLoader = document.getElementById('modal-loader');
    const btnModalClose = document.getElementById('btn-modal-close');
    const statusBadge = document.getElementById('modal-status-badge');
    
    if (modalTitle) modalTitle.textContent = titleText;
    if (statusBadge) {
        statusBadge.textContent = 'RUNNING';
        statusBadge.style.background = '#0284c7';
    }
    const out = document.getElementById('modal-output');
    if (out) out.innerHTML = '';
    if (modalLoader) modalLoader.classList.remove('hidden');
    if (btnModalClose) btnModalClose.classList.add('hidden');

    // ONLY show blocking popup modal if user is NOT on Mobile Tools!
    if (!isMobileActive && modal) {
        modal.classList.remove('hidden');
    }
}

function finishModal(success = true, showTerminalResult = true, errorMsg = '') {
    const modalLoader = document.getElementById('modal-loader');
    const btnModalClose = document.getElementById('btn-modal-close');
    const statusBadge = document.getElementById('modal-status-badge');
    if (modalLoader) modalLoader.classList.add('hidden');
    if (btnModalClose) btnModalClose.classList.remove('hidden');
    if (statusBadge) {
        statusBadge.textContent = success ? 'COMPLETED' : 'FAILED';
        statusBadge.style.background = success ? '#16a34a' : '#dc2626';
    }

    // Update Mobile Right Panel
    const panelBadge = document.getElementById('mobile-panel-badge');
    const panelProgress = document.getElementById('mobile-panel-progress-bar');
    const panelProgressTxt = document.getElementById('mobile-panel-progress-text');
    const panelTerminal = document.getElementById('mobile-panel-terminal');

    if (panelBadge) {
        panelBadge.textContent = success ? 'COMPLETED' : 'FAILED';
        panelBadge.style.background = success ? 'rgba(34, 197, 94, 0.2)' : 'rgba(239, 68, 68, 0.2)';
        panelBadge.style.color = success ? '#4ade80' : '#f87171';
        panelBadge.style.borderColor = success ? 'rgba(34, 197, 94, 0.4)' : 'rgba(239, 68, 68, 0.4)';
    }
    if (panelProgress) {
        panelProgress.style.width = '100%';
        panelProgress.style.background = success ? 'linear-gradient(90deg, #38bdf8, #22c55e)' : '#ef4444';
    }
    if (panelProgressTxt) {
        panelProgressTxt.textContent = success ? '100% (Done)' : 'Failed';
    }

    // Update Dual Progress Bars at bottom of Log Console
    const lblCurrPart = document.getElementById('spd-lbl-curr-part');
    const lblCurrPct = document.getElementById('spd-lbl-curr-pct');
    const barCurrFill = document.getElementById('spd-bar-curr-fill');
    const lblTotalSpeed = document.getElementById('spd-lbl-total-speed');
    const lblTotalPct = document.getElementById('spd-lbl-total-pct');
    const barTotalFill = document.getElementById('spd-bar-total-fill');

    if (lblCurrPart) lblCurrPart.textContent = success ? 'พาร์ติชันปัจจุบัน: เสร็จสิ้น' : 'พาร์ติชันปัจจุบัน: ผิดพลาด';
    if (lblCurrPct) lblCurrPct.textContent = success ? '100%' : 'Failed';
    if (barCurrFill) {
        barCurrFill.style.width = '100%';
        barCurrFill.style.background = success ? 'linear-gradient(90deg, #0284c7, #38bdf8)' : '#ef4444';
    }
    if (lblTotalSpeed) lblTotalSpeed.textContent = success ? 'ความคืบหน้ารวม: สำเร็จ 100%' : 'ความคืบหน้ารวม: ขัดข้อง';
    if (lblTotalPct) lblTotalPct.textContent = success ? '100%' : 'Failed';
    if (barTotalFill) {
        barTotalFill.style.width = '100%';
        barTotalFill.style.background = success ? 'linear-gradient(90deg, #059669, #10b981, #34d399)' : '#ef4444';
    }

    if (panelTerminal && showTerminalResult) {
        const finishSpan = document.createElement('span');
        finishSpan.style.color = success ? '#4ade80' : '#f87171';
        finishSpan.style.fontWeight = 'bold';
        finishSpan.textContent = `\n[RESULT] ${success ? '✅ Operation completed successfully!' : '❌ Operation failed or stopped.'}\n`;
        panelTerminal.appendChild(finishSpan);
        panelTerminal.scrollTop = panelTerminal.scrollHeight;
    }

    // Show floating toast alert for result!
    if (success) {
        showMobileToast(`✅ ${currentRunningActionTitle || 'คำสั่ง'} เสร็จสิ้นสมบูรณ์!`, 'success', 3500);
    } else {
        const msg = errorMsg || `${currentRunningActionTitle || 'คำสั่ง'} ไม่สำเร็จ - โปรดดู Log ในคอนโซล`;
        showMobileToast(`⚠️ ${msg}`, 'error', 5500);
    }
}

function closeModal() {
    const modal = document.getElementById('status-modal');
    if (modal) modal.classList.add('hidden');
}

function logToModal(text, type = 'info') {
    if (typeof text === 'string') {
        const lines = text.split('\n');
        const cleanLines = lines.filter(line => !/^\[SPD_(PROG|DONE|IMEI|SAVED)\]/.test(line.trim()));
        text = cleanLines.join('\n');
        if (!text.trim()) return;
    }

    function formatSpan(spanEl, txt, t) {
        if (t === 'error' || txt.includes('[ERROR]') || txt.includes('failed') || txt.includes('FAIL') || txt.includes('[FAILED]')) {
            spanEl.style.color = '#ff5252';
        } else if (t === 'success' || txt.includes('Completed!') || txt.includes('OK') || txt.includes('✅') || txt.includes('[SUCCESS]')) {
            spanEl.style.color = '#69f0ae';
        } else if (t === 'warning' || txt.includes('⚠️') || txt.includes('Warning') || txt.includes('💡') || txt.includes('[NOTICE]')) {
            spanEl.style.color = '#ffd740';
        } else if (txt.startsWith('>') || txt.startsWith('📱') || txt.startsWith('🔋') || txt.startsWith('⚡')) {
            spanEl.style.color = '#38bdf8';
        } else {
            spanEl.style.color = '#cbd5e1';
        }
        spanEl.textContent = txt;
    }

    // 1. Output to standard modal output
    const modalOutput = document.getElementById('modal-output');
    if (modalOutput) {
        const span = document.createElement('span');
        formatSpan(span, text, type);
        modalOutput.appendChild(span);
        modalOutput.scrollTop = modalOutput.scrollHeight;
    }

    // 2. Output directly to Mobile Right Panel Terminal!
    const panelTerminal = document.getElementById('mobile-panel-terminal');
    if (panelTerminal) {
        const span = document.createElement('span');
        formatSpan(span, text, type);
        panelTerminal.appendChild(span);
        
        const autoScroll = document.getElementById('chk-panel-autoscroll');
        if (!autoScroll || autoScroll.checked) {
            panelTerminal.scrollTop = panelTerminal.scrollHeight;
        }
        
        const linesEl = document.getElementById('mobile-panel-terminal-lines');
        if (linesEl) {
            const lineCount = panelTerminal.innerText.split('\n').length;
            linesEl.textContent = `${lineCount} lines`;
        }
    }
}
function clearConsole() {
    openModal('Running Task...');
}

function setConsoleStatus(actionName) {
    if (consoleActionText) consoleActionText.textContent = actionName;
}

// Hook up live terminal listeners
if (window.api && window.api.onTerminalOutput) {
    window.api.onTerminalOutput((data) => {
        logToModal(data);
    });
}

if (window.api && window.api.onOperationComplete) {
    window.api.onOperationComplete((res) => {
        finishModal(res.success);
    });
}

const btnModalKill = document.getElementById('btn-modal-kill');
if (btnModalKill) {
    btnModalKill.addEventListener('click', () => {
        if (window.api && window.api.killFlasherTool) window.api.killFlasherTool();
        logToModal('\n[STOPPED] Command cancelled by user.\n', 'error');
        finishModal(false);
    });
}

const btnModalCopy = document.getElementById('btn-modal-copy');
if (btnModalCopy) {
    btnModalCopy.addEventListener('click', () => {
        const modalOutput = document.getElementById('modal-output');
        if (modalOutput) {
            navigator.clipboard.writeText(modalOutput.innerText).then(() => {
                const originalHtml = btnModalCopy.innerHTML;
                btnModalCopy.innerHTML = '<i class="fas fa-check"></i> คัดลอกแล้ว! (Copied)';
                btnModalCopy.style.color = '#69f0ae';
                setTimeout(() => {
                    btnModalCopy.innerHTML = originalHtml;
                    btnModalCopy.style.color = '#ccc';
                }, 2000);
            }).catch(err => {
                console.error('Failed to copy: ', err);
            });
        }
    });
}

const btnModalX = document.getElementById('btn-modal-x');
if (btnModalX) btnModalX.addEventListener('click', closeModal);

const btnModalClose = document.getElementById('btn-modal-close');
if (btnModalClose) btnModalClose.addEventListener('click', closeModal);

function simulateProgress(durationMs = 5000) {
    if(!consoleProgress1) return;
    consoleProgress1.style.width = '0%';
    if(consoleProgress2) consoleProgress2.style.width = '0%';
    consoleProgress1.style.transition = 'none';
    if(consoleProgress2) consoleProgress2.style.transition = 'none';
    
    void consoleProgress1.offsetWidth; // Reflow
    
    consoleProgress1.style.transition = `width ${durationMs}ms ease-out`;
    if(consoleProgress2) consoleProgress2.style.transition = `width ${durationMs * 1.5}ms ease-out`;
    consoleProgress1.style.width = '95%';
    if(consoleProgress2) consoleProgress2.style.width = '80%';
    
    let curProgress = 0;
    clearInterval(activeProgressTimer1);
    activeProgressTimer1 = setInterval(() => {
        if(curProgress < 95) {
            curProgress += 1;
            consoleProgressText1.textContent = `${curProgress}%`;
            consoleProgressText2.textContent = `${Math.floor(curProgress * 0.84)}%`;
        }
    }, durationMs / 95);
}

function finishProgress() {
    if(!consoleProgress1) return;
    clearInterval(activeProgressTimer1);
    consoleProgress1.style.transition = 'width 0.2s linear';
    if(consoleProgress2) consoleProgress2.style.transition = 'width 0.2s linear';
    consoleProgress1.style.width = '100%';
    if(consoleProgress2) consoleProgress2.style.width = '100%';
    consoleProgressText1.textContent = '100%';
    if(consoleProgressText2) consoleProgressText2.textContent = '100%';
    setConsoleStatus('Operation Completed!');
    
    const modalLoader = document.getElementById('modal-loader');
    const btnModalClose = document.getElementById('btn-modal-close');
    if (modalLoader) modalLoader.classList.add('hidden'); // Stop loader
    if (btnModalClose) btnModalClose.classList.remove('hidden'); // Show close button
}

function stopProgress() {
    if(!consoleProgress1) return;
    clearInterval(activeProgressTimer1);
    setConsoleStatus('Operation stopped by user!');
    consoleProgress1.style.transition = 'none';
    if(consoleProgress2) consoleProgress2.style.transition = 'none';
}

    
if(document.getElementById('btn-console-stop')) {
        document.getElementById('btn-console-stop').addEventListener('click', () => {
            logToConsole('\n[USER] Stop command issued.\n', 'error');
            stopProgress();
            if (window.api && window.api.send) {
                window.api.send('kill-flasher-tool');
            }
        });
    }
    // Language Toggle
    const savedLang = (() => {
        try { return localStorage.getItem('preferred_language') || 'en'; } catch(e) { return 'en'; }
    })();
    applyTranslations(savedLang);

    document.getElementById('btn-lang-en').addEventListener('click', () => {
        applyTranslations('en');
    });
    document.getElementById('btn-lang-th').addEventListener('click', () => {
        applyTranslations('th');
    });

    // --- Fullscreen Toggle (F11) Logic ---
    const btnFullscreen = document.getElementById('btn-fullscreen');
    const iconFullscreen = document.getElementById('icon-fullscreen');
    const txtFullscreen = document.getElementById('txt-fullscreen');

    function updateFullscreenUI(isFull) {
        if (!btnFullscreen) return;
        if (isFull) {
            if (iconFullscreen) iconFullscreen.className = 'fas fa-compress';
            if (txtFullscreen) txtFullscreen.textContent = currentLang === 'th' ? 'ย่อหน้าจอ (F11 / Esc)' : 'Exit Fullscreen (F11 / Esc)';
            btnFullscreen.style.background = 'rgba(234, 179, 8, 0.15)';
            btnFullscreen.style.borderColor = 'rgba(234, 179, 8, 0.4)';
            btnFullscreen.style.color = '#facc15';
            btnFullscreen.title = currentLang === 'th' ? 'กดย่อหน้าต่างกลับสู่ขนาดปกติ (F11 / Esc)' : 'Restore window (F11 / Esc)';
        } else {
            if (iconFullscreen) iconFullscreen.className = 'fas fa-expand';
            if (txtFullscreen) txtFullscreen.textContent = currentLang === 'th' ? 'ขยายเต็มจอ (F11)' : 'Fullscreen (F11)';
            btnFullscreen.style.background = 'rgba(56, 189, 248, 0.1)';
            btnFullscreen.style.borderColor = 'rgba(56, 189, 248, 0.25)';
            btnFullscreen.style.color = '#38bdf8';
            btnFullscreen.title = currentLang === 'th' ? 'สลับโหมดขยายเต็มจอ (F11)' : 'Toggle Fullscreen mode (F11)';
        }
    }

    if (btnFullscreen && window.api && window.api.toggleFullScreen) {
        btnFullscreen.addEventListener('click', async () => {
            const isFull = await window.api.toggleFullScreen();
            updateFullscreenUI(isFull);
        });

        if (window.api.onFullScreenChange) {
            window.api.onFullScreenChange((isFull) => {
                updateFullscreenUI(isFull);
            });
        }

        if (window.api.isFullScreen) {
            window.api.isFullScreen().then(isFull => updateFullscreenUI(isFull)).catch(() => {});
        }
    }

    // Navigation
    const navBtns = document.querySelectorAll('.nav-btn');
    const sections = document.querySelectorAll('.content-section');

    navBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            navBtns.forEach(b => b.classList.remove('active'));
            sections.forEach(s => s.classList.remove('active'));
            
            btn.classList.add('active');
            document.getElementById(btn.dataset.target).classList.add('active');

            // Show Console Panel only on Mobile Tools
            const cp = document.getElementById('console-panel');
            if (cp) {
                cp.style.display = btn.dataset.target === 'mobile-section' ? 'flex' : 'none';
            }

            if (btn.dataset.target === 'mobile-section') {
                refreshLiveMonitor();
            }
            if (btn.dataset.target === 'tools-section') {
                if (typeof updateDefenderBadge === 'function') updateDefenderBadge();
                if (typeof updateWin11MenuBadge === 'function') updateWin11MenuBadge();
            }
            if (btn.dataset.target === 'cleanup-section') {
                if (typeof refreshCDriveSpace === 'function') refreshCDriveSpace();
            }
        });
    });

    // Hide console panel on initial load (System Tools is default)
    const cpInit = document.getElementById('console-panel');
    if (cpInit) cpInit.style.display = 'none';
    setTimeout(() => {
        if (typeof updateDefenderBadge === 'function') updateDefenderBadge();
        if (typeof updateWin11MenuBadge === 'function') updateWin11MenuBadge();
        if (typeof refreshCDriveSpace === 'function') refreshCDriveSpace();
    }, 1000);

    // --- Tools Category Filter Bar Handler ---
    const toolCatPills = document.querySelectorAll('.tool-cat-pill');
    const toolCatCards = document.querySelectorAll('.tool-category-card');

    toolCatPills.forEach(pill => {
        pill.addEventListener('click', () => {
            const cat = pill.dataset.cat;
            toolCatPills.forEach(p => p.classList.remove('active'));
            pill.classList.add('active');

            if (cat === 'all') {
                toolCatCards.forEach(card => {
                    card.style.display = 'block';
                    card.classList.remove('cat-highlight');
                });
                const firstCard = document.querySelector('.tool-category-card');
                if (firstCard) firstCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            } else {
                toolCatCards.forEach(card => {
                    if (card.dataset.category === cat) {
                        card.style.display = 'block';
                        card.classList.add('cat-highlight');
                        card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                    } else {
                        card.style.display = 'none';
                        card.classList.remove('cat-highlight');
                    }
                });
            }
        });
    });

    // Custom Confirm Dialog
    function showCustomConfirm(message) {
        return new Promise((resolve) => {
            const confirmModal = document.getElementById('confirm-modal');
            const confirmMessage = document.getElementById('confirm-message');
            const btnOk = document.getElementById('btn-confirm-ok');
            const btnCancel = document.getElementById('btn-confirm-cancel');
            
            confirmMessage.textContent = message;
            confirmModal.classList.remove('hidden');
            
            const cleanup = () => {
                btnOk.removeEventListener('click', onOk);
                btnCancel.removeEventListener('click', onCancel);
                confirmModal.classList.add('hidden');
            };
            
            const onOk = () => { cleanup(); resolve(true); };
            const onCancel = () => { cleanup(); resolve(false); };
            
            btnOk.addEventListener('click', onOk);
            btnCancel.addEventListener('click', onCancel);
        });
    }
    window.showCustomConfirm = showCustomConfirm;

    // IPC Listeners
    window.api.onCommandOutput((output) => {
        if (isCleaning) {
            const text = document.getElementById('cleanup-progress-text');
            // Show only the last line of output if it's a path
            const lines = output.trim().split('\n');
            const lastLine = lines[lines.length - 1];
            if (lastLine && lastLine.length > 5) {
                // Keep it short
                let shortPath = lastLine;
                if (shortPath.length > 50) shortPath = "..." + shortPath.substring(shortPath.length - 47);
                text.textContent = 'กำลังลบ: ' + shortPath;
            }
        } else {
            const modal = document.getElementById('status-modal');
            if (modal && !modal.classList.contains('hidden')) {
                logToModal(output);
            } else {
                logToConsole(output);
            }
        }
    });

    window.api.onCommandDone((success) => {
        finishProgress();
        
        // Handle PC Cleanup completion
        if (isCleaning) {
            clearInterval(cleanupInterval);
            const bar = document.getElementById('cleanup-progress-bar');
            const pct = document.getElementById('cleanup-progress-percent');
            const text = document.getElementById('cleanup-progress-text');
            
            bar.style.width = '100%';
            pct.textContent = '100%';
            text.textContent = 'เสร็จสมบูรณ์! (Cleanup Complete!)';
            text.style.color = '#00e676';
            
            setTimeout(() => {
                isCleaning = false;
                const runBtn = document.getElementById('btn-run-cleanup');
                if (runBtn) runBtn.disabled = false;
                const smartBtn = document.getElementById('btn-smart-clean');
                if (smartBtn) smartBtn.disabled = false;
                
                document.getElementById('cleanup-progress-container').classList.add('hidden');
                text.style.color = 'var(--text-light)';

                const alertEl = document.getElementById('cleanup-summary-alert');
                if (alertEl) alertEl.classList.remove('hidden');

                if (typeof refreshCDriveSpace === 'function') {
                    refreshCDriveSpace();
                }
            }, 2000);
        }
        
        // Refresh test mode status if we were toggling it
        window.api.getTestModeStatus();
    });

    // System Tools
    document.getElementById('btn-devmgmt').addEventListener('click', () => {
        window.api.runCmd('devmgmt', false);
    });
    document.getElementById('btn-regedit').addEventListener('click', () => {
        window.api.runCmd('regedit', false);
    });
    
    
    // ---- PROGRESS MODAL SYSTEM ----
    const progressModal = document.getElementById('tool-progress-modal');
    const progressTitle = document.getElementById('tool-progress-title');
    const progressSubtitle = document.getElementById('tool-progress-subtitle');
    const progressBar = document.getElementById('tool-progress-bar');
    const progressStatus = document.getElementById('tool-progress-status');
    const progressPct = document.getElementById('tool-progress-pct');
    const progressLog = document.getElementById('tool-progress-log');
    const progressClose = document.getElementById('tool-progress-close');
    // Add close button event listener
    if (progressClose) {
        progressClose.addEventListener('click', () => {
            if (progressModal) progressModal.style.display = 'none';
        });
    }

    const progressIcon = document.getElementById('tool-progress-icon');
    
    let progressInterval = null;
    
    function showProgressModal(title, subtitle, icon = '⚙️') {
        if (!progressModal) return;
        progressTitle.textContent = title;
        progressSubtitle.textContent = subtitle;
        progressIcon.textContent = icon;
        progressBar.style.width = '0%';
        progressBar.style.background = 'var(--primary)';
        progressPct.textContent = '0%';
        progressStatus.textContent = 'เริ่มต้น...';
        progressLog.textContent = '';
        progressClose.disabled = true;
        progressModal.style.display = 'flex';
        
        // Simulate progress animation
        let pct = 0;
        clearInterval(progressInterval);
        progressInterval = setInterval(() => {
            pct += Math.random() * 8;
            if (pct > 90) pct = 90; // Hold at 90% until done
            progressBar.style.width = pct + '%';
            progressPct.textContent = Math.floor(pct) + '%';
        }, 400);
    }
    
    function finishProgressModal(success, msg) {
        clearInterval(progressInterval);
        progressBar.style.width = '100%';
        progressPct.textContent = '100%';
        if (success) {
            progressBar.style.background = '#10b981';
            progressStatus.textContent = '✅ เสร็จสมบูรณ์!';
            progressIcon.textContent = '✅';
        } else {
            progressBar.style.background = '#ef4444';
            progressStatus.textContent = '❌ เกิดข้อผิดพลาด';
            progressIcon.textContent = '❌';
        }
        if (msg) progressLog.textContent += msg;
        progressClose.disabled = false;
    }
    
    // Listen for command output to update log
    if (window.api && window.api.onCommandOutput) {
        window.api.onCommandOutput((output) => {
            if (progressModal && progressModal.style.display === 'flex') {
                progressLog.textContent += output + '\n';
                progressLog.scrollTop = progressLog.scrollHeight;
            }
        });
        window.api.onCommandDone((success) => {
            if (progressModal && progressModal.style.display === 'flex') {
                finishProgressModal(success, success ? '' : '\n❌ คำสั่งล้มเหลว');
            }
        });
    }

    // ---- NETWORK TOOLS ----
    function showNetOutput(msg) {
        // legacy - now using modal
    }
    const btnNetReset = document.getElementById('btn-net-reset');
    if (btnNetReset) btnNetReset.addEventListener('click', () => {
        if (confirm('รีเซ็ตเน็ตเวิร์คทั้งหมด? (ต้องการสิทธิ์ Admin)')) {
            showProgressModal('กำลังรีเซ็ตเน็ตเวิร์ค', 'รีเซ็ต TCP/IP, Winsock, DNS Cache...', '🔄');
            window.api.runCmd('net-reset', true);
        }
    });
    const btnFlushDns = document.getElementById('btn-flush-dns');
    if (btnFlushDns) btnFlushDns.addEventListener('click', () => {
        showProgressModal('กำลังล้าง DNS Cache', 'ipconfig /flushdns...', '🧹');
        window.api.runCmd('flush-dns', false);
    });
    const btnShowIp = document.getElementById('btn-show-ip');
    if (btnShowIp) btnShowIp.addEventListener('click', () => {
        showProgressModal('ข้อมูล IP Address', 'กำลังดึงข้อมูลเครือข่าย...', '🖥️');
        window.api.runCmd('show-ip', false);
    });
    const btnPingTest = document.getElementById('btn-ping-test');
    if (btnPingTest) btnPingTest.addEventListener('click', () => {
        showProgressModal('ทดสอบการเชื่อมต่ออินเตอร์เน็ต', 'กำลัง Ping 8.8.8.8 (4 ครั้ง)...', '📡');
        window.api.runCmd('ping-test', false);
    });
    const btnProxy = document.getElementById('btn-proxy');
    if (btnProxy) btnProxy.addEventListener('click', () => window.api.runCmd('proxy', false));

    // ---- DRIVER TOOLS ----
    const driverUrls = {
        'btn-drv-adb': 'https://adb.clockworkmod.com/',
        'btn-drv-mtk': 'https://androidsupported.com/mtk-usb-vcom-driver/',
        'btn-drv-qcom': 'https://qualcomm-hs-usb-qdloader9008.en.lo4d.com/',
        'btn-drv-spd': 'https://spreadtrum-drivers.en.lo4d.com/',
        'btn-drv-samsung': 'https://developer.samsung.com/mobile/android-usb-driver.html',
    };
    Object.entries(driverUrls).forEach(([id, url]) => {
        const btn = document.getElementById(id);
        if (btn) btn.addEventListener('click', async () => {
            if (window.api && window.api.openExternalUrl) await window.api.openExternalUrl(url);
        });
    });
    const btnDrvZadig = document.getElementById('btn-drv-zadig');
    if (btnDrvZadig) btnDrvZadig.addEventListener('click', () => window.api.openZadig());

    // ---- MAINTENANCE ----
    function showMaintOutput(msg) {
        // legacy - now using modal
    }
    const maintCmds = {
        'btn-chkdsk': { id: 'chkdsk', elevated: true, title: 'ตรวจสอบ HDD (CHKDSK)', subtitle: 'ตรวจสอบและซ่อม Bad Sector บน C: ...', icon: '💾', confirm: 'CHKDSK จะทำงานตอน Restart ใช่ไหม?' },
        'btn-sfc': { id: 'sfc', elevated: true, title: 'ซ่อมไฟล์ระบบ (SFC)', subtitle: 'กำลังสแกนและซ่อม Windows System Files...', icon: '🛡️' },
        'btn-dism': { id: 'dism', elevated: true, title: 'ซ่อม Windows Image (DISM)', subtitle: 'กำลัง Restore Health... (อาจใช้เวลา 15-30 นาที)', icon: '🔩' },
        'btn-startup': { id: 'startup', elevated: false, open: true },
        'btn-msinfo': { id: 'msinfo', elevated: false, open: true },
        'btn-services': { id: 'services', elevated: false, open: true },
    };
    Object.entries(maintCmds).forEach(([btnId, opt]) => {
        const btn = document.getElementById(btnId);
        if (btn) btn.addEventListener('click', () => {
            if (opt.confirm && !confirm(opt.confirm)) return;
            if (!opt.open && opt.title) {
                showProgressModal(opt.title, opt.subtitle, opt.icon);
            }
            window.api.runCmd(opt.id, opt.elevated);
        });
    });

    // ---- QUICK LAUNCH ----
    const quickCmds = {
        'btn-taskmgr': 'taskmgr',
        'btn-calc': 'calc',
        'btn-notepad': 'notepad-blank',
        'btn-snip': 'snip',
        'btn-paint': 'paint',
        'btn-diskmgmt': 'diskmgmt',
    };
    Object.entries(quickCmds).forEach(([btnId, cmdId]) => {
        const btn = document.getElementById(btnId);
        if (btn) btn.addEventListener('click', () => window.api.runCmd(cmdId, false));
    });

    // ========================================================
    // ADVANCED SYSTEM TOOLS HANDLERS & LOGIC (10 PRO FEATURES)
    // ========================================================

    // 1. Quick Utilities (Admin Shortcuts)
    const btnCompMgmt = document.getElementById('btn-compmgmt');
    if (btnCompMgmt) btnCompMgmt.addEventListener('click', () => window.api.runCmd('compmgmt', false));

    const btnGpEdit = document.getElementById('btn-gpedit');
    if (btnGpEdit) btnGpEdit.addEventListener('click', () => window.api.runCmd('gpedit', false));

    const btnGodMode = document.getElementById('btn-create-godmode');
    if (btnGodMode) {
        btnGodMode.addEventListener('click', async () => {
            try {
                const res = await window.api.createGodMode();
                if (res.success) {
                    alert('👑 ' + res.message);
                } else {
                    alert('❌ ' + (res.error || 'Failed to create God Mode'));
                }
            } catch (e) {
                alert('❌ ' + e.message);
            }
        });
    }

    // 2. Windows Activation & License Checker
    const btnCheckActivation = document.getElementById('btn-check-activation');
    const winActivationBadge = document.getElementById('win-activation-badge');
    const winActivationDetails = document.getElementById('win-activation-details');
    if (btnCheckActivation) {
        btnCheckActivation.addEventListener('click', async () => {
            btnCheckActivation.disabled = true;
            btnCheckActivation.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังตรวจสอบ...';
            if (winActivationBadge) {
                winActivationBadge.textContent = 'Checking...';
                winActivationBadge.style.background = 'rgba(234, 179, 8, 0.2)';
                winActivationBadge.style.color = '#facc15';
            }
            try {
                const res = await window.api.winCheckActivation();
                if (res.success) {
                    if (res.isActivated) {
                        winActivationBadge.textContent = '🟢 เปิดใช้งานถาวร (Activated)';
                        winActivationBadge.style.background = 'rgba(34, 197, 94, 0.2)';
                        winActivationBadge.style.color = '#4ade80';
                    } else {
                        winActivationBadge.textContent = '🔴 ยังไม่ Activate';
                        winActivationBadge.style.background = 'rgba(239, 68, 68, 0.2)';
                        winActivationBadge.style.color = '#f87171';
                    }
                    if (winActivationDetails) {
                        winActivationDetails.style.display = 'block';
                        winActivationDetails.innerHTML = `<strong>Edition:</strong> ${res.edition}<br><strong>Channel:</strong> ${res.channel}<br><strong>License Status:</strong> ${res.licenseStatus}`;
                    }
                } else {
                    if (winActivationBadge) winActivationBadge.textContent = '❌ ผิดพลาด';
                }
            } catch (e) {
                if (winActivationBadge) winActivationBadge.textContent = '❌ ผิดพลาด';
            } finally {
                btnCheckActivation.disabled = false;
                btnCheckActivation.innerHTML = '<i class="fas fa-search"></i> ตรวจสอบสถานะลิขสิทธิ์ Windows';
            }
        });
    }

    // 3. Ultimate Performance Mode
    const btnUnlockUltimatePerf = document.getElementById('btn-unlock-ultimate-perf');
    const ultimatePerfStatus = document.getElementById('ultimate-perf-status');
    if (btnUnlockUltimatePerf) {
        btnUnlockUltimatePerf.addEventListener('click', async () => {
            btnUnlockUltimatePerf.disabled = true;
            btnUnlockUltimatePerf.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังปลดล็อก...';
            try {
                const res = await window.api.unlockUltimatePerformance();
                if (ultimatePerfStatus) {
                    ultimatePerfStatus.style.display = 'block';
                    if (res.success) {
                        ultimatePerfStatus.style.background = 'rgba(34, 197, 94, 0.2)';
                        ultimatePerfStatus.style.color = '#4ade80';
                        ultimatePerfStatus.textContent = '✅ ' + res.message;
                    } else {
                        ultimatePerfStatus.style.background = 'rgba(239, 68, 68, 0.2)';
                        ultimatePerfStatus.style.color = '#f87171';
                        ultimatePerfStatus.textContent = '❌ ' + res.error;
                    }
                }
            } catch (e) {
                if (ultimatePerfStatus) {
                    ultimatePerfStatus.style.display = 'block';
                    ultimatePerfStatus.style.background = 'rgba(239, 68, 68, 0.2)';
                    ultimatePerfStatus.style.color = '#f87171';
                    ultimatePerfStatus.textContent = '❌ ' + e.message;
                }
            } finally {
                btnUnlockUltimatePerf.disabled = false;
                btnUnlockUltimatePerf.innerHTML = '<i class="fas fa-bolt"></i> ปลดล็อก & เปิดใช้ Ultimate Performance';
            }
        });
    }

    // 4. Battery Health Report
    const btnBatteryReport = document.getElementById('btn-battery-report');
    const batteryReportStatus = document.getElementById('battery-report-status');
    if (btnBatteryReport) {
        btnBatteryReport.addEventListener('click', async () => {
            btnBatteryReport.disabled = true;
            btnBatteryReport.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังสร้างรายงาน...';
            try {
                const res = await window.api.getBatteryReport();
                if (batteryReportStatus) {
                    batteryReportStatus.style.display = 'block';
                    if (res.success) {
                        batteryReportStatus.style.background = 'rgba(34, 197, 94, 0.2)';
                        batteryReportStatus.style.color = '#4ade80';
                        batteryReportStatus.textContent = '✅ สร้างและเปิดรายงานในเบราว์เซอร์แล้ว (' + (res.reportPath || '') + ')';
                    } else {
                        batteryReportStatus.style.background = 'rgba(234, 179, 8, 0.2)';
                        batteryReportStatus.style.color = '#facc15';
                        batteryReportStatus.textContent = res.error || 'ไม่พบแบตเตอรี่ในอุปกรณ์นี้';
                    }
                }
            } catch (e) {
                if (batteryReportStatus) {
                    batteryReportStatus.style.display = 'block';
                    batteryReportStatus.style.background = 'rgba(239, 68, 68, 0.2)';
                    batteryReportStatus.style.color = '#f87171';
                    batteryReportStatus.textContent = '❌ ' + e.message;
                }
            } finally {
                btnBatteryReport.disabled = false;
                btnBatteryReport.innerHTML = '<i class="fas fa-file-medical-alt"></i> สร้างและเปิดรายงานแบตเตอรี่';
            }
        });
    }

    // 5. Windows Defender Live Status & Control
    async function updateDefenderBadge() {
        const badge = document.getElementById('defender-live-badge');
        if (!badge || !window.api || !window.api.getDefenderStatus) return;
        try {
            const res = await window.api.getDefenderStatus();
            if (res.success) {
                if (res.realTimeEnabled) {
                    badge.textContent = '🟢 ปกป้องอยู่ (Active)';
                    badge.style.background = 'rgba(34, 197, 94, 0.2)';
                    badge.style.color = '#4ade80';
                    badge.style.border = '1px solid rgba(34, 197, 94, 0.4)';
                } else {
                    badge.textContent = '🔴 ปิดอยู่ (Disabled)';
                    badge.style.background = 'rgba(239, 68, 68, 0.2)';
                    badge.style.color = '#f87171';
                    badge.style.border = '1px solid rgba(239, 68, 68, 0.4)';
                }
            }
        } catch (e) {
            console.error('Defender status error:', e);
        }
    }

    const btnDefOff = document.getElementById('btn-def-off');
    if (btnDefOff) {
        btnDefOff.addEventListener('click', () => {
            showProgressModal('กำลังปิด Windows Defender', 'ปิด Real-time Protection...', '🛡️');
            window.api.runCmd('def-off', true);
            setTimeout(updateDefenderBadge, 3500);
        });
    }
    const btnDefOn = document.getElementById('btn-def-on');
    if (btnDefOn) {
        btnDefOn.addEventListener('click', () => {
            showProgressModal('กำลังเปิด Windows Defender', 'เปิด Real-time Protection...', '🛡️');
            window.api.runCmd('def-on', true);
            setTimeout(updateDefenderBadge, 3500);
        });
    }

    // 6. Windows Update Manager
    const winUpdateStatus = document.getElementById('win-update-status');
    function handleWinUpdate(action, btn, title) {
        if (!btn) return;
        btn.addEventListener('click', async () => {
            btn.disabled = true;
            const origHtml = btn.innerHTML;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>...';
            if (winUpdateStatus) {
                winUpdateStatus.style.display = 'block';
                winUpdateStatus.style.background = 'rgba(234, 179, 8, 0.2)';
                winUpdateStatus.style.color = '#facc15';
                winUpdateStatus.textContent = 'กำลังดำเนินการ ' + title + '...';
            }
            try {
                const res = await window.api.winUpdateAction(action);
                if (winUpdateStatus) {
                    if (res.success) {
                        winUpdateStatus.style.background = 'rgba(34, 197, 94, 0.2)';
                        winUpdateStatus.style.color = '#4ade80';
                        winUpdateStatus.textContent = '✅ ' + res.message;
                    } else {
                        winUpdateStatus.style.background = 'rgba(239, 68, 68, 0.2)';
                        winUpdateStatus.style.color = '#f87171';
                        winUpdateStatus.textContent = '❌ ' + (res.error || 'เกิดข้อผิดพลาด');
                    }
                }
            } catch (e) {
                if (winUpdateStatus) {
                    winUpdateStatus.style.background = 'rgba(239, 68, 68, 0.2)';
                    winUpdateStatus.style.color = '#f87171';
                    winUpdateStatus.textContent = '❌ ' + e.message;
                }
            } finally {
                btn.disabled = false;
                btn.innerHTML = origHtml;
            }
        });
    }
    handleWinUpdate('pause', document.getElementById('btn-pause-updates'), 'หยุดอัปเดต');
    handleWinUpdate('resume', document.getElementById('btn-resume-updates'), 'เปิดรับอัปเดต');
    handleWinUpdate('fix', document.getElementById('btn-fix-updates'), 'ซ่อมแซมแคชอัปเดต');

    // 7. BSOD Minidump Crash Analyzer
    const btnAnalyzeBsod = document.getElementById('btn-analyze-bsod');
    const bsodResultBox = document.getElementById('bsod-result-box');
    if (btnAnalyzeBsod) {
        btnAnalyzeBsod.addEventListener('click', async () => {
            btnAnalyzeBsod.disabled = true;
            btnAnalyzeBsod.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังสแกน Minidump...';
            if (bsodResultBox) {
                bsodResultBox.style.display = 'block';
                bsodResultBox.textContent = 'กำลังตรวจสอบโฟลเดอร์ C:\Windows\Minidump...';
            }
            try {
                const res = await window.api.analyzeBsod();
                if (bsodResultBox) {
                    if (res.success) {
                        if (res.dumps && res.dumps.length > 0) {
                            let html = `<div style="color: #4ade80; font-weight: bold; margin-bottom: 6px;">พบ ${res.dumps.length} Minidump ล่าสุด:</div>`;
                            res.dumps.forEach((d, idx) => {
                                html += `<div style="border-top: 1px solid rgba(255,255,255,0.1); padding-top: 4px; margin-top: 4px;">
                                    <strong>[${idx + 1}] ${d.fileName}</strong> (${d.date})<br>
                                    <span style="color: #f87171;">BugCheck: ${d.bugCheck}</span> | ไดรเวอร์ที่เกี่ยวข้อง: <span style="color: #fbbf24;">${d.probableCause || 'N/A'}</span>
                                </div>`;
                            });
                            bsodResultBox.innerHTML = html;
                        } else {
                            bsodResultBox.innerHTML = `<div style="color: #4ade80;">✅ ไม่พบไฟล์ Minidump (ระบบไม่เคยจอฟ้า หรือเพิ่งล้างแคชไป)</div>`;
                        }
                    } else {
                        bsodResultBox.innerHTML = `<div style="color: #fbbf24;">ℹ️ ${res.message || res.error}</div>`;
                    }
                }
            } catch (e) {
                if (bsodResultBox) bsodResultBox.innerHTML = `<div style="color: #f87171;">❌ ${e.message}</div>`;
            } finally {
                btnAnalyzeBsod.disabled = false;
                btnAnalyzeBsod.innerHTML = '<i class="fas fa-search-plus"></i> สแกนวิเคราะห์จอฟ้า (Minidump)';
            }
        });
    }

    // 8. Win 11 Classic Menu & Take Ownership
    async function updateWin11MenuBadge() {
        const badge = document.getElementById('win11-menu-badge');
        if (!badge || !window.api || !window.api.getWin11MenuStatus) return;
        try {
            const res = await window.api.getWin11MenuStatus();
            if (res.success) {
                if (res.isClassic) {
                    badge.textContent = 'Classic Menu';
                    badge.style.background = 'rgba(34, 197, 94, 0.2)';
                    badge.style.color = '#4ade80';
                } else {
                    badge.textContent = 'Win 11 Default';
                    badge.style.background = 'rgba(255, 255, 255, 0.08)';
                    badge.style.color = '#94a3b8';
                }
            }
        } catch (e) {}
    }

    const btnToggleWin11Menu = document.getElementById('btn-toggle-win11-menu');
    const win11MenuStatus = document.getElementById('win11-menu-status');
    if (btnToggleWin11Menu) {
        btnToggleWin11Menu.addEventListener('click', async () => {
            btnToggleWin11Menu.disabled = true;
            try {
                const res = await window.api.toggleWin11ClassicMenu();
                if (win11MenuStatus) {
                    win11MenuStatus.style.display = 'block';
                    if (res.success) {
                        win11MenuStatus.style.background = 'rgba(34, 197, 94, 0.2)';
                        win11MenuStatus.style.color = '#4ade80';
                        win11MenuStatus.textContent = '✅ ' + res.message;
                    } else {
                        win11MenuStatus.style.background = 'rgba(239, 68, 68, 0.2)';
                        win11MenuStatus.style.color = '#f87171';
                        win11MenuStatus.textContent = '❌ ' + (res.error || 'ล้มเหลว');
                    }
                }
                updateWin11MenuBadge();
            } catch (e) {
                if (win11MenuStatus) {
                    win11MenuStatus.style.display = 'block';
                    win11MenuStatus.style.background = 'rgba(239, 68, 68, 0.2)';
                    win11MenuStatus.style.color = '#f87171';
                    win11MenuStatus.textContent = '❌ ' + e.message;
                }
            } finally {
                btnToggleWin11Menu.disabled = false;
            }
        });
    }

    const btnAddTakeOwnership = document.getElementById('btn-add-take-ownership');
    if (btnAddTakeOwnership) {
        btnAddTakeOwnership.addEventListener('click', async () => {
            btnAddTakeOwnership.disabled = true;
            try {
                const res = await window.api.addTakeOwnership();
                if (win11MenuStatus) {
                    win11MenuStatus.style.display = 'block';
                    if (res.success) {
                        win11MenuStatus.style.background = 'rgba(34, 197, 94, 0.2)';
                        win11MenuStatus.style.color = '#4ade80';
                        win11MenuStatus.textContent = '✅ ' + res.message;
                    } else {
                        win11MenuStatus.style.background = 'rgba(239, 68, 68, 0.2)';
                        win11MenuStatus.style.color = '#f87171';
                        win11MenuStatus.textContent = '❌ ' + res.error;
                    }
                }
            } catch (e) {
                alert('Error: ' + e.message);
            } finally {
                btnAddTakeOwnership.disabled = false;
            }
        });
    }

    // 9. Driver Export & Restore
    const btnDriverExport = document.getElementById('btn-driver-export');
    const btnDriverRestore = document.getElementById('btn-driver-restore');
    if (btnDriverExport) {
        btnDriverExport.addEventListener('click', async () => {
            showProgressModal('กำลังสำรองไดรเวอร์ทั้งหมด', 'DISM กำลัง Export 3rd-party drivers ไปที่ C:\\DriverBackup...', '💾');
            try {
                const res = await window.api.driverExportAll();
                finishProgressModal(res.success, res.success ? `\n✅ สำรองไดรเวอร์เรียบร้อยแล้วที่:\n${res.path}` : `\n❌ เกิดข้อผิดพลาด: ${res.error}`);
            } catch (e) {
                finishProgressModal(false, `\n❌ ${e.message}`);
            }
        });
    }
    if (btnDriverRestore) {
        btnDriverRestore.addEventListener('click', async () => {
            const ok = await showCustomConfirm('ต้องการติดตั้งไดรเวอร์คืนจาก C:\\DriverBackup ใช่หรือไม่?\n\n(pnputil จะทำการติดตั้งไดรเวอร์ .inf ทั้งหมดในโฟลเดอร์)');
            if (!ok) return;
            showProgressModal('กำลังติดตั้งไดรเวอร์คืน', 'pnputil กำลังติดตั้งไดรเวอร์จาก C:\\DriverBackup...', '💾');
            try {
                const res = await window.api.driverRestoreAll();
                finishProgressModal(res.success, res.success ? `\n✅ ติดตั้งไดรเวอร์คืนเรียบร้อยแล้ว!` : `\n❌ เกิดข้อผิดพลาด: ${res.error}`);
            } catch (e) {
                finishProgressModal(false, `\n❌ ${e.message}`);
            }
        });
    }

    // 10. Port Scanner & Process Killer
    const inputKillerPort = document.getElementById('input-killer-port');
    const btnPortCheck = document.getElementById('btn-port-check');
    const btnPortKill = document.getElementById('btn-port-kill');
    const portKillerResult = document.getElementById('port-killer-result');
    let currentKillerPid = null;

    if (btnPortCheck) {
        btnPortCheck.addEventListener('click', async () => {
            const port = inputKillerPort.value.trim();
            if (!port) {
                alert('กรุณากรอกหมายเลขพอร์ต');
                return;
            }
            btnPortCheck.disabled = true;
            btnPortCheck.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
            if (portKillerResult) {
                portKillerResult.style.display = 'block';
                portKillerResult.textContent = `กำลังตรวจสอบพอร์ต :${port}...`;
            }
            try {
                const res = await window.api.checkPortKiller(port);
                if (res.success) {
                    if (res.found) {
                        currentKillerPid = res.pid;
                        portKillerResult.innerHTML = `<span style="color: #f87171; font-weight: bold;">🔴 พอร์ตถูกใช้งานอยู่!</span><br><strong>Process:</strong> ${res.procName} (PID: ${res.pid})<br><strong>Line:</strong> ${res.line}`;
                        if (btnPortKill) {
                            btnPortKill.style.display = 'block';
                            btnPortKill.innerHTML = `<i class="fas fa-skull"></i> ปิด ${res.procName} (PID: ${res.pid})`;
                        }
                    } else {
                        currentKillerPid = null;
                        portKillerResult.innerHTML = `<span style="color: #4ade80;">🟢 พอร์ต ${port} ว่าง (ไม่มีโปรแกรมใดบล็อกอยู่)</span>`;
                        if (btnPortKill) btnPortKill.style.display = 'none';
                    }
                } else {
                    portKillerResult.textContent = '❌ ' + res.error;
                }
            } catch (e) {
                portKillerResult.textContent = '❌ ' + e.message;
            } finally {
                btnPortCheck.disabled = false;
                btnPortCheck.innerHTML = '<i class="fas fa-search"></i> ตรวจ';
            }
        });
    }

    if (btnPortKill) {
        btnPortKill.addEventListener('click', async () => {
            if (!currentKillerPid) return;
            const ok = await showCustomConfirm(`ยืนยันการบังคับปิด Process PID ${currentKillerPid} หรือไม่?`);
            if (!ok) return;
            btnPortKill.disabled = true;
            try {
                const res = await window.api.killProcessPid(currentKillerPid);
                if (res.success) {
                    alert('✅ สั่งปิดกระบวนการเรียบร้อยแล้ว!');
                    btnPortKill.style.display = 'none';
                    currentKillerPid = null;
                    if (btnPortCheck) btnPortCheck.click();
                } else {
                    alert('❌ ไม่สามารถปิดได้: ' + res.error);
                }
            } catch (e) {
                alert('❌ ' + e.message);
            } finally {
                btnPortKill.disabled = false;
            }
        });
    }

    // 11. Visual C++ & DirectX Runtime Installer
    const btnInstallVcRedist = document.getElementById('btn-install-vcredist');
    if (btnInstallVcRedist) {
        btnInstallVcRedist.addEventListener('click', async () => {
            const ok = await showCustomConfirm('ต้องการเริ่มติดตั้งชุด Visual C++ 2005-2022 และ DirectX หรือไม่?\n\n(ระบบจะเรียก winget ติดตั้ง Runtimes ทั้งหมดแบบอัตโนมัติ)');
            if (!ok) return;
            showProgressModal('กำลังติดตั้ง VC++ & DirectX', 'กำลังดาวน์โหลดและติดตั้งชุดรันไทม์ทั้งหมด...', '⚙️');
            try {
                const res = await window.api.installVcRedist();
                finishProgressModal(res.success, res.success ? `\n✅ ติดตั้งชุด Runtime สำเร็จเรียบร้อยแล้ว!` : `\n${res.error || res.message}`);
            } catch (e) {
                finishProgressModal(false, `\n❌ ${e.message}`);
            }
        });
    }

    // 12. Hosts File Editor & Reset Default
    const btnHosts = document.getElementById('btn-hosts');
    if (btnHosts) {
        btnHosts.addEventListener('click', () => {
            window.api.runCmd('hosts', true);
        });
    }

    const btnResetHosts = document.getElementById('btn-reset-hosts');
    const hostsResetStatus = document.getElementById('hosts-reset-status');
    if (btnResetHosts) {
        btnResetHosts.addEventListener('click', async () => {
            const ok = await showCustomConfirm('คุณแน่ใจหรือไม่ที่จะรีเซ็ตไฟล์ Hosts กลับเป็นค่าเริ่มต้นแท้ของ Windows?\n\n(การบล็อกโดเมนทั้งหมดจะถูกล้าง)');
            if (!ok) return;
            btnResetHosts.disabled = true;
            try {
                const res = await window.api.resetDefaultHosts();
                if (hostsResetStatus) {
                    hostsResetStatus.style.display = 'block';
                    if (res.success) {
                        hostsResetStatus.style.background = 'rgba(34, 197, 94, 0.2)';
                        hostsResetStatus.style.color = '#4ade80';
                        hostsResetStatus.textContent = '✅ ' + res.message;
                    } else {
                        hostsResetStatus.style.background = 'rgba(239, 68, 68, 0.2)';
                        hostsResetStatus.style.color = '#f87171';
                        hostsResetStatus.textContent = '❌ ' + res.error;
                    }
                }
            } catch (e) {
                alert('Error: ' + e.message);
            } finally {
                btnResetHosts.disabled = false;
            }
        });
    }

    // 13. Network Adapters
    const btnNcpa = document.getElementById('btn-ncpa');
    if (btnNcpa) {
        btnNcpa.addEventListener('click', () => {
            window.api.runCmd('ncpa', false);
        });
    }

    // 14. Reserved Storage
    const btnStorage = document.getElementById('btn-storage');
    if (btnStorage) {
        btnStorage.addEventListener('click', () => {
            showProgressModal('ปิด Reserved Storage', 'กำลังคืนพื้นที่ฮาร์ดดิสก์ 7GB (Admin)...', '💾');
            window.api.runCmd('storage', true);
        });
    }

    // 15. WiFi Passwords with Copy Feature
    let lastRetrievedWifiPw = '';
    const wifiPwResult = document.getElementById('wifi-pw-result');
    const btnWifiCopy = document.getElementById('btn-wifi-copy');

    document.getElementById('btn-wifi-scan').addEventListener('click', async () => {
        const select = document.getElementById('wifi-profiles');
        select.innerHTML = '<option value="">Scanning...</option>';
        if (wifiPwResult) wifiPwResult.style.display = 'none';
        lastRetrievedWifiPw = '';
        try {
            const profiles = await window.api.getWifiProfiles();
            select.innerHTML = '';
            if (profiles.length === 0) {
                select.innerHTML = '<option value="">No profiles found</option>';
            } else {
                profiles.forEach(p => {
                    const opt = document.createElement('option');
                    opt.value = p;
                    opt.textContent = p;
                    select.appendChild(opt);
                });
            }
        } catch (err) {
            select.innerHTML = '<option value="">Error scanning</option>';
            alert("Error: " + err);
        }
    });

    document.getElementById('btn-wifi-show').addEventListener('click', async () => {
        const select = document.getElementById('wifi-profiles');
        const profileName = select.value;
        if (!profileName) {
            alert("กรุณาเลือกชื่อ WiFi ก่อน");
            return;
        }
        try {
            const result = await window.api.getWifiPassword(profileName);
            const match = result.match(/(?:Key Content|เนื้อหาของคีย์)\s*:\s*(.+)/i);
            const cleanPw = match ? match[1].trim() : '(ไม่มีรหัสผ่าน หรือเปิดเป็น Open)';
            lastRetrievedWifiPw = cleanPw;
            if (wifiPwResult) {
                wifiPwResult.style.display = 'block';
                wifiPwResult.innerHTML = `🔑 รหัสผ่าน <strong>${profileName}</strong>: <span style="color:#fbbf24; font-size:14px; font-weight:bold;">${cleanPw}</span>`;
            }
            openModal('WiFi Password: ' + profileName);
            logToModal(result);
            finishProgress();
        } catch (err) {
            alert("Error: " + err);
        }
    });

    if (btnWifiCopy) {
        btnWifiCopy.addEventListener('click', async () => {
            const select = document.getElementById('wifi-profiles');
            const profileName = select.value;
            if (!profileName) {
                alert('กรุณาเลือกชื่อ WiFi ก่อน');
                return;
            }
            try {
                let pwToCopy = lastRetrievedWifiPw;
                if (!pwToCopy) {
                    const res = await window.api.getWifiPassword(profileName);
                    const match = res.match(/(?:Key Content|เนื้อหาของคีย์)\s*:\s*(.+)/i);
                    pwToCopy = match ? match[1].trim() : res.trim();
                }
                await navigator.clipboard.writeText(pwToCopy);
                if (wifiPwResult) {
                    wifiPwResult.style.display = 'block';
                    wifiPwResult.innerHTML = `📋 คัดลอกรหัสผ่าน <strong>${profileName}</strong> ใส่คลิปบอร์ดแล้ว!`;
                }
                alert(`✅ คัดลอกรหัสผ่าน WiFi (${profileName}) สำเร็จแล้ว:\n${pwToCopy}`);
            } catch (e) {
                alert('Error copying password: ' + e.message);
            }
        });
    }

    // 16. Rainmeter Skins Integration
    const btnDlRm = document.getElementById('btn-dl-rm');
    if (btnDlRm) btnDlRm.addEventListener('click', () => window.api.downloadRainmeter());
    const btnApplyRm = document.getElementById('btn-apply-rm');
    if (btnApplyRm) btnApplyRm.addEventListener('click', () => window.api.applyRainmeterSkins());
    const btnApplyRmFull = document.getElementById('btn-apply-rm-full');
    if (btnApplyRmFull) btnApplyRmFull.addEventListener('click', () => window.api.applyRainmeterFull());

    document.getElementById('btn-usb-scan').addEventListener('click', async () => {
        const select = document.getElementById('usb-drive-select');
        select.innerHTML = '<option value="">Scanning...</option>';
        try {
            const drives = await window.api.getDrives();
            select.innerHTML = '';
            if (drives.length === 0) {
                select.innerHTML = '<option value="">No drives found</option>';
            } else {
                drives.forEach(d => {
                    const opt = document.createElement('option');
                    opt.value = d.name;
                    opt.textContent = `${d.name} (${d.label})`;
                    select.appendChild(opt);
                });
            }
        } catch (err) {
            select.innerHTML = '<option value="">Error scanning</option>';
            alert("Error: " + err);
        }
    });

    document.getElementById('btn-usb-fix').addEventListener('click', async () => {
        const select = document.getElementById('usb-drive-select');
        const drive = select.value;
        if (!drive) {
            alert("Please select a drive first.");
            return;
        }
        const userConfirmed = await showCustomConfirm(`คุณแน่ใจหรือไม่ที่จะแก้ไวรัสซ่อนไฟล์ในไดรฟ์ ${drive}?\n\nการทำงานนี้จะทำการยกเลิกการซ่อนไฟล์ทั้งหมด และลบไฟล์ทางลัด (.lnk) ที่เกิดจากไวรัสออกจากไดรฟ์ทันที`);
        if (!userConfirmed) return;

        openModal('Fixing USB Virus on ' + drive);
        
        try {
            const result = await window.api.fixUsbVirus(drive);
            logToModal(result);
        } catch (err) {
            logToModal("Error: " + err);
        }
        finishProgress();
    });

    // PC Cleanup
    // Function to refresh C: Drive Capacity
    async function refreshCDriveSpace() {
        try {
            const info = await window.api.getCDriveSpace();
            if (!info || !info.success) return;
            
            const freeEl = document.getElementById('drive-c-free');
            const totalEl = document.getElementById('drive-c-total');
            const usedEl = document.getElementById('drive-c-used');
            const pctEl = document.getElementById('drive-c-pct-text');
            const barEl = document.getElementById('drive-c-bar');
            const badgeEl = document.getElementById('drive-c-badge');
            
            if (freeEl) freeEl.textContent = `${info.freeGB} GB`;
            if (totalEl) totalEl.textContent = `${info.totalGB} GB`;
            if (usedEl) usedEl.textContent = `${info.usedGB} GB`;
            if (pctEl) pctEl.textContent = `${info.percent}%`;
            
            if (barEl) {
                barEl.style.width = `${Math.min(100, Math.max(0, info.percent))}%`;
                if (info.percent > 90) {
                    barEl.style.background = 'linear-gradient(90deg, #ff9800, #ff1744)';
                } else if (info.percent > 75) {
                    barEl.style.background = 'linear-gradient(90deg, #26c6da, #ff9800)';
                } else {
                    barEl.style.background = 'linear-gradient(90deg, #26c6da, #00e676)';
                }
            }
            
            if (badgeEl) {
                if (info.percent > 90) {
                    badgeEl.className = 'badge danger';
                    badgeEl.textContent = currentLang === 'th' ? 'พื้นที่เหลือน้อยวิกฤต' : 'Critical Low';
                } else if (info.percent > 75) {
                    badgeEl.className = 'badge warning';
                    badgeEl.textContent = currentLang === 'th' ? 'พื้นที่เริ่มเหลือน้อย' : 'Warning Low';
                } else {
                    badgeEl.className = 'badge success';
                    badgeEl.textContent = currentLang === 'th' ? 'ปกติ (Healthy)' : 'Healthy';
                }
            }
        } catch (e) {
            console.error('Failed to get C: drive space:', e);
        }
    }

    // Refresh Drive Space button
    const btnRefreshDrive = document.getElementById('btn-refresh-drive');
    if (btnRefreshDrive) {
        btnRefreshDrive.addEventListener('click', async () => {
            const icon = btnRefreshDrive.querySelector('i');
            if (icon) icon.classList.add('fa-spin');
            await refreshCDriveSpace();
            setTimeout(() => {
                if (icon) icon.classList.remove('fa-spin');
            }, 600);
        });
    }

    // Close cleanup alert
    const btnCloseAlert = document.getElementById('btn-close-cleanup-alert');
    if (btnCloseAlert) {
        btnCloseAlert.addEventListener('click', () => {
            document.getElementById('cleanup-summary-alert').classList.add('hidden');
        });
    }

    // Parent checkbox toggles all sub-checkboxes & sub toggles parent
    function bindCleanupGroup(parentId, subClass) {
        const parent = document.getElementById(parentId);
        const subs = document.querySelectorAll('.' + subClass);
        if (!parent || !subs.length) return;
        
        parent.addEventListener('change', () => {
            subs.forEach(c => c.checked = parent.checked);
        });
        
        subs.forEach(s => {
            s.addEventListener('change', () => {
                const anyChecked = Array.from(subs).some(sub => sub.checked);
                parent.checked = anyChecked;
            });
        });
    }

    bindCleanupGroup('chk-temp', 'sub-chk-temp');
    bindCleanupGroup('chk-trash', 'sub-chk-trash');
    bindCleanupGroup('chk-shader', 'sub-chk-shader');
    bindCleanupGroup('chk-browser', 'sub-chk-browser');
    bindCleanupGroup('chk-game', 'sub-chk-game');
    bindCleanupGroup('chk-app', 'sub-chk-app');
    bindCleanupGroup('chk-dev', 'sub-chk-dev');
    bindCleanupGroup('chk-win', 'sub-chk-win');

    // Presets
    const btnPresetAll = document.getElementById('btn-preset-all');
    if (btnPresetAll) {
        btnPresetAll.addEventListener('click', () => {
            document.querySelectorAll('#cleanup-section input[type="checkbox"]').forEach(c => c.checked = true);
        });
    }

    const btnPresetNone = document.getElementById('btn-preset-none');
    if (btnPresetNone) {
        btnPresetNone.addEventListener('click', () => {
            document.querySelectorAll('#cleanup-section input[type="checkbox"]').forEach(c => c.checked = false);
        });
    }

    const btnPresetSafe = document.getElementById('btn-preset-safe');
    if (btnPresetSafe) {
        btnPresetSafe.addEventListener('click', () => {
            const safeGroups = ['chk-temp', 'chk-trash', 'chk-shader', 'chk-browser', 'chk-game', 'chk-app'];
            const unsafeGroups = ['chk-dev', 'chk-win'];
            
            safeGroups.forEach(id => {
                const el = document.getElementById(id);
                if (el) {
                    el.checked = true;
                    el.dispatchEvent(new Event('change'));
                }
            });
            unsafeGroups.forEach(id => {
                const el = document.getElementById(id);
                if (el) {
                    el.checked = false;
                    el.dispatchEvent(new Event('change'));
                }
            });
            const elEvt = document.getElementById('chk-temp-eventlogs');
            if (elEvt) elEvt.checked = false;
            const elLogs = document.getElementById('chk-trash-logs');
            if (elLogs) elLogs.checked = false;
        });
    }

    let cleanupInterval = null;
    let isCleaning = false;
    let scanInterval = null;
    let isScanning = false;

    function executeCleanup(options) {
        if (isCleaning) return;
        isCleaning = true;
        
        const runBtn = document.getElementById('btn-run-cleanup');
        const smartBtn = document.getElementById('btn-smart-clean');
        if (runBtn) runBtn.disabled = true;
        if (smartBtn) smartBtn.disabled = true;
        
        const alertEl = document.getElementById('cleanup-summary-alert');
        if (alertEl) alertEl.classList.add('hidden');
        
        const container = document.getElementById('cleanup-progress-container');
        const text = document.getElementById('cleanup-progress-text');
        const bar = document.getElementById('cleanup-progress-bar');
        const pct = document.getElementById('cleanup-progress-percent');
        
        container.classList.remove('hidden');
        text.textContent = currentLang === 'th' ? 'กำลังเริ่มลบไฟล์ขยะและแคชระบบ...' : 'Starting cleanup...';
        bar.style.width = '0%';
        pct.textContent = '0%';
        
        let progress = 0;
        clearInterval(cleanupInterval);
        cleanupInterval = setInterval(() => {
            if (progress < 90) {
                progress += options.hasWin ? 2 : 5;
                if (progress > 90) progress = 90;
                bar.style.width = progress + '%';
                pct.textContent = progress + '%';
            }
        }, 400);

        window.api.runCleanup(options);
    }

    // 1-Click Smart Clean
    const btnSmartClean = document.getElementById('btn-smart-clean');
    if (btnSmartClean) {
        btnSmartClean.addEventListener('click', () => {
            const options = {
                temp: { user: true, win: true, prefetch: true, recent: true, thumb: true, delivery: true, eventlogs: false },
                trash: { recycle: true, dumps: true, wer: true, logs: false },
                shader: { d3d: true, nvidia: true, amd: true, intel: true },
                browser: { chrome: true, edge: true, firefox: true, brave: true, opera: true },
                game: { steam: true, epic: true, riot: true, ea: true },
                app: { discord: true, spotify: true, line: true, telegram: true, apple: true, tiktok: true },
                dev: { gradle: false, npm: false, pip: false, nuget: false, pub: false, yarn: false },
                win: { update: true, cleanmgr: false, dism: false },
                hasWin: true
            };
            executeCleanup(options);
        });
    }

    // Scan Junk Files
    document.getElementById('btn-scan-junk').addEventListener('click', async () => {
        if (isScanning || isCleaning) return;
        isScanning = true;
        
        const scanBtn = document.getElementById('btn-scan-junk');
        const originalText = scanBtn.innerHTML;
        scanBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> ' + (translations[currentLang]?.scan_progress || 'Scanning...');
        scanBtn.disabled = true;
        
        const progContainer = document.getElementById('scan-progress-container');
        const resultsContainer = document.getElementById('scan-results-container');
        const bar = document.getElementById('scan-progress-bar');
        const pct = document.getElementById('scan-progress-percent');
        const resultsList = document.getElementById('scan-results-list');
        const totalSize = document.getElementById('scan-total-size');
        
        resultsContainer.classList.add('hidden');
        progContainer.classList.remove('hidden');
        bar.style.width = '0%';
        pct.textContent = '0%';
        resultsList.innerHTML = '';
        totalSize.textContent = '';
        
        let progress = 0;
        scanInterval = setInterval(() => {
            if (progress < 95) {
                progress += 3;
                if (progress > 95) progress = 95;
                bar.style.width = progress + '%';
                pct.textContent = progress + '%';
            }
        }, 300);

        try {
            const result = await window.api.scanJunk();
            clearInterval(scanInterval);
            bar.style.width = '100%';
            pct.textContent = '100%';
            
            setTimeout(() => {
                progContainer.classList.add('hidden');
                resultsContainer.classList.remove('hidden');
                
                const mbTotal = (result.totalBytes / (1024 * 1024)).toFixed(2);
                const gbTotal = (result.totalBytes / (1024 * 1024 * 1024)).toFixed(2);
                totalSize.textContent = result.totalBytes > 1024 * 1024 * 1024 ? `${gbTotal} GB` : `${mbTotal} MB`;
                
                const entries = Object.entries(result.results);
                entries.forEach(([name, size]) => {
                    if (size > 0) {
                        const sizeMB = (size / (1024 * 1024)).toFixed(2);
                        const item = document.createElement('div');
                        item.style = 'font-size: 13px; color: var(--text-light); display: flex; justify-content: space-between; align-items: center; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.06); border-radius: 6px; padding: 6px 12px;';
                        item.innerHTML = `<span><i class="fas fa-folder" style="color: #26c6da; margin-right: 6px; font-size: 11px;"></i>${name}</span><span style="color: #00e676; font-weight: 600; font-family: monospace;">${sizeMB} MB</span>`;
                        resultsList.appendChild(item);
                    }
                });
                if (resultsList.children.length === 0) {
                    resultsList.innerHTML = '<span style="color: var(--text-light); font-size: 13px;">' + (translations[currentLang]?.scan_no_junk || 'No junk files found!') + '</span>';
                }
                
                scanBtn.innerHTML = originalText;
                scanBtn.disabled = false;
                isScanning = false;
            }, 400);
            
        } catch (error) {
            console.error('Scan error:', error);
            clearInterval(scanInterval);
            scanBtn.innerHTML = originalText;
            scanBtn.disabled = false;
            isScanning = false;
            progContainer.classList.add('hidden');
        }
    });

    // Run Selected Cleanup
    document.getElementById('btn-run-cleanup').addEventListener('click', () => {
        if (isCleaning) return;
        const getChk = (id) => {
            const el = document.getElementById(id);
            return el ? el.checked : false;
        };
        
        const options = {
            temp: {
                user: getChk('chk-temp-user'),
                win: getChk('chk-temp-win'),
                prefetch: getChk('chk-temp-prefetch'),
                recent: getChk('chk-temp-recent'),
                thumb: getChk('chk-temp-thumb'),
                delivery: getChk('chk-temp-delivery'),
                eventlogs: getChk('chk-temp-eventlogs')
            },
            trash: {
                recycle: getChk('chk-trash-recycle'),
                dumps: getChk('chk-trash-dumps'),
                wer: getChk('chk-trash-wer'),
                logs: getChk('chk-trash-logs')
            },
            shader: {
                d3d: getChk('chk-shader-d3d'),
                nvidia: getChk('chk-shader-nvidia'),
                amd: getChk('chk-shader-amd'),
                intel: getChk('chk-shader-intel')
            },
            browser: {
                chrome: getChk('chk-browser-chrome'),
                edge: getChk('chk-browser-edge'),
                firefox: getChk('chk-browser-firefox'),
                brave: getChk('chk-browser-brave'),
                opera: getChk('chk-browser-opera')
            },
            game: {
                steam: getChk('chk-game-steam'),
                epic: getChk('chk-game-epic'),
                riot: getChk('chk-game-riot'),
                ea: getChk('chk-game-ea')
            },
            app: {
                discord: getChk('chk-app-discord'),
                spotify: getChk('chk-app-spotify'),
                line: getChk('chk-app-line'),
                apple: getChk('chk-app-apple'),
                telegram: getChk('chk-app-telegram'),
                tiktok: getChk('chk-app-tiktok')
            },
            dev: {
                gradle: getChk('chk-dev-gradle'),
                npm: getChk('chk-dev-npm'),
                pip: getChk('chk-dev-pip'),
                nuget: getChk('chk-dev-nuget'),
                pub: getChk('chk-dev-pub'),
                yarn: getChk('chk-dev-yarn')
            },
            win: {
                update: getChk('chk-win-update'),
                cleanmgr: getChk('chk-win-cleanmgr'),
                dism: getChk('chk-win-dism')
            },
            hasWin: getChk('chk-win-update') || getChk('chk-win-cleanmgr') || getChk('chk-win-dism')
        };
        
        executeCleanup(options);
    });

    // Test Mode
    const testmodeStatusText = document.getElementById('testmode-status-text');
    const testmodeDot = document.getElementById('testmode-dot');

    window.api.onTestModeStatusReply((status) => {
        if (status === 'ON') {
            testmodeStatusText.textContent = translations[currentLang]['test_status_on'];
            testmodeDot.classList.remove('off');
            testmodeDot.classList.add('on');
        } else {
            testmodeStatusText.textContent = translations[currentLang]['test_status_off'];
            testmodeDot.classList.remove('on');
            testmodeDot.classList.add('off');
        }
    });

    // Initial check
    window.api.getTestModeStatus();

    document.getElementById('btn-testmode-on').addEventListener('click', () => {
        openModal('modal_title_test_on');
        window.api.runCmd('testmode-on', true);
    });

    document.getElementById('btn-testmode-off').addEventListener('click', () => {
        openModal('modal_title_test_off');
        window.api.runCmd('testmode-off', true);
    });

    // Mobile Tools
    async function runMobileTool(titleKey, apiMethod, ...args) {
        openModal(titleKey);
        try {
            const result = await apiMethod(...args);
            logToConsole(result || "Done.");
        } catch (err) {
            logToConsole(err.toString());
        }
        finishProgress();
    }

    // --- Mobile Section UI Logic (Redesigned) ---

    // Category Segmented Switcher
    const proCatBtns = document.querySelectorAll('.pro-cat-btn');
    const proSubtabGroups = document.querySelectorAll('.pro-subtab-group');

    function switchMobileCategory(catId) {
        proCatBtns.forEach(b => {
            b.classList.toggle('active', b.getAttribute('data-cat') === catId);
        });
        proSubtabGroups.forEach(grp => {
            if (grp.id === `group-${catId}`) {
                grp.style.display = 'flex';
                grp.classList.add('active');
                // If no tab in this group is active, click the first one
                const activeTab = grp.querySelector('.tab-btn.active');
                if (!activeTab) {
                    const firstTab = grp.querySelector('.tab-btn');
                    if (firstTab) firstTab.click();
                }
            } else {
                grp.style.display = 'none';
                grp.classList.remove('active');
            }
        });
    }

    proCatBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const catId = btn.getAttribute('data-cat');
            switchMobileCategory(catId);
        });
    });

    // Tab Switching
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            tabBtns.forEach(b => {
                b.classList.remove('active');
                b.style.background = '';
                b.style.color = '';
            });
            tabContents.forEach(c => {
                if (c) c.style.display = 'none';
            });
            
            btn.classList.add('active');
            btn.style.background = '';
            btn.style.color = '';
            const targetId = btn.getAttribute('data-target');
            const targetEl = document.getElementById(targetId);
            if (targetEl) targetEl.style.display = 'block';

            // Auto-activate matching category pill if tab was clicked programmatically
            const parentGrp = btn.closest('.pro-subtab-group');
            if (parentGrp) {
                const catId = parentGrp.id.replace('group-', '');
                proCatBtns.forEach(b => {
                    b.classList.toggle('active', b.getAttribute('data-cat') === catId);
                });
                proSubtabGroups.forEach(grp => {
                    grp.style.display = (grp === parentGrp) ? 'flex' : 'none';
                });
            }
        });
    });

    // Helper: update checkboxes status
    function updateFlashBtnStatus(listId, btnId) {
        const fwPartitionsList = document.getElementById(listId);
        const btnFlashFwNow = document.getElementById(btnId);
        if (!fwPartitionsList || !btnFlashFwNow) return;
        const checked = fwPartitionsList.querySelectorAll('input[type="checkbox"]:checked');
        btnFlashFwNow.disabled = checked.length === 0;
    }

    function renderPartitions(parsedPartitions, listId, btnId) {
        const fwPartitionsList = document.getElementById(listId);
        fwPartitionsList.innerHTML = '';
        let hasValidPartition = false;
        
        parsedPartitions.forEach((p, idx) => {
            const id = `chk-${listId}-${idx}`;
            const div = document.createElement('div');
            div.style.display = 'flex';
            div.style.alignItems = 'center';
            div.style.gap = '8px';
            div.style.opacity = p.exists ? '1' : '0.5';
            
            const cb = document.createElement('input');
            cb.type = 'checkbox';
            cb.id = id;
            cb.value = idx;
            cb.checked = p.defaultChecked;
            cb.disabled = !p.exists;
            
            if (p.defaultChecked) hasValidPartition = true;
            
            cb.addEventListener('change', () => updateFlashBtnStatus(listId, btnId));
            
            const lbl = document.createElement('label');
            lbl.htmlFor = id;
            lbl.style.cursor = 'pointer';
            lbl.style.fontSize = '12px';
            lbl.style.color = p.exists ? 'var(--text-color)' : 'var(--text-muted)';
            lbl.style.overflow = 'hidden';
            lbl.style.textOverflow = 'ellipsis';
            lbl.style.whiteSpace = 'nowrap';
            lbl.style.flex = '1';
            let metaHtml = '';
            if (p.tarSource) {
                metaHtml += ` <span style="font-size:9.5px; padding:1px 5px; border-radius:3px; background:rgba(59,130,246,0.2); color:#93c5fd; font-weight:700;">${p.tarSource}</span>`;
            }
            if (p.sizeStr) {
                metaHtml += ` <span style="font-size:10px; color:#94a3b8; font-family:monospace;">${p.sizeStr}</span>`;
            }
            lbl.innerHTML = `<strong>${p.partition}</strong> <span style="opacity:0.7">(${p.fileName})</span>${metaHtml}`;
            if (!p.exists) lbl.innerHTML += ' <span style="color:var(--danger-color);">(Missing)</span>';
            
            const btnChange = document.createElement('button');
            btnChange.textContent = "Change File";
            btnChange.style.fontSize = '10px';
            btnChange.style.padding = '2px 6px';
            btnChange.style.marginLeft = 'auto';
            btnChange.style.borderRadius = '4px';
            btnChange.style.border = '1px solid var(--border-color)';
            btnChange.style.background = 'var(--bg-secondary)';
            btnChange.style.color = 'var(--text-color)';
            btnChange.style.cursor = 'pointer';
            
            btnChange.onclick = async () => {
                const newPath = await window.api.browseSingleFile();
                if (newPath) {
                    p.fullPath = newPath;
                    p.fileName = newPath.substring(newPath.lastIndexOf('\\') + 1);
                    p.exists = true;
                    
                    div.style.opacity = '1';
                    cb.disabled = false;
                    cb.checked = true;
                    lbl.style.color = 'var(--text-color)';
                    lbl.innerHTML = `<strong>${p.partition}</strong> <span style="opacity:0.7">(${p.fileName})</span> <span style="color:var(--accent-color);">(Mod)</span>`;
                    updateFlashBtnStatus(listId, btnId);
                }
            };

            div.appendChild(cb);
            div.appendChild(lbl);
            div.appendChild(btnChange);
            fwPartitionsList.appendChild(div);
        });
        
        updateFlashBtnStatus(listId, btnId);
    }

    // --- QUALCOMM SECTION ---
    let applySamsungMtkResult = null;
    let applySamsungQcomResult = null;
    let openTestPointForModel = null;
    let openDirectTestPointImage = null;
    let qcomParsedPartitions = [];
    let qcomSelectedProgrammer = null;
    let qcomSelectedPatch = null;
    let qcomSelectedComPort = null;
    let qcomFwDir = null;

    const btnQcomScanPorts = document.getElementById('btn-qcom-scan-ports');
    const qcomPortSelect = document.getElementById('qcom-port-select');
    
    btnQcomScanPorts.addEventListener('click', async () => {
        btnQcomScanPorts.disabled = true;
        btnQcomScanPorts.textContent = "Scanning...";
        const ports = await window.api.scanComPorts();
        
        qcomPortSelect.innerHTML = '';
        if (ports && ports.length > 0) {
            let bestPort = null;
            ports.forEach(port => {
                const opt = document.createElement('option');
                const portVal = typeof port === 'object' ? port.port : port;
                const portDesc = typeof port === 'object' ? (port.description || '') : '';
                const isEdl = typeof port === 'object' ? (port.isEdl || /9008|QUALCOMM/i.test(portDesc)) : /9008/i.test(port);
                opt.value = portVal;
                opt.textContent = portDesc ? `${portVal} (${portDesc})` : portVal;
                if (isEdl && !bestPort) {
                    opt.selected = true;
                    bestPort = portVal;
                }
                qcomPortSelect.appendChild(opt);
            });
            qcomSelectedComPort = bestPort || (typeof ports[0] === 'object' ? ports[0].port : ports[0]);
        } else {
            const opt = document.createElement('option');
            opt.value = "";
            opt.textContent = "No devices found";
            qcomPortSelect.appendChild(opt);
            qcomSelectedComPort = null;
        }
        btnQcomScanPorts.disabled = false;
        btnQcomScanPorts.textContent = "Scan Ports";
    });

    qcomPortSelect.addEventListener('change', (e) => {
        qcomSelectedComPort = e.target.value;
    });

    document.getElementById('btn-qcom-browse-fw').addEventListener('click', async () => {
        const filePath = await window.api.browseAdvFirmwareFile();
        if (filePath) {
            document.getElementById('qcom-fw-file-path').textContent = filePath;
            document.getElementById('qcom-fw-file-path').title = filePath;
            
            const result = await window.api.parseFirmwareFile(filePath);
            if (result.error) {
                alert("Error reading file: " + result.error);
                return;
            }
            
            if (result.type === 'SAMSUNG_QCOM' || result.type === 'SAMSUNG_MTK') {
                applySamsungQcomResult(result);
                return;
            }

            if (result.type !== 'QCOM' && !filePath.toLowerCase().endsWith('.map')) {
                alert("Please select a valid QCOM XML or .map file.");
                return;
            }
            
            qcomParsedPartitions = result.partitions;
            qcomFwDir = filePath.substring(0, filePath.lastIndexOf('\\'));
            
            if (result.autoPatch) {
                qcomSelectedPatch = result.autoPatch;
                document.getElementById('qcom-patch-file-path').textContent = result.autoPatch;
                document.getElementById('qcom-patch-file-path').title = result.autoPatch;
            }

            btnQcomScanPorts.click();
            document.getElementById('qcom-partitions-container').style.display = 'block';
            renderPartitions(qcomParsedPartitions, 'qcom-partitions-list', 'btn-qcom-flash-now');
        }
    });

    let currentLoadedQcomSamsungTp = null;

    applySamsungQcomResult = (result) => {
        if (!result || !result.partitions) return;
        document.getElementById('qcom-fw-file-path').textContent = result.firmwareDir;
        document.getElementById('qcom-fw-file-path').title = result.firmwareDir;

        qcomParsedPartitions = result.partitions;
        qcomFwDir = result.firmwareDir;

        btnQcomScanPorts.click();
        document.getElementById('qcom-partitions-container').style.display = 'block';
        renderPartitions(qcomParsedPartitions, 'qcom-partitions-list', 'btn-qcom-flash-now');

        const badge = document.getElementById('qcom-selected-prog-badge');
        if (badge && result.model) {
            badge.textContent = `⚡ ${result.model} (${result.chipset || 'Qualcomm'})`;
        }

        currentLoadedQcomSamsungTp = result.testPoint || null;
        const qcomAlertBox = document.getElementById('qcom-tp-alert-box');
        const qcomAlertText = document.getElementById('qcom-tp-alert-text');
        const qcomViewModelTp = document.getElementById('btn-qcom-view-model-tp');

        if (qcomAlertBox) {
            if (result.testPoint) {
                qcomAlertBox.style.display = 'block';
                if (qcomAlertText) {
                    qcomAlertText.innerHTML = `<i class="fas fa-crosshairs" style="color: #fbbf24;"></i> <span>เครื่องดับ/เปิดไม่ติด? จิ้ม TP: <strong>${result.testPoint.testPoint}</strong></span>`;
                }
                if (qcomViewModelTp) {
                    qcomViewModelTp.style.display = result.testPoint.image ? 'inline-flex' : 'none';
                }
            } else {
                qcomAlertBox.style.display = 'none';
            }
        }

        logToConsole(`\n================================================\n`);
        logToConsole(`  [SAMSUNG QUALCOMM ENGINE] โหลดรอมสำเร็จ (EDL 9008 Style)\n`);
        logToConsole(`================================================\n`);
        logToConsole(`> รุ่นที่ตรวจพบ: ${result.model} [${result.modelRaw || ''}]\n`);
        logToConsole(`> ชิปเซ็ต: ${result.chipset} (${result.platform || 'Qualcomm'})\n`);
        logToConsole(`> โฟลเดอร์: ${result.firmwareDir}\n`);
        logToConsole(`> พาร์ติชันที่โหลดได้: ${result.partitions.length} รายการ\n`);
        if (result.testPoint) {
            logToConsole(`> 📌 จุดจิ้ม Test Point (EDL 9008): ${result.testPoint.testPoint}\n`);
            logToConsole(`> 🛠️ วิธีทำ: ถอดแบต -> เอาแหนบแตะจุด TP ลง GND -> เสียบสาย USB -> ปล่อยแหนบเมื่อพบพอร์ต 9008\n`);
        }
        logToConsole(`> เลือกรุ่นหรือ Firehose Loader ให้ตรงชิป และเชื่อมต่อโหมด EDL 9008\n\n`);
    };

    const btnQcomTpGuide = document.getElementById('btn-qcom-tp-guide');
    if (btnQcomTpGuide) {
        btnQcomTpGuide.addEventListener('click', () => {
            const modelVal = document.getElementById('qcom-model-select')?.value || '';
            if (typeof openTestPointForModel === 'function') {
                openTestPointForModel(modelVal || 'samsung', 'samsung');
            } else {
                const btnTpGallery = document.getElementById('btn-open-testpoint-gallery');
                if (btnTpGallery) btnTpGallery.click();
            }
        });
    }

    const btnQcomViewModelTp = document.getElementById('btn-qcom-view-model-tp');
    if (btnQcomViewModelTp) {
        btnQcomViewModelTp.addEventListener('click', () => {
            if (currentLoadedQcomSamsungTp && currentLoadedQcomSamsungTp.image) {
                if (typeof openDirectTestPointImage === 'function') {
                    openDirectTestPointImage(
                        currentLoadedQcomSamsungTp.image,
                        `${currentLoadedQcomSamsungTp.model} — ไดอะแกรม Test Point`,
                        `ชิปเซ็ต: ${currentLoadedQcomSamsungTp.chip} | โหมด: ${currentLoadedQcomSamsungTp.mode}`,
                        currentLoadedQcomSamsungTp.testPoint
                    );
                }
            } else {
                const modelVal = document.getElementById('qcom-model-select')?.value || '';
                if (typeof openTestPointForModel === 'function') {
                    openTestPointForModel(modelVal || 'samsung', 'samsung');
                }
            }
        });
    }

    const btnQcomBrowseSamsung = document.getElementById('btn-qcom-browse-samsung');
    if (btnQcomBrowseSamsung) {
        btnQcomBrowseSamsung.addEventListener('click', async () => {
            const result = await window.api.browseSamsungFirmwareFolder();
            if (!result) return;
            if (result.error) {
                alert("ไม่สามารถโหลดรอม Samsung: " + result.error);
                return;
            }

            if (result.chipsetCode === 'MTK') {
                const goToMtk = confirm(`รอม Samsung นี้ตรวจพบว่าเป็นชิปเซ็ต MediaTek:\nรุ่น: ${result.model}\nชิปเซ็ต: ${result.chipset}\n\nคุณต้องการสลับไปยังแท็บ MediaTek เพื่อแฟลชในโหมด BROM / Scatter หรือไม่?`);
                if (goToMtk) {
                    const mtkTabBtn = document.querySelector('.tab-btn[data-target="tab-mtk"]');
                    if (mtkTabBtn) mtkTabBtn.click();
                    if (applySamsungMtkResult) applySamsungMtkResult(result);
                    return;
                }
            }

            applySamsungQcomResult(result);
        });
    }

    const btnQcomBrowsePatch = document.getElementById('btn-qcom-browse-patch');
    if (btnQcomBrowsePatch) {
        btnQcomBrowsePatch.addEventListener('click', async () => {
            const filePath = await window.api.browseSingleFile();
            if (filePath) {
                qcomSelectedPatch = filePath;
                document.getElementById('qcom-patch-file-path').textContent = filePath.split('\\').pop();
                document.getElementById('qcom-patch-file-path').title = filePath;
            }
        });
    }

    // Qualcomm Firehose loaders and brand/model database initialized via initFlasherSuiteDatabase()

    document.getElementById('btn-qcom-select-all').addEventListener('click', () => {
        const cbs = document.getElementById('qcom-partitions-list').querySelectorAll('input[type="checkbox"]:not(:disabled)');
        cbs.forEach(cb => cb.checked = true);
        updateFlashBtnStatus('qcom-partitions-list', 'btn-qcom-flash-now');
    });

    document.getElementById('btn-qcom-select-none').addEventListener('click', () => {
        const cbs = document.getElementById('qcom-partitions-list').querySelectorAll('input[type="checkbox"]');
        cbs.forEach(cb => cb.checked = false);
        updateFlashBtnStatus('qcom-partitions-list', 'btn-qcom-flash-now');
    });

    document.getElementById('btn-qcom-flash-now').addEventListener('click', async () => {
        const checkedBoxes = document.getElementById('qcom-partitions-list').querySelectorAll('input[type="checkbox"]:checked');
        if (checkedBoxes.length === 0) return;
        
        const selectedParts = [];
        for (const cb of checkedBoxes) {
            selectedParts.push(qcomParsedPartitions[cb.value]);
        }
        
        
        
        
        if (!qcomSelectedComPort) {
            logToConsole(`\n[ERROR] Please select a COM port first.\n`);
            finishProgress();
            return;
        }
        if (!qcomSelectedProgrammer) {
            logToConsole(`\n[ERROR] Please select a Programmer file (.mbn/.elf) for QCOM flashing.\n`);
            finishProgress();
            return;
        }

        logToConsole(`\n> [QCOM EDL] Port: ${qcomSelectedComPort}\n`);
        logToConsole(`> [QCOM EDL] Programmer: ${qcomSelectedProgrammer}\n`);
        logToConsole(`> [QCOM EDL] Selected Partitions: ${selectedParts.length}\n`);
        

        try {
            const res = await window.api.runQcomFlash(qcomSelectedComPort, qcomSelectedProgrammer, qcomSelectedPatch, qcomFwDir, selectedParts);
            logToConsole(`\n[QCOM EDL] Flash Completed!\nOutput:\n${res}\n`);
        } catch (err) {
            logToConsole(`\n[ERROR] QCOM Flashing failed:\n${err.message || err}\n`);
        }
        finishProgress();
    });

    // --- MEDIATEK SECTION ---
    let mtkParsedPartitions = [];
    let mtkSelectedDa = null;
    let mtkMode = 'brom'; // 'brom' or 'preloader'
    let mtkFwDir = null;

    const mtkModeRadios = document.querySelectorAll('input[name="mtk-mode"]');
    mtkModeRadios.forEach(r => {
        r.addEventListener('change', (e) => {
            mtkMode = e.target.value;
            const mtkDaContainer = document.getElementById('mtk-da-container');
            if (mtkDaContainer) {
                mtkDaContainer.style.display = mtkMode === 'preloader' ? 'flex' : 'none';
            }
        });
    });

    let mtkSelectedPreloader = null;
    let mtkSelectedAuth = null;
    
    // Checkbox toggles
    document.getElementById('chk-custom-da').addEventListener('change', (e) => {
        document.getElementById('btn-mtk-browse-da').disabled = !e.target.checked;
        if (!e.target.checked) mtkSelectedDa = null;
    });
    document.getElementById('chk-custom-preloader').addEventListener('change', (e) => {
        document.getElementById('btn-mtk-browse-preloader').disabled = !e.target.checked;
        if (!e.target.checked) mtkSelectedPreloader = null;
    });
    document.getElementById('chk-custom-auth').addEventListener('change', (e) => {
        document.getElementById('btn-mtk-browse-auth').disabled = !e.target.checked;
        if (!e.target.checked) mtkSelectedAuth = null;
    });

    document.getElementById('btn-mtk-browse-da').addEventListener('click', async () => {
        const filePath = await window.api.browseSingleFile();
        if (filePath) {
            mtkSelectedDa = filePath;
            document.getElementById('mtk-da-file-path').textContent = filePath.split('\\').pop();
            document.getElementById('mtk-da-file-path').title = filePath;
        }
    });
    
    document.getElementById('btn-mtk-browse-preloader').addEventListener('click', async () => {
        const filePath = await window.api.browseSingleFile();
        if (filePath) {
            mtkSelectedPreloader = filePath;
            document.getElementById('mtk-preloader-file-path').textContent = filePath.split('\\').pop();
            document.getElementById('mtk-preloader-file-path').title = filePath;
        }
    });
    
    document.getElementById('btn-mtk-browse-auth').addEventListener('click', async () => {
        const filePath = await window.api.browseSingleFile();
        if (filePath) {
            mtkSelectedAuth = filePath;
            document.getElementById('mtk-auth-file-path').textContent = filePath.split('\\').pop();
            document.getElementById('mtk-auth-file-path').title = filePath;
        }
    });

    document.getElementById('btn-mtk-browse-fw').addEventListener('click', async () => {
        const filePath = await window.api.browseAdvFirmwareFile();
        if (filePath) {
            document.getElementById('mtk-fw-file-path').textContent = filePath;
            document.getElementById('mtk-fw-file-path').title = filePath;
            
            const result = await window.api.parseFirmwareFile(filePath);
            if (result.error) {
                alert("Error reading file: " + result.error);
                return;
            }
            
            if (result.type === 'SAMSUNG_MTK' || result.type === 'SAMSUNG_QCOM') {
                applySamsungMtkResult(result);
                return;
            }

            if (result.type !== 'MTK' && result.type !== 'MTK_MAP' && result.type !== 'MTK_ZIP') {
                alert("Please select a valid MTK Scatter, .map, or .zip NV backup file.");
                return;
            }
            
            // Validate model if ZIP has proinfo
            if (result.type === 'MTK_ZIP' && result.hasProinfo) {
                const model = result.proinfoModel || "Unknown";
                const usbText = document.getElementById('console-usb-status') ? document.getElementById('console-usb-status').textContent : '';
                let warning = `ไฟล์ NV Backup นี้มาจากเครื่องรุ่น: ${model}\n\n`;
                if (usbText && usbText !== '- Waiting for devices -') {
                    warning += `เครื่องที่กำลังเชื่อมต่ออยู่: ${usbText}\n\n`;
                    if (model !== "Unknown" && !usbText.toUpperCase().includes(model.toUpperCase())) {
                        warning += `ข้อควรระวัง: เครื่องที่เชื่อมต่ออยู่ดูเหมือนจะไม่ตรงกับรุ่น ${model}!\nการแฟลชข้อมูล NV ผิดรุ่นอาจทำให้เลข IMEI หรือ Baseband สูญหายได้\n\n`;
                    }
                }
                warning += `คุณต้องการดำเนินการต่อและโหลดพาร์ติชันเหล่านี้หรือไม่?`;
                const userConfirmed = await showCustomConfirm(warning);
                if (!userConfirmed) {
                    document.getElementById('mtk-fw-file-path').textContent = 'No file selected';
                    return;
                }
            }
            
            mtkParsedPartitions = result.partitions;
            mtkFwDir = filePath.substring(0, filePath.lastIndexOf('\\'));
            
            document.getElementById('mtk-partitions-container').style.display = 'block';
            renderPartitions(mtkParsedPartitions, 'mtk-partitions-list', 'btn-mtk-flash-now');
        }
    });

    let currentLoadedMtkSamsungTp = null;

    applySamsungMtkResult = (result) => {
        if (!result || !result.partitions) return;
        document.getElementById('mtk-fw-file-path').textContent = result.scatterPath || result.firmwareDir;
        document.getElementById('mtk-fw-file-path').title = result.scatterPath || result.firmwareDir;

        if (result.preloaderPath) {
            mtkSelectedPreloader = result.preloaderPath;
            const chkPre = document.getElementById('chk-custom-preloader');
            if (chkPre) chkPre.checked = true;
            const btnPre = document.getElementById('btn-mtk-browse-preloader');
            if (btnPre) btnPre.disabled = false;
            const preDisp = document.getElementById('mtk-preloader-file-path');
            if (preDisp) {
                preDisp.textContent = result.preloaderPath.split('\\').pop();
                preDisp.title = result.preloaderPath;
            }
        }

        mtkParsedPartitions = result.partitions;
        mtkFwDir = result.firmwareDir;

        // Force BROM mode radio for dead-boot unbrick
        const bromRadio = document.querySelector('input[name="mtk-mode"][value="brom"]');
        if (bromRadio) {
            bromRadio.checked = true;
            bromRadio.dispatchEvent(new Event('change'));
        }

        currentLoadedMtkSamsungTp = result.testPoint || null;
        const mtkAlertBox = document.getElementById('mtk-tp-alert-box');
        const mtkAlertText = document.getElementById('mtk-tp-alert-text');
        const mtkViewModelTp = document.getElementById('btn-mtk-view-model-tp');

        if (mtkAlertBox) {
            if (result.testPoint) {
                mtkAlertBox.style.display = 'block';
                if (mtkAlertText) {
                    mtkAlertText.innerHTML = `<i class="fas fa-crosshairs" style="color: #fbbf24;"></i> <span>เครื่องดับ/เปิดไม่ติด? จิ้ม TP: <strong>${result.testPoint.testPoint}</strong></span>`;
                }
                if (mtkViewModelTp) {
                    mtkViewModelTp.style.display = result.testPoint.image ? 'inline-flex' : 'none';
                }
            } else {
                mtkAlertBox.style.display = 'none';
            }
        }

        document.getElementById('mtk-partitions-container').style.display = 'block';
        renderPartitions(mtkParsedPartitions, 'mtk-partitions-list', 'btn-mtk-flash-now');

        const badge = document.getElementById('mtk-selected-status-badge');
        if (badge && result.model) {
            badge.textContent = `⚡ ${result.model} (${result.chipset || 'MTK'})`;
        }

        logToConsole(`\n================================================\n`);
        logToConsole(`  [SAMSUNG MTK ENGINE] โหลดรอมสำเร็จ (UnlockTool Style)\n`);
        logToConsole(`================================================\n`);
        logToConsole(`> รุ่นที่ตรวจพบ: ${result.model} [${result.modelRaw || ''}]\n`);
        logToConsole(`> ชิปเซ็ต: ${result.chipset} (${result.platform || 'Auto'})\n`);
        logToConsole(`> โฟลเดอร์: ${result.firmwareDir}\n`);
        if (result.scatterPath) logToConsole(`> Scatter File: ${result.scatterPath}\n`);
        if (result.preloaderPath) logToConsole(`> Preloader ที่สกัดได้: ${result.preloaderPath}\n`);
        logToConsole(`> พาร์ติชันที่โหลดได้: ${result.partitions.length} รายการ (BL/AP/CP/CSC)\n`);
        if (result.testPoint) {
            logToConsole(`> 📌 จุดจิ้ม Test Point (TP BROM): ${result.testPoint.testPoint}\n`);
            logToConsole(`> 🛠️ ขั้นตอนแก้เครื่องดับ / เปิดไม่ติด:\n`);
            logToConsole(`   1. ถอดขั้วแบตเตอรี่ออก (หรือเสียบแบตตามรุ่น)\n`);
            logToConsole(`   2. ใช้แหนบแตะจุด Test Point กับ กราวด์ (GND / แผ่นชีลด์) ค้างไว้\n`);
            logToConsole(`   3. เสียบสาย USB เข้าคอมพิวเตอร์\n`);
            logToConsole(`   4. เมื่อโปรแกรมตรวจพบพอร์ต MediaTek USB Port (BROM) ให้ปล่อยแหนบทันที\n`);
            logToConsole(`   5. กดปุ่ม FLASH FIRMWARE เพื่อแฟลชคืนชีพเครื่อง\n\n`);
        } else {
            logToConsole(`> โหมดที่แนะนำ: ปิดเครื่องสนิท กด Vol(+) & Vol(-) หรือ จิ้ม TP เสียบสาย USB (BROM Mode)\n\n`);
        }
    };

    const btnMtkTpGuide = document.getElementById('btn-mtk-tp-guide');
    if (btnMtkTpGuide) {
        btnMtkTpGuide.addEventListener('click', () => {
            const modelVal = document.getElementById('mtk-model-select')?.value || '';
            if (typeof openTestPointForModel === 'function') {
                openTestPointForModel(modelVal || 'samsung', 'samsung');
            } else {
                const btnTpGallery = document.getElementById('btn-open-testpoint-gallery');
                if (btnTpGallery) btnTpGallery.click();
            }
        });
    }

    const btnMtkViewModelTp = document.getElementById('btn-mtk-view-model-tp');
    if (btnMtkViewModelTp) {
        btnMtkViewModelTp.addEventListener('click', () => {
            if (currentLoadedMtkSamsungTp && currentLoadedMtkSamsungTp.image) {
                if (typeof openDirectTestPointImage === 'function') {
                    openDirectTestPointImage(
                        currentLoadedMtkSamsungTp.image,
                        `${currentLoadedMtkSamsungTp.model} — ไดอะแกรม Test Point`,
                        `ชิปเซ็ต: ${currentLoadedMtkSamsungTp.chip} | โหมด: ${currentLoadedMtkSamsungTp.mode}`,
                        currentLoadedMtkSamsungTp.testPoint
                    );
                }
            } else {
                const modelVal = document.getElementById('mtk-model-select')?.value || '';
                if (typeof openTestPointForModel === 'function') {
                    openTestPointForModel(modelVal || 'samsung', 'samsung');
                }
            }
        });
    }

    const btnMtkBrowseSamsung = document.getElementById('btn-mtk-browse-samsung');
    if (btnMtkBrowseSamsung) {
        btnMtkBrowseSamsung.addEventListener('click', async () => {
            const result = await window.api.browseSamsungFirmwareFolder();
            if (!result) return;
            if (result.error) {
                alert("ไม่สามารถโหลดรอม Samsung: " + result.error);
                return;
            }

            if (result.chipsetCode === 'QCOM') {
                const goToQcom = confirm(`รอม Samsung นี้ตรวจพบว่าเป็นชิปเซ็ต Qualcomm:\nรุ่น: ${result.model}\nชิปเซ็ต: ${result.chipset}\n\nคุณต้องการสลับไปยังแท็บ Qualcomm เพื่อแฟลชในโหมด EDL หรือไม่?`);
                if (goToQcom) {
                    const qcomTabBtn = document.querySelector('.tab-btn[data-target="tab-qcom"]');
                    if (qcomTabBtn) qcomTabBtn.click();
                    if (applySamsungQcomResult) applySamsungQcomResult(result);
                    return;
                }
            }

            applySamsungMtkResult(result);
        });
    }

    document.getElementById('btn-mtk-select-all').addEventListener('click', () => {
        const cbs = document.getElementById('mtk-partitions-list').querySelectorAll('input[type="checkbox"]:not(:disabled)');
        cbs.forEach(cb => cb.checked = true);
        updateFlashBtnStatus('mtk-partitions-list', 'btn-mtk-flash-now');
    });

    document.getElementById('btn-mtk-select-none').addEventListener('click', () => {
        const cbs = document.getElementById('mtk-partitions-list').querySelectorAll('input[type="checkbox"]');
        cbs.forEach(cb => cb.checked = false);
        updateFlashBtnStatus('mtk-partitions-list', 'btn-mtk-flash-now');
    });

    document.getElementById('btn-mtk-flash-now').addEventListener('click', async () => {
        const checkedBoxes = document.getElementById('mtk-partitions-list').querySelectorAll('input[type="checkbox"]:checked');
        if (checkedBoxes.length === 0) return;
        
        const selectedParts = [];
        for (const cb of checkedBoxes) {
            selectedParts.push(mtkParsedPartitions[cb.value]);
        }
        
        
        
        
        logToConsole(`\n> [MTK] Preparing to flash ${selectedParts.length} partitions...\n`);
        

        let cmdStr = "";
        for (const p of selectedParts) {
            cmdStr += `w ${p.partition} "${p.fullPath}"; `;
        }
        
        try {
            // Use the new partition extractor/flasher for MTK
            const res = await window.api.flashMtkPartitions(selectedParts, mtkMode, mtkSelectedDa, mtkSelectedPreloader);
            logToConsole(`\n[MTK] Flash Completed!\nOutput:\n${res}\n`);
        } catch (err) {
            logToConsole(`\n[ERROR] MTK Flashing failed:\n${err.message || err}\n`);
        }

        finishProgress();
    });

    // --- ADB & FASTBOOT SECTION ---
    const btnAdbGpt = document.getElementById('btn-adb-gpt');
    if (btnAdbGpt) {
        btnAdbGpt.addEventListener('click', async () => {
        openModal('ADB: Read GPT Table');
        logToModal('> Requesting GPT Table via ADB...\n');
        
        try {
            let rootCheck = '';
            try {
                rootCheck = await window.api.runAdbCommand('shell su -c "id"');
            } catch(e) {
                rootCheck = '';
            }
            if (!rootCheck || (!rootCheck.includes('uid=0') && !rootCheck.includes('root'))) {
                logToModal('[ERROR] Root access denied. Device is not rooted (su not found) or permission was denied.\n', 'error');
                finishModal(false);
                return;
            }
            window.api.send('adb-read-gpt', {});
        } catch(err) {
            logToModal(`[ERROR] ${err.message || err}\n`, 'error');
            finishModal(false);
        }
        });
    }

    document.getElementById('btn-adb-info').addEventListener('click', async () => {
        openModal('ADB: Read Device Info');
        logToModal('> Reading Device Info via ADB...\n');
        
        try {
            const getProp = async (prop) => {
                try {
                    const res = await window.api.runAdbCommand('shell getprop ' + prop);
                    return (res && res.trim() !== '') ? res.trim() : 'Unknown';
                } catch(e) { return 'Unknown'; }
            };
            
            const getKernel = async () => {
                try {
                    const res = await window.api.runAdbCommand('shell uname -a');
                    return (res && res.trim() !== '') ? res.trim() : 'Unknown';
                } catch(e) { return 'Unknown'; }
            };

            const info = {
                'Patch Level': await getProp('ro.build.version.security_patch'),
                'Ver. CodeName': await getProp('ro.build.version.codename'),
                'Ver. Release': await getProp('ro.build.version.release'),
                'Sec. Patch': await getProp('ro.build.version.security_patch'),
                'Product Manfct': await getProp('ro.product.manufacturer'),
                'Build Time': await getProp('ro.build.date'),
                'Product Brand': await getProp('ro.product.brand'),
                'Product Model': await getProp('ro.product.model'),

                'Product Device': await getProp('ro.product.device'),
                'Product Name': await getProp('ro.product.name'),
                'SW OTA Version': await getProp('ro.build.version.incremental'),

                'Kernel Info': await getKernel(),
                'Android Version': await getProp('ro.build.version.release'),
                'Platform/Chipset': await getProp('ro.board.platform'),

                'CPU Arch': await getProp('ro.product.cpu.abi'),
                'Build ID': await getProp('ro.build.display.id'),
                'SIM State': await getProp('gsm.sim.state'),
                'SIM Operator': await getProp('gsm.sim.operator.alpha'),
            };
            
            let csc = await getProp('ro.csc.sales_code');
            if (csc === 'Unknown' || csc === '') csc = await getProp('ril.sales_code');
            info['Sales Code / CSC'] = csc;

            logToModal('--------------------------------\n');
            for (const [key, value] of Object.entries(info)) {
                logToModal(`${key.padEnd(16, ' ')}: ${value}\n`);
            }
            logToModal('--------------------------------\n');
            
            const simState = info['SIM State'];
            const operator = info['SIM Operator'];
            if (simState.includes('NETWORK_LOCKED') || simState.includes('PIN_REQUIRED') || simState.includes('PUK_REQUIRED')) {
                let lockSource = operator !== 'Unknown' ? operator : (csc !== 'Unknown' ? csc : 'Unknown Carrier');
                logToModal(`📌 ข้อสรุป: 🔒 เครื่องนี้ติดล็อกซิม (Locked to: ${lockSource})\n`, 'warning');
            } else if (simState.includes('LOADED') || simState.includes('READY')) {
                logToModal(`📌 ข้อสรุป: ✅ เครื่องเปล่า ไม่ล็อกซิม (Unlocked)\n`, 'success');
            } else if (simState.includes('ABSENT')) {
                logToModal(`📌 ข้อสรุป: ⚠️ ไม่ได้ใส่ซิมการ์ด (Please insert SIM to check lock status)\n`, 'warning');
            } else {
                logToModal(`📌 ข้อสรุป: ⚠️ ไม่สามารถระบุสถานะล็อกซิมได้จาก ADB (Unknown)\n`, 'warning');
            }
            logToModal('--------------------------------\n');
            finishModal(true);
        } catch (err) {
            logToModal(`\n[ERROR] ${err.message || err}\n`, 'error');
            finishModal(false);
        }
    });

    document.getElementById('btn-adb-reboot-rec').addEventListener('click', () => runAdbSimple('reboot recovery'));
    document.getElementById('btn-adb-reboot-bl').addEventListener('click', () => runAdbSimple('reboot bootloader'));
    document.getElementById('btn-adb-reboot-edl').addEventListener('click', () => runAdbSimple('reboot edl'));
    
    // Fastboot Buttons
    document.getElementById('btn-fb-scan')?.addEventListener('click', () => runFbSimple('devices'));
    document.getElementById('btn-fb-info')?.addEventListener('click', () => runFbSimple('getvar all'));
    document.getElementById('btn-fb-erasefrp')?.addEventListener('click', () => runFbSimple('erase frp'));
    document.getElementById('btn-fb-unlock')?.addEventListener('click', async () => {
        const confirmUnlock = confirm('⚠️ คำเตือน: การปลดล็อค Bootloader จะล้างข้อมูลในเครื่องทั้งหมด (Factory Reset)\n\nคุณต้องการส่งคำสั่งปลดล็อคใช่หรือไม่?');
        if (!confirmUnlock) return;
        openModal('Fastboot: UNLOCK BOOTLOADER');
        logToModal('> กำลังส่งคำสั่งปลดล็อค Bootloader...\n');
        try {
            logToModal('> fastboot flashing unlock...\n');
            const res1 = await window.api.runFastbootCommand('flashing unlock');
            logToModal(`\n${res1}\n`, 'info');
        } catch(e1) {
            logToModal(`> flashing unlock ไม่สำเร็จ (${e1.message || e1}), กำลังลอง fastboot oem unlock...\n`);
            try {
                const res2 = await window.api.runFastbootCommand('oem unlock');
                logToModal(`\n${res2}\n`, 'info');
            } catch(e2) {
                logToModal(`\n[ERROR] ${e2.message || e2}\n`, 'error');
            }
        }
        logToModal('\n💡 หากบนหน้าจอมือถือมีข้อความขึ้นเตือน ให้กดปุ่ม Vol Up บนเครื่องเพื่อยืนยันการปลดล็อค\n', 'warning');
        finishModal(true);
    });
    document.getElementById('btn-fb-reboot')?.addEventListener('click', () => runFbSimple('reboot'));
    document.getElementById('btn-fb-reboot-rec')?.addEventListener('click', () => runFbSimple('reboot recovery'));
    document.getElementById('btn-fb-reboot-bl')?.addEventListener('click', () => runFbSimple('reboot bootloader'));
    document.getElementById('btn-fb-reboot-edl')?.addEventListener('click', async () => {
        openModal('Fastboot: REBOOT EDL (9008)');
        logToModal('> กำลังส่งคำสั่งรีบูตเข้าโหมด EDL 9008...\n');
        try {
            logToModal('> fastboot oem edl...\n');
            const res = await window.api.runFastbootCommand('oem edl');
            logToModal(`\n${res}\n`, 'success');
            finishModal(true);
        } catch(e) {
            logToModal(`> oem edl ไม่สำเร็จ, กำลังลอง fastboot reboot-edl...\n`);
            try {
                const res2 = await window.api.runFastbootCommand('reboot-edl');
                logToModal(`\n${res2}\n`, 'success');
                finishModal(true);
            } catch(e2) {
                logToModal(`\n[ERROR] ${e2.message || e2}\n`, 'error');
                finishModal(false);
            }
        }
    });

    async function runAdbSimple(cmd) {
        openModal(`ADB: ${cmd.toUpperCase()}`);
        logToModal(`> adb ${cmd}...\n`);
        try {
            const res = await window.api.runAdbCommand(cmd);
            logToModal(`\n${res}\n`, 'success');
            finishModal(true);
        } catch (err) {
            logToModal(`\n[ERROR] ${err.message || err}\n`, 'error');
            finishModal(false);
        }
    }

    async function runFbSimple(cmd) {
        openModal(`Fastboot: ${cmd.toUpperCase()}`);
        logToModal(`> fastboot ${cmd}...\n`);
        try {
            const res = await window.api.runFastbootCommand(cmd);
            logToModal(`\n${res}\n`, 'success');
            finishModal(true);
        } catch (err) {
            logToModal(`\n[ERROR] ${err.message || err}\n`, 'error');
            finishModal(false);
        }
    }

    // ADB App Remover Logic
    let installedApps = [];
    
    // ADB Dump Logic (Legacy / Root)
    let adbDiscoveredPartitions = [];
    const btnAdbScanParts = document.getElementById('btn-adb-scan-parts');
    if (btnAdbScanParts) {
        btnAdbScanParts.addEventListener('click', async () => {
            const listDiv = document.getElementById('adb-partitions-list');
            listDiv.innerHTML = `<div style="grid-column: 1 / -1; text-align: center; color: var(--text-muted); padding: 10px;">${currentLang === 'th' ? 'กำลังค้นหาพาร์ติชั่น (ต้อง Root)...' : 'Scanning partitions (requires Root)...'}</div>`;
            document.getElementById('adb-dump-partitions-container').style.display = 'block';
            adbDiscoveredPartitions = [];
            
            try {
                // Check Root
                let rootCheck = '';
                try {
                    rootCheck = await window.api.runAdbCommand('shell su -c "id"');
                } catch(e) {
                    rootCheck = '';
                }
                if (!rootCheck || (!rootCheck.includes('uid=0') && !rootCheck.includes('root'))) {
                    const text = currentLang === 'th' ? 'การเข้าถึง Root ไม่สำเร็จ (เครื่องยังไม่ได้รูท หรือ su: not found)' : 'Root access denied. Device must be rooted and grant su permissions to ADB.';
                    listDiv.innerHTML = `<div style="grid-column: 1 / -1; text-align: center; color: var(--danger-color); padding: 10px;">${text}</div>`;
                    return;
                }

                // Get partition list
                const lsOutput = await window.api.runAdbCommand('shell su -c "ls -la /dev/block/by-name/"');
                
                if (!lsOutput || lsOutput.includes('No such file or directory')) {
                    const text = currentLang === 'th' ? 'ไม่พบ /dev/block/by-name/ โครงสร้างพาร์ติชั่นของรุ่นนี้อาจจะแตกต่างออกไป' : 'Could not find /dev/block/by-name/. Device might have a different partition layout.';
                    listDiv.innerHTML = `<div style="grid-column: 1 / -1; text-align: center; color: var(--danger-color); padding: 10px;">${text}</div>`;
                    return;
                }

                const lines = lsOutput.split('\n');
                for (const line of lines) {
                    // Parse symlinks: lrwxrwxrwx ... boot -> /dev/block/mmcblk0p24
                    const match = line.match(/([^\s]+)\s*->\s*(.+)$/);
                    if (match) {
                        const name = match[1].trim();
                        const path = match[2].trim();
                        // exclude '.' and '..'
                        if (name !== '.' && name !== '..') {
                            adbDiscoveredPartitions.push({ name, path });
                        }
                    }
                }
                
                if (adbDiscoveredPartitions.length === 0) {
                    const text = currentLang === 'th' ? 'ไม่พบพาร์ติชั่นในไดเรกทอรี by-name' : 'No partitions found in by-name directory.';
                    listDiv.innerHTML = `<div style="grid-column: 1 / -1; text-align: center; color: var(--warning-color); padding: 10px;">${text}</div>`;
                    return;
                }

                // Render
                listDiv.innerHTML = '';
                adbDiscoveredPartitions.forEach((p, i) => {
                    const id = 'chk-adb-part-' + i;
                    listDiv.innerHTML += `
                        <label style="display: flex; align-items: center; gap: 8px; font-size: 13px; color: var(--text-light); cursor: pointer;">
                            <input type="checkbox" id="${id}" data-name="${p.name}" data-path="${p.path}" class="adb-part-chk"> 
                            ${p.name}
                        </label>
                    `;
                });
                
            } catch (err) {
                let errMsg = err.message || err;
                if (errMsg.includes('su: inaccessible or not found') || errMsg.includes('not found')) {
                    const text = currentLang === 'th' ? 'ข้อผิดพลาด: เครื่องยังไม่ได้ Root หรือไม่มีคำสั่ง su (su: inaccessible or not found)' : 'Error: Device is not Rooted or su binary is missing.';
                    listDiv.innerHTML = `<div style="grid-column: 1 / -1; text-align: center; color: var(--danger-color); padding: 10px;">${text}</div>`;
                } else {
                    listDiv.innerHTML = `<div style="grid-column: 1 / -1; text-align: center; color: var(--danger-color); padding: 10px;">Error: ${errMsg}</div>`;
                }
            }
        });

        document.getElementById('btn-adb-sel-all')?.addEventListener('click', () => {
            document.querySelectorAll('.adb-part-chk').forEach(c => c.checked = true);
        });
        document.getElementById('btn-adb-sel-none')?.addEventListener('click', () => {
            document.querySelectorAll('.adb-part-chk').forEach(c => c.checked = false);
        });

        document.getElementById('btn-adb-dump-now')?.addEventListener('click', async () => {
            const selected = [];
            document.querySelectorAll('.adb-part-chk:checked').forEach(c => {
                selected.push({ name: c.getAttribute('data-name'), path: c.getAttribute('data-path') });
            });
            
            if (selected.length === 0) {
                alert('Please select at least one partition to dump.');
                return;
            }
            
            const generateScatter = document.getElementById('chk-adb-scatter')?.checked;
            
            const saveDir = await window.api.showOpenDialog({ properties: ['openDirectory'], title: 'Select folder to save dump' });
            if (!saveDir) return;
            
            clearConsole();
            setConsoleStatus('Dumping Firmware via ADB...');
            window.api.send('adb-dump-partitions', { partitions: selected, saveDir, generateScatter });
        });
    }

    document.getElementById('btn-adb-list-apps').addEventListener('click', async () => {
        const tbody = document.getElementById('adb-apps-table-body');
        tbody.innerHTML = '<tr><td colspan="2" style="padding: 20px; text-align: center;">Scanning devices...</td></tr>';
        
        try {
            // Check if device is connected first
            const devices = await window.api.runAdbCommand("devices");
            if (!devices.includes("\tdevice")) {
                tbody.innerHTML = '<tr><td colspan="2" style="padding: 20px; text-align: center; color: var(--danger-color);">No ADB device connected. Make sure USB Debugging is ON.</td></tr>';
                return;
            }
            
            // Get third party apps or all apps
            const appsStr = await window.api.runAdbCommand("shell pm list packages -3"); // -3 for 3rd party
            if (appsStr) {
                installedApps = appsStr.split('\n').filter(line => line.includes('package:')).map(line => line.replace('package:', '').trim());
                installedApps.sort();
                renderAppsTable(installedApps);
            }
        } catch(err) {
            tbody.innerHTML = `<tr><td colspan="2" style="padding: 20px; text-align: center; color: var(--danger-color);">Error: ${err.message}</td></tr>`;
        }
    });

    function getFriendlyAppInfo(pkg) {
        const known = {
            'com.facebook.katana': { name: 'Facebook', icon: 'fab fa-facebook' },
            'com.facebook.orca': { name: 'Messenger', icon: 'fab fa-facebook-messenger' },
            'com.zhiliaoapp.musically': { name: 'TikTok', icon: 'fab fa-tiktok' },
            'com.google.android.youtube': { name: 'YouTube', icon: 'fab fa-youtube' },
            'com.android.vending': { name: 'Google Play Store', icon: 'fab fa-google-play' },
            'com.whatsapp': { name: 'WhatsApp', icon: 'fab fa-whatsapp' },
            'com.instagram.android': { name: 'Instagram', icon: 'fab fa-instagram' },
            'org.telegram.messenger': { name: 'Telegram', icon: 'fab fa-telegram' },
            'com.twitter.android': { name: 'Twitter / X', icon: 'fab fa-twitter' },
            'com.netflix.mediaclient': { name: 'Netflix', icon: 'fas fa-film' },
            'com.spotify.music': { name: 'Spotify', icon: 'fab fa-spotify' },
            'com.shopee.th': { name: 'Shopee', icon: 'fas fa-shopping-bag' },
            'com.lazada.android': { name: 'Lazada', icon: 'fas fa-shopping-cart' },
            'com.google.android.gm': { name: 'Gmail', icon: 'fas fa-envelope' },
            'com.google.android.apps.maps': { name: 'Google Maps', icon: 'fas fa-map-marker-alt' },
            'com.google.android.chrome': { name: 'Chrome Browser', icon: 'fab fa-chrome' }
        };
        
        if (known[pkg]) return known[pkg];
        
        let icon = 'fas fa-box';
        let name = pkg;
        
        if (pkg.includes('google')) icon = 'fab fa-google';
        else if (pkg.includes('samsung') || pkg.includes('sec')) icon = 'fas fa-mobile-alt';
        else if (pkg.includes('game')) icon = 'fas fa-gamepad';
        else if (pkg.includes('video') || pkg.includes('player') || pkg.includes('camera')) icon = 'fas fa-play-circle';
        
        const parts = pkg.split('.');
        if (parts.length >= 2) {
            let n = parts[parts.length - 1];
            if (n.length < 3 && parts.length > 2) n = parts[parts.length - 2] + ' ' + n;
            name = n.charAt(0).toUpperCase() + n.slice(1);
        }
        
        return { name, icon };
    }

    function renderAppsTable(apps) {
        const tbody = document.getElementById('adb-apps-table-body');
        tbody.innerHTML = '';
        if (apps.length === 0) {
            tbody.innerHTML = '<tr><td colspan="2" style="padding: 20px; text-align: center;">No third-party apps found.</td></tr>';
            return;
        }

        apps.forEach(pkg => {
            const tr = document.createElement('tr');
            tr.style.borderBottom = '1px solid rgba(255,255,255,0.1)';
            
            const tdName = document.createElement('td');
            tdName.style.padding = '10px';
            const info = getFriendlyAppInfo(pkg);
            tdName.innerHTML = `<i class="${info.icon}" style="margin-right:8px; color:var(--primary-color);"></i> <b>${info.name}</b> <br><small style="color:gray; font-size:10px;">${pkg}</small>`;
            
            const tdAction = document.createElement('td');
            tdAction.style.padding = '10px';
            tdAction.style.textAlign = 'center';
            
            const btnDel = document.createElement('button');
            btnDel.textContent = 'Delete';
            btnDel.className = 'action-btn warning-btn';
            btnDel.style.padding = '4px 8px';
            btnDel.style.fontSize = '11px';
            btnDel.onclick = async () => {
                const confirmed = await showCustomConfirm(`คุณต้องการบังคับลบแอปพลิเคชัน ${pkg} ใช่หรือไม่?\n\nการลบแอประบบอาจทำให้เครื่องทำงานผิดปกติได้`);
                if (confirmed) {
                    btnDel.disabled = true;
                    btnDel.textContent = '...';
                    try {
                        const res = await window.api.runAdbCommand(`shell pm uninstall -k --user 0 ${pkg}`);
                        if (res.includes('Success')) {
                            tr.style.opacity = '0.3';
                            btnDel.textContent = 'Done';
                        } else {
                            alert("Failed: " + res);
                            btnDel.disabled = false;
                            btnDel.textContent = 'Delete';
                        }
                    } catch(e) {
                        alert("Error: " + e.message);
                        btnDel.disabled = false;
                        btnDel.textContent = 'Delete';
                    }
                }
            };
            
            tdAction.appendChild(btnDel);
            tr.appendChild(tdName);
            tr.appendChild(tdAction);
            tbody.appendChild(tr);
        });
    }

    document.getElementById('adb-search-app').addEventListener('input', (e) => {
        const q = e.target.value.toLowerCase();
        if (!installedApps || installedApps.length === 0) return;
        const filtered = installedApps.filter(pkg => pkg.toLowerCase().includes(q));
        renderAppsTable(filtered);
    });

    // ========================================================
    // 📱 Enhanced Mobile Workstation Controllers
    // ========================================================
    function initEnhancedMobileTools() {
        // 1. Battery & Hardware Diagnostics
        const btnBatteryInfo = document.getElementById('btn-adb-battery-info');
        if (btnBatteryInfo) {
            btnBatteryInfo.addEventListener('click', async () => {
                btnBatteryInfo.disabled = true;
                btnBatteryInfo.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังตรวจสภาพแบตเตอรี่...';
                try {
                    const res = await window.api.getAndroidBatteryInfo();
                    const d = (res && res.data) ? res.data : (res && res.battery ? { ...res.battery, ...(res.device || {}) } : null);
                    
                    if (res && res.success && d) {
                        const levelEl = document.getElementById('adb-battery-level-val');
                        const barEl = document.getElementById('adb-battery-bar');
                        const healthEl = document.getElementById('adb-battery-health-val');
                        const tempEl = document.getElementById('adb-battery-temp-val');
                        const voltEl = document.getElementById('adb-battery-volt-val');
                        const sourceEl = document.getElementById('adb-battery-source-val');
                        const devEl = document.getElementById('adb-battery-dev-val');

                        if (levelEl) levelEl.textContent = `${d.level}%`;
                        if (barEl) barEl.style.width = `${Math.min(100, Math.max(0, d.level))}%`;
                        
                        if (healthEl) {
                            healthEl.textContent = d.health;
                            if (d.health && d.health.toLowerCase().includes('good')) {
                                healthEl.style.background = 'rgba(34, 197, 94, 0.2)';
                                healthEl.style.color = '#4ade80';
                            } else {
                                healthEl.style.background = 'rgba(239, 68, 68, 0.2)';
                                healthEl.style.color = '#f87171';
                            }
                        }
                        if (tempEl) tempEl.textContent = `${d.temperature} °C`;
                        if (voltEl) voltEl.textContent = `${d.voltage} V`;
                        if (sourceEl) sourceEl.textContent = d.source;
                        if (devEl) devEl.textContent = `${d.brand} ${d.model}`;

                        openModal('รายงานผลการตรวจแบตเตอรี่ & ฮาร์ดแวร์');
                        logToModal(`📱 อุปกรณ์: ${d.brand} ${d.model} (Android ${d.version})\n`);
                        logToModal(`🔋 ระดับแบตเตอรี่: ${d.level}%\n`);
                        logToModal(`🩺 สถานะความสมบูรณ์ (Health): ${d.health}\n`);
                        logToModal(`⚡ สถานะการทำงาน (Status): ${d.status}\n`);
                        logToModal(`🌡️ อุณหภูมิ: ${d.temperature} °C\n`);
                        logToModal(`⚡ แรงดันไฟ: ${d.voltage} V\n`);
                        logToModal(`🔌 แหล่งจ่ายไฟ: ${d.source}\n`);
                        logToModal(`🧪 เทคโนโลยีเซลล์: ${d.technology}\n`);
                        finishModal(true);
                    } else {
                        const errMsg = (res && res.error) ? res.error : 'ไม่พบอุปกรณ์ ADB หรืออุปกรณ์ยังไม่ได้เปิดโหมด USB Debugging';
                        openModal('รายงานผลการตรวจแบตเตอรี่ & ฮาร์ดแวร์');
                        logToModal(`[ERROR] ไม่สามารถตรวจค่าแบตเตอรี่ได้\n\n`, 'error');
                        logToModal(`รายละเอียดข้อผิดพลาด: ${errMsg}\n\n`);
                        logToModal(`💡 ขั้นตอนตรวจสอบ:\n`);
                        logToModal(`1. ตรวจสอบว่าเปิดโหมด "แก้จุดบกพร่อง USB" (USB Debugging) บนโทรศัพท์แล้วหรือยัง\n`);
                        logToModal(`2. ปลดล็อกหน้าจอโทรศัพท์ และกดยอมรับ "อนุญาตการดีบัก USB จากคอมพิวเตอร์เครื่องนี้เสมอ"\n`);
                        logToModal(`3. ลองถอดสาย USB แล้วเสียบใหม่ หรือเปลี่ยนพอร์ต USB\n`);
                        finishModal(false);
                    }
                } catch (e) {
                    openModal('รายงานผลการตรวจแบตเตอรี่ & ฮาร์ดแวร์');
                    logToModal(`[EXCEPTION] ${e.message}\n`, 'error');
                    finishModal(false);
                } finally {
                    btnBatteryInfo.disabled = false;
                    btnBatteryInfo.innerHTML = '<i class="fas fa-stethoscope"></i> ตรวจสุขภาพแบตเตอรี่ & ฮาร์ดแวร์';
                }
            });
        }

        // 2. 1-Click Screen Capture to PC
        const btnScreenshot = document.getElementById('btn-adb-screenshot');
        const resScreenshot = document.getElementById('adb-screenshot-result');
        if (btnScreenshot) {
            btnScreenshot.addEventListener('click', async () => {
                btnScreenshot.disabled = true;
                btnScreenshot.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังจับภาพหน้าจอ...';
                if (resScreenshot) resScreenshot.style.display = 'none';
                try {
                    const res = await window.api.captureAndroidScreenshot();
                    if (res && res.success) {
                        if (resScreenshot) {
                            resScreenshot.style.display = 'block';
                            resScreenshot.innerHTML = `
                                <span>📸 บันทึกภาพแล้ว: <b>${res.fileName}</b> (${(res.fileSize / 1024).toFixed(1)} KB)</span>
                                <button id="btn-open-sc-dir" style="margin-left: 8px; padding: 2px 8px; font-size: 11px; background: rgba(56, 189, 248, 0.2); border: 1px solid #38bdf8; color: #38bdf8; border-radius: 4px; cursor: pointer;">เปิดโฟลเดอร์รูป</button>
                            `;
                            const btnOpenDir = document.getElementById('btn-open-sc-dir');
                            if (btnOpenDir) {
                                btnOpenDir.addEventListener('click', () => {
                                    window.api.openFileLocation(res.filePath);
                                });
                            }
                        }
                    } else {
                        alert(`ไม่สามารถถ่ายภาพหน้าจอได้: ${res ? res.error : 'ADB Connection Error'}`);
                    }
                } catch (e) {
                    alert(`เกิดข้อผิดพลาด: ${e.message}`);
                } finally {
                    btnScreenshot.disabled = false;
                    btnScreenshot.innerHTML = '<i class="fas fa-camera"></i> ถ่ายภาพหน้าจอบันทึกลง PC';
                }
            });
        }

        // 3. Wireless ADB & TCP/IP
        const btnWireless = document.getElementById('btn-adb-wireless');
        const inputWirelessIp = document.getElementById('adb-wireless-ip');
        const statusWireless = document.getElementById('adb-wireless-status');
        if (btnWireless) {
            btnWireless.addEventListener('click', async () => {
                btnWireless.disabled = true;
                btnWireless.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังเปิดโหมดไร้สาย...';
                if (statusWireless) statusWireless.style.display = 'none';
                try {
                    const customIp = inputWirelessIp ? inputWirelessIp.value.trim() : null;
                    const res = await window.api.enableWirelessAdb(customIp || null);
                    if (statusWireless) {
                        statusWireless.style.display = 'block';
                        if (res && res.success) {
                            statusWireless.style.background = 'rgba(34, 197, 94, 0.15)';
                            statusWireless.style.color = '#4ade80';
                            statusWireless.innerHTML = `<i class="fas fa-check-circle"></i> ${res.message} (IP: ${res.deviceIp}:5555)`;
                        } else {
                            statusWireless.style.background = 'rgba(239, 68, 68, 0.15)';
                            statusWireless.style.color = '#f87171';
                            statusWireless.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${res ? (res.error || res.message) : 'เกิดข้อผิดพลาด'}`;
                        }
                    }
                } catch (e) {
                    if (statusWireless) {
                        statusWireless.style.display = 'block';
                        statusWireless.style.background = 'rgba(239, 68, 68, 0.15)';
                        statusWireless.style.color = '#f87171';
                        statusWireless.innerHTML = `<i class="fas fa-exclamation-circle"></i> Error: ${e.message}`;
                    }
                } finally {
                    btnWireless.disabled = false;
                    btnWireless.innerHTML = '<i class="fas fa-network-wired"></i> เปิดโหมดไร้สาย & เชื่อมต่อ IP';
                }
            });
        }

        // 4. Reboot Modes (Samsung Download, Sideload, Normal)
        const btnRebootSam = document.getElementById('btn-adb-reboot-sam');
        if (btnRebootSam) {
            btnRebootSam.addEventListener('click', async () => {
                openModal('ADB: Reboot Samsung Odin Mode');
                logToModal('> กำลังส่งคำสั่งรีบูตเข้า Samsung Download / Odin Mode...\n');
                try {
                    const res = await window.api.rebootAndroidMode('download');
                    if (res && res.success) {
                        logToModal(`\n[SUCCESS] ${res.output || 'รีบูตเข้า Samsung Odin Mode สำเร็จ'}\n`, 'success');
                        finishModal(true);
                    } else {
                        logToModal(`\n[ERROR] ${res ? (res.error || res.output) : 'ล้มเหลว'}\n`, 'error');
                        finishModal(false);
                    }
                } catch (e) {
                    logToModal(`\n[ERROR] ${e.message}\n`, 'error');
                    finishModal(false);
                }
            });
        }

        const btnRebootSideload = document.getElementById('btn-adb-reboot-sideload');
        if (btnRebootSideload) {
            btnRebootSideload.addEventListener('click', async () => {
                openModal('ADB: Reboot Sideload Mode');
                logToModal('> กำลังส่งคำสั่งรีบูตเข้า Recovery Sideload Mode...\n');
                try {
                    const res = await window.api.rebootAndroidMode('sideload');
                    if (res && res.success) {
                        logToModal(`\n[SUCCESS] ${res.output || 'รีบูตเข้า Sideload สำเร็จ'}\n`, 'success');
                        finishModal(true);
                    } else {
                        logToModal(`\n[ERROR] ${res ? (res.error || res.output) : 'ล้มเหลว'}\n`, 'error');
                        finishModal(false);
                    }
                } catch (e) {
                    logToModal(`\n[ERROR] ${e.message}\n`, 'error');
                    finishModal(false);
                }
            });
        }

        const btnRebootNormal = document.getElementById('btn-adb-reboot-normal');
        if (btnRebootNormal) {
            btnRebootNormal.addEventListener('click', async () => {
                openModal('ADB: Reboot Normal System');
                logToModal('> กำลังส่งคำสั่งรีบูตเข้าระบบปกติ (System)...\n');
                try {
                    const res = await window.api.rebootAndroidMode('normal');
                    if (res && res.success) {
                        logToModal(`\n[SUCCESS] ${res.output || 'รีบูตระบบสำเร็จ'}\n`, 'success');
                        finishModal(true);
                    } else {
                        logToModal(`\n[ERROR] ${res ? (res.error || res.output) : 'ล้มเหลว'}\n`, 'error');
                        finishModal(false);
                    }
                } catch (e) {
                    logToModal(`\n[ERROR] ${e.message}\n`, 'error');
                    finishModal(false);
                }
            });
        }

        // 5. Proxy Manager
        const btnSetProxy = document.getElementById('btn-adb-set-proxy');
        const btnClearProxy = document.getElementById('btn-adb-clear-proxy');
        const inputProxyHost = document.getElementById('adb-proxy-host');
        const inputProxyPort = document.getElementById('adb-proxy-port');
        const statusProxy = document.getElementById('adb-proxy-status');

        if (btnSetProxy) {
            btnSetProxy.addEventListener('click', async () => {
                const host = inputProxyHost ? inputProxyHost.value.trim() : '';
                const port = inputProxyPort ? inputProxyPort.value.trim() : '8080';
                if (!host) {
                    alert('กรุณากรอก Proxy Host หรือ IP');
                    return;
                }
                btnSetProxy.disabled = true;
                try {
                    const res = await window.api.setAndroidProxy(host, port);
                    if (statusProxy) {
                        statusProxy.style.display = 'block';
                        if (res && res.success) {
                            statusProxy.style.background = 'rgba(34, 197, 94, 0.15)';
                            statusProxy.style.color = '#4ade80';
                            statusProxy.innerHTML = `<i class="fas fa-check-circle"></i> ตั้ง Proxy สำเร็จ: ${host}:${port}`;
                        } else {
                            statusProxy.style.background = 'rgba(239, 68, 68, 0.15)';
                            statusProxy.style.color = '#f87171';
                            statusProxy.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${res ? res.error : 'ล้มเหลว'}`;
                        }
                    }
                } catch (e) {
                    alert(`Error: ${e.message}`);
                } finally {
                    btnSetProxy.disabled = false;
                }
            });
        }

        if (btnClearProxy) {
            btnClearProxy.addEventListener('click', async () => {
                btnClearProxy.disabled = true;
                try {
                    const res = await window.api.clearAndroidProxy();
                    if (statusProxy) {
                        statusProxy.style.display = 'block';
                        if (res && res.success) {
                            if (inputProxyHost) inputProxyHost.value = '';
                            if (inputProxyPort) inputProxyPort.value = '';
                            statusProxy.style.background = 'rgba(56, 189, 248, 0.15)';
                            statusProxy.style.color = '#38bdf8';
                            statusProxy.innerHTML = `<i class="fas fa-info-circle"></i> ล้างค่า Proxy เรียบร้อย (Direct Connection)`;
                        } else {
                            statusProxy.style.background = 'rgba(239, 68, 68, 0.15)';
                            statusProxy.style.color = '#f87171';
                            statusProxy.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${res ? res.error : 'ล้มเหลว'}`;
                        }
                    }
                } catch (e) {
                    alert(`Error: ${e.message}`);
                } finally {
                    btnClearProxy.disabled = false;
                }
            });
        }

        // 6. Quick ADB Terminal & Preset Chips
        const inputQuickCmd = document.getElementById('adb-quick-cmd');
        const btnRunQuick = document.getElementById('btn-adb-run-quick');
        const outQuick = document.getElementById('adb-quick-output');
        const presetChips = document.querySelectorAll('.adb-preset-chip');

        presetChips.forEach(chip => {
            chip.addEventListener('click', () => {
                const cmd = chip.getAttribute('data-cmd');
                if (inputQuickCmd) {
                    inputQuickCmd.value = cmd;
                    if (btnRunQuick) btnRunQuick.click();
                }
            });
        });

        if (btnRunQuick) {
            btnRunQuick.addEventListener('click', async () => {
                const rawCmd = inputQuickCmd ? inputQuickCmd.value.trim() : '';
                if (!rawCmd) {
                    alert('กรุณาพิมพ์คำสั่ง ADB');
                    return;
                }
                btnRunQuick.disabled = true;
                if (outQuick) {
                    outQuick.style.display = 'block';
                    outQuick.textContent = `> adb ${rawCmd}\n[Running...]`;
                }
                try {
                    const cleanCmd = rawCmd.startsWith('adb ') ? rawCmd.slice(4).trim() : rawCmd;
                    const res = await window.api.runAdbCommand(cleanCmd);
                    if (outQuick) {
                        outQuick.textContent = `> adb ${cleanCmd}\n\n${res || '(No output returned)'}`;
                    }
                } catch (e) {
                    if (outQuick) {
                        outQuick.textContent = `> adb ${rawCmd}\n\n[ERROR] ${e.message || e}`;
                    }
                } finally {
                    btnRunQuick.disabled = false;
                }
            });
        }

        // 7. Zadig & Platform Tools Launchers
        const btnZadig = document.getElementById('btn-open-zadig');
        if (btnZadig) {
            btnZadig.addEventListener('click', () => {
                window.api.openZadig();
            });
        }

        const btnPtCmd = document.getElementById('btn-open-pt-cmd');
        if (btnPtCmd) {
            btnPtCmd.addEventListener('click', async () => {
                try {
                    await window.api.openPlatformToolsCmd();
                } catch(e) {
                    alert(`ไม่สามารถเปิด CMD ได้: ${e.message}`);
                }
            });
        }
    }

    initEnhancedMobileTools();

    // Helper functions for Service and Security buttons
    window.spdSelectedComPort = window.spdSelectedComPort || null;
    window.spdSelectedPacPath = window.spdSelectedPacPath || null;
    if (window.api && window.api.onSpdOutput && !window._spdOutputSetup) {
        window._spdOutputSetup = true;
        window.api.onSpdOutput((text) => {
            if (window._currentSpdHandler) {
                window._currentSpdHandler(text);
            }
        });
    }

    function bindQcomAction(id, cmdName) {
        const btn = document.getElementById(id);
        if (!btn) return;
        btn.addEventListener('click', async () => {
            openModal(`Qualcomm (EDL): ${cmdName.toUpperCase()}`);
            logToModal(`> Running QCOM EDL: ${cmdName}...\n`);
            if (qcomSelectedComPort) {
                logToModal(`> Selected Port: ${qcomSelectedComPort}\n`);
            } else {
                logToModal(`> 🔌 Auto-detecting Qualcomm HS-USB QDLoader 9008...\n`);
            }
            
            const qBrandSelect = document.getElementById('qcom-brand-select');
            const qModelSelect = document.getElementById('qcom-model-select');
            const qBrand = qBrandSelect ? qBrandSelect.value : 'auto';
            const qModelText = (qModelSelect && qModelSelect.selectedIndex >= 0) ? qModelSelect.options[qModelSelect.selectedIndex].text : '';
            const guide = getBootInstruction('qualcomm', qBrand, qModelText);

            logToModal(`> 💡 คำแนะนำการเข้า EDL [${guide.title}] (${guide.badge}):\n`);
            guide.plain.split('\n').forEach(line => logToModal(`   ${line}\n`));
            logToModal('\n');
            
            try {
                const res = await window.api.runQcomService(cmdName, qcomSelectedComPort, qcomSelectedProgrammer);
                logToModal(`\n${res}\n`, 'success');
                finishModal(true);
            } catch (err) {
                logToModal(`\n[ERROR] ${err.message || err}\n`, 'error');
                finishModal(false);
            }
        });
    }

    function bindMtkAction(id, cmdName) {
        const btn = document.getElementById(id);
        if (!btn) return;
        btn.addEventListener('click', async () => {
            openModal(`MediaTek (MTK): ${cmdName.toUpperCase()}`);
            logToModal(`> Running MTK Service: ${cmdName}...\n`);
            
            const mBrandSelect = document.getElementById('mtk-brand-select');
            const mCpuSelect = document.getElementById('mtk-cpu-select');
            const mBrand = mBrandSelect ? mBrandSelect.value : 'default';
            const mCpuText = (mCpuSelect && mCpuSelect.selectedIndex >= 0) ? mCpuSelect.options[mCpuSelect.selectedIndex].text : '';
            const guide = getBootInstruction('mediatek', mBrand, mCpuText);

            logToModal(`> 💡 คำแนะนำการเชื่อมต่อ BROM [${guide.title}] (${guide.badge}):\n`);
            guide.plain.split('\n').forEach(line => logToModal(`   ${line}\n`));
            logToModal('\n');
            
            try {
                const res = await window.api.runMtkService(cmdName, mtkMode, mtkSelectedDa, mtkSelectedPreloader);
                logToModal(`\n${res}\n`, 'success');
                finishModal(true);
            } catch (err) {
                logToModal(`\n[ERROR] ${err.message || err}\n`, 'error');
                finishModal(false);
            }
        });
    }

    async function getVerifiedLiveSpdPort(requireBsl = false) {
        let ports = [];
        if (window.api && window.api.scanComPorts) {
            try {
                ports = await window.api.scanComPorts() || [];
            } catch (e) {
                console.warn('Scan COM ports error:', e);
            }
        }

        const liveSpdPorts = [];
        let bestBslPort = null;
        let bestDiagPort = null;
        let hasAtPort = false;

        for (const p of ports) {
            const portVal = typeof p === 'object' ? p.port : p;
            const portDesc = typeof p === 'object' ? (p.description || p.desc || '') : '';
            const hwid = typeof p === 'object' ? (p.hwid || '') : '';
            const fullDesc = `${portVal} ${portDesc} ${hwid}`;

            const isSpd = typeof p === 'object'
                ? (p.isSpd || /SPRD|Sci|Unisoc|SPREADTRUM|1782/i.test(fullDesc))
                : /SPRD|Sci|Unisoc|u2s/i.test(portVal);

            if (isSpd) {
                liveSpdPorts.push({ port: portVal, desc: portDesc, hwid: hwid });
                if (/u2s|sci.*download|boot/i.test(fullDesc)) {
                    bestBslPort = portVal;
                } else if (/diag/i.test(fullDesc)) {
                    if (!bestDiagPort) bestDiagPort = portVal;
                }
                if (/at\s*\(|at\s*port/i.test(fullDesc) || /1782:0009/i.test(hwid)) {
                    hasAtPort = true;
                }
            }
        }

        const cachedPort = window.spdSelectedComPort || document.getElementById('spd-port-select')?.value || null;
        const isCachedStillConnected = cachedPort && liveSpdPorts.some(p => p.port.toUpperCase() === cachedPort.toUpperCase());

        let targetPort = null;
        if (isCachedStillConnected) {
            targetPort = cachedPort;
        } else if (bestBslPort) {
            targetPort = bestBslPort;
        } else if (bestDiagPort) {
            targetPort = bestDiagPort;
        } else if (liveSpdPorts.length > 0) {
            targetPort = liveSpdPorts[0].port;
        }

        if (targetPort) {
            window.spdSelectedComPort = targetPort;
            const portSel = document.getElementById('spd-port-select');
            if (portSel) portSel.value = targetPort;
        } else {
            window.spdSelectedComPort = null;
        }

        const isNormalMode = hasAtPort && !bestBslPort;

        return {
            targetPort,
            hasDevice: liveSpdPorts.length > 0,
            isBsl: !!bestBslPort,
            isNormalMode: isNormalMode,
            livePorts: liveSpdPorts,
            allPorts: ports
        };
    }

    function bindSpdAction(id, cmdName) {
        const btn = document.getElementById(id);
        if (!btn) return;
        btn.addEventListener('click', async () => {
            let title = `Unisoc (SPD): ${cmdName.toUpperCase()}`;
            if (cmdName === 'readinfo') title = 'Unisoc: อ่านข้อมูลเครื่อง (Read Info)';
            else if (cmdName === 'unlock') title = 'Unisoc: ปลดล็อกซิม (SIM Unlock)';
            else if (cmdName === 'format' || cmdName === 'factory') title = 'Unisoc: ล้างเครื่อง / คืนค่าโรงงาน';
            else if (cmdName === 'erasefrp') title = 'Unisoc: ปลดล็อก FRP';

            openModal(title);
            logToModal(`> 🔍 ตรวจสอบการเชื่อมต่อพอร์ตสื่อสาร Unisoc...\n`);

            const conn = await getVerifiedLiveSpdPort();

            const bootSel = document.getElementById('spd-boots-select');
            const selectedBoot = bootSel ? bootSel.value : 'auto';
            const guide = getBootInstruction('unisoc', selectedBoot);

            if (!conn.hasDevice || !conn.targetPort) {
                logToModal(`\n❌ ยังไม่พบอุปกรณ์ Unisoc ที่เชื่อมต่อกับคอมพิวเตอร์!\n`, 'error');
                logToModal(`============================================================\n`, 'warning');
                if (cmdName === 'readinfo') {
                    logToModal(`💡 คำแนะนำสำหรับการอ่านข้อมูลเครื่อง (Read Info):\n`, 'warning');
                    logToModal(`  • กรณีเปิดเครื่องปกติ: เสียบสาย USB ให้ Windows ตรวจพบพอร์ต SPRD AT/DIAG\n`);
                    logToModal(`  • กรณีปิดเครื่องอยู่: ถอดและใส่แบตเตอรี่ใหม่ -> กดปุ่ม Boot Key (${guide.badge}) -> เสียบสาย USB\n`);
                } else {
                    logToModal(`💡 วิธีเชื่อมต่อเครื่องเข้าโหมด Bootloader [${guide.title}] (${guide.badge}):\n`, 'warning');
                    guide.plain.split('\n').forEach(line => logToModal(`  ${line}\n`, 'warning'));
                    logToModal(`  * รอให้ Windows ตรวจพบพอร์ต SPRD U2S แล้วกดทำรายการอีกครั้ง\n`, 'warning');
                }
                logToModal(`============================================================\n`, 'warning');
                finishModal(false);
                return;
            }

            if (cmdName !== 'readinfo' && conn.isNormalMode) {
                logToModal(`\n⚠️ ตรวจพบโทรศัพท์เปิดอยู่ในโหมดปกติ (Normal Mode: ${conn.targetPort})\n`, 'warning');
                logToModal(`   ฟังก์ชัน ${title} จำเป็นต้องใช้โหมด Bootloader (BSL) เท่านั้น!\n\n`);
                logToModal(`============================================================\n`, 'warning');
                logToModal(`💡 กรุณาปิดเครื่องและเข้าโหมด BSL [${guide.title}] (${guide.badge}):\n`, 'warning');
                guide.plain.split('\n').forEach(line => logToModal(`  ${line}\n`, 'warning'));
                logToModal(`  * เมื่อเข้าโหมด BSL (SPRD U2S) แล้ว ให้กดปุ่มเริ่มทำงานอีกครั้ง\n`, 'warning');
                logToModal(`============================================================\n`, 'warning');
                finishModal(false);
                return;
            }

            const targetPort = conn.targetPort;
            logToModal(`> 🔌 ตรวจพบพอร์ตสื่อสาร: ${targetPort}\n`);

            if (cmdName === 'readinfo') {
                logToModal(`> 🔍 กำลังอ่านข้อมูลอุปกรณ์จากพอร์ต ${targetPort}...\n\n`);
            } else if (cmdName === 'unlock') {
                logToModal(`> 🔓 เริ่มต้นกระบวนการปลดล็อกซิมการ์ด (ทุกเครือข่าย)...\n\n`);
            } else {
                logToModal(`> ⚙️ กำลังประมวลผลคำสั่ง ${cmdName}...\n\n`);
            }

            let hasStreamedOutput = false;
            window._currentSpdHandler = (text) => {
                const lines = text.split('\n');
                for (const rawLine of lines) {
                    const trimmed = rawLine.trim();
                    if (!trimmed) continue;
                    if (trimmed.startsWith('[SPD_PROG]') || trimmed.startsWith('[SPD_DONE]') || trimmed.startsWith('[SPD_IMEI]') || trimmed.startsWith('[DUMP_SAVED]')) {
                        continue;
                    }
                    if (trimmed.includes('DEBUG') || trimmed.includes('Command timeout after')) {
                        continue;
                    }
                    hasStreamedOutput = true;
                    logToModal(`${trimmed}\n`);
                }
            };

            try {
                const res = await window.api.runSpdService(cmdName, targetPort, window.spdSelectedPacPath);
                if (!hasStreamedOutput && res && res.trim()) {
                    logToModal(`\n${res.trim()}\n`, 'success');
                }
                finishModal(true);
            } catch (err) {
                logToModal(`\n${err.message || err}\n`, 'error');
                finishModal(false);
            } finally {
                window._currentSpdHandler = null;
            }
        });
    }

    // Bind Qualcomm buttons
    bindQcomAction('btn-qcom-readinfo', 'readinfo');
    bindQcomAction('btn-qcom-dump', 'dump');
    bindQcomAction('btn-qcom-erasefrp', 'erasefrp');
    bindQcomAction('btn-qcom-factory', 'factory');
    bindQcomAction('btn-qcom-micloud', 'micloud');
    bindQcomAction('btn-qcom-backupefs', 'backupefs');
    bindQcomAction('btn-qcom-restoreefs', 'restoreefs');
    bindQcomAction('btn-qcom-eraseefs', 'eraseefs');

    // Bind MediaTek buttons
    bindMtkAction('btn-mtk-readinfo', 'readinfo');
    bindMtkAction('btn-mtk-wipedata', 'wipedata');
    bindMtkAction('btn-mtk-format', 'format');
    bindMtkAction('btn-mtk-dump', 'dump');
    bindMtkAction('btn-mtk-erasefrp', 'erasefrp');
    bindMtkAction('btn-mtk-factory', 'factory');
    bindMtkAction('btn-mtk-unlockbl', 'unlockbl');
    bindMtkAction('btn-mtk-backupnv', 'backupnv');
    bindMtkAction('btn-mtk-restorenv', 'restorenv');
    bindMtkAction('btn-mtk-erasenv', 'erasenv');

    // Bind Unisoc/Spreadtrum buttons
    bindSpdAction('btn-spd-readinfo', 'readinfo');
    bindSpdAction('btn-spd-unlock', 'unlock');
    bindSpdAction('btn-spd-format', 'format');
    bindSpdAction('btn-spd-factory', 'factory');
    bindSpdAction('btn-spd-erasefrp', 'erasefrp');

    // Dedicated Dump ROM Handler with Destination Picker & Auto Model/CPU Naming
    const btnSpdDump = document.getElementById('btn-spd-dump');
    if (btnSpdDump) {
        btnSpdDump.addEventListener('click', async () => {
            // 1. Determine Model and CPU automatically
            const bootSel = document.getElementById('spd-boots-select');
            const selectedBoot = bootSel ? bootSel.value : 'auto';
            let chipVal = document.getElementById('spd-chip-val')?.textContent?.trim();
            if (chipVal === '-') chipVal = '';

            let model = 'True_Super_3';
            let cpu = 'SC7702';

            if (selectedBoot === 'SC7702') {
                model = 'True_Super_3';
                cpu = 'SC7702';
            } else if (selectedBoot === 'SC7731') {
                model = 'True_Super_4';
                cpu = 'SC7731';
            } else if (selectedBoot === 'SC6531') {
                model = 'Feature_Phone';
                cpu = 'SC6531';
            } else if (selectedBoot === 'SC9832E') {
                model = 'Unisoc_Phone';
                cpu = 'SC9832E';
            } else if (selectedBoot === 'UMS9230') {
                model = 'Unisoc_T606_T616';
                cpu = 'UMS9230';
            } else {
                // Auto mode
                if (chipVal) {
                    cpu = chipVal;
                    if (/7702/i.test(cpu)) model = 'True_Super_3';
                    else if (/7731/i.test(cpu)) model = 'True_Super_4';
                    else model = `Unisoc_${cpu}`;
                } else if (window.spdSelectedPacPath) {
                    const pacBase = window.spdSelectedPacPath.split(/[\\/]/).pop().replace(/\.pac$/i, '');
                    model = pacBase.replace(/[^a-zA-Z0-9_-]/g, '_');
                    cpu = 'SC7702';
                } else {
                    model = 'True_Super_3';
                    cpu = 'SC7702';
                }
            }

            // 2. Prompt user to choose destination folder first
            let chosenDir = null;
            try {
                chosenDir = await window.api.showOpenDialog({
                    properties: ['openDirectory', 'createDirectory'],
                    title: `เลือกโฟลเดอร์สำหรับจัดเก็บไฟล์ดูดรอม (Dump ROM) - [${model} / ${cpu}]`
                });
            } catch (e) {
                console.error('Error showing open dialog for dump:', e);
            }

            // If user canceled the folder picker dialog, abort
            if (!chosenDir) {
                return;
            }

            // 3. Automatically generate folder name: [Model]_[CPU]_Dump_[YYYYMMDD_HHMMSS]
            const now = new Date();
            const pad = (n) => String(n).padStart(2, '0');
            const timeStr = `${now.getFullYear()}${pad(now.getMonth()+1)}${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;
            const dumpFolderName = `${model}_${cpu}_Dump_${timeStr}`;
            const sep = chosenDir.includes('/') ? '/' : '\\';
            const finalDumpDir = chosenDir.endsWith(sep) ? `${chosenDir}${dumpFolderName}` : `${chosenDir}${sep}${dumpFolderName}`;

            // 4. Open Modal & prepare UI
            const guide = getBootInstruction('unisoc', selectedBoot, model);

            openModal(`Unisoc (SPD): ดูดรอม (${model} / ${cpu})`);
            logToModal(`> 🚀 เริ่มต้นกระบวนการดูดรอม (Dump Full ROM)...\n`);
            logToModal(`> 📱 รุ่นอุปกรณ์: ${model}\n`);
            logToModal(`> ⚙️ ชิปเซ็ต CPU: ${cpu}\n`);
            logToModal(`> 📁 โฟลเดอร์จัดเก็บ: ${finalDumpDir}\n\n`);
            logToModal(`> 💡 คำแนะนำการเชื่อมต่อ [${guide.title}] (${guide.badge}):\n`);
            guide.plain.split('\n').forEach(line => logToModal(`   ${line}\n`));
            logToModal('\n');

            // 5. Live Port Verification
            logToModal(`> 🔍 ตรวจสอบการเชื่อมต่อพอร์ต Unisoc...\n`);
            const conn = await getVerifiedLiveSpdPort();

            if (!conn.hasDevice || !conn.targetPort) {
                logToModal(`\n❌ ยังไม่พบพอร์ตสื่อสาร Unisoc (SPRD U2S) ที่เชื่อมต่ออยู่กับคอมพิวเตอร์!\n`, 'error');
                logToModal(`============================================================\n`, 'warning');
                logToModal(`💡 วิธีเชื่อมต่อเครื่องเข้าโหมดดูดรอม [${guide.title}] (${guide.badge}):\n`, 'warning');
                guide.plain.split('\n').forEach(line => logToModal(`  ${line}\n`, 'warning'));
                logToModal(`  * เมื่อได้ยินเสียงต่อ USB ของ Windows แล้วกดปุ่ม "ดูดรอม (Dump)" ใหม่อีกครั้ง\n`, 'warning');
                logToModal(`============================================================\n`, 'warning');
                finishModal(false);
                return;
            }

            if (conn.isNormalMode) {
                logToModal(`\n⚠️ ตรวจพบโทรศัพท์เปิดอยู่ในโหมดปกติ (Normal Mode: ${conn.targetPort})\n`, 'warning');
                logToModal(`   การดูดรอม (Dump ROM) จำเป็นต้องเข้าโหมด Bootloader (BSL) เท่านั้น!\n\n`);
                logToModal(`============================================================\n`, 'warning');
                logToModal(`💡 กรุณาปิดเครื่องและเข้าโหมด BSL [${guide.title}] (${guide.badge}):\n`, 'warning');
                guide.plain.split('\n').forEach(line => logToModal(`  ${line}\n`, 'warning'));
                logToModal(`  * เมื่อพอร์ตเข้าโหมด BSL แล้ว ให้กด "ดูดรอม" อีกครั้ง\n`, 'warning');
                logToModal(`============================================================\n`, 'warning');
                finishModal(false);
                return;
            }

            const targetPort = conn.targetPort;
            logToModal(`> 🔌 ตรวจพบพอร์ตสื่อสาร: ${targetPort}\n\n`);

            // Reset progress bars
            const lblCurrPart = document.getElementById('spd-lbl-curr-part');
            const lblCurrPct = document.getElementById('spd-lbl-curr-pct');
            const barCurrFill = document.getElementById('spd-bar-curr-fill');
            const lblTotalSpeed = document.getElementById('spd-lbl-total-speed');
            const lblTotalPct = document.getElementById('spd-lbl-total-pct');
            const barTotalFill = document.getElementById('spd-bar-total-fill');

            if (lblCurrPart) lblCurrPart.textContent = 'พาร์ติชัน: กำลังเริ่มดูดรอม...';
            if (lblCurrPct) lblCurrPct.textContent = '0%';
            if (barCurrFill) barCurrFill.style.width = '0%';
            if (lblTotalSpeed) lblTotalSpeed.textContent = 'ความคืบหน้ารวม: 0.0 KB/s';
            if (lblTotalPct) lblTotalPct.textContent = '0%';
            if (barTotalFill) barTotalFill.style.width = '0%';

            const partLines = {};
            let actualSavedDir = finalDumpDir;

            // 6. Wire real-time progress & terminal streaming
            const dumpOutputHandler = (text) => {
                const lines = text.split('\n');
                for (const rawLine of lines) {
                    const trimmed = rawLine.trim();
                    if (!trimmed) continue;

                    if (trimmed.includes('[SPD_PROG]')) {
                        const match = trimmed.match(/\[SPD_PROG\]\s*([^|]+)\|([^|]+)\|([^|]+)\|?(.*)/);
                        if (match) {
                            const part = match[1].trim();
                            const partPct = Math.round(parseFloat(match[2]) || 0);
                            const totalPct = Math.round(parseFloat(match[3]) || 0);
                            const speed = match[4] ? match[4].trim() : '0.0 KB/s';

                            if (lblCurrPart) lblCurrPart.textContent = `พาร์ติชัน: ${part}`;
                            if (lblCurrPct) lblCurrPct.textContent = `${partPct}%`;
                            if (barCurrFill) barCurrFill.style.width = `${partPct}%`;

                            if (lblTotalPct) lblTotalPct.textContent = `${totalPct}%`;
                            if (barTotalFill) barTotalFill.style.width = `${totalPct}%`;
                            if (lblTotalSpeed) lblTotalSpeed.textContent = `ความคืบหน้ารวม (${speed})`;

                            const panelProgress = document.getElementById('mobile-panel-progress-bar');
                            const panelProgressTxt = document.getElementById('mobile-panel-progress-text');
                            if (panelProgress) panelProgress.style.width = `${totalPct}%`;
                            if (panelProgressTxt) panelProgressTxt.textContent = `${totalPct}% (${part})`;

                            const term = document.getElementById('mobile-panel-terminal');
                            if (term) {
                                if (!partLines[part]) {
                                    const lineEl = document.createElement('div');
                                    lineEl.style.fontFamily = "'Consolas', 'JetBrains Mono', monospace";
                                    lineEl.style.fontSize = '12px';
                                    lineEl.style.lineHeight = '1.7';
                                    lineEl.style.color = '#38bdf8';
                                    lineEl.textContent = `⏳ กำลังดูด ${part}... ${partPct}% (${speed})`;
                                    term.appendChild(lineEl);
                                    partLines[part] = lineEl;
                                } else if (!partLines[part].dataset.done) {
                                    partLines[part].textContent = `⏳ กำลังดูด ${part}... ${partPct}% (${speed})`;
                                }
                                const autoScroll = document.getElementById('chk-panel-autoscroll');
                                if (!autoScroll || autoScroll.checked) {
                                    term.scrollTop = term.scrollHeight;
                                }
                            }
                        }
                        continue;
                    }

                    if (trimmed.includes('[SPD_DONE]')) {
                        const match = trimmed.match(/\[SPD_DONE\]\s*(.+)/);
                        const part = match ? match[1].trim() : '';
                        if (part) {
                            const term = document.getElementById('mobile-panel-terminal');
                            if (term) {
                                if (!partLines[part]) {
                                    const lineEl = document.createElement('div');
                                    lineEl.style.fontFamily = "'Consolas', 'JetBrains Mono', monospace";
                                    lineEl.style.fontSize = '12px';
                                    lineEl.style.lineHeight = '1.7';
                                    term.appendChild(lineEl);
                                    partLines[part] = lineEl;
                                }
                                partLines[part].style.color = '#4ade80';
                                partLines[part].style.fontWeight = 'bold';
                                partLines[part].textContent = `✓ ดูด ${part}... สำเร็จ 100%`;
                                partLines[part].dataset.done = 'true';
                            }
                        }
                        continue;
                    }

                    if (trimmed.includes('[DUMP_SAVED]')) {
                        const m = trimmed.match(/\[DUMP_SAVED\]\s*(.+)/);
                        if (m && m[1]) {
                            actualSavedDir = m[1].trim();
                        }
                        continue;
                    }

                    if (!trimmed.startsWith('[SPD_') && !trimmed.includes('DEBUG') && !trimmed.includes('Command timeout')) {
                        logToModal(`${trimmed}\n`);
                    }
                }
            };
            window._currentSpdHandler = dumpOutputHandler;

            // 7. Run Dump Service
            try {
                const dumpOptions = {
                    outDir: finalDumpDir,
                    model: model,
                    cpu: cpu
                };
                await window.api.runSpdService('dump', targetPort, window.spdSelectedPacPath, dumpOptions);

                if (barCurrFill) barCurrFill.style.width = '100%';
                if (barTotalFill) barTotalFill.style.width = '100%';
                if (lblCurrPct) lblCurrPct.textContent = '100%';
                if (lblTotalPct) lblTotalPct.textContent = '100%';

                const targetDirToReport = actualSavedDir || finalDumpDir;
                logToModal(`\n📂 ดูดรอมเสร็จสมบูรณ์ 100%! ไฟล์ทั้งหมดบันทึกไว้ที่:\n   ${targetDirToReport}\n`, 'success');
                finishModal(true);

                // Add clickable buttons to open destination folder directly and pack to .PAC
                const panelTerminal = document.getElementById('mobile-panel-terminal');
                if (panelTerminal && window.api) {
                    const btnDiv = document.createElement('div');
                    btnDiv.style.margin = '10px 0';
                    btnDiv.style.display = 'flex';
                    btnDiv.style.gap = '10px';
                    btnDiv.style.flexWrap = 'wrap';
                    btnDiv.innerHTML = `
                        <button id="btn-open-dump-dir" type="button" style="background: linear-gradient(135deg, #0284c7, #0369a1); border: 1px solid #38bdf8; color: #fff; padding: 7px 16px; border-radius: 6px; font-size: 11px; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 8px;">
                            <i class="fas fa-folder-open"></i> เปิดโฟลเดอร์ไฟล์รอม (${dumpFolderName})
                        </button>
                        <button id="btn-pack-dump-pac" type="button" style="background: linear-gradient(135deg, #8b5cf6, #6d28d9); border: 1px solid #a78bfa; color: #fff; padding: 7px 16px; border-radius: 6px; font-size: 11px; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 8px;">
                            <i class="fas fa-box-archive"></i> รวมไฟล์เป็น .PAC (สร้างเฟิร์มแวร์)
                        </button>
                    `;
                    const btnOpen = btnDiv.querySelector('#btn-open-dump-dir');
                    if (btnOpen && window.api.openFileLocation) {
                        btnOpen.addEventListener('click', () => {
                            window.api.openFileLocation(targetDirToReport);
                        });
                    }
                    const btnPack = btnDiv.querySelector('#btn-pack-dump-pac');
                    if (btnPack && window.api.packDumpToPac) {
                        btnPack.addEventListener('click', async () => {
                            btnPack.disabled = true;
                            btnPack.style.opacity = '0.6';
                            btnPack.innerHTML = `<i class="fas fa-spinner fa-spin"></i> กำลังสร้างไฟล์ .PAC...`;
                            logToModal(`\n📦 เริ่มต้นสร้างไฟล์เฟิร์มแวร์ .PAC จากไฟล์ในโฟลเดอร์...\n`);
                            try {
                                const packRes = await window.api.packDumpToPac(targetDirToReport, { model, cpu });
                                if (packRes && packRes.success) {
                                    logToModal(`\n✅ สร้างไฟล์ PAC สำเร็จ 100%!\n📁 ที่อยู่ไฟล์: ${packRes.pacPath}\n`, 'success');
                                    btnPack.innerHTML = `<i class="fas fa-check"></i> สร้าง .PAC สำเร็จแล้ว`;
                                    if (window.api.openFileLocation) {
                                        window.api.openFileLocation(packRes.pacPath);
                                    }
                                } else {
                                    logToModal(`\n❌ สร้างไฟล์ PAC ไม่สำเร็จ\n`, 'error');
                                    btnPack.disabled = false;
                                    btnPack.style.opacity = '1';
                                    btnPack.innerHTML = `<i class="fas fa-box-archive"></i> ลองสร้างใหม่`;
                                }
                            } catch (pErr) {
                                logToModal(`\n[ERROR] ${pErr.message || pErr}\n`, 'error');
                                btnPack.disabled = false;
                                btnPack.style.opacity = '1';
                                btnPack.innerHTML = `<i class="fas fa-box-archive"></i> ลองสร้างใหม่`;
                            }
                        });
                    }
                    panelTerminal.appendChild(btnDiv);
                    panelTerminal.scrollTop = panelTerminal.scrollHeight;
                }
            } catch (err) {
                logToModal(`\n[ERROR] ${err.message || err}\n`, 'error');
                finishModal(false);
            } finally {
                window._currentSpdHandler = null;
            }
        });
    }

    // Bind Pack PAC toolbar button
    const btnSpdPack = document.getElementById('btn-spd-pack');
    if (btnSpdPack) {
        btnSpdPack.addEventListener('click', async () => {
            if (!window.api || !window.api.browseSaveFolder || !window.api.packDumpToPac) return;
            const chosenDir = await window.api.browseSaveFolder();
            if (!chosenDir) return;

            const selBoot = document.getElementById('spd-boot-select');
            const selectedBoot = selBoot ? selBoot.value : 'SC7702';
            const modelInfo = (typeof GLOBAL_BOOT_KNOWLEDGE !== 'undefined' && GLOBAL_BOOT_KNOWLEDGE.unisoc && GLOBAL_BOOT_KNOWLEDGE.unisoc[selectedBoot]) || {};
            const cpu = modelInfo.chipset || selectedBoot || 'SC7702';
            const model = modelInfo.model || 'True_Super_3';

            openModal(`Unisoc: รวมไฟล์เป็นเฟิร์มแวร์ .PAC`);
            logToModal(`> 📦 กำลังตรวจสอบไฟล์พาร์ติชันในโฟลเดอร์:\n  ${chosenDir}\n\n`);

            try {
                const res = await window.api.packDumpToPac(chosenDir, { model, cpu });
                if (res && res.success) {
                    logToModal(`\n✅ สร้างไฟล์ PAC สำเร็จ 100%!\n📁 ที่อยู่ไฟล์: ${res.pacPath}\n`, 'success');
                    finishModal(true);

                    const panelTerminal = document.getElementById('mobile-panel-terminal');
                    if (panelTerminal && window.api && window.api.openFileLocation) {
                        const btnDiv = document.createElement('div');
                        btnDiv.style.margin = '10px 0';
                        btnDiv.innerHTML = `
                            <button type="button" style="background: linear-gradient(135deg, #8b5cf6, #6d28d9); border: 1px solid #a78bfa; color: #fff; padding: 7px 16px; border-radius: 6px; font-size: 11px; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 8px;">
                                <i class="fas fa-file-archive"></i> เปิดไฟล์ .PAC ที่สร้างเสร็จ
                            </button>
                        `;
                        btnDiv.querySelector('button').addEventListener('click', () => {
                            window.api.openFileLocation(res.pacPath);
                        });
                        panelTerminal.appendChild(btnDiv);
                        panelTerminal.scrollTop = panelTerminal.scrollHeight;
                    }
                } else {
                    logToModal(`\n❌ สร้างไฟล์ PAC ไม่สำเร็จ\n`, 'error');
                    finishModal(false);
                }
            } catch (err) {
                logToModal(`\n[ERROR] ${err.message || err}\n`, 'error');
                finishModal(false);
            }
        });
    }

    // SPD Console & Flasher Engine -> routes directly to unified Log Console
    function appendSpdLog(text, type = '') {
        const formatted = text.endsWith('\n') ? text : (text + '\n');
        logToModal(formatted, type);
    }

    // SPD PAC Browser & Structure Inspector
    const btnSpdBrowsePac = document.getElementById('btn-spd-browse-pac');
    if (btnSpdBrowsePac) {
        btnSpdBrowsePac.addEventListener('click', async () => {
            const filePath = await window.api.showOpenDialog({ filters: [{ name: 'PAC Files', extensions: ['pac'] }] });
            if (!filePath) return;

            window.spdSelectedPacPath = filePath;
            const pacPathEl = document.getElementById('spd-pac-file-path');
            if (pacPathEl) pacPathEl.textContent = filePath;

            const chipVal = document.getElementById('spd-chip-val');
            const imeiVal = document.getElementById('spd-imei-val');
            const partCountVal = document.getElementById('spd-part-count-val');
            const list = document.getElementById('spd-partitions-list');

            if (list) {
                list.innerHTML = '<div style="text-align:center; color:#38bdf8; font-size:11px; padding:40px 0;"><i class="fas fa-spinner fa-spin"></i> กำลังอ่านโครงสร้างรอม PAC...</div>';
            }

            try {
                const res = await window.api.parsePacFile(filePath);
                if (res && res.success && res.partitions && res.partitions.length > 0) {
                    if (chipVal) chipVal.textContent = res.product || 'SC7702';
                    if (imeiVal) imeiVal.textContent = res.imei || '-';
                    if (partCountVal) partCountVal.textContent = res.partitions.length;

                    if (list) {
                        list.innerHTML = '';
                        res.partitions.forEach(p => {
                            const pNameLower = (p.name || '').toLowerCase();
                            const isCore = ['fdl1','fdl2','nvitem','prodnv','uboot','bootloader','sml','smlboot','fdl'].includes(pNameLower);
                            const isEssentialOp = p.is_essential || ['flash', 'erase fs', 'formathfs'].includes(pNameLower);
                            const isChecked = isCore || p.has_file || isEssentialOp;

                            let sizeLabel = '';
                            if (p.size > 0) {
                                sizeLabel = p.size >= 1048576 ? (p.size / 1048576).toFixed(2) + ' MB'
                                    : (p.size >= 1024 ? (p.size / 1024).toFixed(1) + ' KB' : p.size + ' B');
                            } else if (pNameLower === 'flash') {
                                sizeLabel = '⚡ Erase Running-NV';
                            } else if (pNameLower === 'erase fs') {
                                sizeLabel = '⚡ Erase FS Header';
                            } else if (pNameLower === 'formathfs') {
                                sizeLabel = '⚡ Format HFS';
                            } else if (pNameLower === 'phasecheck') {
                                sizeLabel = p.has_file ? 'PhaseCheck' : 'ข้าม (รักษาค่าโรงงาน)';
                            } else {
                                sizeLabel = p.has_file ? 'Erase' : 'System Op';
                            }

                            let badgeHtml = '';
                            if (isEssentialOp) {
                                badgeHtml = '<span style="font-size:9px; padding:1px 5px; background:rgba(239,68,68,0.15); color:#f87171; border-radius:4px; font-weight:700;">CRITICAL OP</span>';
                            } else if (isCore) {
                                badgeHtml = '<span style="font-size:9px; padding:1px 5px; background:rgba(56,189,248,0.15); color:#38bdf8; border-radius:4px; font-weight:700;">CORE BOOT</span>';
                            }

                            const row = document.createElement('div');
                            row.style.cssText = 'display:flex; align-items:center; justify-content:space-between; padding:5px 8px; background:rgba(0,0,0,0.25); border:1px solid rgba(255,255,255,0.05); border-radius:6px; font-size:11px;';
                            row.innerHTML = `
                                <div style="display:flex; align-items:center; gap:8px;">
                                    <input type="checkbox" class="spd-part-cb" value="${p.name}" ${isChecked ? 'checked' : ''} ${isCore ? 'disabled' : ''} style="accent-color:#38bdf8; cursor:pointer;">
                                    <span style="font-weight:600; color:#f1f5f9;">${p.name}</span>
                                    ${badgeHtml}
                                </div>
                                <span style="font-family:monospace; font-size:10px; color:#94a3b8;">${sizeLabel}</span>
                            `;
                            list.appendChild(row);
                        });

                        const checkAll = document.getElementById('spd-check-all');
                        if (checkAll) {
                            checkAll.onchange = (e) => {
                                document.querySelectorAll('.spd-part-cb:not(:disabled)').forEach(cb => cb.checked = e.target.checked);
                            };
                        }

                        appendSpdLog(`[OK] โหลดไฟล์ PAC สำเร็จ: ${res.product || 'SC7702'} (${res.partitions.length} พาร์ติชัน)`, 'success');
                        if (res.imei) {
                            appendSpdLog(`[INFO] ตรวจพบ IMEI โรงงาน: ${res.imei}`, 'info');
                        }
                    }
                } else {
                    if (list) list.innerHTML = `<div style="color:#ef4444; text-align:center; padding:30px;">ไม่สามารถอ่านข้อมูลรอมได้: ${res.error || 'ไฟล์ไม่ถูกต้อง'}</div>`;
                    appendSpdLog(`[ERROR] อ่านไฟล์ PAC ไม่สำเร็จ: ${res.error || 'ไฟล์ไม่ถูกต้อง'}`, 'error');
                }
            } catch (err) {
                if (list) list.innerHTML = `<div style="color:#ef4444; text-align:center; padding:30px;">Error: ${err.message || err}</div>`;
                appendSpdLog(`[ERROR] ข้อผิดพลาด: ${err.message || err}`, 'error');
            }
        });
    }

    // SPD Flashing Action
    const spdFlashBtn = document.getElementById('btn-spd-flash');
    const spdStopBtn = document.getElementById('btn-spd-stop');
    if (spdFlashBtn) {
        spdFlashBtn.addEventListener('click', async () => {
            const pacPath = window.spdSelectedPacPath || document.getElementById('spd-pac-file-path')?.textContent;
            if (!pacPath || pacPath === 'No file selected' || pacPath === 'ยังไม่ได้เลือกไฟล์เฟิร์มแวร์ .pac') {
                alert("กรุณากดเลือกไฟล์รอม .pac ก่อนเริ่มแฟลช");
                return;
            }

            const conn = await getVerifiedLiveSpdPort();
            const activePort = conn.targetPort;

            if (!activePort) {
                const bootSel = document.getElementById('spd-boots-select');
                const selBoot = bootSel ? bootSel.value : 'auto';
                const g = getBootInstruction('unisoc', selBoot);
                alert(`ไม่พบพอร์ต SPRD (โหมด BSL)!\n\nวิธีเชื่อมต่อเครื่อง [${g.title}] (${g.badge}):\n${g.plain}`);
                return;
            }

            const selectedPartCbs = Array.from(document.querySelectorAll('.spd-part-cb:checked')).map(cb => cb.value);
            const selectedPartsArg = selectedPartCbs.length > 0 ? selectedPartCbs.join(',') : null;

            // Update UI State
            spdFlashBtn.disabled = true;
            spdFlashBtn.style.display = 'none';
            if (spdStopBtn) spdStopBtn.style.display = 'flex';

            // Route session to right-panel Log Console and clear old logs
            openModal('Unisoc / SPD: Flash Firmware (PAC)');
            const panelTerminal = document.getElementById('mobile-panel-terminal');
            if (panelTerminal) {
                panelTerminal.innerHTML = '';
            }

            const lblCurrPart = document.getElementById('spd-lbl-curr-part');
            const lblCurrPct = document.getElementById('spd-lbl-curr-pct');
            const barCurrFill = document.getElementById('spd-bar-curr-fill');
            const lblTotalSpeed = document.getElementById('spd-lbl-total-speed');
            const lblTotalPct = document.getElementById('spd-lbl-total-pct');
            const barTotalFill = document.getElementById('spd-bar-total-fill');

            if (lblCurrPart) lblCurrPart.textContent = 'พาร์ติชัน: เริ่มต้นเชื่อมต่อ...';
            if (lblCurrPct) lblCurrPct.textContent = '0%';
            if (barCurrFill) barCurrFill.style.width = '0%';
            if (lblTotalSpeed) lblTotalSpeed.textContent = 'ความคืบหน้ารวม: 0.0 KB/s';
            if (lblTotalPct) lblTotalPct.textContent = '0%';
            if (barTotalFill) barTotalFill.style.width = '0%';

            // Map of partition lines displayed in Log Console
            const partLines = {};

            // Wire real-time output handler
            const spdOutputHandler = (text) => {
                const lines = text.split('\n');
                for (const rawLine of lines) {
                    const trimmed = rawLine.trim();
                    if (!trimmed) continue;

                    if (trimmed.includes('[SPD_PROG]')) {
                        const match = trimmed.match(/\[SPD_PROG\]\s*([^|]+)\|([^|]+)\|([^|]+)\|?(.*)/);
                        if (match) {
                            const part = match[1].trim();
                            const partPct = Math.round(parseFloat(match[2]) || 0);
                            const totalPct = Math.round(parseFloat(match[3]) || 0);
                            const speed = match[4] ? match[4].trim() : '0.0 KB/s';

                            if (lblCurrPart) lblCurrPart.textContent = `พาร์ติชัน: ${part}`;
                            if (lblCurrPct) lblCurrPct.textContent = `${partPct}%`;
                            if (barCurrFill) barCurrFill.style.width = `${partPct}%`;

                            if (lblTotalPct) lblTotalPct.textContent = `${totalPct}%`;
                            if (barTotalFill) barTotalFill.style.width = `${totalPct}%`;
                            if (lblTotalSpeed) lblTotalSpeed.textContent = `ความคืบหน้ารวม (${speed})`;

                            // Sync right panel progress bar and text
                            const panelProgress = document.getElementById('mobile-panel-progress-bar');
                            const panelProgressTxt = document.getElementById('mobile-panel-progress-text');
                            if (panelProgress) panelProgress.style.width = `${totalPct}%`;
                            if (panelProgressTxt) panelProgressTxt.textContent = `${totalPct}% (${part})`;

                            // Update partition progress line in Log Console (Show only clean partition progress)
                            const term = document.getElementById('mobile-panel-terminal');
                            if (term) {
                                if (!partLines[part]) {
                                    const lineEl = document.createElement('div');
                                    lineEl.style.fontFamily = "'Consolas', 'JetBrains Mono', monospace";
                                    lineEl.style.fontSize = '12px';
                                    lineEl.style.lineHeight = '1.7';
                                    if (partPct >= 100) {
                                        lineEl.style.color = '#4ade80';
                                        lineEl.style.fontWeight = 'bold';
                                        lineEl.textContent = `✓ ${part}... สำเร็จ 100%`;
                                        lineEl.dataset.done = 'true';
                                    } else {
                                        lineEl.style.color = '#38bdf8';
                                        lineEl.textContent = `✓ ${part}... ${partPct}%`;
                                    }
                                    term.appendChild(lineEl);
                                    partLines[part] = lineEl;
                                } else if (!partLines[part].dataset.done) {
                                    if (partPct >= 100) {
                                        partLines[part].style.color = '#4ade80';
                                        partLines[part].style.fontWeight = 'bold';
                                        partLines[part].textContent = `✓ ${part}... สำเร็จ 100%`;
                                        partLines[part].dataset.done = 'true';
                                    } else {
                                        partLines[part].textContent = `✓ ${part}... ${partPct}%`;
                                    }
                                }
                                const autoScroll = document.getElementById('chk-panel-autoscroll');
                                if (!autoScroll || autoScroll.checked) {
                                    term.scrollTop = term.scrollHeight;
                                }
                            }
                        }
                        continue;
                    }

                    if (trimmed.includes('[SPD_DONE]')) {
                        const match = trimmed.match(/\[SPD_DONE\]\s*(.+)/);
                        const part = match ? match[1].trim() : '';
                        if (part) {
                            const term = document.getElementById('mobile-panel-terminal');
                            if (term) {
                                if (!partLines[part]) {
                                    const lineEl = document.createElement('div');
                                    lineEl.style.fontFamily = "'Consolas', 'JetBrains Mono', monospace";
                                    lineEl.style.fontSize = '12px';
                                    lineEl.style.lineHeight = '1.7';
                                    term.appendChild(lineEl);
                                    partLines[part] = lineEl;
                                }
                                partLines[part].style.color = '#4ade80';
                                partLines[part].style.fontWeight = 'bold';
                                partLines[part].textContent = `✓ ${part}... สำเร็จ 100%`;
                                partLines[part].dataset.done = 'true';

                                const autoScroll = document.getElementById('chk-panel-autoscroll');
                                if (!autoScroll || autoScroll.checked) {
                                    term.scrollTop = term.scrollHeight;
                                }
                            }
                        }
                        continue;
                    }

                    if (trimmed.includes('[SPD_IMEI]')) {
                        const match = trimmed.match(/\[SPD_IMEI\]\s*(\d+)/);
                        if (match) {
                            const imeiEl = document.getElementById('spd-imei-val');
                            if (imeiEl) imeiEl.textContent = match[1];
                        }
                        continue;
                    }

                    if (trimmed.includes('[ERROR]') || trimmed.includes('Traceback') || trimmed.includes('ล้มเหลว')) {
                        const term = document.getElementById('mobile-panel-terminal');
                        if (term) {
                            const errDiv = document.createElement('div');
                            errDiv.style.color = '#f87171';
                            errDiv.style.fontWeight = 'bold';
                            errDiv.style.fontFamily = "'Consolas', 'JetBrains Mono', monospace";
                            errDiv.style.lineHeight = '1.7';
                            errDiv.textContent = trimmed;
                            term.appendChild(errDiv);
                        }
                    }
                }
            };

            if (!window._spdOutputSetup) {
                window._spdOutputSetup = true;
                if (window.api.onSpdOutput) {
                    window.api.onSpdOutput((text) => {
                        if (window._currentSpdHandler) {
                            window._currentSpdHandler(text);
                        }
                    });
                }
            }
            window._currentSpdHandler = spdOutputHandler;

            try {
                await window.api.runSpdService('flash', activePort, pacPath, selectedPartsArg);
                if (barCurrFill) barCurrFill.style.width = '100%';
                if (barTotalFill) barTotalFill.style.width = '100%';
                if (lblCurrPct) lblCurrPct.textContent = '100%';
                if (lblTotalPct) lblTotalPct.textContent = '100%';
                finishModal(true, false);
            } catch (err) {
                const term = document.getElementById('mobile-panel-terminal');
                if (term) {
                    const errDiv = document.createElement('div');
                    errDiv.style.color = '#ef4444';
                    errDiv.style.fontWeight = 'bold';
                    errDiv.textContent = `❌ [FAIL] การแฟลชขัดข้อง: ${err.message || err}`;
                    term.appendChild(errDiv);
                }
                finishModal(false, false);
            } finally {
                spdFlashBtn.disabled = false;
                spdFlashBtn.style.display = 'flex';
                if (spdStopBtn) spdStopBtn.style.display = 'none';
            }
        });
    }

    // SPD Stop Button listener
    if (spdStopBtn) {
        spdStopBtn.addEventListener('click', () => {
            if (confirm('คุณต้องการหยุดกระบวนการแฟลชใช่หรือไม่? การหยุดกลางคันอาจทำให้เครื่องบูตไม่ติด')) {
                window.api.killFlasherTool();
                const term = document.getElementById('mobile-panel-terminal');
                if (term) {
                    const warnDiv = document.createElement('div');
                    warnDiv.style.color = '#fbbf24';
                    warnDiv.style.fontWeight = 'bold';
                    warnDiv.textContent = '[CANCEL] ได้รับคำสั่งหยุดการแฟลชโดยผู้ใช้';
                    term.appendChild(warnDiv);
                }
                finishModal(false);
            }
        });
    }

    // SPD Scan Ports listener
    const btnSpdScanPorts = document.getElementById('btn-spd-scan-ports');
    const spdPortSelect = document.getElementById('spd-port-select');
    if (btnSpdScanPorts && spdPortSelect) {
        btnSpdScanPorts.addEventListener('click', async () => {
            btnSpdScanPorts.disabled = true;
            btnSpdScanPorts.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Scanning...';
            spdPortSelect.innerHTML = '<option value="" disabled selected>Scanning...</option>';
            try {
                const ports = await window.api.scanComPorts();
                spdPortSelect.innerHTML = '';
                if (ports && ports.length > 0) {
                    const sortedPorts = [...ports].sort((a, b) => {
                        const aDesc = (typeof a === 'object' ? (a.description || '') : '').toLowerCase();
                        const bDesc = (typeof b === 'object' ? (b.description || '') : '').toLowerCase();
                        const aIsDiag = aDesc.includes('diag') || aDesc.includes('u2s');
                        const bIsDiag = bDesc.includes('diag') || bDesc.includes('u2s');
                        if (aIsDiag && !bIsDiag) return -1;
                        if (!aIsDiag && bIsDiag) return 1;
                        const aIsSpd = typeof a === 'object' && a.isSpd;
                        const bIsSpd = typeof b === 'object' && b.isSpd;
                        if (aIsSpd && !bIsSpd) return -1;
                        if (!aIsSpd && bIsSpd) return 1;
                        return 0;
                    });

                    let bestPort = null;
                    sortedPorts.forEach(port => {
                        const opt = document.createElement('option');
                        const portVal = typeof port === 'object' ? port.port : port;
                        const portDesc = typeof port === 'object' ? (port.description || port.desc || '') : '';
                        const isDiag = portDesc.toLowerCase().includes('diag') || portDesc.toLowerCase().includes('u2s');
                        opt.value = portVal;
                        opt.textContent = portDesc ? `${portVal} - ${portDesc}` : portVal;

                        if (!bestPort && (isDiag || (typeof port === 'object' && port.isSpd))) {
                            opt.selected = true;
                            bestPort = portVal;
                        }
                        spdPortSelect.appendChild(opt);
                    });

                    window.spdSelectedComPort = bestPort || (typeof sortedPorts[0] === 'object' ? sortedPorts[0].port : sortedPorts[0]);
                    if (bestPort) {
                        appendSpdLog(`[INFO] ตรวจพบ ${sortedPorts.length} พอร์ต COM (เลือกอัตโนมัติ: ${bestPort})`, 'info');
                    }
                } else {
                    spdPortSelect.innerHTML = '<option value="" disabled selected>-- ไม่พบพอร์ต COM ใดๆ --</option>';
                    window.spdSelectedComPort = null;
                }
                // Also trigger hardware monitor refresh
                if (typeof updateHardwareMonitor === 'function') {
                    updateHardwareMonitor(false);
                }
            } catch (e) {
                spdPortSelect.innerHTML = '<option value="" disabled selected>-- ไม่พบพอร์ต COM ใดๆ --</option>';
                window.spdSelectedComPort = null;
            } finally {
                btnSpdScanPorts.disabled = false;
                btnSpdScanPorts.innerHTML = '<i class="fas fa-sync-alt"></i>';
            }
        });

        spdPortSelect.addEventListener('change', (e) => {
            window.spdSelectedComPort = e.target.value;
            appendSpdLog(`[INFO] เลือกพอร์ต: ${e.target.value}`, 'info');
        });
    }

    // Auto scan ports via top hardware monitor when clicking Unisoc tab
    const tabSpdBtn = document.querySelector('.tab-btn[data-target="tab-spd"]');
    if (tabSpdBtn) {
        tabSpdBtn.addEventListener('click', () => {
            const monScanBtn = document.getElementById('btn-mon-scan-all');
            if (monScanBtn) {
                setTimeout(() => monScanBtn.click(), 100);
            }
        });
    }

    // =========================================================================
    // 🌟 DYNAMIC MULTI-CPU BOOT KEY & CONNECTION KNOWLEDGE BASE
    // =========================================================================
    const GLOBAL_BOOT_KNOWLEDGE = {
        unisoc: {
            'SC7702': {
                title: 'True Super 3 / True Super 4 (SC7702 / SC7701)',
                badge: 'Feature Phone (ปุ่มกด)',
                desc: '1. ปิดเครื่องให้ดับสนิท (ถอดแบตเตอรี่ออก 3 วินาที แล้วใส่กลับเข้าไปใหม่)<br>2. กดปุ่ม <b>กลาง (OK)</b> ค้างไว้ (หากไม่ติด ให้ลองปุ่มเลข <b>0</b> หรือปุ่มโทรออก)<br>3. เสียบสาย USB เข้าคอมพิวเตอร์ ค้างไว้จนกว่าจะได้ยินเสียงตรวจพบพอร์ต <code>SPRD U2S Diag</code> แล้วปล่อยปุ่ม',
                plain: '1. ปิดเครื่องให้ดับสนิท (ถอดแบตเตอรี่ออก 3 วินาที แล้วใส่กลับเข้าไปใหม่)\n2. กดปุ่มกลาง (OK) ค้างไว้ (หากไม่ติด ให้ลองปุ่มเลข 0 หรือปุ่มโทรออก)\n3. เสียบสาย USB เข้าคอมพิวเตอร์ ค้างไว้จนตรวจพบพอร์ต SPRD U2S แล้วปล่อยปุ่ม'
            },
            'SC6531': {
                title: 'Nokia / Itel / Lava / True ปุ่มกด (SC6531 / T107)',
                badge: 'Feature Phone (ปุ่มกด)',
                desc: '1. ปิดเครื่อง ถอดแบตเตอรี่ออก 3-5 วินาที แล้วใส่กลับเข้าไปใหม่<br>2. กดปุ่ม Boot: สำหรับ Nokia ให้กดปุ่ม <b>กลาง Navi Key</b> หรือปุ่ม <b>0</b> | สำหรับ Itel/Lava ให้กดปุ่ม <b>0</b> หรือ <b>Call</b> หรือ <b>*</b><br>3. เสียบสาย USB เข้าคอมพิวเตอร์ รอจนพบพอร์ต <code>SPRD U2S Diag</code> แล้วปล่อยปุ่ม',
                plain: '1. ปิดเครื่อง ถอดแบตเตอรี่ออก 3-5 วินาที แล้วใส่กลับเข้าไปใหม่\n2. กดปุ่ม Boot: สำหรับ Nokia ให้กดปุ่มกลาง Navi Key หรือปุ่ม 0 | สำหรับ Itel/Lava ให้กดปุ่ม 0 หรือ Call หรือ *\n3. เสียบสาย USB เข้าคอมพิวเตอร์ รอจนพบพอร์ต SPRD U2S แล้วปล่อยปุ่ม'
            },
            'SC9863A': {
                title: 'Realme C11 2021 / C21Y / Samsung A03 Core / Nokia C20 (SC9863A)',
                badge: 'Smartphone 4G',
                desc: '1. ปิดโทรศัพท์ให้ดับสนิท (รอหน้าจอดับสนิทอย่างน้อย 5-10 วินาที)<br>2. กดปุ่ม <b>ลดเสียง (Vol Down -)</b> ค้างไว้ (สำหรับ Realme บางล็อต ให้กด <b>Vol Down + Vol Up พร้อมกัน</b>)<br>3. เสียบสาย USB เข้าคอมพิวเตอร์ เครื่องจะเข้าสู่โหมด BSL (<code>SPRD U2S</code>) ทันที',
                plain: '1. ปิดโทรศัพท์ให้ดับสนิท (รอหน้าจอดับสนิท 5-10 วินาที)\n2. กดปุ่ม ลดเสียง (Vol Down -) ค้างไว้ (หรือ Vol Down + Vol Up พร้อมกัน)\n3. เสียบสาย USB เข้าคอมพิวเตอร์ เครื่องจะเข้าสู่โหมด BSL (SPRD U2S) ทันที'
            },
            'UMS9230': {
                title: 'Realme C30 / C31 / C33 / Infinix Smart 7 / Moto E20 (T606 / T610 / T612 / T616)',
                badge: 'Smartphone 4G LTE',
                desc: '1. ปิดเครื่องให้ดับสนิท รอ 5-10 วินาที<br>2. กดปุ่ม <b>ลดเสียง (Vol Down -)</b> ค้างไว้ (หรือกด <b>Vol Down + Vol Up พร้อมกัน</b>)<br>3. เสียบสาย USB เข้ากับคอมพิวเตอร์ รอโปรแกรมตรวจจับพอร์ตแล้วปล่อยปุ่ม',
                plain: '1. ปิดเครื่องให้ดับสนิท รอ 5-10 วินาที\n2. กดปุ่ม ลดเสียง (Vol Down -) ค้างไว้ (หรือกด Vol Down + Vol Up พร้อมกัน)\n3. เสียบสาย USB เข้ากับคอมพิวเตอร์ รอโปรแกรมตรวจจับพอร์ตแล้วปล่อยปุ่ม'
            },
            'SC9832': {
                title: 'Unisoc 4G สมาร์ตโฟนทั่วไป (SC9832 / SC9832E)',
                badge: 'Smartphone 4G',
                desc: '1. ปิดโทรศัพท์ให้ดับสนิท<br>2. กดปุ่ม <b>ลดเสียง (Vol Down -)</b> ค้างไว้<br>3. เสียบสาย USB เข้าคอมพิวเตอร์ (เครื่องจะเข้าสู่โหมด <code>SPRD U2S</code>)',
                plain: '1. ปิดโทรศัพท์ให้ดับสนิท\n2. กดปุ่ม ลดเสียง (Vol Down -) ค้างไว้\n3. เสียบสาย USB เข้าคอมพิวเตอร์ (เครื่องจะเข้าสู่โหมด SPRD U2S)'
            },
            'SC7731': {
                title: 'Unisoc 3G สมาร์ตโฟน / แท็บเล็ต (SC7731 / SC7731E)',
                badge: '3G Smartphone / Tablet',
                desc: '1. ปิดเครื่องให้ดับสนิท (ถอดและใส่แบตใหม่หากถอดได้)<br>2. กดปุ่ม <b>ลดเสียง (Vol Down -)</b> หรือ <b>เพิ่มเสียง (Vol Up +)</b> ค้างไว้<br>3. เสียบสาย USB เข้าคอมพิวเตอร์',
                plain: '1. ปิดเครื่องให้ดับสนิท (ถอดและใส่แบตใหม่หากถอดได้)\n2. กดปุ่ม ลดเสียง (Vol Down -) หรือ เพิ่มเสียง (Vol Up +) ค้างไว้\n3. เสียบสาย USB เข้าคอมพิวเตอร์'
            },
            'auto': {
                title: 'Unisoc / Spreadtrum ทุกรุ่น (ตรวจจับอัตโนมัติ)',
                badge: 'Universal SPD',
                desc: '• <b>สำหรับรุ่นปุ่มกด:</b> ถอดแบตใส่ใหม่ -> กดปุ่ม <b>กลาง (OK)</b> หรือปุ่มเลข <b>0</b> หรือ <b>*</b> ค้างไว้ -> เสียบสาย USB<br>• <b>สำหรับสมาร์ตโฟน:</b> ปิดเครื่องให้ดับสนิท -> กดปุ่ม <b>Vol Down (-)</b> ค้างไว้ (หรือ Vol Down + Vol Up) -> เสียบสาย USB',
                plain: '• สำหรับรุ่นปุ่มกด: ถอดแบตใส่ใหม่ -> กดปุ่มกลาง (OK) หรือปุ่มเลข 0 หรือ * ค้างไว้ -> เสียบสาย USB\n• สำหรับสมาร์ตโฟน: ปิดเครื่องให้ดับสนิท -> กดปุ่ม Vol Down (-) ค้างไว้ (หรือ Vol Down + Vol Up) -> เสียบสาย USB'
            }
        },
        qualcomm: {
            'xiaomi': {
                title: 'Xiaomi / Redmi / POCO Snapdragon (EDL 9008)',
                badge: 'Qualcomm 9008',
                desc: '1. <b>วิธี Test Point (แนะนำสูงสุด 100%):</b> แกะฝาหลัง ถอดขั้วสายแพร์แบตเตอรี่ออก -> ใช้แหนบช็อตจุดสีทอง <b>Test Point (EDL Point 2 จุด)</b> เหนือบอร์ดแบตเตอรี่ค้างไว้ -> เสียบสาย USB เข้า PC -> ได้ยินเสียงเชื่อมต่อ ปล่อยแหนบทันที<br>2. <b>วิธี Fastboot:</b> สำหรับเครื่องที่ปลดล็อก Bootloader แล้ว เปิดเครื่องเข้า Fastboot -> กดปุ่ม <i>"Reboot EDL (9008)"</i> ในโปรแกรม<br>3. <b>วิธีปุ่มกด (เฉพาะรุ่นเก่ามาก):</b> ปิดเครื่องดับสนิท -> กด <code>Vol Up (+)</code> และ <code>Vol Down (-)</code> ค้างไว้ 5 วินาที -> เสียบสาย USB',
                plain: '1. วิธี Test Point (แนะนำสูงสุด 100%): แกะฝาหลัง ถอดขั้วสายแพร์แบตเตอรี่ออก -> ใช้แหนบช็อตจุด Test Point (EDL Point 2 จุด) ค้างไว้ -> เสียบสาย USB -> ได้ยินเสียงเชื่อมต่อ ปล่อยแหนบทันที\n2. วิธี Fastboot: สำหรับเครื่องที่ปลดล็อก Bootloader แล้ว เข้า Fastboot -> สั่ง Reboot EDL ในโปรแกรม\n3. วิธีปุ่มกด (เฉพาะรุ่นเก่ามาก): ปิดเครื่องดับสนิท -> กด Vol Up (+) และ Vol Down (-) ค้างไว้ -> เสียบสาย USB'
            },
            'oppo': {
                title: 'OPPO / Realme Snapdragon (A3s, A5, A7, A53, A74, Realme C1...)',
                badge: 'Qualcomm 9008 (Test Point)',
                desc: '⚠️ <b>สำคัญมาก:</b> รุ่นยอดนิยมเช่น Oppo A3s, A5, A7, A53, Realme C1 <u>ถูกปิดระบบ Boot Key ใน Bootloader 100%</u> (กดปุ่มจะไม่เข้า 9008)<br>1. <b>วิธี Test Point (มาตรฐานช่าง):</b> แกะฝาหลัง ถอดขั้วสายแพร์แบตเตอรี่ออก -> ใช้แหนบช็อตจุด Test Point สีทอง 2 จุดข้างกรอบถาดซิมลงกราวด์ (GND) -> เสียบสาย USB เข้า PC<br>2. เมื่อคอมพิวเตอร์ตรวจพบพอร์ต <code>Qualcomm HS-USB QDLoader 9008</code> ให้ปล่อยแหนบทันที<br>3. หรือใช้สาย <b>EDL Deep Flash Cable</b> ช็อตพิน Data+ ลงกราวด์ขณะเสียบสาย',
                plain: '⚠️ สำคัญมาก: รุ่นเช่น Oppo A3s, A5, A7, A53, Realme C1 ถูกปิดระบบ Boot Key ใน Bootloader 100% (กดปุ่มจะไม่เข้า 9008)!\n1. วิธี Test Point: แกะฝาหลัง ถอดขั้วแบตเตอรี่ออก -> ใช้แหนบช็อตจุด TP 2 จุดข้างกรอบถาดซิมลงกราวด์ (GND) -> เสียบสาย USB เข้า PC\n2. เมื่อคอมตรวจพบพอร์ต Qualcomm HS-USB QDLoader 9008 ให้ปล่อยแหนบทันที\n3. หรือใช้สาย EDL Deep Flash Cable ช็อต Data+ ลงกราวด์ขณะเสียบสาย'
            },
            'realme': {
                title: 'Realme Snapdragon (Realme C1, 2 Pro, 5, 5i, 5s, XT...)',
                badge: 'Qualcomm 9008',
                desc: '1. <b>รุ่น C1 / 5 / 5i / 5s:</b> แนะนำวิธี Test Point แกะฝาหลัง ถอดแบตเตอรี่ -> ช็อตจุด TP 2 จุดข้างถาดซิมลงกราวด์ -> เสียบสาย USB เข้า PC<br>2. <b>สำหรับรุ่นเก่าที่ยังไม่บล็อคคีย์:</b> ปิดเครื่องให้ดับสนิท -> กดปุ่ม <b>Vol Up (+)</b> และ <b>Vol Down (-)</b> ค้างไว้พร้อมกัน 5-8 วินาที -> เสียบสาย USB เข้าคอมพิวเตอร์',
                plain: '1. รุ่น C1 / 5 / 5i / 5s: แนะนำวิธี Test Point แกะฝาหลัง ถอดแบตเตอรี่ -> ช็อตจุด TP 2 จุดข้างถาดซิมลงกราวด์ -> เสียบสาย USB เข้า PC\n2. สำหรับรุ่นเก่าที่ยังไม่บล็อคคีย์: ปิดเครื่อง -> กด Vol Up (+) และ Vol Down (-) ค้างไว้พร้อมกัน -> เสียบสาย USB'
            },
            'vivo': {
                title: 'Vivo / iQOO Snapdragon (Y11 1906, Y20, Y20s, V9, V11, V15 Pro...)',
                badge: 'Qualcomm 9008',
                desc: '⚠️ <b>ข้อสังเกต:</b> Vivo Y11 (1906) และ Y20/Y20s เป็นชิป Qualcomm ห้ามกดปุ่มเหมือนรุ่น Y12/Y15 (MTK)!<br>1. แกะฝาหลัง ถอดขั้วสายแพร์แบตเตอรี่ออกเพื่อตัดไฟ<br>2. ใช้แหนบช็อตจุด <b>Test Point 2 จุดสีทอง</b> (Y11 อยู่ข้างขั้วแบต / Y20 อยู่ด้านซ้ายขั้วแบต) ค้างไว้<br>3. เสียบสาย USB เข้า PC -> ตรวจพบพอร์ต <code>Qualcomm HS-USB QDLoader 9008</code> ปล่อยแหนบทันที',
                plain: '⚠️ ข้อสังเกต: Vivo Y11 (1906) และ Y20/Y20s เป็นชิป Qualcomm ห้ามกดปุ่มเหมือนรุ่น Y12/Y15 (MTK)!\n1. แกะฝาหลัง ถอดขั้วแบตเตอรี่ออก\n2. ใช้แหนบช็อตจุด Test Point 2 จุดสีทองข้างขั้วแบตเตอรี่ค้างไว้\n3. เสียบสาย USB เข้า PC -> ตรวจพบพอร์ต Qualcomm HS-USB QDLoader 9008 ปล่อยแหนบทันที'
            },
            'samsung': {
                title: 'Samsung Galaxy Snapdragon (A01, A11, A52, A70, A71, S20 FE SD...)',
                badge: 'Qualcomm 9008 / EUB',
                desc: '1. <b>กรณีเครื่องเปิดติด / เข้า Download Mode ได้:</b> เข้า Download Mode แล้วใช้คำสั่ง <i>"Reboot EDL (9008)"</i> ในโปรแกรม<br>2. <b>กรณีเครื่องดับสนิท / Hard-Brick:</b> แกะฝาหลัง ถอดขั้วแบตเตอรี่ออก -> ใช้แหนบช็อตจุด <b>EDL Test Point</b> ลงกราวด์ (GND) บนเมนบอร์ด -> เสียบสาย USB เข้าคอมพิวเตอร์',
                plain: '1. กรณีเครื่องเปิดติด / เข้า Download Mode ได้: เข้า Download Mode แล้วสั่ง Reboot EDL ในโปรแกรม\n2. กรณีเครื่องดับสนิท / Hard-Brick: แกะฝาหลัง ถอดขั้วแบตเตอรี่ออก -> ใช้แหนบช็อตจุด EDL Test Point ลงกราวด์ (GND) -> เสียบสาย USB เข้า PC'
            },
            'oneplus': {
                title: 'OnePlus (5/6/7/8/Nord Snapdragon)',
                badge: 'Qualcomm 9008',
                desc: '1. ปิดเครื่องให้ดับสนิท (รอ 5 วินาที)<br>2. กดปุ่ม <b>Vol Up (+)</b> และ <b>Vol Down (-)</b> ค้างไว้พร้อมกัน 5 วินาที<br>3. เสียบสาย USB เข้าคอมพิวเตอร์ ตัวเครื่องจะเข้าสู่โหมด EDL (MSM Download Mode) ทันที',
                plain: '1. ปิดเครื่องให้ดับสนิท (รอ 5 วินาที)\n2. กดปุ่ม Vol Up (+) และ Vol Down (-) ค้างไว้พร้อมกัน 5 วินาที\n3. เสียบสาย USB เข้าคอมพิวเตอร์ ตัวเครื่องจะเข้าสู่โหมด EDL ทันที'
            },
            'lenovo': {
                title: 'Lenovo & Motorola Snapdragon (K6, P2, Moto G...)',
                badge: 'Qualcomm 9008',
                desc: '1. ปิดเครื่องให้ดับสนิท<br>2. กดปุ่ม <b>Vol Up (+)</b> และ <b>Vol Down (-)</b> ค้างไว้พร้อมกัน<br>3. เสียบสาย USB เข้าคอมพิวเตอร์',
                plain: '1. ปิดเครื่องให้ดับสนิท\n2. กดปุ่ม Vol Up (+) และ Vol Down (-) ค้างไว้พร้อมกัน\n3. เสียบสาย USB เข้าคอมพิวเตอร์'
            },
            'auto': {
                title: 'Qualcomm Snapdragon ทุกรุ่นทั่วไป (EDL 9008 Mode)',
                badge: 'Qualcomm 9008',
                desc: '1. <b>วิธี Test Point (แน่นอน 100%):</b> ถอดขั้วแบตเตอรี่ออก -> ใช้แหนบจิ้มจุด <b>Test Point (EDL Point 2 จุด)</b> บนบอร์ดลงกราวด์ขณะเสียบสาย USB เข้า PC<br>2. <b>วิธีปุ่มกด:</b> ปิดเครื่องให้ดับสนิท -> กดปุ่ม <b>เพิ่มเสียง (Vol Up +)</b> และ <b>ลดเสียง (Vol Down -)</b> ค้างไว้พร้อมกัน 5-8 วินาที แล้วเสียบสาย USB',
                plain: '1. วิธี Test Point (แน่นอน 100%): ถอดขั้วแบตออก -> ใช้แหนบจิ้มจุด Test Point บนบอร์ดขณะเสียบสาย USB เข้า PC\n2. วิธีปุ่มกด: ปิดเครื่องให้ดับสนิท -> กดปุ่ม Vol Up (+) และ Vol Down (-) ค้างไว้พร้อมกัน 5-8 วินาที แล้วเสียบสาย USB'
            }
        },
        mediatek: {
            'oppo': {
                title: 'OPPO (MediaTek Helio P35 / G35 / Dimensity - A1k, A5s, A12, A15, A16...)',
                badge: 'MTK BROM Mode',
                desc: '1. ปิดโทรศัพท์ให้ดับสนิท (รอ 5 วินาที ให้ระบบปิดสมบูรณ์)<br>2. กดปุ่ม <b>เพิ่มเสียง (Vol Up +)</b> และ <b>ลดเสียง (Vol Down -)</b> ค้างไว้พร้อมกัน<br>3. เสียบสาย USB เข้ากับคอมพิวเตอร์<br>4. เมื่อโปรแกรมตรวจพบพอร์ต <code>MTK USB VCOM</code> แล้ว ให้ปล่อยมือจากปุ่มทันที (ไม่ต้องแกะเครื่อง)',
                plain: '1. ปิดโทรศัพท์ให้ดับสนิท (รอ 5 วินาที)\n2. กดปุ่ม Vol Up (+) และ Vol Down (-) ค้างไว้พร้อมกัน\n3. เสียบสาย USB เข้าคอมพิวเตอร์\n4. เมื่อโปรแกรมตรวจพบพอร์ต MTK USB VCOM ให้ปล่อยปุ่มทันที (ไม่ต้องแกะเครื่อง)'
            },
            'realme': {
                title: 'Realme (MediaTek Helio / Dimensity - C2, C3, C11, C12, C15, C21, C25...)',
                badge: 'MTK BROM Mode',
                desc: '1. ปิดเครื่องให้ดับสนิท<br>2. กดปุ่ม <b>Vol Up (+)</b> และ <b>Vol Down (-)</b> ค้างไว้พร้อมกัน<br>3. เสียบสาย USB เข้าคอมพิวเตอร์ -> เมื่อเริ่มส่ง Payload ปล่อยปุ่มทันที',
                plain: '1. ปิดเครื่องให้ดับสนิท\n2. กดปุ่ม Vol Up (+) และ Vol Down (-) ค้างไว้พร้อมกัน\n3. เสียบสาย USB เข้าคอมพิวเตอร์ -> เมื่อเริ่มส่ง Payload ปล่อยปุ่มทันที'
            },
            'vivo': {
                title: 'Vivo (MediaTek MTK - Y1s, Y12, Y15, Y17, Y19, Y12s, Y15s, Y16, Y21, V21...)',
                badge: 'MTK BROM Mode',
                desc: '1. ปิดโทรศัพท์ให้ดับสนิท<br>2. กดปุ่ม <b>เพิ่มเสียง (Vol Up +)</b> และ <b>ลดเสียง (Vol Down -)</b> พร้อมกันค้างไว้<br>3. เสียบสาย USB เข้าคอมพิวเตอร์ ปล่อยปุ่มเมื่อตรวจพบพอร์ต VCOM (ไม่ต้องแกะเครื่อง)',
                plain: '1. ปิดโทรศัพท์ให้ดับสนิท\n2. กดปุ่ม Vol Up (+) และ Vol Down (-) พร้อมกันค้างไว้\n3. เสียบสาย USB เข้าคอมพิวเตอร์ ปล่อยปุ่มเมื่อตรวจพบพอร์ต VCOM (ไม่ต้องแกะเครื่อง)'
            },
            'xiaomi': {
                title: 'Xiaomi / Redmi / POCO MediaTek (Redmi 6, 6A, 9, 9A, 9C, 10A, Note 8 Pro, Note 10S...)',
                badge: 'MTK BROM Mode',
                desc: '1. ปิดโทรศัพท์ให้ดับสนิท<br>2. กดปุ่ม <b>Vol Up (+)</b> และ <b>Vol Down (-)</b> ค้างไว้พร้อมกัน -> เสียบสาย USB เข้าคอมพิวเตอร์<br>3. ⚠️ <b>หาก MIUI 12.5+ บล็อก BROM (เครื่องบูทวน):</b> ใช้แหนบช็อตจุด Test Point 2 จุดข้างถาดซิมลงกราวด์ขณะเสียบสาย USB',
                plain: '1. ปิดโทรศัพท์ให้ดับสนิท\n2. กดปุ่ม Vol Up (+) และ Vol Down (-) ค้างไว้พร้อมกัน -> เสียบสาย USB เข้าคอมพิวเตอร์\n3. หาก MIUI 12.5+ บล็อก BROM: ใช้แหนบช็อตจุด Test Point 2 จุดข้างถาดซิมลงกราวด์ขณะเสียบสาย USB'
            },
            'samsung': {
                title: 'Samsung Galaxy MediaTek (A02, A03s, A04, A12 MTK A125F, A13, A22, A32...)',
                badge: 'MTK BROM Mode',
                desc: '1. ปิดโทรศัพท์ให้ดับสนิท (หรือบังคับดับด้วย Power + Vol-)<br>2. กดปุ่ม <b>เพิ่มเสียง (Vol Up +)</b> และ <b>ลดเสียง (Vol Down -)</b> ค้างไว้พร้อมกัน<br>3. เสียบสาย USB ที่ต่อกับ PC เข้าตัวเครื่อง ปล่อยปุ่มเมื่อเข้า BROM<br>4. ⚠️ <b>หากติด Secured Preloader (เด้งไปชาร์จแบต):</b> แกะฝาหลัง ถอดสายแพร์แบตเตอรี่ออก แล้วใช้แหนบช็อตจุด <b>Test Point (DAT0 / TP to GND)</b> ขณะเสียบสาย USB เพื่อบังคับเข้า MTK Hardware BROM',
                plain: '1. ปิดโทรศัพท์ให้ดับสนิท (หรือบังคับดับด้วย Power + Vol-)\n2. กดปุ่ม Vol Up (+) และ Vol Down (-) ค้างไว้พร้อมกัน\n3. เสียบสาย USB ที่ต่อกับ PC เข้าตัวเครื่อง ปล่อยปุ่มเมื่อเข้า BROM\n4. หากติด Secured Preloader (เด้งไปชาร์จแบต): แกะฝาหลัง ถอดแบตออก แล้วใช้แหนบช็อตจุด TP (DAT0 to GND) ขณะเสียบสาย USB เพื่อบังคับเข้า MTK Hardware BROM'
            },
            'infinix_tecno': {
                title: 'Infinix & Tecno MediaTek (Hot 8/9/10/11/12/20/30, Note, Pova, Spark...)',
                badge: 'MTK BROM Mode',
                desc: '1. ปิดโทรศัพท์ให้ดับสนิท<br>2. กดปุ่ม <b>Vol Up (+)</b> และ <b>Vol Down (-)</b> ค้างไว้พร้อมกัน<br>3. เสียบสาย USB เข้าคอมพิวเตอร์ (หากไม่เข้า ให้กดเฉพาะปุ่ม Vol Down ค้างไว้)',
                plain: '1. ปิดโทรศัพท์ให้ดับสนิท\n2. กดปุ่ม Vol Up (+) และ Vol Down (-) ค้างไว้พร้อมกัน\n3. เสียบสาย USB เข้าคอมพิวเตอร์ (หากไม่เข้า ให้กดเฉพาะปุ่ม Vol Down ค้างไว้)'
            },
            'huawei': {
                title: 'Huawei / Honor MediaTek (Y5, Y6, Nova MTK Series)',
                badge: 'MTK BROM Mode',
                desc: '1. ปิดโทรศัพท์ให้ดับสนิท (รอ 5 วินาที)<br>2. กดปุ่ม <b>ลดเสียง (Vol Down -)</b> หรือ <b>Vol Up (+) + Vol Down (-)</b> ค้างไว้ แล้วเสียบสาย USB<br>3. เมื่อพบพอร์ต MTK USB VCOM ให้ปล่อยปุ่มทันที',
                plain: '1. ปิดโทรศัพท์ให้ดับสนิท (รอ 5 วินาที)\n2. กดปุ่ม Vol Down (-) หรือ Vol Up (+) + Vol Down (-) ค้างไว้ แล้วเสียบสาย USB\n3. เมื่อพบพอร์ต MTK USB VCOM ให้ปล่อยปุ่มทันที'
            },
            'default': {
                title: 'MediaTek ทุกรุ่นทั่วไป (BROM / Preloader Mode)',
                badge: 'MTK BROM Mode',
                desc: '1. ปิดโทรศัพท์ให้ดับสนิท (รออย่างน้อย 5 วินาที)<br>2. กดปุ่ม <b>เพิ่มเสียง (Vol Up +)</b> และ <b>ลดเสียง (Vol Down -)</b> ค้างไว้พร้อมกัน<br>3. เสียบสาย USB เข้ากับคอมพิวเตอร์<br>4. ปล่อยปุ่มทันทีที่โปรแกรมตรวจจับพอร์ต <code>MTK USB VCOM</code> ได้',
                plain: '1. ปิดโทรศัพท์ให้ดับสนิท (รออย่างน้อย 5 วินาที)\n2. กดปุ่ม Vol Up (+) และ Vol Down (-) ค้างไว้พร้อมกัน\n3. เสียบสาย USB เข้ากับคอมพิวเตอร์\n4. ปล่อยปุ่มทันทีที่โปรแกรมตรวจจับพอร์ต MTK USB VCOM ได้'
            }
        },
        fastboot: {
            'all': {
                title: 'Fastboot Mode ทุกรุ่นทั่วไป (Android Universal)',
                badge: 'Fastboot Mode',
                desc: 'ปิดโทรศัพท์ให้ดับสนิท -> กดปุ่ม <code>Power</code> + <code>Vol Down (-)</code> ค้างไว้พร้อมกันจนกว่าจะติดหน้าจอ Fastboot / Bootloader -> เสียบสาย USB เข้ากับคอมพิวเตอร์',
                plain: 'ปิดโทรศัพท์ให้ดับสนิท -> กดปุ่ม Power + Vol Down (-) ค้างไว้พร้อมกันจนกว่าจะติดหน้าจอ Fastboot / Bootloader -> เสียบสาย USB เข้ากับคอมพิวเตอร์'
            },
            'xiaomi': {
                title: 'Xiaomi / Redmi / POCO (Fastboot Mode)',
                badge: 'Mi Fastboot',
                desc: '1. ปิดเครื่องให้ดับสนิท (รอ 3-5 วินาที)<br>2. กดปุ่ม <b>ลดเสียง (Vol Down -)</b> และปุ่ม <b>เปิดเครื่อง (Power)</b> ค้างไว้พร้อมกัน<br>3. ปล่อยมือเมื่อหน้าจอติดรูปตุ๊กตากระต่าย Mi Bunny หรือตัวอักษรสีส้ม <b>"FASTBOOT"</b><br>4. เสียบสาย USB เข้ากับคอมพิวเตอร์',
                plain: '1. ปิดเครื่องให้ดับสนิท (รอ 3-5 วินาที)\n2. กดปุ่ม Vol Down (-) และปุ่ม Power ค้างไว้พร้อมกัน\n3. ปล่อยมือเมื่อหน้าจอติดรูปตุ๊กตากระต่าย Mi Bunny หรือตัวอักษรสีส้ม FASTBOOT\n4. เสียบสาย USB เข้าคอมพิวเตอร์'
            },
            'vivo': {
                title: 'Vivo / iQOO (Fastboot Mode)',
                badge: 'Vivo Fastboot',
                desc: '1. ปิดเครื่องให้ดับสนิท<br>2. กดปุ่ม <b>เพิ่มเสียง (Vol Up +)</b> และปุ่ม <b>เปิดเครื่อง (Power)</b> ค้างไว้พร้อมกัน<br>3. เมื่อติดโลโก้ Vivo ปล่อยปุ่ม Power แต่ยังคงกด Vol Up ค้างไว้จนเข้าหน้า Fastboot Mode<br>4. เสียบสาย USB เข้าคอมพิวเตอร์',
                plain: '1. ปิดเครื่องให้ดับสนิท\n2. กดปุ่ม Vol Up (+) และปุ่ม Power ค้างไว้พร้อมกัน\n3. เมื่อติดโลโก้ Vivo ปล่อยปุ่ม Power แต่ยังกด Vol Up ค้างไว้จนเข้าหน้า Fastboot Mode\n4. เสียบสาย USB เข้าคอมพิวเตอร์'
            },
            'oppo_realme': {
                title: 'OPPO / Realme (Fastboot & Bootloader)',
                badge: 'Recovery to Fastboot',
                desc: '1. ปิดเครื่องให้ดับสนิท -> กดปุ่ม <code>Power</code> + <code>Vol Down (-)</code> เพื่อเข้าหน้า Recovery ก่อน<br>2. เลือกภาษา English -> เลือก Advanced -> แตะที่ <b>"Reboot to Bootloader"</b> -> แตะ OK<br>3. ตัวเครื่องจะรีบูตเข้าสู่ Fastboot Mode จอสีดำทันที -> เสียบสาย USB',
                plain: '1. ปิดเครื่องให้ดับสนิท -> กดปุ่ม Power + Vol Down (-) เพื่อเข้าหน้า Recovery ก่อน\n2. เลือกภาษา English -> เลือก Advanced -> แตะ Reboot to Bootloader -> แตะ OK\n3. ตัวเครื่องจะรีบูตเข้าสู่ Fastboot Mode จอสีดำทันที -> เสียบสาย USB'
            },
            'pixel_moto': {
                title: 'Google Pixel / Motorola / OnePlus / ASUS (Bootloader)',
                badge: 'Standard Bootloader',
                desc: '1. ปิดโทรศัพท์ให้ดับสนิท<br>2. กดปุ่ม <b>ลดเสียง (Vol Down -)</b> และปุ่ม <b>Power</b> ค้างไว้พร้อมกันจนหน้าจอติดรูปหุ่นแอนดรอยด์สีเขียวล้ม<br>3. เสียบสาย USB เข้าคอมพิวเตอร์',
                plain: '1. ปิดโทรศัพท์ให้ดับสนิท\n2. กดปุ่ม ลดเสียง (Vol Down -) และปุ่ม Power ค้างไว้พร้อมกันจนหน้าจอติดรูปหุ่นแอนดรอยด์สีเขียวล้ม\n3. เสียบสาย USB เข้าคอมพิวเตอร์'
            },
            'huawei': {
                title: 'Huawei / Honor (Fastboot & Rescue Mode)',
                badge: 'Rescue Mode',
                desc: '1. ปิดโทรศัพท์ให้ดับสนิท<br>2. กดปุ่ม <b>ลดเสียง (Vol Down -)</b> ค้างไว้<br>3. เสียบสาย USB เข้ากับคอมพิวเตอร์ หน้าจอสีขาวจะขึ้นโลโก้และตัวอักษร <b>"FASTBOOT&RESCUE MODE"</b>',
                plain: '1. ปิดโทรศัพท์ให้ดับสนิท\n2. กดปุ่ม ลดเสียง (Vol Down -) ค้างไว้\n3. เสียบสาย USB เข้าคอมพิวเตอร์ หน้าจอขาวจะขึ้น FASTBOOT&RESCUE MODE'
            }
        },
        samsung: {
            'new': {
                title: 'Samsung รุ่นใหม่ (ไม่มีปุ่ม Home - Galaxy A/M/S/Note/Z Series)',
                badge: 'Download Mode',
                desc: '1. <b>กรณีเครื่องปิดได้ปกติ:</b> ปิดเครื่องให้ดับสนิท -> เสียบสาย USB ฝั่งคอมพิวเตอร์ไว้ก่อน -> กดปุ่ม <b>Vol Up (+)</b> และ <b>Vol Down (-)</b> ค้างไว้พร้อมกัน -> เสียบปลายสาย USB เข้าโทรศัพท์ -> หน้าจอสีฟ้าเตือน Warning ติดขึ้นมา -> กดปุ่ม <b>Vol Up 1 ครั้ง</b> เพื่อเข้า Download Mode<br>2. ⚠️ <b>กรณีเครื่องติดรหัสหน้าจอ / บูทวน (ปิดเครื่องไม่ได้):</b> เสียบสาย USB ที่ต่อกับ PC ไว้ -> กดปุ่ม <b>Power + Vol Down (-)</b> ค้างไว้ 7-10 วินาทีจนหน้าจอดับสนิท -> จังหวะที่จอดับพอดี ให้รีบปล่อย Power แล้วกด <b>Vol Up (+) และ Vol Down (-)</b> ค้างไว้ทันที -> กด Vol Up ยืนยัน',
                plain: '1. กรณีเครื่องปิดได้ปกติ: ปิดเครื่องให้สนิท -> เสียบสาย USB ฝั่งคอมพิวเตอร์ไว้ก่อน -> กดปุ่ม Vol Up (+) และ Vol Down (-) ค้างไว้พร้อมกัน -> เสียบปลายสาย USB เข้าโทรศัพท์ -> หน้าจอสีฟ้าเตือน Warning ติด -> กด Vol Up 1 ครั้ง เพื่อเข้า Download Mode\n2. กรณีเครื่องติดรหัส/บูทวน (สั่งปิดไม่ได้): เสียบสาย USB ที่ต่อกับ PC ไว้ -> กด Power + Vol Down (-) ค้างไว้ 7-10 วินาทีจนจอดับ -> วินาทีที่จอดับ ให้ปล่อย Power แล้วรีบกด Vol Up (+) + Vol Down (-) ค้างไว้ทันที -> กด Vol Up 1 ครั้ง'
            },
            'bixby': {
                title: 'Samsung รุ่นมีปุ่ม Bixby (Galaxy S8, S9, S10, Note 8, Note 9)',
                badge: 'Download Mode',
                desc: '1. ปิดเครื่องให้ดับสนิท<br>2. กดปุ่ม <b>Bixby</b> + <b>Vol Down (-)</b> + <b>Power</b> ค้างไว้พร้อมกัน<br>3. ติดหน้าจอสีฟ้าเตือน -> กดปุ่ม <b>Vol Up (+) 1 ครั้ง</b> เพื่อยืนยัน',
                plain: '1. ปิดเครื่องให้ดับสนิท\n2. กดปุ่ม Bixby + Vol Down (-) + Power ค้างไว้พร้อมกัน\n3. ติดหน้าจอสีฟ้าเตือน -> กด Vol Up 1 ครั้ง'
            },
            'home': {
                title: 'Samsung รุ่นเก่า (มีปุ่ม Home - S6, S7, Note 5, J Series)',
                badge: 'Download Mode',
                desc: '1. ปิดเครื่องให้ดับสนิท<br>2. กดปุ่ม <b>Home</b> + <b>Vol Down (-)</b> + <b>Power</b> ค้างไว้พร้อมกัน<br>3. เมื่อติดหน้าจอเตือน Warning -> กดปุ่ม <b>Vol Up (+) 1 ครั้ง</b>',
                plain: '1. ปิดเครื่องให้ดับสนิท\n2. กดปุ่ม Home + Vol Down (-) + Power ค้างไว้พร้อมกัน\n3. ติดหน้าจอเตือน Warning -> กด Vol Up 1 ครั้ง'
            },
            'eub': {
                title: 'Samsung Exynos EUB Mode (A12 SM-A127F, A21s, A51, A71...)',
                badge: 'Exynos USB Booting (EUB)',
                desc: '1. สำหรับกู้เครื่องดับสนิท (Hard-Brick) หรือปลดล็อก FRP แพตช์สูง<br>2. แกะฝาหลัง ถอดขั้วสายแพร์แบตเตอรี่ออกเพื่อตัดไฟ<br>3. ใช้แหนบช็อตจุด <b>EUB Test Point (TP to GND)</b> บนเมนบอร์ด<br>4. เสียบสาย USB เข้า PC -> คอมพิวเตอร์จะตรวจพบ <code>Samsung Exynos USB Booting</code> ใน Device Manager',
                plain: '1. สำหรับกู้เครื่องดับสนิท (Hard-Brick) หรือปลดล็อก FRP แพตช์สูง\n2. แกะฝาหลัง ถอดขั้วสายแพร์แบตเตอรี่ออก\n3. ใช้แหนบช็อตจุด EUB Test Point (TP to GND) บนเมนบอร์ด\n4. เสียบสาย USB เข้า PC -> คอมพิวเตอร์จะตรวจพบ Samsung Exynos USB Booting ใน Device Manager'
            },
            '350k': {
                title: 'Samsung 350K / Test Mode (ไม่ต้องกดปุ่มเครื่อง)',
                badge: 'Auto 350K Jig',
                desc: '1. เปิดเครื่องโทรศัพท์ตามปกติ เข้าหน้าแป้นโทรออก หรือโทรฉุกเฉิน<br>2. กดรหัส: <code>*#0*#</code> หรือ <code>*#0808#</code> (เลือก DM+MODEM+ADB)<br>3. เสียบสาย USB เข้าคอมพิวเตอร์ แล้วกดปุ่ม <i>"Enter Download Mode"</i> ในโปรแกรม',
                plain: '1. เปิดเครื่องโทรศัพท์ตามปกติ เข้าหน้าแป้นโทรออก หรือโทรฉุกเฉิน\n2. กดรหัส: *#0*# หรือ *#0808# (เลือก DM+MODEM+ADB)\n3. เสียบสาย USB เข้าคอมพิวเตอร์ แล้วกดปุ่ม "Enter Download Mode" ในโปรแกรม'
            }
        }
    };

    function getBootInstruction(platform, keyOrBrand, modelOrCpu) {
        const kb = GLOBAL_BOOT_KNOWLEDGE[platform] || {};
        let item = null;

        if (platform === 'unisoc') {
            const k = (keyOrBrand || 'auto').toUpperCase();
            if (k.includes('SC7702') || k.includes('SC7701') || k.includes('SUPER')) item = kb['SC7702'];
            else if (k.includes('SC6531') || k.includes('FEATURE')) item = kb['SC6531'];
            else if (k.includes('SC9863') || k.includes('9863A')) item = kb['SC9863A'];
            else if (k.includes('9230') || k.includes('T606') || k.includes('T610') || k.includes('T612') || k.includes('T616')) item = kb['UMS9230'];
            else if (k.includes('SC9832') || k.includes('9832E')) item = kb['SC9832'];
            else if (k.includes('SC7731') || k.includes('7731E')) item = kb['SC7731'];
            else item = kb[keyOrBrand] || kb['auto'];
        } else if (platform === 'qualcomm') {
            const b = (keyOrBrand || 'auto').toLowerCase();
            const m = (modelOrCpu || '').toLowerCase();
            if (b === 'xiaomi' || m.includes('redmi') || m.includes('xiaomi') || m.includes('poco')) item = kb['xiaomi'];
            else if (b === 'oppo' || m.includes('oppo')) item = kb['oppo'];
            else if (b === 'realme' || m.includes('realme')) item = kb['realme'];
            else if (b === 'vivo' || m.includes('vivo') || m.includes('iqoo')) item = kb['vivo'];
            else if (b === 'samsung' || m.includes('samsung') || m.includes('galaxy')) item = kb['samsung'];
            else if (b === 'oneplus' || m.includes('oneplus')) item = kb['oneplus'];
            else if (b === 'lenovo' || b === 'zuk' || m.includes('lenovo') || m.includes('zuk') || m.includes('moto')) item = kb['lenovo'];
            else item = kb[b] || kb['auto'];
        } else if (platform === 'mediatek') {
            const b = (keyOrBrand || 'default').toLowerCase();
            const c = (modelOrCpu || '').toLowerCase();
            if (b === 'oppo' || c.includes('oppo')) item = kb['oppo'];
            else if (b === 'realme' || c.includes('realme')) item = kb['realme'];
            else if (b === 'vivo' || c.includes('vivo')) item = kb['vivo'];
            else if (b === 'xiaomi' || c.includes('redmi') || c.includes('poco')) item = kb['xiaomi'];
            else if (b === 'samsung' || c.includes('samsung')) item = kb['samsung'];
            else if (b.includes('infinix') || b.includes('tecno') || c.includes('infinix')) item = kb['infinix_tecno'];
            else if (b === 'huawei' || c.includes('huawei') || c.includes('honor')) item = kb['huawei'];
            else item = kb[b] || kb['default'];
        } else if (platform === 'fastboot') {
            const b = (keyOrBrand || 'all').toLowerCase();
            item = kb[b] || kb['all'];
        } else if (platform === 'samsung') {
            const b = (keyOrBrand || 'new').toLowerCase();
            item = kb[b] || kb['new'];
        }

        if (!item) {
            item = {
                title: 'วิธีเชื่อมต่อทั่วไป',
                badge: 'Standard Mode',
                desc: 'ปิดเครื่องให้ดับสนิท -> กดปุ่ม Boot Key ค้างไว้ -> เสียบสาย USB เข้าคอมพิวเตอร์',
                plain: 'ปิดเครื่องให้ดับสนิท -> กดปุ่ม Boot Key ค้างไว้ -> เสียบสาย USB เข้าคอมพิวเตอร์'
            };
        }
        return item;
    }

    function updateDynamicBootGuideUI(platform, keyOrBrand, modelOrCpu) {
        const guide = getBootInstruction(platform, keyOrBrand, modelOrCpu);
        if (platform === 'unisoc') {
            const nameEl = document.getElementById('spd-guide-target-name');
            const tagEl = document.getElementById('spd-guide-mode-tag');
            const contentEl = document.getElementById('spd-guide-content');
            if (nameEl) nameEl.textContent = guide.title;
            if (tagEl) tagEl.textContent = guide.badge;
            if (contentEl) contentEl.innerHTML = `<b><i class="fas fa-plug"></i> วิธีเชื่อมต่อเครื่อง:</b> ${guide.desc.replace(/\n/g, '<br>')}`;
        } else if (platform === 'qualcomm') {
            const nameEl = document.getElementById('qcom-guide-target-name');
            const tagEl = document.getElementById('qcom-guide-mode-tag');
            const contentEl = document.getElementById('qcom-guide-content');
            if (nameEl) nameEl.textContent = guide.title;
            if (tagEl) tagEl.textContent = guide.badge;
            if (contentEl) contentEl.innerHTML = `<b><i class="fas fa-plug"></i> วิธีเข้า EDL 9008:</b><br>${guide.desc.replace(/\n/g, '<br>')}`;
        } else if (platform === 'mediatek') {
            const nameEl = document.getElementById('mtk-guide-target-name');
            const tagEl = document.getElementById('mtk-guide-mode-tag');
            const contentEl = document.getElementById('mtk-guide-content');
            if (nameEl) nameEl.textContent = guide.title;
            if (tagEl) tagEl.textContent = guide.badge;
            if (contentEl) contentEl.innerHTML = `<b><i class="fas fa-plug"></i> วิธีเข้า BROM / Preloader:</b><br>${guide.desc.replace(/\n/g, '<br>')}`;
        } else if (platform === 'fastboot') {
            const nameEl = document.getElementById('fb-guide-target-name');
            const contentEl = document.getElementById('fb-guide-content');
            if (nameEl) nameEl.textContent = guide.title;
            if (contentEl) contentEl.innerHTML = `<b><i class="fas fa-bolt"></i> วิธีเข้า Fastboot Mode:</b><br>${guide.desc.replace(/\n/g, '<br>')}`;
        }
    }

    // ==========================================
    // FLASHER SUITE DATABASE INITIALIZATION
    // Categorized by Brand, Model, & Chipset (CS-Tool Suite)
    // ==========================================
    async function initFlasherSuiteDatabase() {
        if (!window.api || !window.api.getFlasherDatabase) return;
        try {
            const db = await window.api.getFlasherDatabase();
            if (!db) return;

            // Merge dynamic boot knowledge from database if present
            if (db.boot_instructions) {
                for (const plat in db.boot_instructions) {
                    if (!GLOBAL_BOOT_KNOWLEDGE[plat]) GLOBAL_BOOT_KNOWLEDGE[plat] = {};
                    for (const k in db.boot_instructions[plat]) {
                        const it = db.boot_instructions[plat][k];
                        GLOBAL_BOOT_KNOWLEDGE[plat][k] = {
                            title: it.title,
                            badge: it.badge,
                            desc: it.desc.replace(/\n/g, '<br>'),
                            plain: it.desc
                        };
                    }
                }
            }

            // --- 1. Qualcomm Brand & Model Cascading Selectors ---
            const qcomBrandSelect = document.getElementById('qcom-brand-select');
            const qcomModelSelect = document.getElementById('qcom-model-select');
            const qcomBadge = document.getElementById('qcom-selected-prog-badge');

            if (qcomBrandSelect && qcomModelSelect && db.qualcomm) {
                qcomBrandSelect.innerHTML = '';
                db.qualcomm.brands.forEach(b => {
                    const opt = document.createElement('option');
                    opt.value = b.id;
                    opt.textContent = b.name;
                    qcomBrandSelect.appendChild(opt);
                });

                function updateQcomModels(brandId) {
                    qcomModelSelect.innerHTML = '';
                    const models = (db.qualcomm.models && db.qualcomm.models[brandId]) || [];
                    models.forEach(m => {
                        const opt = document.createElement('option');
                        opt.value = m.fullPath || '';
                        opt.textContent = m.name;
                        qcomModelSelect.appendChild(opt);
                    });

                    const selectedPath = qcomModelSelect.value;
                    qcomSelectedProgrammer = selectedPath || null;
                    const selText = qcomModelSelect.options[qcomModelSelect.selectedIndex]?.text || '';
                    if (qcomBadge) {
                        if (selectedPath) {
                            qcomBadge.textContent = `✓ ${selText}`;
                        } else {
                            qcomBadge.textContent = '⚡ ตรวจจับชิปอัตโนมัติ';
                        }
                    }
                    updateDynamicBootGuideUI('qualcomm', brandId, selText);
                }

                qcomBrandSelect.addEventListener('change', () => {
                    updateQcomModels(qcomBrandSelect.value);
                });

                qcomModelSelect.addEventListener('change', () => {
                    const selectedPath = qcomModelSelect.value;
                    qcomSelectedProgrammer = selectedPath || null;
                    const selText = qcomModelSelect.options[qcomModelSelect.selectedIndex]?.text || '';
                    if (qcomBadge) {
                        if (selectedPath) {
                            qcomBadge.textContent = `✓ ${selText}`;
                        } else {
                            qcomBadge.textContent = '⚡ ตรวจจับชิปอัตโนมัติ';
                        }
                    }
                    updateDynamicBootGuideUI('qualcomm', qcomBrandSelect.value, selText);
                });

                // Initialize with Auto
                updateQcomModels('auto');
            }

            // External Browse button for Qualcomm Programmer
            const btnQcomBrowseProg = document.getElementById('btn-qcom-browse-prog');
            if (btnQcomBrowseProg) {
                btnQcomBrowseProg.addEventListener('click', async () => {
                    const filePath = await window.api.browseProgrammerFile();
                    if (filePath) {
                        qcomSelectedProgrammer = filePath;
                        const baseName = filePath.split(/[/\\]/).pop();
                        if (qcomBadge) {
                            qcomBadge.textContent = `📁 กำหนดเอง: ${baseName}`;
                        }
                        if (qcomModelSelect) {
                            let customOpt = document.getElementById('qcom-custom-loader-opt');
                            if (!customOpt) {
                                customOpt = document.createElement('option');
                                customOpt.id = 'qcom-custom-loader-opt';
                                qcomModelSelect.insertBefore(customOpt, qcomModelSelect.firstChild);
                            }
                            customOpt.value = filePath;
                            customOpt.textContent = `📁 กำหนดเอง: ${baseName}`;
                            customOpt.selected = true;
                        }
                        updateDynamicBootGuideUI('qualcomm', qcomBrandSelect ? qcomBrandSelect.value : 'auto', baseName);
                    }
                });
            }

            // --- 2. MediaTek Brand & Model Cascading Selectors ---
            const mtkBrandSelect = document.getElementById('mtk-brand-select');
            const mtkModelSelect = document.getElementById('mtk-model-select');
            const mtkCpuSelect = document.getElementById('mtk-cpu-select');
            const mtkBadge = document.getElementById('mtk-selected-status-badge');
            const chkMtkPreloader = document.getElementById('chk-custom-preloader');
            const mtkPreloaderPathLabel = document.getElementById('mtk-preloader-file-path');
            const btnMtkBrowsePreloader = document.getElementById('btn-mtk-browse-preloader');
            const chkMtkDa = document.getElementById('chk-custom-da');
            const mtkDaPathLabel = document.getElementById('mtk-da-file-path');
            const btnMtkBrowseDa = document.getElementById('btn-mtk-browse-da');
            const chkMtkAuth = document.getElementById('chk-custom-auth');
            const mtkAuthPathLabel = document.getElementById('mtk-auth-file-path');
            const btnMtkBrowseAuth = document.getElementById('btn-mtk-browse-auth');
            const btnMtkCloudFetch = document.getElementById('btn-mtk-cloud-fetch');

            // Load cloud database entries cache
            let cloudLoadersCache = [];
            if (window.api && window.api.fetchCloudDb) {
                window.api.fetchCloudDb().then(data => {
                    cloudLoadersCache = Array.isArray(data) ? data : [];
                }).catch(() => {});
            }

            if (mtkBrandSelect && mtkModelSelect && db.mediatek) {
                // Populate Brands
                mtkBrandSelect.innerHTML = '';
                if (db.mediatek.brands) {
                    db.mediatek.brands.forEach(b => {
                        const opt = document.createElement('option');
                        opt.value = b.id;
                        opt.textContent = b.name;
                        mtkBrandSelect.appendChild(opt);
                    });
                }

                function updateMtkModels(brandId) {
                    mtkModelSelect.innerHTML = '';
                    const brandModels = (db.mediatek.models && db.mediatek.models[brandId]) || [];

                    if (brandId === 'auto') {
                        const defaultOpt = document.createElement('option');
                        defaultOpt.value = 'auto';
                        defaultOpt.textContent = '⚡ ตรวจจับอัตโนมัติ (Auto)';
                        defaultOpt.dataset.modelJson = JSON.stringify({
                            name: 'Auto-Detect MTK Device',
                            mode: 'brom',
                            da: 'MTK_DA_V6.bin',
                            preloader: '',
                            auth: 'auto_bypass'
                        });
                        mtkModelSelect.appendChild(defaultOpt);

                        // Also append popular models for quick pick
                        const popGroup = document.createElement('optgroup');
                        popGroup.label = '— รุ่นยอดนิยม —';
                        const popularList = [
                            { name: 'OPPO A16 (CPH2269 - Helio G35)', mode: 'brom', da: 'MTK_DA_V6.bin', preloader: '0766_preloader_oppo6765_19451_94B0482E99.bin', auth: 'auto_bypass' },
                            { name: 'OPPO A15 / A15s (CPH2185/2179)', mode: 'brom', da: 'MTK_DA_V6.bin', preloader: 'A15s_preloader_oppo6765.bin', auth: 'auto_bypass' },
                            { name: 'Vivo Y12 / Y15 (PD1901 - MT6762)', mode: 'brom', da: 'MTK_DA_V6.bin', preloader: 'preloader_k62v1_64_bsp_viv1901.bin', auth: 'auto_bypass' },
                            { name: 'Vivo Y15s (V2120 - MT6765)', mode: 'brom', da: 'MTK_DA_V6.bin', preloader: 'preloader_k62v1_64_bsp_vivo_y15.bin', auth: 'auto_bypass' },
                            { name: 'Redmi 9 / 9A / 9C (MT6769/MT6765)', mode: 'brom', da: 'MTK_DA_V6.bin', preloader: '0766_preloader_k65v1_64_bsp_titan_rat_DD91307C1E.bin', auth: 'auto_bypass' },
                            { name: 'Redmi Note 8 Pro (Begonia - MT6785)', mode: 'brom', da: 'MTK_DA_V6.bin', preloader: '0813_preloader_begonia_1547BE956A.bin', auth: 'auto_bypass' },
                            { name: 'Samsung Galaxy A03s (SM-A037F - MT6765)', mode: 'brom', da: 'MTK_DA_V6.bin', preloader: '0766_preloader_k65v1_64_bsp_titan_rat_DD91307C1E.bin', auth: 'auto_bypass' },
                            { name: 'Samsung Galaxy A12 (SM-A125F - MT6765)', mode: 'brom', da: 'MTK_DA_V6.bin', preloader: '0766_preloader_k65v1_64_bsp_titan_rat_DD91307C1E.bin', auth: 'auto_bypass' }
                        ];
                        popularList.forEach(m => {
                            const opt = document.createElement('option');
                            opt.value = m.name;
                            opt.textContent = m.name;
                            opt.dataset.modelJson = JSON.stringify(m);
                            popGroup.appendChild(opt);
                        });
                        mtkModelSelect.appendChild(popGroup);
                    } else {
                        const defaultOpt = document.createElement('option');
                        defaultOpt.value = '';
                        defaultOpt.textContent = `⚡ เลือกรุ่น ${mtkBrandSelect.options[mtkBrandSelect.selectedIndex]?.text || ''}`;
                        mtkModelSelect.appendChild(defaultOpt);

                        brandModels.forEach(m => {
                            const opt = document.createElement('option');
                            opt.value = m.name;
                            opt.textContent = m.name;
                            opt.dataset.modelJson = JSON.stringify(m);
                            mtkModelSelect.appendChild(opt);
                        });
                    }

                    onMtkModelSelectionChanged();
                }

                function onMtkModelSelectionChanged() {
                    const selectedOpt = mtkModelSelect.options[mtkModelSelect.selectedIndex];
                    let modelData = null;
                    if (selectedOpt && selectedOpt.dataset.modelJson) {
                        try {
                            modelData = JSON.parse(selectedOpt.dataset.modelJson);
                        } catch (e) {}
                    }

                    if (!modelData || mtkModelSelect.value === '' || mtkModelSelect.value === 'auto') {
                        // Reset to auto default
                        if (mtkBadge) {
                            mtkBadge.textContent = '⚡ ตรวจจับชิปอัตโนมัติ (830+ Preloaders)';
                            mtkBadge.style.color = '#4ade80';
                        }
                        mtkMode = 'brom';
                        const bromRadio = document.querySelector('input[name="mtk-mode"][value="brom"]');
                        if (bromRadio) bromRadio.checked = true;

                        // Default DA
                        if (chkMtkDa) chkMtkDa.checked = true;
                        if (mtkDaPathLabel) mtkDaPathLabel.textContent = 'MTK_AllInOne_DA.bin';
                        mtkSelectedDa = null;

                        // Reset preloader
                        if (chkMtkPreloader) chkMtkPreloader.checked = false;
                        if (mtkPreloaderPathLabel) mtkPreloaderPathLabel.textContent = 'Auto / Not Selected';
                        mtkSelectedPreloader = null;

                        // Reset auth
                        if (chkMtkAuth) chkMtkAuth.checked = false;
                        if (mtkAuthPathLabel) mtkAuthPathLabel.textContent = 'Auto Bypass / Not Selected';
                        mtkSelectedAuth = null;

                        updateDynamicBootGuideUI('mediatek', mtkBrandSelect.value, 'Auto-Detect');
                        return;
                    }

                    // 1. Set Mode (BROM vs Preloader)
                    const targetMode = modelData.mode || 'brom';
                    mtkMode = targetMode;
                    const modeRadio = document.querySelector(`input[name="mtk-mode"][value="${targetMode}"]`);
                    if (modeRadio) {
                        modeRadio.checked = true;
                        modeRadio.dispatchEvent(new Event('change'));
                    }

                    // 2. Set DA File
                    if (modelData.da) {
                        mtkSelectedDa = modelData.daPath || modelData.da;
                        if (chkMtkDa) chkMtkDa.checked = true;
                        if (mtkDaPathLabel) {
                            mtkDaPathLabel.textContent = `✓ ${modelData.da}`;
                            mtkDaPathLabel.title = mtkSelectedDa;
                        }
                    }

                    // 3. Set Preloader File (Auto-select / Background Cloud Fetch)
                    if (modelData.preloader) {
                        if (modelData.hasPreloader && modelData.preloaderPath) {
                            // File exists locally in bundled 838 preloader library
                            mtkSelectedPreloader = modelData.preloaderPath;
                            if (chkMtkPreloader) chkMtkPreloader.checked = true;
                            if (btnMtkBrowsePreloader) btnMtkBrowsePreloader.disabled = false;
                            if (mtkPreloaderPathLabel) {
                                mtkPreloaderPathLabel.textContent = `✓ ${modelData.preloader}`;
                                mtkPreloaderPathLabel.title = mtkSelectedPreloader;
                                mtkPreloaderPathLabel.style.color = '#4ade80';
                            }
                        } else {
                            // File not locally on disk: AUTO-FETCH FROM CLOUD / GITHUB IN BACKGROUND!
                            if (chkMtkPreloader) chkMtkPreloader.checked = true;
                            if (btnMtkBrowsePreloader) btnMtkBrowsePreloader.disabled = false;
                            
                            const cloudMatch = cloudLoadersCache.find(c => 
                                (c.preloader_name && c.preloader_name === modelData.preloader) ||
                                (c.model && modelData.name.includes(c.model))
                            );
                            
                            const dlUrl = (cloudMatch && cloudMatch.preloader_url)
                                ? cloudMatch.preloader_url
                                : `https://raw.githubusercontent.com/bkerler/mtkclient/main/mtkclient/Loader/Preloader/${modelData.preloader}`;
                            
                            if (mtkPreloaderPathLabel) {
                                mtkPreloaderPathLabel.innerHTML = `<i class="fas fa-spinner fa-spin"></i> กำลังโหลด ${modelData.preloader} จากเน็ตอัตโนมัติ...`;
                                mtkPreloaderPathLabel.style.color = '#38bdf8';
                            }
                            
                            if (window.api && window.api.downloadCloudFile) {
                                window.api.downloadCloudFile(dlUrl, modelData.preloader)
                                    .then(downloadedPath => {
                                        if (downloadedPath) {
                                            mtkSelectedPreloader = downloadedPath;
                                            if (chkMtkPreloader) chkMtkPreloader.checked = true;
                                            if (mtkPreloaderPathLabel) {
                                                mtkPreloaderPathLabel.textContent = `✓ (Online) ${modelData.preloader}`;
                                                mtkPreloaderPathLabel.title = downloadedPath;
                                                mtkPreloaderPathLabel.style.color = '#4ade80';
                                            }
                                            logToConsole(`\n[MTK Auto-Resolve] ✓ ดาวน์โหลด Preloader ตรงรุ่นสำเร็จ: ${modelData.preloader}\n`);
                                        }
                                    })
                                    .catch(err => {
                                        console.warn('Auto cloud fetch failed:', err);
                                        if (mtkPreloaderPathLabel) {
                                            mtkPreloaderPathLabel.textContent = `✓ พร้อมแฟลช: ${modelData.preloader}`;
                                            mtkPreloaderPathLabel.style.color = '#fbbf24';
                                        }
                                    });
                            }
                        }
                    } else {
                        // BROM Mode: Pure BootROM Exploit without preloader requirement
                        mtkSelectedPreloader = null;
                        if (chkMtkPreloader) chkMtkPreloader.checked = false;
                        if (mtkPreloaderPathLabel) {
                            mtkPreloaderPathLabel.textContent = '⚡ BROM Auto-Exploit';
                            mtkPreloaderPathLabel.style.color = '#38bdf8';
                        }
                    }

                    // 4. Set SLA / DAA Auth File (Always Auto-Bypass if not specified)
                    if (modelData.auth === 'auto_bypass' || !modelData.auth) {
                        mtkSelectedAuth = 'auto_bypass';
                        if (chkMtkAuth) chkMtkAuth.checked = true;
                        if (mtkAuthPathLabel) {
                            mtkAuthPathLabel.textContent = '⚡ SLA/DAA Auto-Bypass';
                            mtkAuthPathLabel.title = 'MediaTek Hardware SLA/DAA Security Exploit Bypass Enabled';
                            mtkAuthPathLabel.style.color = '#38bdf8';
                        }
                    } else {
                        mtkSelectedAuth = modelData.auth;
                        if (chkMtkAuth) chkMtkAuth.checked = true;
                        if (mtkAuthPathLabel) {
                            mtkAuthPathLabel.textContent = `✓ ${modelData.auth}`;
                            mtkAuthPathLabel.title = modelData.auth;
                            mtkAuthPathLabel.style.color = '#38bdf8';
                        }
                    }

                    // 5. Update Badge & Guide
                    if (mtkBadge) {
                        const shortName = modelData.name.split(' (')[0];
                        mtkBadge.textContent = `✓ ${shortName} (${targetMode.toUpperCase()})`;
                        mtkBadge.style.color = targetMode === 'brom' ? '#38bdf8' : '#fbbf24';
                    }

                    updateDynamicBootGuideUI('mediatek', mtkBrandSelect.value, modelData.name);
                }

                mtkBrandSelect.addEventListener('change', () => {
                    updateMtkModels(mtkBrandSelect.value);
                });

                mtkModelSelect.addEventListener('change', () => {
                    onMtkModelSelectionChanged();
                });

                // Initial populate
                updateMtkModels('auto');
            }

            // Cloud Loaders Modal & Fetch Handler
            const modalCloudLoaders = document.getElementById('modal-cloud-loaders');
            const tbodyCloudLoaders = document.getElementById('cloud-loaders-tbody');
            const inputCloudSearch = document.getElementById('input-cloud-search');
            const btnCloseCloudLoaders = document.getElementById('btn-close-cloud-loaders');

            function renderCloudLoadersUI(filterText = '') {
                if (!tbodyCloudLoaders) return;
                tbodyCloudLoaders.innerHTML = '';
                const query = filterText.toLowerCase();

                const filtered = cloudLoadersCache.filter(item => {
                    if (!query) return true;
                    return (item.brand && item.brand.toLowerCase().includes(query)) ||
                           (item.model && item.model.toLowerCase().includes(query)) ||
                           (item.cpu && item.cpu.toLowerCase().includes(query)) ||
                           (item.preloader_name && item.preloader_name.toLowerCase().includes(query));
                });

                if (filtered.length === 0) {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `<td colspan="4" style="text-align: center; padding: 20px; color: #94a3b8;">
                        <i class="fas fa-search" style="margin-right: 6px;"></i> ไม่พบไฟล์ที่ตรงกับคำค้นหา "${filterText}"
                    </td>`;
                    tbodyCloudLoaders.appendChild(tr);
                    return;
                }

                filtered.forEach(item => {
                    const tr = document.createElement('tr');
                    tr.style.borderBottom = '1px solid rgba(255,255,255,0.06)';
                    tr.innerHTML = `
                        <td style="padding: 10px; font-weight: 700; color: #38bdf8;">${item.brand}</td>
                        <td style="padding: 10px; color: #f8fafc; font-weight: 600;">${item.model}</td>
                        <td style="padding: 10px; color: #cbd5e1; font-size: 11px;">${item.cpu}</td>
                        <td style="padding: 10px; text-align: center;">
                            <button class="action-btn primary-btn btn-dl-cloud-row" style="padding: 5px 12px; font-size: 11px; font-weight: 700; border-radius: 5px; background: linear-gradient(135deg, #0284c7, #0369a1); cursor: pointer;">
                                <i class="fas fa-download"></i> โหลด & ใช้งาน
                            </button>
                        </td>
                    `;

                    const btnDl = tr.querySelector('.btn-dl-cloud-row');
                    if (btnDl) {
                        btnDl.addEventListener('click', async () => {
                            btnDl.disabled = true;
                            btnDl.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังโหลด...';
                            try {
                                logToConsole(`\n[MTK Cloud] เริ่มดาวน์โหลด Preloader: ${item.preloader_name} จาก GitHub / Cloud...\n`);
                                const downloadedPath = await window.api.downloadCloudFile(item.preloader_url, item.preloader_name);
                                if (downloadedPath) {
                                    mtkSelectedPreloader = downloadedPath;
                                    if (chkMtkPreloader) chkMtkPreloader.checked = true;
                                    if (btnMtkBrowsePreloader) btnMtkBrowsePreloader.disabled = false;
                                    if (mtkPreloaderPathLabel) {
                                        mtkPreloaderPathLabel.textContent = `✓ (Cloud) ${item.preloader_name}`;
                                        mtkPreloaderPathLabel.title = downloadedPath;
                                        mtkPreloaderPathLabel.style.color = '#4ade80';
                                    }

                                    // Auto-apply mode and DA
                                    if (item.mode) {
                                        mtkMode = item.mode;
                                        const modeRadio = document.querySelector(`input[name="mtk-mode"][value="${item.mode}"]`);
                                        if (modeRadio) modeRadio.checked = true;
                                    }
                                    if (item.da_name) {
                                        if (chkMtkDa) chkMtkDa.checked = true;
                                        if (mtkDaPathLabel) mtkDaPathLabel.textContent = `✓ ${item.da_name}`;
                                    }
                                    if (mtkBadge) {
                                        mtkBadge.textContent = `✓ ${item.model} (${(item.mode || 'BROM').toUpperCase()})`;
                                        mtkBadge.style.color = '#4ade80';
                                    }

                                    logToConsole(`[MTK Cloud] ดาวน์โหลดเสร็จสมบูรณ์! บันทึกที่: ${downloadedPath}\n`);
                                    if (modalCloudLoaders) modalCloudLoaders.classList.add('hidden');
                                    alert(`✅ ติดตั้ง Cloud Loader สำเร็จ!\nรุ่น: ${item.model}\nไฟล์: ${item.preloader_name}\nพร้อมสำหรับแฟลชแล้ว`);
                                }
                            } catch (err) {
                                logToConsole(`\n[ERROR] MTK Cloud Download Failed: ${err.message}\n`);
                                alert(`เกิดข้อผิดพลาดในการดาวน์โหลด: ${err.message}`);
                            } finally {
                                btnDl.disabled = false;
                                btnDl.innerHTML = '<i class="fas fa-download"></i> โหลด & ใช้งาน';
                            }
                        });
                    }

                    tbodyCloudLoaders.appendChild(tr);
                });
            }

            if (inputCloudSearch) {
                inputCloudSearch.addEventListener('input', (e) => {
                    renderCloudLoadersUI(e.target.value.trim());
                });
            }

            if (btnCloseCloudLoaders && modalCloudLoaders) {
                btnCloseCloudLoaders.addEventListener('click', () => {
                    modalCloudLoaders.classList.add('hidden');
                });
            }

            if (btnMtkCloudFetch) {
                btnMtkCloudFetch.addEventListener('click', async () => {
                    btnMtkCloudFetch.disabled = true;
                    const origHtml = btnMtkCloudFetch.innerHTML;
                    btnMtkCloudFetch.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Cloud...';

                    try {
                        const cloudDb = await window.api.fetchCloudDb();
                        cloudLoadersCache = Array.isArray(cloudDb) ? cloudDb : [];

                        const selectedOpt = mtkModelSelect ? mtkModelSelect.options[mtkModelSelect.selectedIndex] : null;
                        let modelData = null;
                        if (selectedOpt && selectedOpt.dataset.modelJson) {
                            try { modelData = JSON.parse(selectedOpt.dataset.modelJson); } catch (e) {}
                        }

                        // Try finding exact match for selected model first
                        let directMatch = null;
                        if (modelData) {
                            directMatch = cloudLoadersCache.find(c => 
                                (modelData.preloader && c.preloader_name === modelData.preloader) ||
                                (c.model && modelData.name.includes(c.model))
                            );
                        }

                        if (directMatch && directMatch.preloader_url) {
                            // Direct 1-click download of selected model's preloader
                            logToConsole(`\n[MTK Cloud] ตรวจพบไฟล์บน Cloud สำหรับ ${directMatch.model}: ${directMatch.preloader_name}\nกำลังดาวน์โหลดจาก GitHub / Cloud...\n`);
                            const downloadedPath = await window.api.downloadCloudFile(directMatch.preloader_url, directMatch.preloader_name);
                            if (downloadedPath) {
                                mtkSelectedPreloader = downloadedPath;
                                if (chkMtkPreloader) chkMtkPreloader.checked = true;
                                if (btnMtkBrowsePreloader) btnMtkBrowsePreloader.disabled = false;
                                if (mtkPreloaderPathLabel) {
                                    mtkPreloaderPathLabel.textContent = `✓ (Cloud) ${directMatch.preloader_name}`;
                                    mtkPreloaderPathLabel.title = downloadedPath;
                                    mtkPreloaderPathLabel.style.color = '#4ade80';
                                }
                                logToConsole(`[MTK Cloud] ดาวน์โหลดสำเร็จ! บันทึกที่: ${downloadedPath}\n`);
                                alert(`✅ ดาวน์โหลด Cloud Preloader สำเร็จ!\nรุ่น: ${directMatch.model}\nไฟล์: ${directMatch.preloader_name}\nพร้อมสำหรับแฟลชแล้ว`);
                            }
                        } else {
                            // Open dedicated interactive Cloud Database Modal
                            if (modalCloudLoaders) {
                                if (inputCloudSearch) {
                                    inputCloudSearch.value = modelData ? (modelData.name.split(' (')[0] || '') : '';
                                }
                                renderCloudLoadersUI(inputCloudSearch ? inputCloudSearch.value.trim() : '');
                                modalCloudLoaders.classList.remove('hidden');
                            }
                        }
                    } catch (err) {
                        logToConsole(`\n[ERROR] MTK Cloud Fetch Failed: ${err.message}\n`);
                        alert(`เกิดข้อผิดพลาดในการดึงข้อมูล Cloud: ${err.message}`);
                    } finally {
                        btnMtkCloudFetch.disabled = false;
                        btnMtkCloudFetch.innerHTML = origHtml;
                    }
                });
            }

            // --- 3. Unisoc / Spreadtrum Boots Selector ---
            const spdBootsSelect = document.getElementById('spd-boots-select');
            const spdBootStatus = document.getElementById('spd-boot-status');
            if (spdBootsSelect && db.unisoc && db.unisoc.boots) {
                spdBootsSelect.innerHTML = '';
                db.unisoc.boots.forEach(b => {
                    const opt = document.createElement('option');
                    opt.value = b.id;
                    opt.textContent = b.name;
                    opt.style.backgroundColor = '#0f172a';
                    opt.style.color = '#f8fafc';
                    spdBootsSelect.appendChild(opt);
                });

                spdBootsSelect.addEventListener('change', () => {
                    const selId = spdBootsSelect.value;
                    if (spdBootStatus) {
                        if (selId === 'auto') {
                            spdBootStatus.textContent = '92 FDL';
                        } else {
                            const selText = spdBootsSelect.options[spdBootsSelect.selectedIndex]?.text || selId;
                            spdBootStatus.textContent = `✓ ${selText}`;
                            spdBootStatus.style.color = '#4ade80';
                        }
                    }
                    updateDynamicBootGuideUI('unisoc', selId);
                });
            }

            // --- 4. Fastboot Brand Quick Filter Chips ---
            document.querySelectorAll('.fb-brand-chip').forEach(chip => {
                chip.addEventListener('click', () => {
                    document.querySelectorAll('.fb-brand-chip').forEach(c => {
                        c.classList.remove('active');
                        c.style.background = 'rgba(255,255,255,0.06)';
                        c.style.color = '#94a3b8';
                        c.style.borderColor = 'rgba(255,255,255,0.1)';
                    });
                    chip.classList.add('active');
                    chip.style.background = 'rgba(56,189,248,0.2)';
                    chip.style.color = '#38bdf8';
                    chip.style.borderColor = 'rgba(56,189,248,0.4)';
                    updateDynamicBootGuideUI('fastboot', chip.dataset.brand);
                });
            });

            // Initialize all guide cards on startup
            updateDynamicBootGuideUI('qualcomm', 'auto');
            updateDynamicBootGuideUI('mediatek', 'default');
            updateDynamicBootGuideUI('unisoc', 'auto');
            updateDynamicBootGuideUI('fastboot', 'all');

        } catch (err) {
            console.warn('Failed to load flasher database:', err);
        }
    }

    initFlasherSuiteDatabase();


// Custom Dropdown Logic (ROOT section)
(function initCustomDropdowns() {
    function setupDropdown(triggerId, dropdownId, hiddenId) {
        const trigger = document.getElementById(triggerId);
        const dropdown = document.getElementById(dropdownId);
        const hidden = document.getElementById(hiddenId);
        if (!trigger || !dropdown || !hidden) return;

        trigger.addEventListener('click', (e) => {
            e.stopPropagation();
            const isOpen = dropdown.style.display !== 'none';
            // Close all dropdowns first
            document.querySelectorAll('.custom-select-dropdown').forEach(d => d.style.display = 'none');
            dropdown.style.display = isOpen ? 'none' : 'block';
        });

        dropdown.querySelectorAll('.csd-option').forEach(opt => {
            opt.addEventListener('click', () => {
                const val = opt.dataset.value;
                const label = opt.textContent.trim();
                trigger.childNodes[0].textContent = label + ' ';
                trigger.dataset.value = val;
                hidden.value = val;
                dropdown.style.display = 'none';
                // Highlight selected
                dropdown.querySelectorAll('.csd-option').forEach(o => o.classList.remove('selected'));
                opt.classList.add('selected');
            });
        });
    }

    setupDropdown('root-brand-trigger', 'root-brand-dropdown', 'root-brand-select');
    setupDropdown('root-method-trigger', 'root-method-dropdown', 'root-method-select');

    // Close dropdowns when clicking outside
    document.addEventListener('click', () => {
        document.querySelectorAll('.custom-select-dropdown').forEach(d => d.style.display = 'none');
    });
})();


// ============================================================
// ROOT TOOL LOGIC
// ============================================================
(function() {

    // --- helpers ---
    function rootLog(msg, color) {
        if (currentLang === 'th') {
            const thLogs = {
                '> Scanning ADB devices...': '> กำลังค้นหาอุปกรณ์ ADB...',
                'No device found. Enable USB debugging.': 'ไม่พบอุปกรณ์ กรุณาเปิดโหมดแก้จุดบกพร่อง USB',
                '⚡ Starting One-Click ROOT process...': '⚡ เริ่มกระบวนการรูท (One-Click ROOT)...',
                '✅ ADB connected': '✅ เชื่อมต่อ ADB สำเร็จ',
                '⚠️ Bootloader is LOCKED. Attempting Auto-Unlock...': '⚠️ บูตโหลดเดอร์ล็อคอยู่ กำลังพยายามปลดล็อคอัตโนมัติ...',
                '⚠️ Samsung devices cannot be unlocked automatically via Fastboot.': '⚠️ อุปกรณ์ Samsung ไม่สามารถปลดล็อคอัตโนมัติผ่าน Fastboot ได้',
                'Please power off, hold Vol UP + Vol DOWN, plug in USB, and long-press Vol UP to unlock.': 'กรุณาปิดเครื่อง กดปุ่มเพิ่มเสียง+ลดเสียงค้างไว้ แล้วเสียบสาย USB จากนั้นกดปุ่มเพิ่มเสียงค้างเพื่อปลดล็อค',
                '> Sending unlock command...': '> กำลังส่งคำสั่งปลดล็อค...',
                '❌ Bootloader unlock cancelled by user.': '❌ ยกเลิกการปลดล็อคบูตโหลดเดอร์โดยผู้ใช้',
                '> Waiting for device to boot up and reconnect to ADB...': '> กำลังรอเครื่องเปิดและเชื่อมต่อ ADB กลับมาอีกครั้ง...',
                '❌ Device did not reconnect to ADB after unlock.': '❌ เครื่องไม่เชื่อมต่อ ADB กลับมาหลังจากปลดล็อค',
                '✅ Bootloader Unlocked & Device Reconnected': '✅ ปลดล็อคบูตโหลดเดอร์และเชื่อมต่อกลับสำเร็จ',
                '✅ Bootloader: Already Unlocked': '✅ บูตโหลดเดอร์: ปลดล็อคอยู่แล้ว',
                '✅ Magisk pushed to /data/local/tmp/': '✅ ส่งไฟล์ Magisk ไปที่ /data/local/tmp/ สำเร็จ',
                '   Make sure Magisk.apk is in bin\\magisk\\ folder': '   ตรวจสอบให้แน่ใจว่ามีไฟล์ Magisk.apk ในโฟลเดอร์ bin\\magisk\\',
                '✅ boot.img pulled successfully': '✅ ดึงไฟล์ boot.img สำเร็จ',
                '   Device may not be rooted yet - manual step needed': '   เครื่องอาจจะยังไม่รูท - ต้องทำบางขั้นตอนด้วยตนเอง',
                '✅ boot.img patched': '✅ แพตช์ไฟล์ boot.img สำเร็จ',
                '⚠️ Patching via device skipped - using local magiskboot': '⚠️ ข้ามการแพตช์ผ่านมือถือ - ใช้ magiskboot ในคอมแทน',
                '✅ Patched boot flashed!': '✅ แฟลชไฟล์ Boot ที่แพตช์แล้วสำเร็จ!',
                '🎉 Device successfully ROOTED with Magisk!': '🎉 รูทเครื่องด้วย Magisk สำเร็จแล้ว!',
                '   Open Magisk app on your device to verify.': '   เปิดแอป Magisk ในมือถือเพื่อตรวจสอบความเรียบร้อย',
                'Device rebooting - check Magisk app to verify root.': 'เครื่องกำลังรีบูต - ตรวจสอบแอป Magisk เพื่อยืนยันการรูท'
            };
            
            if (msg.startsWith('📱 Device:')) msg = msg.replace('📱 Device:', '📱 อุปกรณ์:');
            else if (msg.startsWith('Error:')) msg = msg.replace('Error:', '❌ ข้อผิดพลาด:');
            else if (msg.startsWith('❌ Error:')) msg = msg.replace('❌ Error:', '❌ ข้อผิดพลาด:');
            else if (msg.startsWith('⚠️ Could not verify bootloader state:')) msg = msg.replace('⚠️ Could not verify bootloader state:', '⚠️ ไม่สามารถตรวจสอบสถานะบูตโหลดเดอร์ได้:');
            else if (thLogs[msg]) msg = thLogs[msg];
            
            // Also handle any string with emoji already mapped if they were missing emoji in mapping
            let cleanMsg = msg;
            // The logs in code use emojis directly like '✅ ADB connected' so the mapping above has them.
        }
        
        const log = document.getElementById('root-log');
        if (!log) return;
        const d = document.createElement('div');
        d.style.cssText = `color:${color || '#ccc'};margin-bottom:2px;`;
        d.textContent = msg;
        log.appendChild(d);
        log.scrollTop = log.scrollHeight;
    }

    function setProgress(pct, stepLabel) {
        const bar = document.getElementById('root-progress-bar');
        const pctEl = document.getElementById('root-progress-pct');
        const stepEl = document.getElementById('root-step-label');
        if (bar) bar.style.width = pct + '%';
        if (pctEl) pctEl.textContent = pct + '%';
        if (stepEl && stepLabel) stepEl.textContent = stepLabel;
    }

    function setStep(num, status) {
        // status: 'done'|'active'|'error'
        const el = document.querySelector(`.root-step[data-step="${num}"]`);
        if (!el) return;
        const icons = { done: '✅', active: '🔄', error: '❌', pending: '⬜' };
        el.querySelector('.step-icon').textContent = icons[status] || '⬜';
        el.style.color = { done: '#69f0ae', active: '#fff', error: '#ff5252', pending: '#777' }[status] || '#777';
        el.style.background = { done: 'rgba(105,240,174,0.08)', active: 'rgba(255,255,255,0.08)', error: 'rgba(255,82,82,0.08)' }[status] || 'rgba(255,255,255,0.03)';
    }

    function setBadge(text, color) {
        const b = document.getElementById('root-status-badge');
        if (!b) return;
        b.textContent = text;
        b.style.background = color || 'rgba(255,255,255,0.1)';
        b.style.color = '#fff';
    }

    function resetSteps() {
        for (let i = 1; i <= 7; i++) setStep(i, 'pending');
        setProgress(0, 'Waiting...');
        setBadge('Idle', 'rgba(255,255,255,0.1)');
        const log = document.getElementById('root-log');
        if (log) log.innerHTML = '';
    }

    // --- Scan Device ---
    const scanBtn = document.getElementById('btn-root-scan');
    if (scanBtn) {
        scanBtn.addEventListener('click', async () => {
            const label = document.getElementById('root-device-label');
            const icon = document.getElementById('root-device-icon');
            if (label) label.textContent = 'Scanning...';
            if (icon) { icon.textContent = '🔍'; icon.style.filter = 'none'; }
            scanBtn.disabled = true;

            // Clear log on new scan
                const log = document.getElementById('root-log');
                if (log) log.innerHTML = '';
                rootLog('> Scanning ADB devices...', '#aaa');

            try {
                // Get device list safely
                const toStr = (v) => typeof v === 'string' ? v : (v && v.message ? v.message : (v && v.output ? v.output : String(v || '')));
                const res = await window.api.invoke('run-adb-devices');
                const rawRes = toStr(res);
                const lines = rawRes.split('\n').filter(l => l.includes('\t'));
                
                if (lines.length === 0 || rawRes.startsWith('[ERROR]')) {
                    const errHint = rawRes.startsWith('[ERROR]') ? ' (' + rawRes.split('\n')[0] + ')' : '';
                    rootLog('No device found. Enable USB debugging.' + errHint, '#ff5252');
                    if (label) label.textContent = 'No device found';
                    if (icon) { icon.textContent = '❌'; }
                    scanBtn.disabled = false;
                    return;
                }

                // Get device info via ADB
                const model = await window.api.invoke('run-adb-command', 'shell getprop ro.product.model');
                const brand = await window.api.invoke('run-adb-command', 'shell getprop ro.product.brand');
                const android = await window.api.invoke('run-adb-command', 'shell getprop ro.build.version.release');
                const serial = await window.api.invoke('run-adb-command', 'shell getprop ro.serialno');
                const cpu = await window.api.invoke('run-adb-command', 'shell getprop ro.product.cpu.abi');
                const blState = await window.api.invoke('run-adb-command', 'shell getprop ro.boot.verifiedbootstate');

                const cleanModel = toStr(model).trim();
                const cleanBrand = toStr(brand).trim();
                const cleanAndroid = toStr(android).trim();
                const cleanSerial = toStr(serial).trim();
                const cleanCpu = toStr(cpu).trim();
                const cleanBL = toStr(blState).trim();

                // Update device card
                if (icon) { icon.textContent = '📱'; icon.style.filter = 'none'; }
                if (label) label.textContent = `${cleanBrand} ${cleanModel}`;

                // Update info grid
                document.getElementById('info-model').textContent = cleanModel || '-';
                document.getElementById('info-android').textContent = 'Android ' + (cleanAndroid || '-');
                document.getElementById('info-serial').textContent = cleanSerial || '-';
                document.getElementById('info-cpu').textContent = cleanCpu || '-';
                
                const flashLocked = await window.api.invoke('run-adb-command', 'shell getprop ro.boot.flash.locked');
                const cleanFL = (flashLocked || '').trim();
                const isUnlocked = cleanBL === 'orange' || cleanFL === '0';
                const blEl = document.getElementById('info-bootloader');
                if (blEl) {
                    blEl.textContent = isUnlocked ? '🔓 Unlocked' : '🔒 Locked';
                    blEl.style.color = isUnlocked ? '#69f0ae' : '#ff5252';
                }

                // Check root status safely
                let isRooted = false;
                try {
                    const suCheck = await window.api.invoke('run-adb-command', 'shell su -c "id"');
                    isRooted = (suCheck || '').includes('uid=0') || (suCheck || '').includes('root');
                } catch(e) {
                    isRooted = false;
                }
                const rootEl = document.getElementById('info-root');
                if (rootEl) {
                    rootEl.textContent = isRooted ? '✅ Rooted' : '❌ Not Rooted';
                    rootEl.style.color = isRooted ? '#69f0ae' : '#888';
                }

                // Auto-fill brand select
                const brandSelect = document.getElementById('root-brand-select');
                if (brandSelect && cleanBrand) {
                    const bl = cleanBrand.toLowerCase();
                    let setVal = 'generic';
                    if (bl.includes('samsung')) setVal = 'samsung';
                    else if (bl.includes('xiaomi') || bl.includes('redmi') || bl.includes('poco')) setVal = 'xiaomi';
                    else if (bl.includes('realme') || bl.includes('oppo') || bl.includes('oneplus')) setVal = 'realme';
                    else if (bl.includes('vivo')) setVal = 'vivo';
                    else if (bl.includes('huawei') || bl.includes('honor')) setVal = 'huawei';
                    else if (bl.includes('motorola') || bl.includes('moto')) setVal = 'motorola';
                    
                    brandSelect.value = setVal;
                    
                    // Update custom dropdown UI
                    const trigger = document.getElementById('root-brand-trigger');
                    const dropdown = document.getElementById('root-brand-dropdown');
                    if (trigger && dropdown) {
                        const opt = dropdown.querySelector(`.csd-option[data-value="${setVal}"]`);
                        if (opt) {
                            const label = opt.textContent.trim();
                            trigger.childNodes[0].textContent = label + ' ';
                            trigger.dataset.value = setVal;
                            dropdown.querySelectorAll('.csd-option').forEach(o => o.classList.remove('selected'));
                            opt.classList.add('selected');
                        }
                    }
                }

                // Auto-fill model
                const modelInput = document.getElementById('root-model-input');
                if (modelInput && cleanModel) modelInput.value = cleanModel;

                rootLog(`✅ Device: ${cleanBrand} ${cleanModel} (Android ${cleanAndroid})`, '#69f0ae');
                rootLog(`   CPU: ${cleanCpu} | Bootloader: ${cleanBL}`, '#aaa');

                // Check Samsung Knox 7-day Security Policy
                if (cleanBrand.toLowerCase().includes('samsung') || cleanModel.toUpperCase().startsWith('SM-')) {
                    await refreshSamsungKnoxPolicy(false);
                } else {
                    const knoxCard = document.getElementById('samsung-knox-policy-card');
                    if (knoxCard) knoxCard.style.display = 'none';
                    const devDetailsCard = document.getElementById('card-root-device-details');
                    if (devDetailsCard) devDetailsCard.style.gridColumn = '1 / -1';
                }

            } catch (e) {
                rootLog('Error: ' + e.message, '#ff5252');
                if (label) label.textContent = 'Error - check ADB';
            }

            scanBtn.disabled = false;
        });
    }

    // --- Samsung Knox 7-Day Security Policy Controller ---
    async function refreshSamsungKnoxPolicy(silent = false) {
        const card = document.getElementById('samsung-knox-policy-card');
        if (!card) return;

        try {
            const data = await window.api.checkSamsungKnoxPolicy();
            if (!data || !data.success || !data.isSamsung) {
                card.style.display = 'none';
                const devDetailsCard = document.getElementById('card-root-device-details');
                if (devDetailsCard) devDetailsCard.style.gridColumn = '1 / -1';
                return;
            }

            // Show card side-by-side with Device Details
            card.style.display = 'flex';
            const devDetailsCard = document.getElementById('card-root-device-details');
            if (devDetailsCard) devDetailsCard.style.gridColumn = 'auto';

            // Populate Elements
            const badge = document.getElementById('knox-policy-badge');
            const oemStatus = document.getElementById('knox-oem-status');
            const setupTime = document.getElementById('knox-setup-time');
            const elapsedTime = document.getElementById('knox-elapsed-time');
            const remainingTime = document.getElementById('knox-remaining-time');
            const estUnlock = document.getElementById('knox-estimated-unlock');
            const kgState = document.getElementById('knox-kg-state');
            const progLabel = document.getElementById('knox-progress-label');
            const progBar = document.getElementById('knox-progress-bar');
            const alertBox = document.getElementById('knox-policy-alert');

            if (setupTime) setupTime.textContent = data.setupTimeStr || '-';
            if (elapsedTime) {
                const hoursTxt = data.elapsedHours < 24 ? `${data.elapsedHours} ชม. (ยังไม่ถึง 24 ชม.)` : `${data.elapsedHours} ชม.`;
                elapsedTime.textContent = hoursTxt;
            }
            if (remainingTime) {
                const daysLeft = (data.remainingHours / 24).toFixed(1);
                remainingTime.textContent = data.remainingHours > 0 ? `~${data.remainingHours} ชม. (${daysLeft} วัน)` : '0 ชม. (ครบกำหนดแล้ว)';
            }
            if (estUnlock) estUnlock.textContent = data.estimatedUnlockStr || '-';
            if (kgState) kgState.textContent = `${data.kgState} (${data.flashLocked ? 'Flash Locked' : 'Unlocked'})`;

            if (progLabel) progLabel.textContent = `${data.percentage}% (${data.elapsedHours}/${data.totalHours} ชม.)`;
            if (progBar) {
                progBar.style.width = `${Math.max(5, data.percentage)}%`;
                progBar.style.background = data.isPolicyActive 
                    ? 'linear-gradient(90deg, #f59e0b, #ef4444)' 
                    : 'linear-gradient(90deg, #10b981, #059669)';
            }

            if (data.isPolicyActive) {
                card.style.borderColor = 'rgba(239,68,68,0.4)';
                card.style.background = 'rgba(239,68,68,0.06)';
                if (badge) {
                    badge.textContent = '🔒 168h Lock Active';
                    badge.style.background = 'rgba(239,68,68,0.2)';
                    badge.style.color = '#f87171';
                    badge.style.borderColor = 'rgba(239,68,68,0.4)';
                }
                if (oemStatus) {
                    oemStatus.textContent = '🔒 ซ่อนเมนู (Locked)';
                    oemStatus.style.color = '#f87171';
                }
                if (alertBox) {
                    alertBox.innerHTML = `⚠️ <b>ตรวจพบนโยบายความปลอดภัย Samsung Knox:</b> ตัวเครื่องเพิ่งเปิดใช้งานมา ${data.elapsedHours} ชม. (${data.elapsedHours < 24 ? 'ยังไม่ถึง 24 ชั่วโมง' : data.elapsedHours + ' ชม.'}) ระบบความปลอดภัย VaultKeeper จึงซ่อนเมนู <b>"การปลดล็อก OEM"</b> ไว้อย่างเข้มงวดเป็นเวลา 168 ชั่วโมง (7 วันเต็ม) เพื่อความปลอดภัยของข้อมูล`;
                }
                if (!silent) {
                    rootLog('🛡️ ตรวจพบเครื่อง Samsung ติดนโยบายความปลอดภัย 7 วัน (168 ชม.)', '#f59e0b');
                    rootLog(`   ใช้งานมาแล้ว: ${data.elapsedHours} ชม. | เหลืออีก: ${data.remainingHours} ชม. | คาดการณ์ปลดล็อก: ${data.estimatedUnlockStr}`, '#aaa');
                }
            } else {
                card.style.borderColor = 'rgba(74,222,128,0.4)';
                card.style.background = 'rgba(74,222,128,0.06)';
                if (badge) {
                    badge.textContent = '✅ OEM Unlock Ready';
                    badge.style.background = 'rgba(74,222,128,0.2)';
                    badge.style.color = '#4ade80';
                    badge.style.borderColor = 'rgba(74,222,128,0.4)';
                }
                if (oemStatus) {
                    oemStatus.textContent = '✅ เมนูพร้อมเปิด (Available)';
                    oemStatus.style.color = '#4ade80';
                }
                if (alertBox) {
                    alertBox.innerHTML = '✅ <b>ผ่านเกณฑ์ความปลอดภัยแล้ว:</b> ตัวเครื่องเปิดใช้งานครบ 168 ชั่วโมงแล้ว เมนู "การปลดล็อก OEM" ในทางเลือกผู้พัฒนาสามารถเปิดใช้งานได้ตามปกติ';
                }
                if (!silent) {
                    rootLog('✅ ตรวจสอบ Samsung Knox Policy: ผ่านเกณฑ์ 168 ชั่วโมงแล้ว', '#4ade80');
                }
            }
        } catch (err) {
            console.error('Samsung Knox Policy error:', err);
        }
    }

    const knoxRefreshBtn = document.getElementById('btn-knox-refresh');
    if (knoxRefreshBtn) {
        knoxRefreshBtn.addEventListener('click', async () => {
            knoxRefreshBtn.disabled = true;
            knoxRefreshBtn.textContent = '⏳ กำลังตรวจ...';
            await refreshSamsungKnoxPolicy(false);
            knoxRefreshBtn.disabled = false;
            knoxRefreshBtn.textContent = '🔄 รีเฟรชสถานะ';
        });
    }

    const knoxGuideBtn = document.getElementById('btn-knox-guide');
    if (knoxGuideBtn) {
        knoxGuideBtn.addEventListener('click', () => {
            alert(
                "📖 คำแนะนำนโยบายความปลอดภัย 7 วัน (168 ชั่วโมง) ของ Samsung Knox\n\n" +
                "1. นโยบายนี้ถูกบังคับใช้กับมือถือ Samsung รุ่นใหม่ทุกเครื่องที่เพิ่งแกะกล่องหรือเพิ่งคืนค่าโรงงาน (Factory Reset)\n" +
                "2. ระบบจะซ่อนเมนู 'การปลดล็อก OEM' ไว้เป็นเวลา 168 ชั่วโมงเต็ม โดยต้องเปิดเครื่อง ใส่ซิม และเชื่อมต่อ Wi-Fi ไว้\n" +
                "3. เมื่อครบกำหนด 168 ชั่วโมง เมนูปลดล็อก OEM จะโผล่ขึ้นมาให้เปิดได้เองโดยอัตโนมัติ\n" +
                "4. เทคนิคย้อนเวลา (Date Trick): บางรุ่นสามารถหลอกระบบได้โดย ปิดเวลาอัตโนมัติ -> ตั้งเวลาย้อนหลัง 10-15 วัน -> กดเช็คอัปเดตซอฟต์แวร์ 1 ครั้ง -> รีสตาร์ทเครื่อง"
            );
        });
    }

    // --- Boot File Selector & Reboot buttons ---
    const browseBootBtn = document.getElementById('btn-root-browse-boot');
    const bootPathInput = document.getElementById('root-boot-path');
    const bootClearBtn = document.getElementById('btn-root-clear-boot');
    const bootStatusBadge = document.getElementById('root-boot-status-badge');

    async function handleBootFileSelection(filePath) {
        if (!filePath) return;
        if (bootPathInput) bootPathInput.value = filePath;
        if (bootClearBtn) bootClearBtn.style.display = 'inline-block';

        const baseName = getBasename(filePath);
        const lowerPath = filePath.toLowerCase();
        const isAp = lowerPath.endsWith('.tar') || lowerPath.endsWith('.tar.md5') || lowerPath.includes('ap_');
        const isZip = lowerPath.endsWith('.zip');

        if (isAp) {
            if (bootStatusBadge) {
                bootStatusBadge.innerHTML = `
                    <div style="background: rgba(56,189,248,0.12); border: 1px solid rgba(56,189,248,0.3); border-radius: 8px; padding: 8px 10px; color: #38bdf8;">
                        <div style="display:flex; align-items:center; gap:8px; font-weight:600; margin-bottom:3px;">
                            <i class="fas fa-spinner fa-spin"></i> ตรวจพบรอมศูนย์ Samsung AP! กำลังสกัด boot.img อัตโนมัติ...
                        </div>
                        <div style="color: #94a3b8; font-size: 11px; word-break: break-all;">ไฟล์: <b>${baseName}</b></div>
                    </div>
                `;
                bootStatusBadge.style.display = 'block';
            }
            rootLog('📦 ตรวจพบรอมศูนย์ Samsung AP: ' + baseName, '#38bdf8');
            rootLog('> กำลังสกัด boot.img อัตโนมัติด้วยเอนจินความเร็วสูง...', '#aaa');

            try {
                const apRes = await window.api.extractBootFromAp(filePath);
                if (apRes && apRes.success) {
                    const lz4Note = apRes.hasDecompressed ? ' (แตก LZ4 &rarr; .img ดิบ)' : '';
                    const initNote = apRes.isInitBoot ? ' [Android 13+ init_boot]' : '';
                    const timeNote = apRes.elapsedSeconds ? `(${apRes.elapsedSeconds}s)` : '';

                    const autoPatchChk = document.getElementById('chk-auto-patch-magisk');
                    const shouldAutoPatch = autoPatchChk && autoPatchChk.checked;

                    if (shouldAutoPatch) {
                        rootLog(`✅ สกัดสำเร็จ: ${apRes.targetFile} ${lz4Note} ${timeNote}`, '#69f0ae');
                        rootLog(`⚡ ตรวจพบการตั้งค่าแพตช์อัตโนมัติ: กำลังเริ่มแพตช์ Magisk Root ทันที...`, '#ff8a65');
                        await executeMagiskPatch(apRes.outPath, bootStatusBadge, rootLog);
                    } else {
                        if (bootStatusBadge) {
                            bootStatusBadge.innerHTML = `
                                <div style="background: rgba(34,197,94,0.12); border: 1px solid rgba(34,197,94,0.3); border-radius: 8px; padding: 10px; color: #4ade80;">
                                    <div style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:6px; margin-bottom:4px;">
                                        <div style="font-weight:600; display:flex; align-items:center; gap:6px;">
                                            <i class="fas fa-check-circle"></i> สกัด Boot Image สำเร็จ! ${timeNote}
                                        </div>
                                        <div style="display:flex; gap:6px; flex-wrap: wrap;">
                                            <button type="button" class="btn-root-patch-now" style="background: linear-gradient(135deg, #ff4e00, #ec9f05); border: none; color: #fff; padding: 3px 10px; border-radius: 4px; font-size: 11px; font-weight: 600; cursor: pointer;">
                                                <i class="fas fa-bolt"></i> แพตช์ Magisk Root ทันที
                                            </button>
                                            <button type="button" class="btn-open-root-extracted" style="background: rgba(34,197,94,0.25); border: 1px solid rgba(34,197,94,0.4); color: #fff; padding: 3px 8px; border-radius: 4px; font-size: 11px; cursor: pointer;">
                                                <i class="fas fa-folder-open"></i> เปิดโฟลเดอร์
                                            </button>
                                        </div>
                                    </div>
                                    <div style="color: #cbd5e1; font-size: 11px; word-break: break-all;">
                                        สกัดได้: <b>${apRes.targetFile}</b> ${lz4Note} ${initNote}
                                    </div>
                                    <div style="color: #94a3b8; font-size: 10px; margin-top: 3px; word-break: break-all;">
                                        ตำแหน่ง: ${apRes.outPath}
                                    </div>
                                </div>
                            `;
                            const patchBtn = bootStatusBadge.querySelector('.btn-root-patch-now');
                            if (patchBtn) {
                                patchBtn.addEventListener('click', () => {
                                    executeMagiskPatch(apRes.outPath, bootStatusBadge, rootLog);
                                });
                            }
                            const openBtn = bootStatusBadge.querySelector('.btn-open-root-extracted');
                            if (openBtn) {
                                openBtn.addEventListener('click', async () => {
                                    if (window.api && window.api.openFileLocation) {
                                        await window.api.openFileLocation(apRes.outPath);
                                    }
                                });
                            }
                        }
                        rootLog(`✅ สกัดสำเร็จ: ${apRes.targetFile} ${lz4Note} ${timeNote}`, '#69f0ae');
                        rootLog(`💡 คุณสามารถคลิกปุ่ม [แพตช์ Magisk Root ทันที] เพื่อแปลงเป็นไฟล์รูทได้เลย`, '#38bdf8');
                    }
                } else {
                    if (bootStatusBadge) {
                        bootStatusBadge.innerHTML = `
                            <div style="background: rgba(239,68,68,0.12); border: 1px solid rgba(239,68,68,0.3); border-radius: 8px; padding: 10px; color: #f87171;">
                                <div style="font-weight:600;"><i class="fas fa-times-circle"></i> สกัดไฟล์ boot ไม่สำเร็จ: ${apRes ? apRes.error : 'Unknown error'}</div>
                            </div>
                        `;
                    }
                    rootLog(`❌ สกัดไฟล์ boot ไม่สำเร็จ: ${apRes ? apRes.error : 'Unknown error'}`, '#ff5252');
                }
            } catch (err) {
                if (bootStatusBadge) {
                    bootStatusBadge.innerHTML = `<div style="color: #f87171; padding: 6px;">❌ เกิดข้อผิดพลาด: ${err.message}</div>`;
                }
                rootLog(`❌ เกิดข้อผิดพลาดในการสกัดไฟล์: ${err.message}`, '#ff5252');
            }
        } else if (isZip) {
            if (bootStatusBadge) {
                bootStatusBadge.innerHTML = `
                    <div style="background: rgba(245,158,11,0.12); border: 1px solid rgba(245,158,11,0.3); border-radius: 8px; padding: 10px; color: #fbbf24;">
                        <div style="font-weight:600; display:flex; align-items:center; gap:6px;">
                            <i class="fas fa-file-archive"></i> ไฟล์ ZIP เฟิร์มแวร์
                        </div>
                        <div style="color: #e2e8f0; font-size: 11px; margin-top: 3px;">
                            กรุณาเลือกไฟล์ <b>AP_*.tar.md5</b> ที่อยู่ภายใน หรือแตกไฟล์ ZIP ออกมาก่อน
                        </div>
                    </div>
                `;
                bootStatusBadge.style.display = 'block';
            }
            rootLog('ℹ️ ตรวจพบไฟล์ ZIP: กรุณาเลือกไฟล์ AP_*.tar.md5 ภายใน', '#fbbf24');
        } else {
            // raw img or other
            if (bootStatusBadge) {
                bootStatusBadge.innerHTML = `
                    <div style="background: rgba(34,197,94,0.12); border: 1px solid rgba(34,197,94,0.3); border-radius: 8px; padding: 10px; color: #4ade80;">
                        <div style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:6px; margin-bottom:4px;">
                            <div style="font-weight:600; display:flex; align-items:center; gap:6px;">
                                <i class="fas fa-check-circle"></i> พร้อมใช้งาน: ${baseName}
                            </div>
                            <div style="display:flex; gap:6px; flex-wrap:wrap;">
                                <button type="button" class="btn-root-pack-tar" style="background: linear-gradient(135deg, #0284c7, #0369a1); border: none; color: #fff; padding: 3px 10px; border-radius: 4px; font-size: 11px; font-weight: 600; cursor: pointer;">
                                    <i class="fas fa-file-archive"></i> รวมเป็นไฟล์ .tar สำหรับ Odin
                                </button>
                                <button type="button" class="btn-root-patch-now" style="background: linear-gradient(135deg, #ff4e00, #ec9f05); border: none; color: #fff; padding: 3px 10px; border-radius: 4px; font-size: 11px; font-weight: 600; cursor: pointer;">
                                    <i class="fas fa-bolt"></i> แพตช์ Magisk Root ทันที
                                </button>
                            </div>
                        </div>
                        <div style="color: #94a3b8; font-size: 10px; margin-top: 3px; word-break: break-all;">
                            ${filePath}
                        </div>
                    </div>
                `;
                bootStatusBadge.style.display = 'block';
                const patchBtn = bootStatusBadge.querySelector('.btn-root-patch-now');
                if (patchBtn) {
                    patchBtn.addEventListener('click', () => {
                        executeMagiskPatch(filePath, bootStatusBadge, rootLog);
                    });
                }
                const packTarBtn = bootStatusBadge.querySelector('.btn-root-pack-tar');
                if (packTarBtn) {
                    packTarBtn.addEventListener('click', async () => {
                        rootLog(`📦 กำลังแปลงไฟล์ ${baseName} เป็น .tar สำหรับ Samsung Odin...`, '#38bdf8');
                        try {
                            const res = await window.api.convertImgToOdinTar(filePath);
                            if (res && res.success) {
                                rootLog(`🎉 แปลงไฟล์เป็น .tar สำเร็จแล้ว!`, '#69f0ae');
                                rootLog(`📁 ที่อยู่ไฟล์: ${res.tarPath}`, '#ffd740');
                                if (window.api.openFileLocation) {
                                    await window.api.openFileLocation(res.tarPath);
                                }
                            } else {
                                rootLog(`❌ แปลงไฟล์ไม่สำเร็จ: ${res ? res.error : 'Unknown error'}`, '#ff5252');
                            }
                        } catch (err) {
                            rootLog(`❌ เกิดข้อผิดพลาด: ${err.message}`, '#ff5252');
                        }
                    });
                }
            }
            rootLog('📁 เลือกไฟล์ Boot Image: ' + baseName, '#69f0ae');
        }
    }

    async function triggerBootFileDialog() {
        try {
            const res = await window.api.showOpenDialog({
                title: 'เลือกไฟล์ boot.img หรือ Samsung AP tar file',
                filters: [
                    { name: 'Boot / Firmware Files', extensions: ['img', 'lz4', 'tar', 'md5', 'bin', 'zip'] },
                    { name: 'Samsung AP Files (*.tar.md5, *.tar)', extensions: ['tar.md5', 'tar'] },
                    { name: 'Boot Images (*.img, *.img.lz4)', extensions: ['img', 'lz4'] },
                    { name: 'All Files', extensions: ['*'] }
                ],
                properties: ['openFile']
            });
            const filePath = resolveDialogPath(res);
            if (filePath) {
                await handleBootFileSelection(filePath);
            }
        } catch(e) {
            rootLog('Error selecting file: ' + e.message, '#ff5252');
        }
    }

    if (browseBootBtn) {
        browseBootBtn.addEventListener('click', triggerBootFileDialog);
    }
    if (bootPathInput) {
        bootPathInput.addEventListener('click', triggerBootFileDialog);
    }
    if (bootClearBtn) {
        bootClearBtn.addEventListener('click', () => {
            if (bootPathInput) bootPathInput.value = '';
            if (bootStatusBadge) {
                bootStatusBadge.innerHTML = '';
                bootStatusBadge.style.display = 'none';
            }
            bootClearBtn.style.display = 'none';
            rootLog('ℹ️ ล้างการเลือกไฟล์ Boot Image แล้ว', '#aaa');
        });
    }

    const rebootDlBtn = document.getElementById('btn-root-reboot-dl');
    if (rebootDlBtn) {
        rebootDlBtn.addEventListener('click', async () => {
            try {
                rootLog('> Rebooting device to Download Mode...', '#aaa');
                await window.api.invoke('run-adb-command', 'reboot download');
                rootLog('✅ Sent reboot download command.', '#69f0ae');
            } catch (e) {
                rootLog('❌ Error: ' + e.message, '#ff5252');
            }
        });
    }

    const rebootFbBtn = document.getElementById('btn-root-reboot-fb');
    if (rebootFbBtn) {
        rebootFbBtn.addEventListener('click', async () => {
            try {
                rootLog('> Rebooting device to Fastboot...', '#aaa');
                await window.api.invoke('run-adb-command', 'reboot bootloader');
                rootLog('✅ Sent reboot bootloader command.', '#69f0ae');
            } catch (e) {
                rootLog('❌ Error: ' + e.message, '#ff5252');
            }
        });
    }

    // --- One-Click ROOT ---
    const rootBtn = document.getElementById('btn-root-oneclick');
    if (rootBtn) {
        rootBtn.addEventListener('click', async () => {
            const model = document.getElementById('root-model-input')?.value?.trim();
            if (!model) {
                alert('Please scan your device or enter model manually first.');
                return;
            }

            resetSteps();
            rootBtn.disabled = true;
            setBadge('Rooting...', 'rgba(255,78,0,0.6)');
            const log = document.getElementById('root-log');
            if (log) log.innerHTML = '';

            rootLog('⚡ Starting One-Click ROOT process...', '#fff');

            // Step 1: Check ADB
            setStep(1, 'active');
            setProgress(5, 'Checking ADB connection...');
            await new Promise(r => setTimeout(r, 400));
            try {
                const rawDevs = await window.api.invoke('run-adb-devices');
                const toStr = (v) => typeof v === 'string' ? v : (v && v.message ? v.message : (v && v.output ? v.output : String(v || '')));
                const devs = toStr(rawDevs);
                if (!devs || !devs.includes('\t')) throw new Error('No device in ADB mode. Make sure USB Debugging is ON.');
                setStep(1, 'done');
                rootLog('✅ ADB connected', '#69f0ae');
                setProgress(14, 'Checking bootloader...');
            } catch(e) {
                setStep(1, 'error');
                setBadge('Failed', 'rgba(255,82,82,0.6)');
                rootLog('❌ ' + e.message, '#ff5252');
                rootBtn.disabled = false;
                return;
            }

            // Step 2 & 3: Check / Unlock Bootloader
            setStep(2, 'active');
            await new Promise(r => setTimeout(r, 400));

            const skipBL = document.getElementById('root-skip-bl-check')?.checked;
            if (skipBL) {
                rootLog('⏩ ข้ามขั้นตอนตรวจ Bootloader (Force Skip / Already Unlocked)', '#69f0ae');
                setStep(2, 'done');
                setStep(3, 'done');
            } else {
                try {
                    const blState = await window.api.invoke('run-adb-command', 'shell getprop ro.boot.verifiedbootstate');
                    const flashLocked = await window.api.invoke('run-adb-command', 'shell getprop ro.boot.flash.locked');
                    const cleanBL = (blState || '').trim().toLowerCase();
                    const cleanFL = (flashLocked || '').trim();
                    const isBLUnlocked = cleanBL === 'orange' || cleanFL === '0';

                    if (isBLUnlocked) {
                        setStep(2, 'done');
                        rootLog('✅ Bootloader: Already Unlocked', '#69f0ae');
                        setStep(3, 'done');
                    } else {
                        rootLog('⚠️ Bootloader is LOCKED.', '#ffa726');
                        setStep(2, 'done');
                        setStep(3, 'active');

                        const currentBrand = (document.getElementById('root-brand-select')?.value || document.getElementById('root-device-label')?.textContent || '').toLowerCase();
                        if (currentBrand.includes('samsung')) {
                            rootLog('⚠️ Samsung devices cannot be unlocked automatically via Fastboot.', '#ffd740');
                            rootLog('Samsung requires manual unlock in Device Unlock Mode.', '#aaa');
                            
                            const msgTh = 'เครื่อง Samsung ต้องทำการปลดล็อค Bootloader บนตัวเครื่องโดยตรง\n\n' +
                                '📌 ขั้นตอนการปลดล็อค (ข้อมูลจะถูกล้าง Factory Reset):\n' +
                                '1. เข้า ตั้งค่า > ข้อมูลซอฟต์แวร์ > กด Build number 7 ครั้ง\n' +
                                '2. เข้า ทางเลือกผู้พัฒนา > เปิด "การปลดล็อค OEM" (OEM Unlock)\n' +
                                '3. ปิดเครื่องโทรศัพท์ให้สนิท\n' +
                                '4. กดปุ่ม [เพิ่มเสียง + ลดเสียง] ค้างไว้ แล้วเสียบสาย USB ต่อเข้าคอม\n' +
                                '5. เมื่อหน้าจอสีฟ้า (Warning) เด้งขึ้นมา ให้ "กดปุ่มเพิ่มเสียงค้างไว้" (Long-press Vol Up)\n' +
                                '6. กดปุ่มเพิ่มเสียงอีก 1 ครั้งเพื่อยืนยัน\n\n' +
                                '💡 หากปลดล็อคเรียบร้อยแล้ว ให้ติ๊กช่อง "ข้ามการตรวจ Bootloader" ด้านล่าง แล้วกด One-Click ROOT อีกครั้ง';
                            
                            await showCustomConfirm(msgTh);
                            setStep(3, 'error');
                            setBadge('Action Needed', 'rgba(255,167,38,0.6)');
                            rootBtn.disabled = false;
                            return;
                        }

                        // Fastboot auto-unlock for non-Samsung
                        setProgress(20, 'Rebooting to Fastboot for Unlock...');
                        await window.api.invoke('run-adb-command', 'reboot bootloader');
                        await new Promise(r => setTimeout(r, 6000));
                        rootLog('> Sending unlock command...', '#aaa');
                        await window.api.invoke('run-fastboot-command', 'flashing unlock');
                        await window.api.invoke('run-fastboot-command', 'oem unlock');
                        
                        const confirmRes = await showCustomConfirm('Please confirm the unlock on your phone screen by pressing Volume Up.');
                        if (!confirmRes) {
                            rootLog('❌ Bootloader unlock cancelled by user.', '#ff5252');
                            setStep(3, 'error');
                            rootBtn.disabled = false;
                            return;
                        }

                        rootLog('> Waiting for device to boot up and reconnect to ADB...', '#aaa');
                        let adbConnected = false;
                        for (let i = 0; i < 40; i++) {
                            await new Promise(r => setTimeout(r, 3000));
                            const d = await window.api.invoke('run-adb-devices');
                            if (d && d.includes('\t')) { adbConnected = true; break; }
                        }
                        if (!adbConnected) {
                            rootLog('❌ Device did not reconnect to ADB after unlock.', '#ff5252');
                            setStep(3, 'error');
                            rootBtn.disabled = false;
                            return;
                        }
                        setStep(3, 'done');
                        rootLog('✅ Bootloader Unlocked & Device Reconnected', '#69f0ae');
                    }
                } catch(e) {
                    setStep(2, 'error');
                    setStep(3, 'error');
                    rootLog('⚠️ Bootloader check error: ' + e.message, '#ff5252');
                    rootBtn.disabled = false;
                    return;
                }
            }

            // Step 4: Push Magisk & Tools
            setStep(4, 'active');
            setProgress(35, 'Pushing Magisk & patching engine to device...');
            try {
                const magiskApk = 'bin\\magisk\\Magisk.apk';
                rootLog('> Installing Magisk app...', '#aaa');
                try {
                    await window.api.invoke('run-adb-command', `install -r -d -g "${magiskApk}"`);
                } catch(installErr) {
                    rootLog('ℹ️ Magisk app push/install note: ' + (installErr.message || ''), '#aaa');
                }
                await window.api.invoke('run-adb-command', `push "${magiskApk}" /data/local/tmp/Magisk.apk`);

                // Push magiskboot engine
                const tools = ['magiskboot', 'magiskinit', 'boot_patch.sh', 'util_functions.sh', 'stub.apk'];
                for (const t of tools) {
                    await window.api.invoke('run-adb-command', `push "bin\\magisk\\${t}" /data/local/tmp/${t}`);
                }
                await window.api.invoke('run-adb-command', 'shell "chmod 755 /data/local/tmp/magiskboot /data/local/tmp/magiskinit /data/local/tmp/boot_patch.sh"');

                setStep(4, 'done');
                rootLog('✅ Magisk engine deployed to /data/local/tmp/', '#69f0ae');
                setProgress(45, 'Preparing boot image...');
            } catch(e) {
                setStep(4, 'error');
                rootLog('❌ ' + e.message, '#ff5252');
                setBadge('Failed', 'rgba(255,82,82,0.6)');
                rootBtn.disabled = false;
                return;
            }

            // Step 5: Pull or Obtain boot.img
            setStep(5, 'active');
            setProgress(50, 'Obtaining boot image...');
            let customBootPath = document.getElementById('root-boot-path')?.value?.trim();

            try {
                if (customBootPath) {
                    rootLog(`> Using provided boot file: ${customBootPath}`, '#aaa');
                } else {
                    // Try pulling via root dd (if already rooted)
                    rootLog('> Checking if boot partition can be dumped via ADB...', '#aaa');
                    let hasBootDump = false;
                    try {
                        await window.api.invoke('run-adb-command', 'shell su -c "dd if=/dev/block/by-name/boot of=/data/local/tmp/boot.img bs=4M"');
                        const checkImg = await window.api.invoke('run-adb-command', 'shell ls -la /data/local/tmp/boot.img');
                        if (checkImg && !checkImg.includes('No such file') && !checkImg.includes('0 bytes')) {
                            hasBootDump = true;
                        }
                    } catch(suErr) {
                        hasBootDump = false;
                    }
                    
                    if (!hasBootDump) {
                        rootLog('⚠️ Cannot dump boot partition directly (device is not rooted yet).', '#ffa726');
                        rootLog('👉 กรุณาเลือกไฟล์ AP (รอมศูนย์ Samsung .tar / .tar.md5) หรือไฟล์ boot.img / boot.img.lz4', '#69f0ae');
                        
                        const filePick = await window.api.showOpenDialog({
                            title: 'เลือกไฟล์รอม Samsung AP (.tar.md5) หรือไฟล์ boot.img',
                            filters: [
                                { name: 'Samsung AP / Boot Image Files', extensions: ['tar.md5', 'tar', 'img', 'lz4', 'bin'] },
                                { name: 'All Files', extensions: ['*'] }
                            ],
                            properties: ['openFile']
                        });

                        const pickedPath = resolveDialogPath(filePick);
                        if (!pickedPath) {
                            throw new Error('จำเป็นต้องใช้ไฟล์ boot.img หรือไฟล์ AP tar ของเครื่องเพื่อทำการรูท');
                        }

                        customBootPath = pickedPath;
                        const bootInp = document.getElementById('root-boot-path');
                        if (bootInp) bootInp.value = customBootPath;
                    }
                }

                // If user selected Samsung AP tar file, extract boot.img from it on PC!
                if (customBootPath && (customBootPath.toLowerCase().endsWith('.tar') || customBootPath.toLowerCase().endsWith('.tar.md5') || customBootPath.toLowerCase().includes('ap_'))) {
                    rootLog('> ตรวจพบไฟล์รอม Samsung AP! กำลังแตกไฟล์ boot.img ออกจาก TAR...', '#60a5fa');
                    const apRes = await window.api.extractBootFromAp(customBootPath);
                    if (!apRes.success) {
                        throw new Error('ไม่สามารถแตกไฟล์ boot จาก AP ได้: ' + apRes.error);
                    }
                    rootLog(`✅ แตกไฟล์สำเร็จ: ${apRes.targetFile}`, '#69f0ae');
                    rootLog(`> กำลังส่ง ${apRes.targetFile} ไปยังมือถือ...`, '#aaa');
                    
                    if (apRes.hasDecompressed) {
                        await window.api.invoke('run-adb-command', `push "${apRes.outPath}" /data/local/tmp/boot.img`);
                    } else if (apRes.isLz4) {
                        await window.api.invoke('run-adb-command', `push "${apRes.outPath}" /data/local/tmp/boot.img.tmp`);
                        rootLog('> กำลังคลายบีบอัด LZ4 บนมือถือ...', '#aaa');
                        await window.api.invoke('run-adb-command', 'shell "/data/local/tmp/magiskboot decompress /data/local/tmp/boot.img.tmp /data/local/tmp/boot.img"');
                    } else {
                        await window.api.invoke('run-adb-command', `push "${apRes.outPath}" /data/local/tmp/boot.img`);
                    }
                } else if (customBootPath) {
                    rootLog(`> Pushing ${customBootPath} to device...`, '#aaa');
                    await window.api.invoke('run-adb-command', `push "${customBootPath}" /data/local/tmp/boot.img.tmp`);
                    if (customBootPath.toLowerCase().endsWith('.lz4')) {
                        await window.api.invoke('run-adb-command', 'shell "/data/local/tmp/magiskboot decompress /data/local/tmp/boot.img.tmp /data/local/tmp/boot.img"');
                    } else {
                        await window.api.invoke('run-adb-command', 'shell "mv /data/local/tmp/boot.img.tmp /data/local/tmp/boot.img"');
                    }
                }

                setStep(5, 'done');
                rootLog('✅ boot.img ready for patching', '#69f0ae');
                setProgress(65, 'Patching boot.img with Magisk...');
            } catch(e) {
                setStep(5, 'error');
                rootLog('❌ ' + e.message, '#ff5252');
                setBadge('Failed', 'rgba(255,82,82,0.6)');
                rootBtn.disabled = false;
                return;
            }

            // Step 6: Patch boot.img
            setStep(6, 'active');
            setProgress(70, 'Patching boot.img with Magisk engine...');
            try {
                const patchCmd = 'shell "cd /data/local/tmp && KEEPVERITY=true KEEPFORCEENCRYPT=true sh boot_patch.sh boot.img 2>&1"';
                const patchOut = await window.api.invoke('run-adb-command', patchCmd);
                rootLog(patchOut || '', '#888');

                // Pull output
                await window.api.invoke('run-adb-command', 'pull /data/local/tmp/new-boot.img bin\\magisk\\magisk_patched.img');
                
                setStep(6, 'done');
                rootLog('✅ boot.img successfully patched with Magisk!', '#69f0ae');
                setProgress(80, 'Preparing flash...');
            } catch(e) {
                setStep(6, 'error');
                rootLog('❌ Patch error: ' + e.message, '#ff5252');
                setBadge('Failed', 'rgba(255,82,82,0.6)');
                rootBtn.disabled = false;
                return;
            }

            // Step 7: Flash patched boot
            setStep(7, 'active');
            const currentBrand = (document.getElementById('root-brand-select')?.value || document.getElementById('root-device-label')?.textContent || '').toLowerCase();

            if (currentBrand.includes('samsung') || (document.getElementById('root-device-label')?.textContent || '').toLowerCase().includes('sm-')) {
                // Samsung uses Odin / Download mode
                setProgress(88, 'Packaging Samsung Odin tar file...');
                try {
                    // Create magisk_patched.tar
                    await window.api.invoke('run-cmd', { id: 'create-patched-tar', elevated: false });
                } catch(e) {}

                setStep(7, 'done');
                rootLog('🎉 รวมไฟล์ magisk_patched.tar สำหรับ Samsung เรียบร้อยแล้ว!', '#69f0ae');
                rootLog('📁 ไฟล์ที่พร้อมแฟลชอยู่ที่: bin\\magisk\\magisk_patched.tar', '#ffd740');
                rootLog('==================================================', '#555');
                rootLog('📱 ขั้นตอนแฟลชสำหรับ Samsung ให้ ROOT สำเร็จ 100%:', '#38bdf8');
                rootLog('1. ปิดเครื่องโทรศัพท์ให้สนิท', '#fff');
                rootLog('2. กดปุ่ม [เพิ่มเสียง + ลดเสียง] ค้างไว้ แล้วเสียบสาย USB ต่อเข้าคอม (เข้า Download Mode)', '#fff');
                rootLog('3. หน้าจอโทรศัพท์จะขึ้นสีฟ้า ให้กดปุ่ม [เพิ่มเสียง 1 ครั้ง] เพื่อยืนยัน', '#fff');
                rootLog('4. ไปที่แท็บ Odin Flasher ในโปรแกรมนี้ ใส่ไฟล์ bin\\magisk\\magisk_patched.tar ในช่อง AP', '#69f0ae');
                rootLog('5. กดปุ่ม Start ใน Odin เพื่อแฟลชรูทเข้าเครื่อง', '#fff');
                rootLog('6. เมื่อเครื่องบูตขึ้นมา เปิดแอป Magisk แล้วกด Reboot 1 ครั้ง -> สำเร็จ 100%!', '#69f0ae');
                rootLog('==================================================', '#555');
                
                setProgress(100, '✅ Magisk Patched Ready for Odin Flash!');
                setBadge('Ready for Odin', 'rgba(105,240,174,0.4)');
            } else {
                // Fastboot flash
                setProgress(88, 'Rebooting to Fastboot and flashing...');
                try {
                    await window.api.invoke('run-adb-command', 'reboot bootloader');
                    await new Promise(r => setTimeout(r, 4000));
                    const flashRes = await window.api.invoke('run-fastboot-command', 'flash boot bin\\magisk\\magisk_patched.img');
                    if ((flashRes || '').includes('OKAY')) {
                        setStep(7, 'done');
                        rootLog('✅ Patched boot flashed via Fastboot!', '#69f0ae');
                    } else {
                        throw new Error('Flash output: ' + flashRes);
                    }
                } catch(e) {
                    setStep(7, 'error');
                    rootLog('❌ ' + e.message, '#ff5252');
                    setBadge('Failed', 'rgba(255,82,82,0.6)');
                    rootBtn.disabled = false;
                    return;
                }

                // Step 8: Reboot
                setStep(8, 'active');
                setProgress(95, 'Rebooting device...');
                try {
                    await window.api.invoke('run-fastboot-command', 'reboot');
                    setStep(8, 'done');
                    setProgress(100, 'Root Complete!');
                    setBadge('Rooted!', 'rgba(105,240,174,0.4)');
                    rootLog('🎉 Root completed! Open Magisk app on device to complete setup.', '#69f0ae');
                } catch(e) {
                    rootLog('⚠️ Reboot warning: ' + e.message, '#ffa726');
                }
            }

            rootBtn.disabled = false;
        });
    }

})();
// ============================================================

});

// (Cloud Loaders DB removed)


// --- Device Status Polling Loop ---
let _lastUsbText = '';
setInterval(async () => {
    try {
        const adbRes = await window.api.runAdbCommand('devices');
        const adbLines = adbRes.split('\n').filter(line => line.trim() !== '' && !line.includes('List of devices'));
        const usbStatus = document.getElementById('console-usb-status');
        if (usbStatus) {
            if (adbLines.length > 0) {
                const parts = adbLines[0].split('\t');
                const devId = parts[0];
                const devMode = parts[1] ? parts[1].trim() : '';
                let modeLabel = 'ADB Interface';
                if (devMode === 'recovery') modeLabel = 'Recovery Mode';
                else if (devMode === 'sideload') modeLabel = 'Sideload Mode';
                else if (devMode === 'unauthorized') modeLabel = 'Unauthorized';
                if (_lastUsbText === '' || !_lastUsbText.includes(devId)) {
                    try {
                        const brand = await window.api.runAdbCommand('shell getprop ro.product.brand');
                        const model = await window.api.runAdbCommand('shell getprop ro.product.model');
                        const b = (brand && brand.trim()) ? brand.trim().toUpperCase() : '';
                        const m = (model && model.trim()) ? model.trim() : '';
                        _lastUsbText = b ? (b + ' ' + m + ' ' + modeLabel + ' [' + devId + ']') : ('Android ' + modeLabel + ' [' + devId + ']');
                    } catch(e2) {
                        _lastUsbText = 'Android ' + modeLabel + ' [' + devId + ']';
                    }
                }
                usbStatus.textContent = _lastUsbText;
                usbStatus.style.color = '#69f0ae';
            } else {
                _lastUsbText = '';
                usbStatus.textContent = '- Waiting for devices -';
                usbStatus.style.color = '#ffa726';
            }
        }
        const comStatus = document.getElementById('console-com-status');
        if (comStatus) {
            const ports = await window.api.scanComPorts();
            if (ports && ports.length > 0) {
                const p = ports[0];
                comStatus.textContent = (p && p.name) ? p.name : (typeof p === 'string' ? p : '');
                comStatus.style.color = '#69f0ae';
            } else {
                comStatus.textContent = '- Waiting for COM ports -';
                comStatus.style.color = '#ffa726';
            }
        }
    } catch(e) {}
}, 3000);

    // Settings logic
    const btnSettings = document.getElementById('btn-settings');
    const settingsModal = document.getElementById('settings-modal');
    const btnSettingsX = document.getElementById('btn-settings-x');
    const btnSettingsCancel = document.getElementById('btn-settings-cancel');
    const btnSettingsSave = document.getElementById('btn-settings-save');
    const inputWinWidth = document.getElementById('input-win-width');
    const inputWinHeight = document.getElementById('input-win-height');

    if (btnSettings && settingsModal) {
        btnSettings.addEventListener('click', () => {
            inputWinWidth.value = window.outerWidth;
            inputWinHeight.value = window.outerHeight;
            settingsModal.classList.remove('hidden');
        });

        // Update values in real-time if user resizes while modal is open
        window.addEventListener('resize', () => {
            if (!settingsModal.classList.contains('hidden')) {
                inputWinWidth.value = window.outerWidth;
                inputWinHeight.value = window.outerHeight;
            }
        });

        const closeSettings = () => settingsModal.classList.add('hidden');
        if (btnSettingsX) btnSettingsX.addEventListener('click', closeSettings);
        if (btnSettingsCancel) btnSettingsCancel.addEventListener('click', closeSettings);

        if (btnSettingsSave) {
            btnSettingsSave.addEventListener('click', async () => {
                const w = parseInt(inputWinWidth.value);
                const h = parseInt(inputWinHeight.value);
                if (w >= 400 && h >= 400) {
                    btnSettingsSave.textContent = currentLang === 'th' ? 'กำลังบันทึก...' : 'Saving...';
                    await window.api.saveSettings({ width: w, height: h });
                    btnSettingsSave.textContent = currentLang === 'th' ? 'บันทึกแล้ว!' : 'Saved!';
                    setTimeout(() => {
                        btnSettingsSave.textContent = currentLang === 'th' ? 'บันทึก' : 'Save';
                        closeSettings();
                    }, 500);
                } else {
                    alert(currentLang === 'th' ? 'ขนาดเล็กเกินไป (ขั้นต่ำ 400)' : 'Size too small (Min 400)');
                }
            });
        }
    }
    // --- Odin Flasher Logic ---
    const odinBtnBl = document.getElementById('odin-btn-bl');
    const odinBtnAp = document.getElementById('odin-btn-ap');
    const odinBtnCp = document.getElementById('odin-btn-cp');
    const odinBtnCsc = document.getElementById('odin-btn-csc');
    const odinBtnUserdata = document.getElementById('odin-btn-userdata');

    const odinPathBl = document.getElementById('odin-path-bl');
    const odinPathAp = document.getElementById('odin-path-ap');
    const odinPathCp = document.getElementById('odin-path-cp');
    const odinPathCsc = document.getElementById('odin-path-csc');
    const odinPathUserdata = document.getElementById('odin-path-userdata');

    const odinChkBl = document.getElementById('odin-chk-bl');
    const odinChkAp = document.getElementById('odin-chk-ap');
    const odinChkCp = document.getElementById('odin-chk-cp');
    const odinChkCsc = document.getElementById('odin-chk-csc');
    const odinChkUserdata = document.getElementById('odin-chk-userdata');

    const odinLog = document.getElementById('odin-log');
    const odinProgressPct = document.getElementById('odin-progress-pct');
    const odinProgressLabel = document.getElementById('odin-progress-label');
    const odinProgressBar = document.getElementById('odin-progress-bar');
    const odinBtnStart = document.getElementById('odin-btn-start');
    const odinBtnReset = document.getElementById('odin-btn-reset');

    function writeOdinLog(msg, color = '#ccc') {
        if (!odinLog) return;
        const d = document.createElement('div');
        d.style.color = color;
        d.textContent = msg;
        odinLog.appendChild(d);
        odinLog.scrollTop = odinLog.scrollHeight;
    }

    async function handleOdinBrowse(type, pathInput, chkInput) {
        try {
            const filePath = await window.api.browseOdinFile(type);
            if (filePath) {
                pathInput.value = filePath;
                chkInput.checked = true;
                writeOdinLog(`<OSM> Added ${type.toUpperCase()} file: ${filePath.split('\\').pop()}`, '#aaa');
            }
        } catch (e) {
            console.error(e);
        }
    }

    if (odinBtnBl) odinBtnBl.addEventListener('click', () => handleOdinBrowse('bl', odinPathBl, odinChkBl));
    if (odinBtnAp) odinBtnAp.addEventListener('click', () => handleOdinBrowse('ap', odinPathAp, odinChkAp));
    if (odinBtnCp) odinBtnCp.addEventListener('click', () => handleOdinBrowse('cp', odinPathCp, odinChkCp));
    if (odinBtnCsc) odinBtnCsc.addEventListener('click', () => handleOdinBrowse('csc', odinPathCsc, odinChkCsc));
    if (odinBtnUserdata) odinBtnUserdata.addEventListener('click', () => handleOdinBrowse('userdata', odinPathUserdata, odinChkUserdata));

    const odinBtnStop = document.getElementById('odin-btn-stop');
    const odinOptReboot = document.getElementById('odin-opt-reboot');
    const odinOptNand = document.getElementById('odin-opt-nand');
    let isOdinFlashing = false;
    let odinPartLines = {};

    if (odinBtnReset) {
        odinBtnReset.addEventListener('click', () => {
            [odinPathBl, odinPathAp, odinPathCp, odinPathCsc, odinPathUserdata].forEach(i => { if (i) i.value = ''; });
            [odinChkBl, odinChkAp, odinChkCp, odinChkCsc, odinChkUserdata].forEach(i => { if (i) i.checked = false; });
            if (odinLog) odinLog.innerHTML = '';
            if (odinProgressBar) odinProgressBar.style.width = '0%';
            if (odinProgressPct) odinProgressPct.textContent = '0%';
            if (odinProgressLabel) odinProgressLabel.textContent = 'Idle';
            const comStatus = document.getElementById('odin-com-status');
            if (comStatus) {
                comStatus.textContent = '[ ]';
                comStatus.style.color = '#94a3b8';
            }
            const comDesc = document.getElementById('odin-com-desc');
            if (comDesc) comDesc.textContent = 'No device';
            const comCard = document.getElementById('odin-com-card');
            if (comCard) {
                comCard.style.borderColor = 'rgba(255, 255, 255, 0.1)';
                comCard.style.background = 'rgba(255, 255, 255, 0.03)';
            }
        });
    }

    if (odinBtnStop) {
        odinBtnStop.addEventListener('click', async () => {
            writeOdinLog('<OSM> ⚠️ กำลังส่งคำสั่งหยุดการแฟลช...', '#ffa726');
            if (window.api && window.api.killOdinFlash) {
                await window.api.killOdinFlash();
            }
        });
    }

    // Real-time parser for Samsung Native Odin Engine
    if (window.api && window.api.onOdinOutput) {
        window.api.onOdinOutput((trimmed) => {
            if (!trimmed) return;

            const lblCurrPart = document.getElementById('spd-lbl-curr-part');
            const lblCurrPct = document.getElementById('spd-lbl-curr-pct');
            const barCurrFill = document.getElementById('spd-bar-curr-fill');
            const lblTotalSpeed = document.getElementById('spd-lbl-total-speed');
            const lblTotalPct = document.getElementById('spd-lbl-total-pct');
            const barTotalFill = document.getElementById('spd-bar-total-fill');
            const term = document.getElementById('mobile-panel-terminal');

            if (trimmed.startsWith('[ODIN_PROG]')) {
                // Format: [ODIN_PROG] filename|partPct|overallPct|speed
                const payload = trimmed.replace('[ODIN_PROG]', '').trim();
                const parts = payload.split('|');
                if (parts.length >= 3) {
                    const part = parts[0].trim();
                    const partPct = Math.round(parseFloat(parts[1]) || 0);
                    const totalPct = Math.round(parseFloat(parts[2]) || 0);
                    const speed = parts[3] ? parts[3].trim() : '0.0 KB/s';

                    if (lblCurrPart) lblCurrPart.textContent = `พาร์ติชัน: ${part}`;
                    if (lblCurrPct) lblCurrPct.textContent = `${partPct}%`;
                    if (barCurrFill) barCurrFill.style.width = `${partPct}%`;

                    if (lblTotalPct) lblTotalPct.textContent = `${totalPct}%`;
                    if (barTotalFill) barTotalFill.style.width = `${totalPct}%`;
                    if (lblTotalSpeed) lblTotalSpeed.textContent = `ความคืบหน้ารวม (${speed})`;

                    if (odinProgressBar) odinProgressBar.style.width = `${totalPct}%`;
                    if (odinProgressPct) odinProgressPct.textContent = `${totalPct}%`;
                    if (odinProgressLabel) odinProgressLabel.textContent = `Flashing ${part} (${partPct}%)`;

                    // Update right panel header progress bar
                    const panelProgress = document.getElementById('mobile-panel-progress-bar');
                    const panelProgressTxt = document.getElementById('mobile-panel-progress-text');
                    if (panelProgress) panelProgress.style.width = `${totalPct}%`;
                    if (panelProgressTxt) panelProgressTxt.textContent = `${totalPct}% (${part})`;

                    // Update partition progress line in Log Console (Show clean partition progress)
                    if (term) {
                        if (!odinPartLines[part]) {
                            const lineEl = document.createElement('div');
                            lineEl.style.fontFamily = "'Consolas', 'JetBrains Mono', monospace";
                            lineEl.style.fontSize = '12px';
                            lineEl.style.lineHeight = '1.7';
                            if (partPct >= 100) {
                                lineEl.style.color = '#4ade80';
                                lineEl.style.fontWeight = 'bold';
                                lineEl.textContent = `✓ ${part}... สำเร็จ 100%`;
                                lineEl.dataset.done = 'true';
                            } else {
                                lineEl.style.color = '#38bdf8';
                                lineEl.textContent = `✓ ${part}... ${partPct}%`;
                            }
                            term.appendChild(lineEl);
                            odinPartLines[part] = lineEl;
                        } else if (!odinPartLines[part].dataset.done) {
                            if (partPct >= 100) {
                                odinPartLines[part].style.color = '#4ade80';
                                odinPartLines[part].style.fontWeight = 'bold';
                                odinPartLines[part].textContent = `✓ ${part}... สำเร็จ 100%`;
                                odinPartLines[part].dataset.done = 'true';
                            } else {
                                odinPartLines[part].textContent = `✓ ${part}... ${partPct}%`;
                            }
                        }
                        const autoScroll = document.getElementById('chk-panel-autoscroll');
                        if (!autoScroll || autoScroll.checked) {
                            term.scrollTop = term.scrollHeight;
                        }
                    }
                }
            } else if (trimmed.startsWith('[ODIN_DONE]')) {
                const part = trimmed.replace('[ODIN_DONE]', '').trim();
                if (part && term) {
                    if (!odinPartLines[part]) {
                        const lineEl = document.createElement('div');
                        lineEl.style.fontFamily = "'Consolas', 'JetBrains Mono', monospace";
                        lineEl.style.fontSize = '12px';
                        lineEl.style.lineHeight = '1.7';
                        term.appendChild(lineEl);
                        odinPartLines[part] = lineEl;
                    }
                    odinPartLines[part].style.color = '#4ade80';
                    odinPartLines[part].style.fontWeight = 'bold';
                    odinPartLines[part].textContent = `✓ ${part}... สำเร็จ 100%`;
                    odinPartLines[part].dataset.done = 'true';

                    const autoScroll = document.getElementById('chk-panel-autoscroll');
                    if (!autoScroll || autoScroll.checked) {
                        term.scrollTop = term.scrollHeight;
                    }
                }
            } else if (trimmed.startsWith('[ODIN_SUCCESS]')) {
                if (lblCurrPart) lblCurrPart.textContent = 'พาร์ติชัน: สำเร็จทั้งหมด';
                if (lblCurrPct) lblCurrPct.textContent = '100%';
                if (barCurrFill) {
                    barCurrFill.style.width = '100%';
                    barCurrFill.style.background = '#10b981';
                }
                if (lblTotalSpeed) lblTotalSpeed.textContent = 'ความคืบหน้ารวม: สำเร็จ 100%';
                if (lblTotalPct) lblTotalPct.textContent = '100%';
                if (barTotalFill) {
                    barTotalFill.style.width = '100%';
                    barTotalFill.style.background = '#10b981';
                }
                if (odinProgressLabel) {
                    odinProgressLabel.textContent = 'PASS!';
                    odinProgressLabel.style.color = '#00c853';
                }
                if (odinProgressPct) odinProgressPct.textContent = '100%';
                if (odinProgressBar) {
                    odinProgressBar.style.width = '100%';
                    odinProgressBar.style.background = '#00c853';
                }
                const comStatus = document.getElementById('odin-com-status');
                if (comStatus) {
                    comStatus.textContent = 'PASS!';
                    comStatus.style.color = '#00e676';
                }
            } else if (trimmed.startsWith('[ODIN_ERROR]')) {
                const errMsg = trimmed.replace('[ODIN_ERROR]', '').trim();
                if (lblCurrPart) lblCurrPart.textContent = `ข้อผิดพลาด: ${errMsg}`;
                if (lblCurrPct) lblCurrPct.textContent = 'FAILED';
                if (barCurrFill) barCurrFill.style.background = '#ef4444';
                if (lblTotalSpeed) lblTotalSpeed.textContent = 'ความคืบหน้ารวม: ขัดข้อง';
                if (lblTotalPct) lblTotalPct.textContent = 'FAIL';
                if (barTotalFill) barTotalFill.style.background = '#ef4444';
                if (odinProgressLabel) {
                    odinProgressLabel.textContent = 'FAILED';
                    odinProgressLabel.style.color = '#ff5252';
                }
                const comStatus = document.getElementById('odin-com-status');
                if (comStatus) {
                    comStatus.textContent = 'FAIL';
                    comStatus.style.color = '#ff5252';
                }
            }
        });
    }

    if (odinBtnStart) {
        odinBtnStart.addEventListener('click', async () => {
            if (isOdinFlashing) return;

            const blPath = (odinChkBl && odinChkBl.checked && odinPathBl) ? odinPathBl.value.trim() : null;
            const apPath = (odinChkAp && odinChkAp.checked && odinPathAp) ? odinPathAp.value.trim() : null;
            const cpPath = (odinChkCp && odinChkCp.checked && odinPathCp) ? odinPathCp.value.trim() : null;
            const cscPath = (odinChkCsc && odinChkCsc.checked && odinPathCsc) ? odinPathCsc.value.trim() : null;
            const userdataPath = (odinChkUserdata && odinChkUserdata.checked && odinPathUserdata) ? odinPathUserdata.value.trim() : null;

            if (!blPath && !apPath && !cpPath && !cscPath && !userdataPath) {
                alert(currentLang === 'th' ? 'กรุณาเลือกไฟล์อย่างน้อย 1 ช่อง (BL, AP, CP, CSC, USERDATA)' : 'Please select at least one firmware file (BL, AP, CP, CSC, USERDATA).');
                return;
            }

            // Update UI to running state
            isOdinFlashing = true;
            odinBtnStart.style.display = 'none';
            if (odinBtnStop) odinBtnStop.style.display = 'flex';
            if (odinLog) odinLog.innerHTML = '';
            odinPartLines = {};

            // Initialize progress bars
            if (odinProgressLabel) {
                odinProgressLabel.textContent = 'Initializing...';
                odinProgressLabel.style.color = 'var(--text-color)';
            }
            if (odinProgressPct) odinProgressPct.textContent = '0%';
            if (odinProgressBar) {
                odinProgressBar.style.width = '0%';
                odinProgressBar.style.background = 'linear-gradient(90deg, #00c853, #69f0ae)';
            }

            // Route to right-panel Log Console
            openModal('Samsung Odin: Flash Firmware (Native)');
            const panelTerminal = document.getElementById('mobile-panel-terminal');
            if (panelTerminal) panelTerminal.innerHTML = '';

            const lblCurrPart = document.getElementById('spd-lbl-curr-part');
            const lblCurrPct = document.getElementById('spd-lbl-curr-pct');
            const barCurrFill = document.getElementById('spd-bar-curr-fill');
            const lblTotalSpeed = document.getElementById('spd-lbl-total-speed');
            const lblTotalPct = document.getElementById('spd-lbl-total-pct');
            const barTotalFill = document.getElementById('spd-bar-total-fill');

            if (lblCurrPart) lblCurrPart.textContent = 'พาร์ติชัน: เริ่มต้นเชื่อมต่อ Samsung Download Mode...';
            if (lblCurrPct) lblCurrPct.textContent = '0%';
            if (barCurrFill) {
                barCurrFill.style.width = '0%';
                barCurrFill.style.background = 'linear-gradient(90deg, #0284c7, #38bdf8)';
            }
            if (lblTotalSpeed) lblTotalSpeed.textContent = 'ความคืบหน้ารวม: กำลังเตรียมไฟล์...';
            if (lblTotalPct) lblTotalPct.textContent = '0%';
            if (barTotalFill) {
                barTotalFill.style.width = '0%';
                barTotalFill.style.background = 'linear-gradient(90deg, #059669, #10b981, #34d399)';
            }

            const flashParams = {
                bl: blPath,
                ap: apPath,
                cp: cpPath,
                csc: cscPath,
                userdata: userdataPath,
                reboot: odinOptReboot ? odinOptReboot.checked : true,
                repartition: odinOptNand ? odinOptNand.checked : false
            };

            try {
                const res = await window.api.runOdinFlash(flashParams);
                const isSuccess = res && (res === true || res.success === true);
                finishModal(isSuccess);
            } catch (err) {
                writeOdinLog('<OSM> Internal error: ' + err.message, '#ff5252');
                finishModal(false);
            } finally {
                isOdinFlashing = false;
                odinBtnStart.style.display = 'flex';
                if (odinBtnStop) odinBtnStop.style.display = 'none';
            }
        });
    }

    const odinBtnZadig = document.getElementById('odin-btn-zadig');
    if (odinBtnZadig) {
        odinBtnZadig.addEventListener('click', () => {
            window.api.openZadig();
        });
    }

    if (window.api.onOdinLog) {
        window.api.onOdinLog((msg, color) => {
            writeOdinLog(msg, color);
        });
    }

    // Samsung 350K 1-Click Tool Integration
    const odinBtnRebootDl = document.getElementById('odin-btn-reboot-dl');
    const odinBtnRebootPhone = document.getElementById('odin-btn-reboot-phone');
    const odinBtnScanSam = document.getElementById('odin-btn-scan-sam');
    const odinSamPortStatus = document.getElementById('odin-sam-port-status');

    async function checkSamsungModemPort(showLog = false) {
        try {
            if (odinSamPortStatus) odinSamPortStatus.textContent = 'Scanning...';
            const res = await window.api.samsung350kScan();
            if (res && res.best_samsung) {
                const p = res.best_samsung;
                const label = p.mode === 'download' ? 'Download Mode' : (p.mode === 'preloader' ? 'MTK Preloader' : 'Samsung Modem');
                if (odinSamPortStatus) {
                    odinSamPortStatus.textContent = `${p.port} (${label})`;
                    odinSamPortStatus.style.color = '#00e676';
                }
                const comStatus = document.getElementById('odin-com-status');
                if (comStatus) {
                    comStatus.textContent = `[${p.port}]`;
                    comStatus.style.color = '#00e5ff';
                }
                const comDesc = document.getElementById('odin-com-desc');
                if (comDesc) {
                    comDesc.textContent = p.description || label;
                }
                const comCard = document.getElementById('odin-com-card');
                if (comCard) {
                    comCard.style.borderColor = '#00e5ff';
                    comCard.style.background = 'rgba(0, 229, 255, 0.08)';
                }
                if (showLog) writeOdinLog(`<OSM> Detected: ${p.port} - ${p.description}`, '#00e676');
                return p.port;
            } else {
                if (odinSamPortStatus) {
                    odinSamPortStatus.textContent = 'Modem: Not Connected';
                    odinSamPortStatus.style.color = '#ff9800';
                }
                const comStatus = document.getElementById('odin-com-status');
                if (comStatus && comStatus.textContent !== 'PASS!' && comStatus.textContent !== 'FAIL') {
                    comStatus.textContent = '[ ]';
                    comStatus.style.color = '#94a3b8';
                }
                const comDesc = document.getElementById('odin-com-desc');
                if (comDesc && comDesc.textContent !== 'Flashing...') {
                    comDesc.textContent = 'No device';
                }
                const comCard = document.getElementById('odin-com-card');
                if (comCard) {
                    comCard.style.borderColor = 'rgba(255, 255, 255, 0.1)';
                    comCard.style.background = 'rgba(255, 255, 255, 0.03)';
                }
                if (showLog) writeOdinLog('<OSM> Samsung port not detected. Connect device via USB.', '#ff9800');
                return null;
            }
        } catch (err) {
            if (odinSamPortStatus) {
                odinSamPortStatus.textContent = 'Modem: Auto';
                odinSamPortStatus.style.color = '#aaa';
            }
            return null;
        }
    }

    if (odinBtnScanSam) {
        odinBtnScanSam.addEventListener('click', () => checkSamsungModemPort(true));
    }
    setTimeout(() => {
        checkSamsungModemPort(false);
    }, 1500);

    if (window.api.onSamsung350kLog) {
        window.api.onSamsung350kLog((line) => {
            let color = '#ccc';
            if (line.includes('Done')) color = '#00e676';
            else if (line.includes('Not found') || line.includes('Error')) color = '#ff5252';
            else if (line.includes('Connecting') || line.includes('SAMSUNG Mobile')) color = '#00e5ff';
            else if (line.includes('Scanning')) color = '#9e9e9e';
            writeOdinLog(`<OSM> ${line}`, color);
        });
    }

    if (odinBtnRebootDl) {
        odinBtnRebootDl.addEventListener('click', async () => {
            odinLog.innerHTML = '';
            writeOdinLog('<OSM> === Samsung 350K: Enter Download Mode ===', '#00e5ff');
            odinBtnRebootDl.disabled = true;
            try {
                const res = await window.api.samsung350kAction({ action: 'download' });
                if (res.success) {
                    writeOdinLog('<OSM> Success! Device switching to Download Mode...', '#00e676');
                } else {
                    writeOdinLog('<OSM> Device not responding. Make sure USB cable is plugged in.', '#ffa726');
                    writeOdinLog('<OSM> 💡 คำแนะนำ: ในโทรศัพท์กด *#0*# ในหน้าโทรฉุกเฉินเพื่อปลดล็อกพอร์ต หรือ ปิดเครื่องแล้วกด Vol Up + Vol Down ค้างไว้แล้วเสียบสาย USB', '#ffca28');
                }

            } catch (e) {
                if (e.message && e.message.includes('No handler registered')) {
                    writeOdinLog('<OSM> ⚠️ กรุณาปิดโปรแกรมแล้วเปิดใหม่อีกครั้ง (Restart App) เพื่อให้ระบบโหลดคำสั่งใหม่', '#ffca28');
                } else {
                    writeOdinLog('<OSM> Error: ' + e.message, '#ff5252');
                }
            } finally {
                odinBtnRebootDl.disabled = false;
                setTimeout(checkSamsungModemPort, 2000);
            }
        });
    }

    if (odinBtnRebootPhone) {
        odinBtnRebootPhone.addEventListener('click', async () => {
            odinLog.innerHTML = '';
            writeOdinLog('<OSM> === Samsung 350K: Reboot Phone ===', '#29b6f6');
            odinBtnRebootPhone.disabled = true;
            try {
                const res = await window.api.samsung350kAction({ action: 'reboot' });
                if (res.success) {
                    writeOdinLog('<OSM> Success! Device reboot command sent...', '#00e676');
                } else {
                    writeOdinLog('<OSM> Device not responding. Make sure USB cable is plugged in.', '#ffa726');
                }
            } catch (e) {
                if (e.message && e.message.includes('No handler registered')) {
                    writeOdinLog('<OSM> ⚠️ กรุณาปิดโปรแกรมแล้วเปิดใหม่อีกครั้ง (Restart App) เพื่อให้ระบบโหลดคำสั่งใหม่', '#ffca28');
                } else {
                    writeOdinLog('<OSM> Error: ' + e.message, '#ff5252');
                }
            } finally {
                odinBtnRebootPhone.disabled = false;
                setTimeout(checkSamsungModemPort, 2000);
            }
        });
    }


    // Poll Odin connection status
    let odinIsConnected = false;
    let odinCurrentPort = null;
    let odinCurrentMode = null;

    setInterval(async () => {
        // Only poll if odin-section is active (display is block)
        const odinSection = document.getElementById('odin-section');
        if (odinSection && odinSection.style.display !== 'none') {
            try {
                const res = await window.api.checkOdinConnection();
                const isConn = res && (typeof res === 'boolean' ? res : !!res.connected);
                const port = (res && res.port) ? res.port : 'COM';
                const pNum = (res && res.portNumber) ? res.portNumber : port.replace(/\D/g, '') || '0';
                const mode = (res && res.mode) ? res.mode : 'download';
                const desc = (res && res.description) ? res.description : '';

                const comCard = document.getElementById('odin-com-card');
                const comStatus = document.getElementById('odin-com-status');
                const comDesc = document.getElementById('odin-com-desc');

                if (isConn) {
                    const statusChanged = !odinIsConnected || odinCurrentPort !== port || odinCurrentMode !== mode;
                    odinIsConnected = true;
                    odinCurrentPort = port;
                    odinCurrentMode = mode;

                    if (comStatus) {
                        comStatus.textContent = `0:[${port}]`;
                        comStatus.style.color = '#ffffff';
                    }

                    if (mode === 'download') {
                        if (comCard) {
                            comCard.style.background = 'linear-gradient(135deg, #0284c7 0%, #00bcd4 100%)';
                            comCard.style.border = '1px solid #38bdf8';
                            comCard.style.boxShadow = '0 0 15px rgba(0, 188, 212, 0.4)';
                        }
                        if (comDesc) {
                            comDesc.textContent = '⚡ Download Mode Ready';
                            comDesc.style.color = '#e0f7fa';
                        }
                        if (statusChanged) {
                            writeOdinLog(`<OSM> <ID:0/${pNum}> Added!! Device ready in Download Mode.`, '#00e5ff');
                        }
                    } else if (mode === 'modem') {
                        if (comCard) {
                            comCard.style.background = 'linear-gradient(135deg, #0369a1 0%, #0284c7 100%)';
                            comCard.style.border = '1px solid #0ea5e9';
                            comCard.style.boxShadow = '0 0 15px rgba(2, 132, 199, 0.35)';
                        }
                        if (comDesc) {
                            comDesc.textContent = '📱 Samsung Modem Ready';
                            comDesc.style.color = '#bae6fd';
                        }
                        if (statusChanged) {
                            writeOdinLog(`<OSM> <ID:0/${pNum}> Added!! ${desc || 'SAMSUNG Mobile USB Modem'} (${port}).`, '#38bdf8');
                            writeOdinLog('<OSM> 💡 คำแนะนำ: กดปุ่ม [ 📱 Enter Download Mode ] หรือใช้วิธีกดปุ่มเพื่อเข้า Download Mode ก่อนเริ่มแฟลช', '#facc15');
                        }
                    } else if (mode === 'preloader') {
                        if (comCard) {
                            comCard.style.background = 'linear-gradient(135deg, #d97706 0%, #b45309 100%)';
                            comCard.style.border = '1px solid #f59e0b';
                            comCard.style.boxShadow = '0 0 15px rgba(245, 158, 11, 0.3)';
                        }
                        if (comDesc) {
                            comDesc.textContent = '⚡ MTK Preloader Port';
                            comDesc.style.color = '#fef3c7';
                        }
                        if (statusChanged) {
                            writeOdinLog(`<OSM> <ID:0/${pNum}> Added!! MediaTek Preloader Port (${port}).`, '#f59e0b');
                        }
                    } else {
                        if (comCard) {
                            comCard.style.background = 'linear-gradient(135deg, #1e293b 0%, #334155 100%)';
                            comCard.style.border = '1px solid #64748b';
                            comCard.style.boxShadow = 'none';
                        }
                        if (comDesc) {
                            comDesc.textContent = desc || port;
                            comDesc.style.color = '#94a3b8';
                        }
                        if (statusChanged) {
                            writeOdinLog(`<OSM> <ID:0/${pNum}> Added!! Device connected (${port}).`, '#94a3b8');
                        }
                    }

                    // Keep Samsung 350K status bar synchronized
                    if (odinSamPortStatus) {
                        const label = mode === 'download' ? 'Download Mode' : (mode === 'preloader' ? 'MTK Preloader' : 'Samsung Modem');
                        odinSamPortStatus.textContent = `${port} (${label})`;
                        odinSamPortStatus.style.color = '#00e676';
                    }
                } else if (!isConn && odinIsConnected) {
                    const lastPNum = odinCurrentPort ? odinCurrentPort.replace(/\D/g, '') || '0' : '0';
                    odinIsConnected = false;
                    odinCurrentPort = null;
                    odinCurrentMode = null;

                    if (comStatus) {
                        comStatus.textContent = '[ ]';
                        comStatus.style.color = '#94a3b8';
                    }
                    if (comCard) {
                        comCard.style.background = 'rgba(255, 255, 255, 0.03)';
                        comCard.style.border = '1px solid rgba(255, 255, 255, 0.1)';
                        comCard.style.boxShadow = 'none';
                    }
                    if (comDesc) {
                        comDesc.textContent = 'No device';
                        comDesc.style.color = '#64748b';
                    }
                    writeOdinLog(`<OSM> <ID:0/${lastPNum}> Removed!!`, '#aaa');

                    if (odinSamPortStatus) {
                        odinSamPortStatus.textContent = 'Modem: Not Connected';
                        odinSamPortStatus.style.color = '#ff9800';
                    }
                }
            } catch (e) {
                // Ignore silent errors during polling
            }
        }
    }, 2000);

    const btnApplyRm = document.getElementById('btn-apply-rm');
    if (btnApplyRm) {
        btnApplyRm.addEventListener('click', async () => {
            const originalText = btnApplyRm.textContent;
            btnApplyRm.textContent = 'Applying...';
            btnApplyRm.disabled = true;
            try {
                const success = await window.api.applyRainmeterSkins();
                if (success) {
                    btnApplyRm.textContent = 'Applied & Refreshed!';
                    btnApplyRm.style.background = '#00c853';
                } else {
                    btnApplyRm.textContent = 'Failed';
                    btnApplyRm.style.background = '#ff5252';
                }
            } catch (e) {
                btnApplyRm.textContent = 'Error';
            }
            setTimeout(() => {
                btnApplyRm.textContent = originalText;
                btnApplyRm.style.background = '';
                btnApplyRm.disabled = false;
            }, 3000);
        });
    }

    const btnDlRm = document.getElementById('btn-dl-rm');
    if (btnDlRm) {
        btnDlRm.addEventListener('click', () => {
            window.api.downloadRainmeter();
        });
    }

    const btnApplyRmFull = document.getElementById('btn-apply-rm-full');
    if (btnApplyRmFull) {
        btnApplyRmFull.addEventListener('click', async () => {
            const originalText = btnApplyRmFull.textContent;
            btnApplyRmFull.textContent = 'Applying...';
            btnApplyRmFull.disabled = true;
            try {
                const success = await window.api.applyRainmeterFull();
                if (success) {
                    btnApplyRmFull.textContent = 'Applied & Refreshed!';
                    btnApplyRmFull.style.background = '#00c853';
                } else {
                    btnApplyRmFull.textContent = 'Failed';
                    btnApplyRmFull.style.background = '#ff5252';
                }
            } catch (e) {
                btnApplyRmFull.textContent = 'Error';
            }
            setTimeout(() => {
                btnApplyRmFull.textContent = originalText;
                btnApplyRmFull.style.background = '';
                btnApplyRmFull.disabled = false;
            }, 3000);
        });
    }

    // ============================================================
    // ROM & FIRMWARE WORKSTATION LOGIC
    // ============================================================
    (function initRomWorkstation() {
        const romSection = document.getElementById('rom-section');
        if (!romSection) return;

        // Subtab Navigation
        const subtabBtns = document.querySelectorAll('.rom-subtab-btn');
        const subtabContents = document.querySelectorAll('.rom-subtab-content');

        function switchRomSubtab(targetId) {
            subtabBtns.forEach(b => {
                if (b.dataset.subtab === targetId) {
                    b.classList.add('active');
                    b.style.background = '#3b82f6';
                    b.style.color = '#fff';
                    b.style.fontWeight = '600';
                } else {
                    b.classList.remove('active');
                    b.style.background = 'transparent';
                    b.style.color = '#94a3b8';
                    b.style.fontWeight = '500';
                }
            });
            subtabContents.forEach(c => {
                c.style.display = (c.id === targetId) ? 'block' : 'none';
            });

            // Auto-fetch Apple devices if switching to Apple tab and empty
            if (targetId === 'rom-tab-apple') {
                if (typeof ensureAppleDevicesLoaded === 'function') ensureAppleDevicesLoaded();
                if (typeof refreshConnectedIosDevice === 'function') refreshConnectedIosDevice();
                if (typeof startIosPolling === 'function') startIosPolling();
            } else {
                if (typeof stopIosPolling === 'function') stopIosPolling();
            }
        }

        subtabBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                switchRomSubtab(btn.dataset.subtab);
            });
        });

        // ------------------------------------------------------------
        // 1. In-App Download Manager & Streaming Engine
        // ------------------------------------------------------------
        let configuredSaveDir = '';
        const activeDownloads = new Map(); // id -> item
        const downloadHistory = [];

        const romDlDestPath = document.getElementById('rom-dl-dest-path');
        const btnRomChangeDest = document.getElementById('btn-rom-change-dest');
        const btnRomOpenDest = document.getElementById('btn-rom-open-dest');
        const romActiveCardContainer = document.getElementById('rom-active-dl-card-container');
        const romNoActiveDownloads = document.getElementById('rom-no-active-downloads');
        const romActiveTasksCount = document.getElementById('rom-active-tasks-count');
        const romStatusLed = document.getElementById('rom-status-led');
        const romStatusText = document.getElementById('rom-status-text');
        const romActiveBadge = document.getElementById('rom-active-badge');
        const romDlHistoryContainer = document.getElementById('rom-dl-history-container');
        const btnClearDlHistory = document.getElementById('btn-clear-dl-history');

        if (romDlDestPath) {
            configuredSaveDir = '';
            romDlDestPath.value = 'กำลังตรวจสอบโฟลเดอร์ดาวน์โหลด...';
        }

        async function initStoragePath() {
            try {
                if (window.api && window.api.getDefaultDownloadsDir) {
                    const defaultPath = await window.api.getDefaultDownloadsDir();
                    if (defaultPath) {
                        configuredSaveDir = defaultPath;
                        if (romDlDestPath) {
                            romDlDestPath.value = defaultPath;
                        }
                    }
                }
            } catch (e) {
                console.error('Failed to get default downloads dir:', e);
            }
            if (!configuredSaveDir && romDlDestPath) {
                romDlDestPath.value = 'Downloads';
            }
        }
        initStoragePath();

        if (btnRomChangeDest) {
            btnRomChangeDest.addEventListener('click', async () => {
                if (!window.api || !window.api.browseSaveFolder) return;
                const chosen = await window.api.browseSaveFolder();
                if (chosen) {
                    configuredSaveDir = chosen;
                    romDlDestPath.value = chosen;
                }
            });
        }

        if (btnRomOpenDest) {
            btnRomOpenDest.addEventListener('click', async () => {
                const origHtml = btnRomOpenDest.innerHTML;
                btnRomOpenDest.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังเปิด...';
                try {
                    if (window.api && window.api.openFileLocation) {
                        const target = configuredSaveDir || (romDlDestPath && romDlDestPath.value && romDlDestPath.value !== 'Downloads' && !romDlDestPath.value.includes('...') ? romDlDestPath.value : '');
                        const res = await window.api.openFileLocation(target);
                        if (res && res.success) {
                            btnRomOpenDest.innerHTML = '<i class="fas fa-check" style="color: #22c55e;"></i> เปิดแล้ว!';
                        } else {
                            btnRomOpenDest.innerHTML = '<i class="fas fa-folder-open"></i> เปิดโฟลเดอร์';
                        }
                    }
                } catch (err) {
                    console.error('Error opening save destination:', err);
                }
                setTimeout(() => {
                    btnRomOpenDest.innerHTML = origHtml;
                }, 1500);
            });
        }

        function formatBytes(bytes) {
            if (!bytes || bytes === 0) return '0 B';
            const k = 1024;
            const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        }

        function updateTopStatus() {
            const activeCount = [...activeDownloads.values()].filter(d => d.status === 'downloading').length;
            if (romActiveBadge) {
                if (activeCount > 0) {
                    romActiveBadge.textContent = activeCount;
                    romActiveBadge.style.display = 'inline-block';
                } else {
                    romActiveBadge.style.display = 'none';
                }
            }
            if (romActiveTasksCount) {
                romActiveTasksCount.textContent = `${activeCount} กำลังทำงาน`;
            }
            if (romStatusLed && romStatusText) {
                if (activeCount > 0) {
                    romStatusLed.style.color = '#38bdf8';
                    romStatusText.textContent = `กำลังดาวน์โหลด (${activeCount} ไฟล์)...`;
                } else {
                    romStatusLed.style.color = '#22c55e';
                    romStatusText.textContent = 'พร้อมใช้งาน (Idle)';
                }
            }
        }

        function renderActiveCard(item) {
            let card = document.getElementById(`dl-card-${item.id}`);
            if (!card) {
                card = document.createElement('div');
                card.id = `dl-card-${item.id}`;
                card.style.background = 'rgba(15, 23, 42, 0.7)';
                card.style.border = '1px solid rgba(255, 255, 255, 0.1)';
                card.style.borderRadius = '10px';
                card.style.padding = '14px 16px';
                card.style.display = 'flex';
                card.style.flexDirection = 'column';
                card.style.gap = '10px';
                if (romActiveCardContainer) {
                    romActiveCardContainer.appendChild(card);
                }
            }

            if (romNoActiveDownloads) romNoActiveDownloads.style.display = 'none';

            let statusBadge = `<span style="font-size: 11px; background: rgba(56,189,248,0.2); color: #38bdf8; padding: 2px 8px; border-radius: 4px;">กำลังโหลด</span>`;
            if (item.status === 'completed') {
                statusBadge = `<span style="font-size: 11px; background: rgba(34,197,94,0.2); color: #22c55e; padding: 2px 8px; border-radius: 4px; font-weight: 600;">สำเร็จ (Done)</span>`;
            } else if (item.status === 'error') {
                statusBadge = `<span style="font-size: 11px; background: rgba(239,68,68,0.2); color: #ef4444; padding: 2px 8px; border-radius: 4px; font-weight: 600;">ล้มเหลว</span>`;
            } else if (item.status === 'cancelled') {
                statusBadge = `<span style="font-size: 11px; background: rgba(148,163,184,0.2); color: #94a3b8; padding: 2px 8px; border-radius: 4px;">ยกเลิกแล้ว</span>`;
            }

            const transferredText = item.total > 0 ? `${formatBytes(item.downloaded)} / ${formatBytes(item.total)}` : formatBytes(item.downloaded);

            let actionButtons = '';
            if (item.status === 'downloading') {
                actionButtons = `
                    <button class="action-btn danger-btn btn-dl-cancel" data-id="${item.id}" style="padding: 6px 12px; font-size: 11px;">
                        <i class="fas fa-stop"></i> ยกเลิก
                    </button>
                `;
            } else if (item.status === 'completed') {
                actionButtons = `
                    <button class="action-btn safe-btn btn-dl-openfile" data-path="${item.savePath || ''}" style="padding: 6px 12px; font-size: 11px;">
                        <i class="fas fa-play"></i> เปิดไฟล์
                    </button>
                    <button class="action-btn btn-dl-openfolder" data-path="${item.savePath || ''}" style="padding: 6px 12px; font-size: 11px; background: rgba(255,255,255,0.08); color: #fff;">
                        <i class="fas fa-folder"></i> แสดงในโฟลเดอร์
                    </button>
                `;
            }

            card.innerHTML = `
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div style="display: flex; align-items: center; gap: 8px; overflow: hidden; max-width: 75%;">
                        <i class="fas fa-file-arrow-down" style="color: #a78bfa; font-size: 14px;"></i>
                        <span style="font-weight: 600; font-size: 13px; color: #f8fafc; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${item.filename}">${item.filename}</span>
                    </div>
                    <div>${statusBadge}</div>
                </div>

                <div style="width: 100%; height: 7px; background: rgba(0,0,0,0.4); border-radius: 4px; overflow: hidden;">
                    <div style="width: ${item.percent}%; height: 100%; background: ${item.status === 'completed' ? '#22c55e' : (item.status === 'error' ? '#ef4444' : 'linear-gradient(90deg, #3b82f6, #a78bfa)')}; transition: width 0.2s linear;"></div>
                </div>

                <div style="display: flex; justify-content: space-between; align-items: center; font-size: 11px; color: #94a3b8; flex-wrap: wrap; gap: 8px;">
                    <div style="display: flex; gap: 12px; align-items: center;">
                        <span style="color: #38bdf8; font-weight: 700;">${item.percent}%</span>
                        <span>${transferredText}</span>
                        ${item.status === 'downloading' ? `<span>⚡ ${item.speed || '0.00 MB/s'}</span> <span>⏳ เหลือ ~${item.eta || '--'}</span>` : ''}
                        ${item.error ? `<span style="color: #ef4444;">${item.error}</span>` : ''}
                    </div>
                    <div style="display: flex; gap: 6px;">
                        ${actionButtons}
                    </div>
                </div>
            `;

            const cancelBtn = card.querySelector('.btn-dl-cancel');
            if (cancelBtn) {
                cancelBtn.addEventListener('click', () => {
                    if (window.api && window.api.cancelFileDownload) {
                        window.api.cancelFileDownload(item.id);
                    }
                });
            }

            const openFileBtn = card.querySelector('.btn-dl-openfile');
            if (openFileBtn) {
                openFileBtn.addEventListener('click', async () => {
                    const orig = openFileBtn.innerHTML;
                    openFileBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังเปิด...';
                    if (window.api && window.api.openFile) {
                        const res = await window.api.openFile(openFileBtn.dataset.path);
                        if (!res || !res.success) {
                            if (window.api.openFileLocation) {
                                await window.api.openFileLocation(openFileBtn.dataset.path);
                            }
                        }
                    }
                    setTimeout(() => { openFileBtn.innerHTML = orig; }, 1200);
                });
            }

            const openFolderBtn = card.querySelector('.btn-dl-openfolder');
            if (openFolderBtn) {
                openFolderBtn.addEventListener('click', async () => {
                    const orig = openFolderBtn.innerHTML;
                    openFolderBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังเปิด...';
                    if (window.api && window.api.openFileLocation) {
                        await window.api.openFileLocation(openFolderBtn.dataset.path);
                    }
                    setTimeout(() => { openFolderBtn.innerHTML = orig; }, 1200);
                });
            }
        }

        async function triggerFileDownload(url, filename) {
            if (!url) {
                alert('กรุณาระบุ URL ที่ต้องการดาวน์โหลด');
                return;
            }

            const dlId = 'dl_' + Date.now() + '_' + Math.floor(Math.random() * 1000);
            const initialItem = {
                id: dlId,
                filename: filename || url.split('/').pop() || 'firmware_download.bin',
                url,
                savePath: '',
                percent: 0,
                speed: '0.00 MB/s',
                eta: '--',
                downloaded: 0,
                total: 0,
                status: 'downloading'
            };

            activeDownloads.set(dlId, initialItem);
            switchRomSubtab('rom-tab-downloader');
            renderActiveCard(initialItem);
            updateTopStatus();

            try {
                if (window.api && window.api.startFileDownload) {
                    const res = await window.api.startFileDownload({
                        id: dlId,
                        url,
                        filename: initialItem.filename,
                        saveDir: configuredSaveDir
                    });

                    if (!res || !res.success) {
                        initialItem.status = 'error';
                        initialItem.error = (res && res.error) ? res.error : 'Failed to start download';
                        renderActiveCard(initialItem);
                        updateTopStatus();
                    } else {
                        initialItem.savePath = res.savePath;
                    }
                }
            } catch (err) {
                initialItem.status = 'error';
                initialItem.error = err.message;
                renderActiveCard(initialItem);
                updateTopStatus();
            }
        }

        if (window.api && window.api.onDownloadProgress) {
            window.api.onDownloadProgress((data) => {
                const item = activeDownloads.get(data.id);
                if (item) {
                    item.percent = data.percent;
                    item.downloaded = data.downloadedBytes;
                    item.total = data.totalBytes;
                    item.speed = data.speed;
                    item.eta = data.eta;
                    item.status = data.status || 'downloading';
                    renderActiveCard(item);
                    updateTopStatus();
                }
            });
        }

        if (window.api && window.api.onDownloadComplete) {
            window.api.onDownloadComplete((data) => {
                const item = activeDownloads.get(data.id);
                if (item) {
                    item.status = data.status || (data.success ? 'completed' : 'error');
                    if (data.filePath) item.savePath = data.filePath;
                    if (data.filename) item.filename = data.filename;
                    if (data.totalBytes) item.downloaded = data.totalBytes;
                    if (data.error) item.error = data.error;
                    if (data.success) item.percent = 100;
                    renderActiveCard(item);
                    updateTopStatus();

                    downloadHistory.unshift({
                        filename: item.filename,
                        savePath: item.savePath,
                        status: item.status,
                        time: new Date().toLocaleTimeString(),
                        size: item.total || item.downloaded
                    });
                    renderHistory();
                }
            });
        }

        function renderHistory() {
            if (!romDlHistoryContainer) return;
            romDlHistoryContainer.innerHTML = '';
            if (downloadHistory.length === 0) {
                romDlHistoryContainer.innerHTML = '<div style="text-align: center; padding: 14px;">ยังไม่มีประวัติการดาวน์โหลด</div>';
                return;
            }
            downloadHistory.slice(0, 10).forEach(h => {
                const row = document.createElement('div');
                row.style.display = 'flex';
                row.style.justifyContent = 'space-between';
                row.style.alignItems = 'center';
                row.style.background = 'rgba(0,0,0,0.2)';
                row.style.padding = '8px 12px';
                row.style.borderRadius = '6px';
                row.style.border = '1px solid rgba(255,255,255,0.04)';
                row.innerHTML = `
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <i class="fas ${h.status === 'completed' ? 'fa-check-circle' : 'fa-times-circle'}" style="color: ${h.status === 'completed' ? '#22c55e' : '#ef4444'};"></i>
                        <span style="color: #e2e8f0; font-weight: 500;">${h.filename}</span>
                        <span style="color: #64748b; font-size: 10px;">(${formatBytes(h.size)})</span>
                    </div>
                    <div style="display: flex; gap: 8px; align-items: center;">
                        <span style="color: #64748b; font-size: 11px;">${h.time}</span>
                        ${h.status === 'completed' ? `<button class="action-btn btn-history-open" data-path="${h.savePath}" style="background: rgba(255,255,255,0.06); padding: 4px 8px; font-size: 10px; color: #38bdf8;">เปิดโฟลเดอร์</button>` : ''}
                    </div>
                `;
                const btn = row.querySelector('.btn-history-open');
                if (btn) {
                    btn.addEventListener('click', async () => {
                        const orig = btn.innerHTML;
                        btn.innerHTML = '<i class="fas fa-check" style="color: #22c55e;"></i> เปิดแล้ว';
                        if (window.api && window.api.openFileLocation) {
                            await window.api.openFileLocation(btn.dataset.path);
                        }
                        setTimeout(() => { btn.innerHTML = orig; }, 1200);
                    });
                }
                romDlHistoryContainer.appendChild(row);
            });
        }

        if (btnClearDlHistory) {
            btnClearDlHistory.addEventListener('click', () => {
                downloadHistory.length = 0;
                renderHistory();
            });
        }

        const btnStartCustomDl = document.getElementById('btn-start-custom-dl');
        const romCustomUrlInput = document.getElementById('rom-custom-url-input');
        const romCustomFilenameInput = document.getElementById('rom-custom-filename-input');

        if (btnStartCustomDl) {
            btnStartCustomDl.addEventListener('click', () => {
                const url = romCustomUrlInput ? romCustomUrlInput.value.trim() : '';
                const filename = romCustomFilenameInput ? romCustomFilenameInput.value.trim() : '';
                if (!url) {
                    alert('กรุณาระบุ URL ที่ถูกต้อง');
                    return;
                }
                triggerFileDownload(url, filename);
                if (romCustomUrlInput) romCustomUrlInput.value = '';
                if (romCustomFilenameInput) romCustomFilenameInput.value = '';
            });
        }

        // ------------------------------------------------------------
        // 2. Android Firmware Hub
        // ------------------------------------------------------------
        const romBrandDropdown = document.getElementById('rom-brand-dropdown');
        const romModelSearch = document.getElementById('rom-model-search');
        const romModelList = document.getElementById('rom-model-list');
        const androidSelectedBrandBadge = document.getElementById('android-selected-brand-badge');
        const androidSelectedChipBadge = document.getElementById('android-selected-chip-badge');
        const androidSelectedTitle = document.getElementById('android-selected-title');
        const androidSelectedCsc = document.getElementById('android-selected-csc');
        const androidTipsText = document.getElementById('android-tips-text');
        const btnPortalPrimary = document.getElementById('btn-portal-primary');
        const btnPortalPrimaryTitle = document.getElementById('btn-portal-primary-title');
        const btnPortalPrimaryDesc = document.getElementById('btn-portal-primary-desc');
        const btnPortalSecondary = document.getElementById('btn-portal-secondary');
        const btnPortalSecondaryTitle = document.getElementById('btn-portal-secondary-title');
        const btnPortalSecondaryDesc = document.getElementById('btn-portal-secondary-desc');
        const btnPortalFrp = document.getElementById('btn-portal-frp');
        const btnPortalRecovery = document.getElementById('btn-portal-recovery');
        const androidCountLabel = document.getElementById('android-count-label');

        const brandModelsDatabase = {
            'SAMSUNG': [
                'SM-S928B (Galaxy S24 Ultra)', 'SM-S926B (Galaxy S24+)', 'SM-S921B (Galaxy S24)',
                'SM-S918B (Galaxy S23 Ultra)', 'SM-S916B (Galaxy S23+)', 'SM-S911B (Galaxy S23)',
                'SM-S908B (Galaxy S22 Ultra)', 'SM-S906B (Galaxy S22+)', 'SM-S901B (Galaxy S22)',
                'SM-G998B (Galaxy S21 Ultra 5G)', 'SM-G996B (Galaxy S21+ 5G)', 'SM-G991B (Galaxy S21 5G)',
                'SM-G781B (Galaxy S20 FE 5G)', 'SM-G780G (Galaxy S20 FE LTE)',
                'SM-F946B (Galaxy Z Fold 5)', 'SM-F731B (Galaxy Z Flip 5)',
                'SM-F936B (Galaxy Z Fold 4)', 'SM-F721B (Galaxy Z Flip 4)',
                'SM-A556E (Galaxy A55 5G)', 'SM-A546E (Galaxy A54 5G)', 'SM-A536E (Galaxy A53 5G)', 'SM-A528B (Galaxy A52s 5G)', 'SM-A525F (Galaxy A52)', 'SM-A515F (Galaxy A51)', 'SM-A505F (Galaxy A50)',
                'SM-A356E (Galaxy A35 5G)', 'SM-A346E (Galaxy A34 5G)', 'SM-A336E (Galaxy A33 5G)', 'SM-A325F (Galaxy A32)', 'SM-A315F (Galaxy A31)', 'SM-A305F (Galaxy A30)',
                'SM-A256E (Galaxy A25 5G)', 'SM-A245F (Galaxy A24)', 'SM-A235F (Galaxy A23)', 'SM-A225F (Galaxy A22)', 'SM-A217F (Galaxy A21s)', 'SM-A205F (Galaxy A20)',
                'SM-A156E (Galaxy A15 5G)', 'SM-A155F (Galaxy A15 LTE)', 'SM-A146B (Galaxy A14 5G)', 'SM-A145F (Galaxy A14)', 'SM-A135F (Galaxy A13)', 'SM-A125F (Galaxy A12)', 'SM-A115F (Galaxy A11)', 'SM-A105F (Galaxy A10)',
                'SM-A057F (Galaxy A05s)', 'SM-A055F (Galaxy A05)', 'SM-A045F (Galaxy A04)', 'SM-A042F (Galaxy A04e)', 'SM-A037F (Galaxy A03s)', 'SM-A035F (Galaxy A03)', 'SM-A032F (Galaxy A03 Core)', 'SM-A025F (Galaxy A02s)', 'SM-A022F (Galaxy A02)', 'SM-A015F (Galaxy A01)',
                'SM-N986B (Galaxy Note 20 Ultra 5G)', 'SM-N980F (Galaxy Note 20)', 'SM-N975F (Galaxy Note 10+)', 'SM-N970F (Galaxy Note 10)', 'SM-N960F (Galaxy Note 9)', 'SM-N950F (Galaxy Note 8)',
                'SM-X910 (Galaxy Tab S9 Ultra)', 'SM-X810 (Galaxy Tab S9+)', 'SM-X710 (Galaxy Tab S9)', 'SM-X210 (Galaxy Tab A9+)', 'SM-X110 (Galaxy Tab A9)'
            ],
            'Xiaomi': [
                'manet (Xiaomi 13 Pro)', 'fuxi (Xiaomi 13)', 'nuwa (Xiaomi 13 Ultra)', 'corot (Xiaomi 13T Pro)', 'aristotle (Xiaomi 13T)',
                'cupid (Xiaomi 12 Pro)', 'zeus (Xiaomi 12)', 'plato (Xiaomi 12T)', 'diting (Xiaomi 12T Pro)',
                'venus (Mi 11)', 'cetus (Mi MIX Fold)', 'dipper (Mi 8)', 'cepheus (Mi 9)',
                'peridot (Poco F6)', 'manet (Poco F5 Pro)', 'marble (Poco F5)', 'munch (Poco F4)', 'alioth (Poco F3)', 'beryllium (Poco F1)',
                'duchamp (Poco X6 Pro 5G)', 'garnet (Poco X6 5G)', 'redwood (Poco X5 Pro 5G)', 'moonstone (Poco X5 5G)', 'vayu (Poco X3 Pro)', 'surya (Poco X3 NFC)',
                'gold (Redmi Note 13 5G)', 'garnet (Redmi Note 13 Pro 5G)', 'zircon (Redmi Note 13 Pro+ 5G)',
                'sunstone (Redmi Note 12 5G)', 'tapas (Redmi Note 12 4G)', 'ruby (Redmi Note 12 Pro 5G)',
                'spes (Redmi Note 11)', 'veux (Redmi Note 11 Pro 5G)', 'viva (Redmi Note 11 Pro 4G)',
                'sweet (Redmi Note 10 Pro)', 'mojito (Redmi Note 10)', 'rosemary (Redmi Note 10S)', 'camellia (Redmi Note 10 5G)',
                'merlin (Redmi Note 9)', 'joyeuse (Redmi Note 9 Pro)', 'curtana (Redmi Note 9S)',
                'ginkgo (Redmi Note 8)', 'begonia (Redmi Note 8 Pro)', 'lavender (Redmi Note 7)',
                'earth (Redmi 12 5G)', 'fire (Redmi 12 4G)', 'fog (Redmi 10C)', 'selene (Redmi 10)',
                'lancelot (Redmi 9)', 'dandelion (Redmi 9A)', 'angelica (Redmi 9C)'
            ],
            'OPPO': [
                'CPH2525 (Reno 10 Pro+ 5G)', 'CPH2531 (Reno 10 5G)', 'CPH2357 (Reno 8 Pro 5G)', 'CPH2359 (Reno 8 5G)', 'CPH2377 (Reno 7 5G)', 'CPH2145 (Reno 5 5G)', 'CPH2113 (Reno 4)', 'CPH1989 (Reno 2F)',
                'CPH2505 (Find N3 Flip)', 'CPH2499 (Find N3)', 'CPH2305 (Find X5 Pro)', 'CPH2173 (Find X3 Pro)',
                'CPH2565 (A79 5G)', 'CPH2495 (A78 5G)', 'CPH2387 (A77 5G)', 'CPH2375 (A76)', 'CPH2219 (A74)',
                'CPH2385 (A57 4G)', 'CPH2239 (A54)', 'CPH2127 (A53)', 'CPH1931 (A5 2020)', 'CPH1909 (A5s)', 'CPH1803 (A3s)',
                'CPH2477 (A17)', 'CPH2269 (A16)', 'CPH2185 (A15)', 'CPH2083 (A12)',
                'CPH1823 (F9)', 'CPH1819 (F7)', 'CPH1723 (F5)', 'CPH1601 (F1s)', 'CPH1911 (F11)', 'CPH1969 (F11 Pro)',
                'RMX3741 (Realme 11 Pro+ 5G)', 'RMX3771 (Realme 11 5G)', 'RMX3630 (Realme 10)', 'RMX3472 (Realme 9 Pro 5G)', 'RMX3511 (Realme C35)', 'RMX3501 (Realme C31)', 'RMX3261 (Realme C21Y)',
                'OnePlus 12 (CPH2581)', 'OnePlus 11 (CPH2449)', 'OnePlus 10 Pro (NE2213)', 'OnePlus 9 Pro (LE2123)', 'OnePlus Nord CE 3 Lite (CPH2493)'
            ],
            'VIVO': [
                'V2244 (V29 5G)', 'V2231 (V27 5G)', 'V2202 (V25 5G)', 'V2130 (V23 5G)', 'V2050 (V21 5G)', 'V2022 (V20)', 'V1933 (V19)', 'V1818 (V15 Pro)', 'V1819 (V15)', '1804 (V11)', '1723 (V9)', '1718 (V7)', '1601 (V5)',
                'V2246 (Y36 5G)', 'V2247 (Y36 4G)', 'V2249 (Y27 5G)', 'V2248 (Y27 4G)', 'V2204 (Y22)', 'V2111 (Y21)', 'V2027 (Y20)', 'V2034 (Y20s)', 'V2041 (Y72 5G)', '1935 (Y50)', '1915 (Y19)', '1902 (Y17)', '1901 (Y15)', '1904 (Y12)', '1906 (Y11)', '1820 (Y91C)', '1816 (Y91)', '1807 (Y95)',
                'V2241 (X90 Pro)', 'V2145 (X80 Pro)', 'V2219 (iQOO Neo 7)', 'V2230 (iQOO Z7 5G)'
            ],
            'Google': [
                'husky (Pixel 8 Pro)', 'shiba (Pixel 8)', 'akita (Pixel 8a)',
                'felix (Pixel Fold)', 'tangorpro (Pixel Tablet)',
                'cheetah (Pixel 7 Pro)', 'panther (Pixel 7)', 'lynx (Pixel 7a)',
                'raven (Pixel 6 Pro)', 'oriole (Pixel 6)', 'bluejay (Pixel 6a)',
                'redfin (Pixel 5)', 'bramble (Pixel 4a 5G)', 'sunfish (Pixel 4a)', 'coral (Pixel 4 XL)', 'flame (Pixel 4)',
                'bonito (Pixel 3a XL)', 'sargo (Pixel 3a)', 'crosshatch (Pixel 3 XL)', 'blueline (Pixel 3)'
            ],
            'Infinix': [
                'X6837 (Infinix HOT 40 Pro)', 'X6836 (Infinix HOT 40)', 'X6831 (Infinix HOT 30)', 'X669 (Infinix HOT 30i)',
                'X6711 (Infinix NOTE 30 5G)', 'X6833B (Infinix NOTE 30)', 'X676B (Infinix NOTE 12 Pro 5G)', 'X670 (Infinix NOTE 12)',
                'X6525 (Infinix SMART 8)', 'X6515 (Infinix SMART 7)',
                'BG7 (Tecno Spark 20)', 'CK8n (Tecno Camon 20 Pro 5G)', 'KJ5 (Tecno Spark 20C)',
                'S665L (itel S23)', 'A663L (itel A60s)', 'P662L (itel P40)'
            ],
            'HUAWEI': [
                'NAM-LX9 (Nova 9)', 'JNY-L22 (Nova 7i)', 'YAL-L21 (Nova 5T)', 'INE-LX2 (Nova 3i)', 'RNE-L22 (Nova 2i)',
                'STK-L22 (Y9 Prime)', 'JKM-LX2 (Y9 2019)', 'DUB-LX2 (Y7 Pro)', 'ATU-L31 (Y6 Prime)', 'DRA-LX2 (Y5 Prime)', 'CRO-L22 (Y3 2017)',
                'NOH-NX9 (Mate 40 Pro)', 'TAS-L29 (Mate 30)', 'HMA-L29 (Mate 20)', 'ALP-L29 (Mate 10)',
                'ELS-NX9 (P40 Pro)', 'ANA-NX9 (P40)', 'VOG-L29 (P30 Pro)', 'ELE-L29 (P30)', 'CLT-L29 (P20 Pro)', 'EML-L29 (P20)'
            ],
            'LG': [
                'LMV405 (V40 ThinQ)', 'H930 (V30)', 'H990 (V20)', 'H960 (V10)',
                'LMG710 (G7 ThinQ)', 'H870 (G6)', 'H850 (G5)', 'H815 (G4)', 'D855 (G3)', 'D802 (G2)', 'K420 (K10)'
            ],
            'LAVA/AIS': [
                'Iris 54 (LAVA Iris 54)', 'Iris 50 (LAVA Iris 50)', '870 (LAVA 870)', '810 (LAVA 810)', '800 (LAVA 800)', '755 (LAVA 755)', '750 (LAVA 750)', '708 (LAVA 708)', '700 (LAVA 700)', '600+ (LAVA 600+)', '600 (LAVA 600)', '565 (LAVA 565)', '560 (LAVA 560)', '550 (LAVA 550)', '515 (LAVA 515)', '512 (LAVA 512)', '510 (LAVA 510)', '505 (LAVA 505)', '504Q (LAVA 504Q)', '500 (LAVA 500)', '456 (LAVA 456)', '405+ (LAVA 405+)', '360R (LAVA 360R)', '360 (LAVA 360)', '353 (LAVA 353)', 'W5 (LAVA W5)', 'W3 (LAVA W3)', 'W1 (LAVA W1)'
            ],
            'TRUE': [
                'A1000 (Lenovo A1000)', 'A2010 (Lenovo A2010)', 'A6000 (Lenovo A6000)', 'A7000 (Lenovo A7000)', 'K52e78 (Lenovo K5 Note)', 'A6020 (Lenovo Vibe K5)', 'P2a42 (Lenovo P2)',
                'Smart 4G (True Smart 4G)', 'Smart Max (True Smart Max)', 'Smart 5.0 (True Smart 5.0)', 'Smart 4.0 (True Smart 4.0)', 'Smart 3.5 (True Smart 3.5)', 'Speedy 4.0 (True Smart 4G Speedy 4.0)', 'Octa 5.5 (True Smart 4G Octa 5.5)', 'Tab 4G (True Smart Tab 4G)'
            ],
            'WIKO': [
                'W-V600 (Jerry)', 'W-V610 (Jerry 2)', 'W-K210 (Jerry 3)', 'W-K230 (Jerry 4)', 'W-K130 (Lenny 3)', 'W-K140 (Lenny 4)', 'W-V800 (Sunny)', 'W-V820 (Sunny 2 Plus)', 'W-V830 (Sunny 3 Plus)', 'W-V500 (Tommy 3)', 'W-V510 (Tommy 3 Plus)', 'W-C200 (View)'
            ],
            'ZTE/DTAC': [
                'Blade A3 (ZTE Blade A3)', 'Blade A5 (ZTE Blade A5)', 'Blade A7 (ZTE Blade A7)', 'Blade V9 (ZTE Blade V9)', 'Blade V10 (ZTE Blade V10)',
                'M1 (Dtac Phone M1)', 'M2 (Dtac Phone M2)', 'T3 (Dtac Phone T3)', 'X3 (Dtac Phone X3)'
            ],
            'ACER': [
                'Z150 (Liquid Z5)', 'Z500 (Liquid Z500)', 'T09 (Liquid Z6)', 'S55 (Liquid Jade)', 'A1-713 (Iconia Tab 7)', 'A1-840 (Iconia Tab 8)', 'E39 (Liquid E700)', 'T01 (Liquid Z330)', 'T02 (Liquid Z520)', 'T03 (Liquid Z630)'
            ],
            'ASTON': [
                'Aston A1', 'Aston Pro', 'Aston Idea', 'Aston Thunder', 'Aston X', 'Aston Infinite', 'Aston Ultimate', 'Aston A8',
                'Aplus A1', 'Aplus A2', 'Aplus G9', 'Aplus R11', 'Aplus V5', 'Aplus V7', 'Aplus X1', 'Aplus X2', 'Aplus Z5',
                'SKG A1', 'SKG A8', 'SKG G1', 'SKG G2', 'SKG G3', 'SKG S1', 'SKG V3'
            ]
        };

        function populateAndroidModels() {
            if (!romBrandDropdown || !romModelList) return;
            const brand = romBrandDropdown.value;
            const models = brandModelsDatabase[brand] || [];
            const searchKeyword = (romModelSearch ? romModelSearch.value.trim().toLowerCase() : '');

            romModelList.innerHTML = '';
            let matchCount = 0;

            models.forEach(m => {
                if (!searchKeyword || m.toLowerCase().includes(searchKeyword)) {
                    const opt = document.createElement('option');
                    opt.value = m;
                    opt.textContent = m;
                    romModelList.appendChild(opt);
                    matchCount++;
                }
            });

            if (matchCount === 0) {
                const emptyOpt = document.createElement('option');
                emptyOpt.value = '';
                emptyOpt.textContent = '-- ไม่พบชื่อรุ่นที่ค้นหา --';
                emptyOpt.disabled = true;
                romModelList.appendChild(emptyOpt);
            } else {
                romModelList.selectedIndex = 0;
                updateSelectedAndroidModel();
            }

            if (androidCountLabel) {
                androidCountLabel.textContent = `${matchCount} รุ่นพร้อมใช้งาน`;
            }
        }

        function updateSelectedAndroidModel() {
            if (!romBrandDropdown || !romModelList) return;
            const brand = romBrandDropdown.value;
            const model = romModelList.value;
            if (!model) return;

            if (androidSelectedBrandBadge) androidSelectedBrandBadge.textContent = brand;
            if (androidSelectedTitle) androidSelectedTitle.textContent = model;

            let cleanModel = model;
            if (cleanModel.includes('(')) {
                cleanModel = cleanModel.split('(')[0].trim();
            }

            if (brand === 'SAMSUNG') {
                if (androidSelectedCsc) androidSelectedCsc.textContent = 'THL (Thailand Official)';
                if (androidSelectedChipBadge) androidSelectedChipBadge.textContent = 'Odin 4-Files (AP/BL/CP/CSC)';
                if (androidTipsText) {
                    androidTipsText.textContent = 'Samsung: ใช้โปรแกรม Odin Flasher ใส่ไฟล์ครบ 4 ช่อง (BL, AP, CP, CSC_THL). เข้า Download Mode โดยปิดเครื่อง แล้วกดปุ่ม Volume Up + Volume Down ค้างไว้พร้อมเสียบสาย Type-C เข้า PC';
                }
                if (btnPortalPrimaryTitle) btnPortalPrimaryTitle.textContent = 'SamFW Direct Download';
                if (btnPortalPrimaryDesc) btnPortalPrimaryDesc.textContent = `เปิดหน้ารหัสรุ่น ${cleanModel} (THL)`;
                if (btnPortalPrimary) {
                    btnPortalPrimary.onclick = () => {
                        window.api.openExternalUrl(`https://samfw.com/firmware/${cleanModel}/THL`);
                    };
                }
                if (btnPortalSecondaryTitle) btnPortalSecondaryTitle.textContent = 'SamMobile Mirror';
                if (btnPortalSecondaryDesc) btnPortalSecondaryDesc.textContent = `สำรองรอมศูนย์ Galaxy ${cleanModel}`;
                if (btnPortalSecondary) {
                    btnPortalSecondary.onclick = () => {
                        window.api.openExternalUrl(`https://www.sammobile.com/samsung/firmware/`);
                    };
                }
            } else if (brand === 'Xiaomi') {
                if (androidSelectedCsc) androidSelectedCsc.textContent = 'Global / EEA / ID';
                if (androidSelectedChipBadge) androidSelectedChipBadge.textContent = 'Fastboot (.tgz) / Recovery (.zip)';
                if (androidTipsText) {
                    androidTipsText.textContent = 'Xiaomi: ปลดล็อค Mi Bootloader ก่อนแฟลชรอม Fastboot ด้วย Mi Flash Tool. กด Volume Down + Power เพื่อเข้าหน้า Fastboot';
                }
                if (btnPortalPrimaryTitle) btnPortalPrimaryTitle.textContent = 'MiFirm.net Fastboot';
                if (btnPortalPrimaryDesc) btnPortalPrimaryDesc.textContent = `ค้นหารอมตรงรุ่น ${cleanModel}`;
                if (btnPortalPrimary) {
                    btnPortalPrimary.onclick = () => {
                        window.api.openExternalUrl(`https://mifirm.net/model/${cleanModel.toLowerCase()}.ttt`);
                    };
                }
                if (btnPortalSecondaryTitle) btnPortalSecondaryTitle.textContent = 'XiaomiFirmwareUpdater';
                if (btnPortalSecondaryDesc) btnPortalSecondaryDesc.textContent = 'HyperOS & MIUI คลังรอมทั่วโลก';
                if (btnPortalSecondary) {
                    btnPortalSecondary.onclick = () => {
                        window.api.openExternalUrl(`https://xiaomifirmwareupdater.com/`);
                    };
                }
            } else if (brand === 'Google') {
                if (androidSelectedCsc) androidSelectedCsc.textContent = 'Google Direct Factory CDN';
                if (androidSelectedChipBadge) androidSelectedChipBadge.textContent = 'Fastboot flash-all.bat';
                if (androidTipsText) {
                    androidTipsText.textContent = 'Google Pixel: รอมศูนย์ของแท้จาก Google Developers. แตกไฟล์ zip แล้วรันคำสั่ง flash-all.bat ใน Fastboot Mode ได้ทันที';
                }
                if (btnPortalPrimaryTitle) btnPortalPrimaryTitle.textContent = 'Google Factory Images';
                if (btnPortalPrimaryDesc) btnPortalPrimaryDesc.textContent = `เปิดหน้าดาวน์โหลดรอม Pixel ${cleanModel}`;
                if (btnPortalPrimary) {
                    btnPortalPrimary.onclick = () => {
                        window.api.openExternalUrl(`https://developers.google.com/android/images#${cleanModel.toLowerCase()}`);
                    };
                }
                if (btnPortalSecondaryTitle) btnPortalSecondaryTitle.textContent = 'Google Full OTA Images';
                if (btnPortalSecondaryDesc) btnPortalSecondaryDesc.textContent = 'แพ็กเกจ OTA สำหรับ adb sideload';
                if (btnPortalSecondary) {
                    btnPortalSecondary.onclick = () => {
                        window.api.openExternalUrl(`https://developers.google.com/android/ota`);
                    };
                }
            } else {
                if (androidSelectedCsc) androidSelectedCsc.textContent = 'Official Stock';
                if (androidSelectedChipBadge) androidSelectedChipBadge.textContent = 'Scatter / PAC / QFIL';
                if (androidTipsText) {
                    androidTipsText.textContent = `${brand}: ตรวจสอบประเภทชิปเซ็ต (MediaTek ใช้ SP Flash Tool, Unisoc ใช้ UpgradeDownload .PAC, Qualcomm ใช้ EDL 9008 Sahara)`;
                }
                if (btnPortalPrimaryTitle) btnPortalPrimaryTitle.textContent = 'Official Stock Search';
                if (btnPortalPrimaryDesc) btnPortalPrimaryDesc.textContent = `ค้นหาไฟล์รอมศูนย์ ${brand} ${cleanModel}`;
                if (btnPortalPrimary) {
                    btnPortalPrimary.onclick = () => {
                        window.api.openExternalUrl(`https://www.google.com/search?q=${encodeURIComponent(brand + ' ' + cleanModel + ' official stock rom firmware download')}`);
                    };
                }
                if (btnPortalSecondaryTitle) btnPortalSecondaryTitle.textContent = 'GSM-Forum Mirror';
                if (btnPortalSecondaryDesc) btnPortalSecondaryDesc.textContent = 'ไฟล์จากช่างซ่อมมืออาชีพ';
                if (btnPortalSecondary) {
                    btnPortalSecondary.onclick = () => {
                        window.api.openExternalUrl(`https://www.google.com/search?q=${encodeURIComponent(brand + ' ' + cleanModel + ' firmware gsm forum')}`);
                    };
                }
            }

            if (btnPortalFrp) {
                btnPortalFrp.onclick = () => {
                    window.api.openExternalUrl(`https://www.google.com/search?q=${encodeURIComponent(brand + ' ' + cleanModel + ' frp bypass unlock instructions youtube')}`);
                };
            }

            if (btnPortalRecovery) {
                btnPortalRecovery.onclick = () => {
                    window.api.openExternalUrl(`https://www.google.com/search?q=${encodeURIComponent(cleanModel + ' twrp orangefox recovery download')}`);
                };
            }
        }

        if (romBrandDropdown) {
            romBrandDropdown.addEventListener('change', populateAndroidModels);
        }
        if (romModelSearch) {
            romModelSearch.addEventListener('input', populateAndroidModels);
        }
        if (romModelList) {
            romModelList.addEventListener('change', updateSelectedAndroidModel);
        }

        document.querySelectorAll('.portal-link-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                if (btn.dataset.url && window.api && window.api.openExternalUrl) {
                    window.api.openExternalUrl(btn.dataset.url);
                }
            });
        });

        populateAndroidModels();

        // ------------------------------------------------------------
        // 3. Apple iOS Connected Device Inspector (3uTools Style) & IPSW Live Downloader
        // ------------------------------------------------------------
        let cachedAppleDevices = [];
        let currentAppleCategory = 'iPhone';
        let currentConnectedIosDevice = null;
        let iosScanInterval = null;

        // Apple Device Inspector Elements
        const iosDevicePanel = document.getElementById('ios-device-panel');
        const iosConnBadge = document.getElementById('ios-conn-badge');
        const btnIosScanDevices = document.getElementById('btn-ios-scan-devices');
        const iosNoDeviceState = document.getElementById('ios-no-device-state');
        const iosConnectedCard = document.getElementById('ios-connected-card');
        const iosAvatarIcon = document.getElementById('ios-avatar-icon');
        const iosAvatarType = document.getElementById('ios-avatar-type');
        const iosDetailName = document.getElementById('ios-detail-name');
        const iosDetailIosVersion = document.getElementById('ios-detail-ios-version');
        const iosDetailModeBadge = document.getElementById('ios-detail-mode-badge');
        const iosDetailModelId = document.getElementById('ios-detail-model-id');
        const iosDetailSerial = document.getElementById('ios-detail-serial');
        const iosDetailRegion = document.getElementById('ios-detail-region');
        const iosDetailImei = document.getElementById('ios-detail-imei');
        const iosDetailActivation = document.getElementById('ios-detail-activation');
        const iosDetailUdid = document.getElementById('ios-detail-udid');
        const iosTrustAlert = document.getElementById('ios-trust-alert');
        const btnIosMatchIpsw = document.getElementById('btn-ios-match-ipsw');

        // IPSW Elements
        const ipswDeviceSelect = document.getElementById('ipsw-device-select');
        const ipswDeviceInfoBar = document.getElementById('ipsw-device-info-bar');
        const ipswInfoName = document.getElementById('ipsw-info-name');
        const ipswInfoId = document.getElementById('ipsw-info-id');
        const ipswInfoBoard = document.getElementById('ipsw-info-board');
        const ipswFirmwareTbody = document.getElementById('ipsw-firmware-tbody');
        const btnIpswRefresh = document.getElementById('btn-ipsw-refresh');
        const ipswCatBtns = document.querySelectorAll('.ipsw-cat-btn');

        function setAppleCategory(catName) {
            currentAppleCategory = catName;
            ipswCatBtns.forEach(x => {
                if (x.dataset.cat === catName) {
                    x.classList.add('active');
                    x.style.background = '#3b82f6';
                    x.style.color = '#fff';
                    x.style.fontWeight = '600';
                } else {
                    x.classList.remove('active');
                    x.style.background = 'transparent';
                    x.style.color = '#94a3b8';
                    x.style.fontWeight = '500';
                }
            });
            populateAppleDeviceDropdown();
        }

        ipswCatBtns.forEach(b => {
            b.addEventListener('click', () => {
                setAppleCategory(b.dataset.cat);
            });
        });

        async function ensureAppleDevicesLoaded() {
            if (cachedAppleDevices.length > 0) return true;
            if (!window.api || !window.api.fetchIpswApi) return false;

            if (ipswDeviceSelect) {
                ipswDeviceSelect.innerHTML = '<option value="">-- กำลังดึงรายชื่อรุ่นจาก Apple API... --</option>';
            }

            try {
                const res = await window.api.fetchIpswApi('/v4/devices');
                if (res && res.success && Array.isArray(res.data)) {
                    cachedAppleDevices = res.data;
                    populateAppleDeviceDropdown();
                    return true;
                } else {
                    if (ipswDeviceSelect) {
                        ipswDeviceSelect.innerHTML = '<option value="">-- ไม่สามารถโหลดข้อมูลได้ (ตรวจสอบเน็ต) --</option>';
                    }
                    return false;
                }
            } catch (err) {
                if (ipswDeviceSelect) {
                    ipswDeviceSelect.innerHTML = '<option value="">-- ไม่สามารถเชื่อมต่อ API ได้ --</option>';
                }
                return false;
            }
        }

        function populateAppleDeviceDropdown() {
            if (!ipswDeviceSelect) return;
            ipswDeviceSelect.innerHTML = '';

            const filtered = cachedAppleDevices.filter(d => {
                const id = (d.identifier || '').toLowerCase();
                if (currentAppleCategory === 'iPhone') return id.startsWith('iphone');
                if (currentAppleCategory === 'iPad') return id.startsWith('ipad');
                if (currentAppleCategory === 'Mac') return id.startsWith('mac') || id.startsWith('virtualmac');
                if (currentAppleCategory === 'Watch') return id.startsWith('watch');
                if (currentAppleCategory === 'iPod') return id.startsWith('ipod');
                return true;
            });

            if (filtered.length === 0) {
                ipswDeviceSelect.innerHTML = '<option value="">-- ไม่พบรุ่นในหมวดหมู่นี้ --</option>';
                return;
            }

            filtered.reverse().forEach(dev => {
                const opt = document.createElement('option');
                opt.value = dev.identifier;
                opt.textContent = `${dev.name} (${dev.identifier})`;
                ipswDeviceSelect.appendChild(opt);
            });

            ipswDeviceSelect.selectedIndex = 0;
            loadDeviceFirmwares();
        }

        async function loadDeviceFirmwares() {
            if (!ipswDeviceSelect) return;
            const devId = ipswDeviceSelect.value;
            if (!devId) return;

            const dev = cachedAppleDevices.find(d => d.identifier === devId);
            if (dev && ipswDeviceInfoBar) {
                ipswDeviceInfoBar.style.display = 'flex';
                if (ipswInfoName) ipswInfoName.textContent = dev.name;
                if (ipswInfoId) ipswInfoId.textContent = dev.identifier;
                if (ipswInfoBoard) ipswInfoBoard.textContent = dev.boardconfig || '-';
            }

            if (ipswFirmwareTbody) {
                ipswFirmwareTbody.innerHTML = `
                    <tr>
                        <td colspan="6" style="padding: 24px; text-align: center; color: #38bdf8;">
                            <i class="fas fa-spinner fa-spin" style="margin-right: 8px;"></i> กำลังโหลดรายการเฟิร์มแวร์จาก Apple CDN...
                        </td>
                    </tr>
                `;
            }

            try {
                const res = await window.api.fetchIpswApi(`/v4/device/${devId}`);
                if (res && res.success && res.data && Array.isArray(res.data.firmwares)) {
                    renderFirmwareTable(res.data.firmwares, dev ? dev.name : devId);
                } else {
                    if (ipswFirmwareTbody) {
                        ipswFirmwareTbody.innerHTML = `<tr><td colspan="6" style="padding: 20px; text-align: center; color: #ef4444;">ไม่สามารถดึงข้อมูลเฟิร์มแวร์ได้ (${res ? res.error : 'Unknown error'})</td></tr>`;
                    }
                }
            } catch (err) {
                if (ipswFirmwareTbody) {
                    ipswFirmwareTbody.innerHTML = `<tr><td colspan="6" style="padding: 20px; text-align: center; color: #ef4444;">เกิดข้อผิดพลาด: ${err.message}</td></tr>`;
                }
            }
        }

        function renderFirmwareTable(firmwares, deviceName) {
            if (!ipswFirmwareTbody) return;
            ipswFirmwareTbody.innerHTML = '';

            if (firmwares.length === 0) {
                ipswFirmwareTbody.innerHTML = `<tr><td colspan="6" style="padding: 20px; text-align: center; color: #64748b;">ไม่มีข้อมูลเฟิร์มแวร์สำหรับรุ่นนี้</td></tr>`;
                return;
            }

            const firstSignedIndex = firmwares.findIndex(f => !!f.signed);

            firmwares.forEach((fw, idx) => {
                const tr = document.createElement('tr');
                const isSigned = !!fw.signed;
                const isLatestSigned = (idx === firstSignedIndex && isSigned);
                const matchesDeviceBuild = (currentConnectedIosDevice && currentConnectedIosDevice.buildVersion && fw.buildid === currentConnectedIosDevice.buildVersion);

                tr.style.borderBottom = '1px solid rgba(255,255,255,0.05)';
                tr.style.transition = 'background 0.15s';
                
                if (isLatestSigned) {
                    tr.style.background = 'rgba(16, 185, 129, 0.08)';
                    tr.style.borderLeft = '3px solid #10b981';
                }

                tr.onmouseenter = () => {
                    tr.style.background = isLatestSigned ? 'rgba(16, 185, 129, 0.14)' : 'rgba(255,255,255,0.04)';
                };
                tr.onmouseleave = () => {
                    tr.style.background = isLatestSigned ? 'rgba(16, 185, 129, 0.08)' : 'transparent';
                };

                const sizeGb = (fw.filesize / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
                const releaseDate = fw.releasedate ? fw.releasedate.split('T')[0] : '-';
                
                let signBadge = isSigned
                    ? `<span style="background: rgba(34,197,94,0.15); color: #22c55e; border: 1px solid rgba(34,197,94,0.3); padding: 3px 8px; border-radius: 4px; font-weight: 700; font-size: 11px;">🟢 Signed (รีสโตร์ได้)</span>`
                    : `<span style="background: rgba(239,68,68,0.1); color: #ef4444; border: 1px solid rgba(239,68,68,0.25); padding: 3px 8px; border-radius: 4px; font-size: 11px;">🔴 Unsigned</span>`;

                let recommendationBadge = '';
                if (isLatestSigned) {
                    recommendationBadge = `<span style="background: linear-gradient(135deg, rgba(16,185,129,0.25) 0%, rgba(5,150,105,0.3) 100%); color: #34d399; border: 1px solid rgba(16,185,129,0.5); padding: 2px 7px; border-radius: 4px; font-weight: 700; font-size: 10px; margin-left: 8px; display: inline-flex; align-items: center; gap: 4px;"><i class="fas fa-star" style="color: #facc15;"></i> ⭐ แนะนำ (Latest Signed)</span>`;
                } else if (matchesDeviceBuild) {
                    recommendationBadge = `<span style="background: rgba(59,130,246,0.25); color: #60a5fa; border: 1px solid rgba(59,130,246,0.5); padding: 2px 7px; border-radius: 4px; font-weight: 700; font-size: 10px; margin-left: 8px; display: inline-flex; align-items: center; gap: 4px;"><i class="fas fa-mobile"></i> ตรงกับ iOS ในเครื่อง</span>`;
                }

                tr.innerHTML = `
                    <td style="padding: 10px; font-weight: 600; color: #f8fafc;">
                        <span style="display: inline-flex; align-items: center; flex-wrap: wrap; gap: 4px;">
                            <span>iOS / iPadOS ${fw.version}</span>
                            ${recommendationBadge}
                        </span>
                    </td>
                    <td style="padding: 10px; font-family: monospace; color: #94a3b8;">${fw.buildid}</td>
                    <td style="padding: 10px; color: #cbd5e1;">${sizeGb}</td>
                    <td style="padding: 10px; color: #94a3b8;">${releaseDate}</td>
                    <td style="padding: 10px; text-align: center;">${signBadge}</td>
                    <td style="padding: 10px; text-align: right;">
                        <div style="display: inline-flex; gap: 6px;">
                            <button class="action-btn ${isLatestSigned ? 'safe-btn' : 'primary-btn'} btn-ipsw-dl" style="padding: 5px 10px; font-size: 11px; font-weight: 600; display: inline-flex; align-items: center; gap: 4px;" title="เริ่มดาวน์โหลดตรงในโปรแกรม">
                                <i class="fas fa-bolt"></i> โหลดในแอป
                            </button>
                            <button class="action-btn btn-ipsw-copy" style="padding: 5px 8px; font-size: 11px; background: rgba(255,255,255,0.08); color: #cbd5e1;" title="คัดลอกลิงก์ Apple CDN">
                                <i class="fas fa-copy"></i>
                            </button>
                            <button class="action-btn btn-ipsw-web" style="padding: 5px 8px; font-size: 11px; background: rgba(255,255,255,0.08); color: #cbd5e1;" title="เปิดในเบราว์เซอร์">
                                <i class="fas fa-arrow-up-right-from-square"></i>
                            </button>
                        </div>
                    </td>
                `;

                const dlBtn = tr.querySelector('.btn-ipsw-dl');
                if (dlBtn) {
                    dlBtn.addEventListener('click', () => {
                        const filename = `${fw.identifier || deviceName || 'Apple'}_${fw.version}_${fw.buildid}_Restore.ipsw`;
                        triggerFileDownload(fw.url, filename);
                    });
                }

                const copyBtn = tr.querySelector('.btn-ipsw-copy');
                if (copyBtn) {
                    copyBtn.addEventListener('click', () => {
                        navigator.clipboard.writeText(fw.url).then(() => {
                            copyBtn.innerHTML = '<i class="fas fa-check" style="color:#22c55e;"></i>';
                            setTimeout(() => copyBtn.innerHTML = '<i class="fas fa-copy"></i>', 2000);
                        });
                    });
                }

                const webBtn = tr.querySelector('.btn-ipsw-web');
                if (webBtn) {
                    webBtn.addEventListener('click', () => {
                        if (window.api && window.api.openExternalUrl) {
                            window.api.openExternalUrl(fw.url);
                        }
                    });
                }

                ipswFirmwareTbody.appendChild(tr);
            });
        }

        // Live iOS Device Detection & Auto-Select Controller
        async function refreshConnectedIosDevice(showVisualFeedback = false) {
            if (!window.api || !window.api.getConnectedIosDevice) return;

            if (showVisualFeedback && btnIosScanDevices) {
                btnIosScanDevices.innerHTML = '<i class="fas fa-spinner fa-spin"></i> <span>กำลังสแกน...</span>';
            }

            try {
                const res = await window.api.getConnectedIosDevice();
                if (res && res.connected && res.device) {
                    currentConnectedIosDevice = res.device;
                    const dev = res.device;

                    // Update Badge
                    if (iosConnBadge) {
                        iosConnBadge.innerHTML = `<i class="fas fa-circle" style="font-size: 7px; margin-right: 4px; color: #22c55e;"></i> เชื่อมต่อแล้ว (${dev.name || 'Apple Device'})`;
                        iosConnBadge.style.background = 'rgba(34,197,94,0.15)';
                        iosConnBadge.style.color = '#22c55e';
                        iosConnBadge.style.borderColor = 'rgba(34,197,94,0.3)';
                    }

                    // Toggle Views
                    if (iosNoDeviceState) iosNoDeviceState.style.display = 'none';
                    if (iosConnectedCard) iosConnectedCard.style.display = 'block';

                    // Update Avatar & Device Class
                    const dClass = (dev.deviceClass || 'iPhone').toLowerCase();
                    if (iosAvatarIcon) {
                        if (dClass.includes('ipad')) {
                            iosAvatarIcon.className = 'fa-solid fa-tablet-screen-button';
                        } else if (dClass.includes('ipod')) {
                            iosAvatarIcon.className = 'fa-solid fa-music';
                        } else {
                            iosAvatarIcon.className = 'fa-solid fa-mobile-screen-button';
                        }
                    }
                    if (iosAvatarType) {
                        iosAvatarType.textContent = dev.deviceClass || 'iPhone';
                    }

                    // Title & Version
                    if (iosDetailName) {
                        const displayName = (dev.deviceName && dev.name && dev.deviceName !== dev.name) ? `${dev.name} (${dev.deviceName})` : (dev.name || dev.deviceName || 'Apple Device');
                        iosDetailName.textContent = displayName;
                    }
                    if (iosDetailIosVersion) {
                        if (dev.productVersion) {
                            iosDetailIosVersion.textContent = `iOS ${dev.productVersion}${dev.buildVersion ? ' (' + dev.buildVersion + ')' : ''}`;
                            iosDetailIosVersion.style.display = 'inline-block';
                        } else {
                            iosDetailIosVersion.textContent = 'iOS --';
                        }
                    }

                    // Connection Mode Badge
                    if (iosDetailModeBadge) {
                        if (dev.mode === 'Recovery') {
                            iosDetailModeBadge.textContent = '🟡 Recovery Mode';
                            iosDetailModeBadge.style.background = 'rgba(245,158,11,0.2)';
                            iosDetailModeBadge.style.color = '#fbbf24';
                            iosDetailModeBadge.style.borderColor = 'rgba(245,158,11,0.4)';
                        } else if (dev.mode === 'DFU') {
                            iosDetailModeBadge.textContent = '🔴 DFU Mode';
                            iosDetailModeBadge.style.background = 'rgba(239,68,68,0.2)';
                            iosDetailModeBadge.style.color = '#f87171';
                            iosDetailModeBadge.style.borderColor = 'rgba(239,68,68,0.4)';
                        } else {
                            iosDetailModeBadge.textContent = '🟢 Normal Mode';
                            iosDetailModeBadge.style.background = 'rgba(34,197,94,0.2)';
                            iosDetailModeBadge.style.color = '#22c55e';
                            iosDetailModeBadge.style.borderColor = 'rgba(34,197,94,0.4)';
                        }
                    }

                    // Details Grid
                    if (iosDetailModelId) iosDetailModelId.textContent = dev.productType || dev.hardwareModel || '-';
                    if (iosDetailSerial) iosDetailSerial.textContent = dev.serialNumber || '-';
                    if (iosDetailRegion) {
                        const reg = [dev.modelNumber, dev.regionInfo].filter(Boolean).join(' ');
                        iosDetailRegion.textContent = reg || '-';
                    }
                    if (iosDetailImei) iosDetailImei.textContent = dev.imei || '-';
                    if (iosDetailActivation) {
                        if (dev.activationState === 'Activated') {
                            iosDetailActivation.innerHTML = '<span style="color: #22c55e;"><i class="fas fa-check-circle"></i> เปิดใช้งานแล้ว (Activated)</span>';
                        } else if (dev.activationState) {
                            iosDetailActivation.textContent = dev.activationState;
                        } else {
                            iosDetailActivation.textContent = '-';
                        }
                    }
                    if (iosDetailUdid) {
                        iosDetailUdid.textContent = dev.udid || '-';
                        iosDetailUdid.title = dev.udid ? 'คลิกเพื่อคัดลอก UDID: ' + dev.udid : '';
                    }

                    // Trust Screen Alert
                    if (iosTrustAlert) {
                        iosTrustAlert.style.display = dev.needTrust ? 'block' : 'none';
                    }
                } else {
                    currentConnectedIosDevice = null;
                    if (iosConnBadge) {
                        iosConnBadge.innerHTML = '<i class="fas fa-circle" style="font-size: 7px; margin-right: 4px;"></i> รอการเสียบสาย';
                        iosConnBadge.style.background = 'rgba(148,163,184,0.15)';
                        iosConnBadge.style.color = '#94a3b8';
                        iosConnBadge.style.borderColor = 'rgba(148,163,184,0.3)';
                    }
                    if (iosNoDeviceState) iosNoDeviceState.style.display = 'block';
                    if (iosConnectedCard) iosConnectedCard.style.display = 'none';
                }
            } catch (err) {
                console.error('Error refreshing iOS device:', err);
            } finally {
                if (showVisualFeedback && btnIosScanDevices) {
                    btnIosScanDevices.innerHTML = '<i class="fas fa-rotate"></i> <span>สแกนตรวจหา</span>';
                }
            }
        }

        async function selectIpswForConnectedDevice(dev) {
            if (!dev) {
                await refreshConnectedIosDevice(true);
                dev = currentConnectedIosDevice;
            }

            if (!dev) {
                alert('ยังไม่พบอุปกรณ์ iPhone หรือ iPad ที่เสียบอยู่ กรุณาเสียบสาย USB แล้วลองใหม่อีกครั้ง');
                return;
            }

            // 1. Load Apple device list
            await ensureAppleDevicesLoaded();

            // 2. Identify Category
            let targetCategory = 'iPhone';
            const devClass = (dev.deviceClass || '').toLowerCase();
            const pType = (dev.productType || '').toLowerCase();
            if (devClass.includes('ipad') || pType.startsWith('ipad')) {
                targetCategory = 'iPad';
            } else if (devClass.includes('ipod') || pType.startsWith('ipod')) {
                targetCategory = 'iPod';
            } else if (devClass.includes('mac') || pType.startsWith('mac')) {
                targetCategory = 'Mac';
            } else {
                targetCategory = 'iPhone';
            }

            // Switch category tab & populate dropdown
            setAppleCategory(targetCategory);

            // 3. Find matching model in ipswDeviceSelect
            if (ipswDeviceSelect) {
                let foundMatch = false;
                if (dev.productType) {
                    for (let i = 0; i < ipswDeviceSelect.options.length; i++) {
                        if (ipswDeviceSelect.options[i].value.toLowerCase() === dev.productType.toLowerCase()) {
                            ipswDeviceSelect.selectedIndex = i;
                            foundMatch = true;
                            break;
                        }
                    }
                }

                if (!foundMatch && dev.name) {
                    const cleanName = dev.name.toLowerCase().replace(/[^a-z0-9]/g, '');
                    for (let i = 0; i < ipswDeviceSelect.options.length; i++) {
                        const optText = ipswDeviceSelect.options[i].textContent.toLowerCase().replace(/[^a-z0-9]/g, '');
                        if (optText.includes(cleanName) || cleanName.includes(optText)) {
                            ipswDeviceSelect.selectedIndex = i;
                            foundMatch = true;
                            break;
                        }
                    }
                }

                await loadDeviceFirmwares();

                // Scroll to firmware table
                if (ipswDeviceInfoBar) {
                    ipswDeviceInfoBar.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
            }
        }

        function startIosPolling() {
            if (iosScanInterval) clearInterval(iosScanInterval);
            iosScanInterval = setInterval(() => {
                const appleTab = document.getElementById('rom-tab-apple');
                if (appleTab && appleTab.style.display !== 'none') {
                    refreshConnectedIosDevice(false);
                } else {
                    stopIosPolling();
                }
            }, 3500);
        }

        function stopIosPolling() {
            if (iosScanInterval) {
                clearInterval(iosScanInterval);
                iosScanInterval = null;
            }
        }

        if (ipswDeviceSelect) {
            ipswDeviceSelect.addEventListener('change', loadDeviceFirmwares);
        }
        if (btnIpswRefresh) {
            btnIpswRefresh.addEventListener('click', () => {
                cachedAppleDevices = [];
                ensureAppleDevicesLoaded();
            });
        }
        if (btnIosScanDevices) {
            btnIosScanDevices.addEventListener('click', () => {
                refreshConnectedIosDevice(true);
            });
        }
        if (btnIosMatchIpsw) {
            btnIosMatchIpsw.addEventListener('click', () => {
                selectIpswForConnectedDevice(currentConnectedIosDevice);
            });
        }
        if (iosDetailUdid) {
            iosDetailUdid.addEventListener('click', () => {
                const udid = iosDetailUdid.textContent.trim();
                if (udid && udid !== '-') {
                    navigator.clipboard.writeText(udid).then(() => {
                        const orig = iosDetailUdid.textContent;
                        iosDetailUdid.textContent = '✓ คัดลอก UDID แล้ว!';
                        setTimeout(() => { iosDetailUdid.textContent = orig; }, 1500);
                    });
                }
            });
        }

        // ------------------------------------------------------------
        // 4. Service & Unlock Files
        // ------------------------------------------------------------
        document.querySelectorAll('.frp-dl-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const name = btn.dataset.name;
                const url = btn.dataset.url;
                triggerFileDownload(url, name);
            });
        });

        // ------------------------------------------------------------
        // 5. Firmware Tools & Hasher
        // ------------------------------------------------------------
        const hashFilePath = document.getElementById('hash-file-path');
        const btnHashBrowse = document.getElementById('btn-hash-browse');
        const btnCalcHash = document.getElementById('btn-calc-hash');
        const hashOutput = document.getElementById('hash-output');
        const hashSizeText = document.getElementById('hash-size-text');
        const hashCompareInput = document.getElementById('hash-compare-input');
        const hashCompareStatus = document.getElementById('hash-compare-status');

        if (btnHashBrowse) {
            btnHashBrowse.addEventListener('click', async () => {
                if (window.api && window.api.browseFileForHash) {
                    const chosen = await window.api.browseFileForHash();
                    if (chosen && hashFilePath) {
                        hashFilePath.value = chosen;
                        if (hashOutput) hashOutput.textContent = '- กดคำนวณ Hash เพื่อเริ่มต้น -';
                        if (hashCompareStatus) hashCompareStatus.style.display = 'none';
                    }
                }
            });
        }

        if (btnCalcHash) {
            btnCalcHash.addEventListener('click', async () => {
                const filePath = hashFilePath ? hashFilePath.value.trim() : '';
                if (!filePath) {
                    alert('กรุณาเลือกไฟล์ที่ต้องการตรวจสอบก่อน');
                    return;
                }

                const selectedAlgoRadio = document.querySelector('input[name="hash-algo"]:checked');
                const algo = selectedAlgoRadio ? selectedAlgoRadio.value : 'md5';

                if (hashOutput) hashOutput.innerHTML = `<i class="fas fa-spinner fa-spin"></i> กำลังอ่านและคำนวณ Checksum ${algo.toUpperCase()}...`;

                try {
                    const res = await window.api.calculateFileHash({ filePath, algorithm: algo });
                    if (res && res.success) {
                        if (hashOutput) hashOutput.textContent = res.hash;
                        if (hashSizeText) hashSizeText.textContent = `ขนาดไฟล์: ${formatBytes(res.size)} | Algo: ${res.algorithm.toUpperCase()}`;
                        checkHashMatch();
                    } else {
                        if (hashOutput) hashOutput.textContent = 'เกิดข้อผิดพลาด: ' + (res.error || 'Unknown error');
                    }
                } catch (err) {
                    if (hashOutput) hashOutput.textContent = 'เกิดข้อผิดพลาด: ' + err.message;
                }
            });
        }

        function checkHashMatch() {
            if (!hashCompareInput || !hashCompareStatus || !hashOutput) return;
            const expected = hashCompareInput.value.trim().toLowerCase();
            const computed = hashOutput.textContent.trim().toLowerCase();

            if (!expected || computed.startsWith('-') || computed.startsWith('เกิดข้อผิดพลาด') || computed.startsWith('กำลัง')) {
                hashCompareStatus.style.display = 'none';
                return;
            }

            hashCompareStatus.style.display = 'block';
            if (expected === computed) {
                hashCompareStatus.style.background = 'rgba(34,197,94,0.2)';
                hashCompareStatus.style.color = '#22c55e';
                hashCompareStatus.style.border = '1px solid rgba(34,197,94,0.4)';
                hashCompareStatus.innerHTML = '<i class="fas fa-circle-check"></i> <strong>MATCH:</strong> ค่า Checksum ตรงกัน 100% ไฟล์สมบูรณ์ ปลอดภัยต่อการแฟลช';
            } else {
                hashCompareStatus.style.background = 'rgba(239,68,68,0.2)';
                hashCompareStatus.style.color = '#ef4444';
                hashCompareStatus.style.border = '1px solid rgba(239,68,68,0.4)';
                hashCompareStatus.innerHTML = '<i class="fas fa-triangle-exclamation"></i> <strong>MISMATCH:</strong> ค่า Checksum ไม่ตรงกัน! ไฟล์อาจดาวน์โหลดไม่สมบูรณ์หรือถูกดัดแปลง ห้ามแฟลชเด็ดขาด';
            }
        }

        if (hashCompareInput) {
            hashCompareInput.addEventListener('input', checkHashMatch);
        }

        // Samsung AP Boot Extractor
        const apExtractPath = document.getElementById('ap-extract-path');
        const btnApExtractBrowse = document.getElementById('btn-ap-extract-browse');
        const btnApExtractRun = document.getElementById('btn-ap-extract-run');
        const apExtractResult = document.getElementById('ap-extract-result');

        if (btnApExtractBrowse) {
            btnApExtractBrowse.addEventListener('click', async () => {
                const browseFn = (window.api && window.api.browseApFile) ? window.api.browseApFile : (window.api ? window.api.browseFileForHash : null);
                if (browseFn) {
                    const chosen = await browseFn();
                    if (chosen && apExtractPath) {
                        apExtractPath.value = chosen;
                    }
                }
            });
        }

        if (btnApExtractRun) {
            btnApExtractRun.addEventListener('click', async () => {
                const filePath = apExtractPath ? apExtractPath.value.trim() : '';
                if (!filePath) {
                    alert('กรุณาเลือกไฟล์ AP_*.tar.md5 ของ Samsung ก่อน');
                    return;
                }

                if (apExtractResult) {
                    apExtractResult.innerHTML = `<div style="color: #38bdf8;"><i class="fas fa-spinner fa-spin"></i> กำลังตรวจสอบโครงสร้างไฟล์ AP และสกัด boot image...</div>`;
                }

                try {
                    const res = await window.api.extractBootFromAp(filePath);
                    if (res && res.success) {
                        const lz4Badge = res.hasDecompressed 
                            ? `<span style="font-size: 10px; background: rgba(34, 197, 94, 0.2); color: #4ade80; padding: 2px 6px; border-radius: 4px; margin-left: 6px;">แตกไฟล์ LZ4 เรียบร้อย (.img)</span>`
                            : (res.isLz4 ? `<span style="font-size: 10px; background: rgba(245, 158, 11, 0.2); color: #fbbf24; padding: 2px 6px; border-radius: 4px; margin-left: 6px;">ไฟล์บีบอัด .lz4</span>` : '');
                        const initBadge = res.isInitBoot
                            ? `<span style="font-size: 10px; background: rgba(168, 85, 247, 0.2); color: #c084fc; padding: 2px 6px; border-radius: 4px; margin-left: 6px;">Android 13+ (init_boot)</span>`
                            : '';
                        const timeText = res.elapsedSeconds ? `(ใช้เวลา ${res.elapsedSeconds} วินาที)` : '';

                        const chkApAutoPatch = document.getElementById('chk-ap-auto-patch');
                        if (chkApAutoPatch && chkApAutoPatch.checked) {
                            await executeMagiskPatch(res.outPath, apExtractResult, null);
                        } else {
                            apExtractResult.innerHTML = `
                                <div style="color: #22c55e; font-weight: 600; margin-bottom: 6px; display: flex; align-items: center; flex-wrap: wrap; gap: 4px;">
                                    <i class="fas fa-check-circle"></i> สกัดไฟล์สำเร็จ! <b>${res.targetFile}</b> ${lz4Badge} ${initBadge} <small style="color: #94a3b8; font-size: 11px;">${timeText}</small>
                                </div>
                                <div style="color: #94a3b8; font-size: 11px; word-break: break-all; margin-bottom: 8px;">
                                    ที่อยู่ไฟล์: <b>${res.outPath}</b>
                                </div>
                                <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                                    <button class="action-btn warning-btn btn-patch-magisk-now" style="padding: 5px 12px; font-size: 11px; background: linear-gradient(135deg, #ff4e00, #ec9f05); border: none; color: #fff; font-weight: 600; cursor: pointer;">
                                        <i class="fas fa-bolt"></i> แพตช์ Magisk Root ทันที
                                    </button>
                                    <button class="action-btn safe-btn btn-open-extracted" style="padding: 5px 12px; font-size: 11px;">
                                        <i class="fas fa-folder-open"></i> เปิดโฟลเดอร์เก็บไฟล์
                                    </button>
                                </div>
                            `;
                            const patchBtn = apExtractResult.querySelector('.btn-patch-magisk-now');
                            if (patchBtn) {
                                patchBtn.addEventListener('click', () => {
                                    executeMagiskPatch(res.outPath, apExtractResult, null);
                                });
                            }
                            const openBtn = apExtractResult.querySelector('.btn-open-extracted');
                            if (openBtn) {
                                openBtn.addEventListener('click', async () => {
                                    const orig = openBtn.innerHTML;
                                    openBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังเปิด...';
                                    if (window.api && window.api.openFileLocation) {
                                        await window.api.openFileLocation(res.outPath);
                                    }
                                    setTimeout(() => { openBtn.innerHTML = '<i class="fas fa-check" style="color: #22c55e;"></i> เปิดแล้ว!'; }, 400);
                                    setTimeout(() => { openBtn.innerHTML = orig; }, 1800);
                                });
                            }
                        }
                    } else {
                        apExtractResult.innerHTML = `<div style="color: #ef4444;"><i class="fas fa-times-circle"></i> ล้มเหลว: ${res.error || 'Unknown error'}</div>`;
                    }
                } catch (err) {
                    apExtractResult.innerHTML = `<div style="color: #ef4444;"><i class="fas fa-times-circle"></i> เกิดข้อผิดพลาด: ${err.message}</div>`;
                }
            });
        }

    })();


// ============================================================
// RASPBERRY PI PICO / RP2350 FLASHER (usbliter8)
// ============================================================
(function() {
    let availableFirmwares = [];
    let detectedDrives = [];
    let selectedFile = null;

    function picoLog(msg, color) {
        const log = document.getElementById('pico-log');
        if (!log) return;
        const d = document.createElement('div');
        d.style.cssText = `color:${color || '#ccc'};margin-bottom:3px;word-break:break-all;`;
        d.textContent = msg;
        log.appendChild(d);
        log.scrollTop = log.scrollHeight;
    }

    function setPicoProgress(pct, stepLabel) {
        const bar = document.getElementById('pico-progress-bar');
        const pctEl = document.getElementById('pico-progress-pct');
        const stepEl = document.getElementById('pico-step-label');
        if (bar) bar.style.width = pct + '%';
        if (pctEl) pctEl.textContent = pct + '%';
        if (stepEl && stepLabel) stepEl.textContent = stepLabel;
    }

    function setPicoStep(num, status) {
        const el = document.querySelector(`.pico-step[data-step="${num}"]`);
        if (!el) return;
        const icons = { done: '✅', active: '🔄', error: '❌', pending: '⬜' };
        el.querySelector('.step-icon').textContent = icons[status] || '⬜';
        el.style.color = { done: '#69f0ae', active: '#fff', error: '#ff5252', pending: '#777' }[status] || '#777';
        el.style.background = { done: 'rgba(105,240,174,0.08)', active: 'rgba(255,255,255,0.08)', error: 'rgba(255,82,82,0.08)' }[status] || 'rgba(255,255,255,0.03)';
    }

    function setPicoBadge(text, color) {
        const b = document.getElementById('pico-status-badge');
        if (!b) return;
        b.textContent = text;
        b.style.background = color || 'rgba(255,255,255,0.08)';
        b.style.color = '#fff';
    }

    function resetPicoSteps() {
        for (let i = 1; i <= 4; i++) setPicoStep(i, 'pending');
        setPicoProgress(0, 'Ready');
        setPicoBadge('Idle', 'rgba(255,255,255,0.08)');
    }

    function pathBasename(p) {
        if (!p) return '';
        const parts = p.split(/[\\/]/);
        return parts[parts.length - 1];
    }

    function updateSelectedFileInfo(f) {
        const fn = document.getElementById('pico-info-filename');
        const sz = document.getElementById('pico-info-filesize');
        const tg = document.getElementById('pico-info-target');
        const loc = document.getElementById('pico-info-location');

        if (!f) {
            selectedFile = null;
            if (fn) fn.textContent = '-';
            if (sz) sz.textContent = '-';
            if (tg) tg.textContent = '-';
            if (loc) loc.textContent = '-';
            return;
        }

        selectedFile = f;
        if (fn) fn.textContent = f.fileName || pathBasename(f.fullPath);
        if (sz) sz.textContent = f.sizeFormatted || '-';
        if (tg) tg.textContent = f.title || 'Raspberry Pi RP2350';
        if (loc) {
            const isInternal = f.fullPath && (f.fullPath.includes('bin\\pico') || f.fullPath.includes('bin/pico'));
            loc.textContent = isInternal ? '📦 In Project (bin\\pico\\) 🔒 ห้ามลบ' : '📁 External / Custom';
            loc.style.color = isInternal ? '#00b0ff' : '#ffd740';
        }
    }

    // Load firmwares from directory (defaults to internal project library bin/pico)
    async function loadFirmwares(customDir) {
        const fwSelect = document.getElementById('pico-firmware-select');

        if (fwSelect) {
            fwSelect.innerHTML = '<option value="">-- Scanning firmwares... --</option>';
        }

        try {
            const res = await window.api.getPicoFirmwares(customDir || null);
            const displayDir = res?.dir || 'bin\\pico';

            if (!res || !res.exists || !res.files || res.files.length === 0) {
                if (fwSelect) {
                    fwSelect.innerHTML = '<option value="">-- ไม่พบไฟล์ .uf2 ในคลังโปรเจกต์ --</option><option value="__custom__">📁 เลือกไฟล์ .uf2 จากเครื่อง (Browse)...</option>';
                }
                picoLog(`⚠️ ไม่พบไฟล์ .uf2 ใน: ${displayDir}`, '#ffa726');
                updateSelectedFileInfo(null);
                return;
            }

            availableFirmwares = res.files;
            if (fwSelect) {
                fwSelect.innerHTML = '';
                availableFirmwares.forEach((f) => {
                    const opt = document.createElement('option');
                    opt.value = f.fullPath;
                    opt.textContent = `${f.icon} ${f.title} (${f.sizeFormatted})`;
                    fwSelect.appendChild(opt);
                });

                // Add option to browse custom
                const customOpt = document.createElement('option');
                customOpt.value = '__custom__';
                customOpt.textContent = '📁 เลือกไฟล์ .uf2 อื่นๆ จากเครื่อง (Browse)...';
                fwSelect.appendChild(customOpt);

                // Select first
                fwSelect.selectedIndex = 0;
                updateSelectedFileInfo(availableFirmwares[0]);
            }

            picoLog(`✅ โหลดไฟล์เฟิร์มแวร์ในคลังโปรเจกต์ (${availableFirmwares.length} ไฟล์): ${displayDir}`, '#69f0ae');
        } catch(e) {
            picoLog('❌ Error loading firmwares: ' + e.message, '#ff5252');
        }
    }

    // Scan connected drives for Raspberry Pi BOOTSEL
    async function scanPicoDrives(isSilent = false) {
        if (!isSilent) {
            const l = document.getElementById('pico-log');
            if (l) l.innerHTML = '';
        }
        const drvSelect = document.getElementById('pico-drive-select');
        const drvLabel = document.getElementById('pico-drive-label');
        const drvSub = document.getElementById('pico-drive-sub');
        const drvIcon = document.getElementById('pico-drive-icon');

        if (drvLabel) {
            drvLabel.textContent = 'กำลังค้นหาบอร์ด...';
            drvLabel.style.color = '#ffd740';
        }

        try {
            const res = await window.api.scanPicoDrives();
            detectedDrives = res?.picoDrives || [];
            const otherDrives = res?.otherDrives || [];

            if (drvSelect) drvSelect.innerHTML = '';

            if (detectedDrives.length > 0) {
                const mainPico = detectedDrives[0];
                if (drvLabel) {
                    drvLabel.textContent = `ตรวจพบบอร์ดที่ไดรฟ์ [${mainPico.letter}]`;
                    drvLabel.style.color = '#69f0ae';
                }
                if (drvSub) {
                    drvSub.textContent = mainPico.model || 'Raspberry Pi Pico (BOOTSEL Mode)';
                }
                if (drvIcon) {
                    drvIcon.textContent = '🍓';
                    drvIcon.style.filter = 'none';
                }

                detectedDrives.forEach(d => {
                    const opt = document.createElement('option');
                    opt.value = d.letter;
                    opt.textContent = `[${d.letter}] ${d.model}`;
                    drvSelect.appendChild(opt);
                });

                picoLog(`✅ Raspberry Pi Pico detected at ${mainPico.letter} (${mainPico.model})`, '#69f0ae');
            } else {
                if (drvLabel) {
                    drvLabel.textContent = 'ยังไม่พบบอร์ด (Not Detected)';
                    drvLabel.style.color = '#ff5252';
                }
                if (drvSub) {
                    drvSub.textContent = 'กดปุ่ม BOOTSEL บนบอร์ดค้างไว้ แล้วเสียบสาย USB เข้าคอม';
                }
                if (drvIcon) {
                    drvIcon.textContent = '🔌';
                }

                if (drvSelect) {
                    drvSelect.innerHTML = '<option value="">-- ไม่พบไดรฟ์ RPI-RP2 / RP2350 --</option>';
                    otherDrives.forEach(d => {
                        const opt = document.createElement('option');
                        opt.value = d.letter;
                        opt.textContent = `[${d.letter}] Other Drive (Manual Select)`;
                        drvSelect.appendChild(opt);
                    });
                }

                picoLog('⚠️ ไม่พบไดรฟ์ Raspberry Pi ในโหมด BOOTSEL', '#aaa');
                picoLog('   คำแนะนำ: ถอดสาย USB > กดปุ่ม BOOTSEL บนบอร์ดค้างไว้ > เสียบสาย USB เข้าคอม', '#ffd740');
            }
        } catch(e) {
            picoLog('❌ Scan error: ' + e.message, '#ff5252');
        }
    }

    // Event Listeners
    const btnScan = document.getElementById('btn-pico-scan-drives');
    if (btnScan) {
        btnScan.addEventListener('click', scanPicoDrives);
    }


    // Open bin/pico Folder in Explorer
    const btnOpenFolder = document.getElementById('btn-pico-open-folder');
    if (btnOpenFolder) {
        btnOpenFolder.addEventListener('click', async () => {
            try {
                const l = document.getElementById('pico-log');
                if (l) l.innerHTML = '';
                picoLog('📂 เปิดโฟลเดอร์ bin\\pico ใน File Explorer...', '#aaa');
                await window.api.openPicoFolder();
            } catch (err) {
                picoLog(`❌ ไม่สามารถเปิดโฟลเดอร์ได้: ${err.message}`, '#ff5252');
            }
        });
    }

    const fwSelectEl = document.getElementById('pico-firmware-select');
    if (fwSelectEl) {
        fwSelectEl.addEventListener('change', async () => {
            const val = fwSelectEl.value;
            if (val === '__custom__') {
                try {
                    const pick = await window.api.showOpenDialog({
                        title: 'Select .uf2 Firmware File',
                        filters: [
                            { name: 'Pico UF2 Firmware', extensions: ['uf2'] },
                            { name: 'All Files', extensions: ['*'] }
                        ],
                        properties: ['openFile']
                    });
                    const cp = resolveDialogPath(pick);
                    if (cp) {
                        const customObj = {
                            fileName: pathBasename(cp),
                            fullPath: cp,
                            sizeFormatted: 'Custom',
                            title: 'Custom UF2 File'
                        };
                        updateSelectedFileInfo(customObj);
                        picoLog('📁 Selected custom file: ' + cp, '#69f0ae');
                    } else {
                        if (availableFirmwares.length > 0) {
                            fwSelectEl.selectedIndex = 0;
                            updateSelectedFileInfo(availableFirmwares[0]);
                        }
                    }
                } catch(e) {}
            } else {
                const found = availableFirmwares.find(f => f.fullPath === val);
                updateSelectedFileInfo(found || { fullPath: val, fileName: pathBasename(val), title: 'Firmware' });
            }
        });
    }

    const btnClearLog = document.getElementById('btn-pico-clear-log');
    if (btnClearLog) {
        btnClearLog.addEventListener('click', () => {
            const l = document.getElementById('pico-log');
            if (l) l.innerHTML = '';
        });
    }

    // Flash Button Action
    const btnFlash = document.getElementById('btn-pico-flash');
    if (btnFlash) {
        btnFlash.addEventListener('click', async () => {
            const l = document.getElementById('pico-log');
            if (l) l.innerHTML = '';
            const drvSelect = document.getElementById('pico-drive-select');
            const targetDrive = drvSelect?.value;

            if (!selectedFile || !selectedFile.fullPath) {
                alert('กรุณาเลือกไฟล์เฟิร์มแวร์ .uf2 ก่อนกดแฟลช');
                return;
            }

            if (!targetDrive) {
                alert('ยังไม่พบไดรฟ์ Raspberry Pi (BOOTSEL)\n\nกรุณากดปุ่ม BOOTSEL บนบอร์ดค้างไว้ แล้วเสียบสาย USB เข้าคอมพิวเตอร์');
                return;
            }

            btnFlash.disabled = true;
            resetPicoSteps();
            setPicoBadge('Flashing...', 'rgba(233,30,99,0.6)');
            
            picoLog('==================================================', '#555');
            picoLog(`⚡ เริ่มกระบวนการแฟลช ${selectedFile.title || 'usbliter8'}...`, '#fff');
            picoLog(`   ไฟล์ต้นทาง: ${selectedFile.fullPath}`, '#aaa');
            picoLog(`   ไดรฟ์เป้าหมาย: ${targetDrive}`, '#aaa');

            // Step 1: Check Target Drive
            setPicoStep(1, 'active');
            setPicoProgress(20, 'Checking target drive...');
            await new Promise(r => setTimeout(r, 400));
            try {
                setPicoStep(1, 'done');
                picoLog(`✅ ไดรฟ์ [${targetDrive}] พร้อมสำหรับการเขียนเฟิร์มแวร์`, '#69f0ae');
            } catch(e) {
                setPicoStep(1, 'error');
                setPicoBadge('Failed', 'rgba(255,82,82,0.6)');
                picoLog('❌ Drive error: ' + e.message, '#ff5252');
                btnFlash.disabled = false;
                return;
            }

            // Step 2: Verify UF2 Payload
            setPicoStep(2, 'active');
            setPicoProgress(45, 'Verifying UF2 payload...');
            await new Promise(r => setTimeout(r, 300));
            try {
                setPicoStep(2, 'done');
                picoLog(`✅ ไฟล์ UF2 ถูกต้อง (${selectedFile.fileName})`, '#69f0ae');
            } catch(e) {
                setPicoStep(2, 'error');
                setPicoBadge('Failed', 'rgba(255,82,82,0.6)');
                picoLog('❌ File error: ' + e.message, '#ff5252');
                btnFlash.disabled = false;
                return;
            }

            // Step 3: Copy to Flash
            setPicoStep(3, 'active');
            setPicoProgress(70, 'Writing UF2 to Raspberry Pi...');
            picoLog(`> กำลังคัดลอกไฟล์ลงบอร์ด ${targetDrive}\\${selectedFile.fileName}...`, '#aaa');
            await new Promise(r => setTimeout(r, 500));

            try {
                const flashRes = await window.api.invoke('flash-pico-uf2', {
                    filePath: selectedFile.fullPath,
                    driveLetter: targetDrive
                });

                if (!flashRes.success) {
                    throw new Error(flashRes.error || 'Copy failed');
                }

                setPicoStep(3, 'done');
                picoLog(`✅ เขียนไฟล์ลงแฟลชเมมโมรีเรียบร้อย (${flashRes.message})`, '#69f0ae');
            } catch(e) {
                setPicoStep(3, 'error');
                setPicoBadge('Failed', 'rgba(255,82,82,0.6)');
                picoLog('❌ Flash error: ' + e.message, '#ff5252');
                btnFlash.disabled = false;
                return;
            }

            // Step 4: Auto-reboot & complete
            setPicoStep(4, 'active');
            setPicoProgress(90, 'Verifying auto-reboot...');
            await new Promise(r => setTimeout(r, 800));

            setPicoStep(4, 'done');
            setPicoProgress(100, '✅ Flash Complete!');
            setPicoBadge('Success!', 'rgba(105,240,174,0.4)');

            picoLog('', '');
            picoLog('🎉 แฟลชเฟิร์มแวร์เข้าบอร์ด Raspberry Pi สำเร็จแล้ว!', '#69f0ae');
            picoLog('💡 บอร์ดได้ทำการรีบูตเข้าสู่โปรแกรม usbliter8 เรียบร้อยแล้ว พร้อมใช้งาน!', '#ffd740');
            picoLog('==================================================', '#555');

            btnFlash.disabled = false;

            setTimeout(scanPicoDrives, 1500);
        });
    }

    // Auto-init on section load or startup
    loadFirmwares();
    scanPicoDrives();

    // Hook to reload when user clicks on pico-section nav button
    const picoNavBtn = document.querySelector('.nav-btn[data-target="pico-section"]');
    if (picoNavBtn) {
        picoNavBtn.addEventListener('click', () => {
            loadFirmwares();
            scanPicoDrives();
        });
    }
})();


// ============================================================================
// 🚀 20 PRO SUPERPOWERS SUITE (SYSTEM & MOBILE TOOLS CONTROLLER)
// ============================================================================
(function init20ProSuperpowers() {
    console.log('[PRO SUPERPOWERS] Initializing 20 Pro Features Controller...');

    function setStatusBox(elId, msg, isSuccess = true, isLoading = false) {
        const el = document.getElementById(elId);
        if (!el) return;
        el.style.display = 'block';
        if (isLoading) {
            el.style.background = 'rgba(56, 189, 248, 0.15)';
            el.style.color = '#38bdf8';
            el.style.border = '1px solid rgba(56, 189, 248, 0.3)';
            el.innerHTML = `<i class="fas fa-spinner fa-spin"></i> ${msg}`;
        } else if (isSuccess) {
            el.style.background = 'rgba(34, 197, 94, 0.15)';
            el.style.color = '#4ade80';
            el.style.border = '1px solid rgba(34, 197, 94, 0.3)';
            el.innerHTML = `<i class="fas fa-check-circle"></i> ${msg}`;
        } else {
            el.style.background = 'rgba(239, 68, 68, 0.15)';
            el.style.color = '#f87171';
            el.style.border = '1px solid rgba(239, 68, 68, 0.3)';
            el.innerHTML = `<i class="fas fa-exclamation-triangle"></i> ${msg}`;
        }
    }

    // -------------------------------------------------------------
    // 1. RAM Memory Cleaner
    // -------------------------------------------------------------
    const btnCleanRam = document.getElementById('btn-clean-ram');
    if (btnCleanRam) {
        btnCleanRam.addEventListener('click', async () => {
            btnCleanRam.disabled = true;
            setStatusBox('ram-cleaner-status', 'กำลังล้าง WorkingSet Cache และคืนหน่วยความจำ...', true, true);
            try {
                const res = await window.api.cleanRam();
                if (res.success) {
                    const freed = res.FreedMB > 0 ? `${res.FreedMB} MB` : 'หน่วยความจำถูกจัดระเบียบแล้ว';
                    setStatusBox('ram-cleaner-status', `สำเร็จ! ก่อนล้าง: ${res.BeforeMB} MB | หลังล้าง: ${res.AfterMB} MB (คืนแรม: ${freed})`, true);
                } else {
                    setStatusBox('ram-cleaner-status', `ข้อผิดพลาด: ${res.error}`, false);
                }
            } catch (err) {
                setStatusBox('ram-cleaner-status', `เกิดข้อผิดพลาด: ${err.message}`, false);
            } finally {
                btnCleanRam.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 2. SSD/HDD S.M.A.R.T. Health
    // -------------------------------------------------------------
    const btnDiskHealth = document.getElementById('btn-disk-health');
    const diskDetails = document.getElementById('disk-health-details');
    if (btnDiskHealth && diskDetails) {
        btnDiskHealth.addEventListener('click', async () => {
            btnDiskHealth.disabled = true;
            diskDetails.style.display = 'block';
            diskDetails.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังอ่านสถานะ S.M.A.R.T. ของไดรฟ์...';
            try {
                const res = await window.api.getDiskHealth();
                if (res.success && res.disks && res.disks.length > 0) {
                    let html = '';
                    res.disks.forEach((d, idx) => {
                        const statusColor = d.Status === 'OK' ? '#4ade80' : '#f87171';
                        html += `<div style="margin-bottom: 6px; border-bottom: 1px solid rgba(255,255,255,0.05); padding-bottom: 4px;">
                            <strong>[Drive ${idx + 1}]</strong> ${d.Model}<br>
                            ความจุ: <strong>${d.SizeGB} GB</strong> | ชนิด: ${d.MediaType || d.Interface}<br>
                            สถานะ: <span style="color:${statusColor}; font-weight:bold;">${d.Status}</span> | S/N: ${d.Serial}
                        </div>`;
                    });
                    diskDetails.innerHTML = html;
                } else {
                    diskDetails.innerHTML = `<span style="color:#f87171;">ไม่สามารถอ่านข้อมูลไดรฟ์ได้: ${res.error || 'ไม่มีข้อมูล'}</span>`;
                }
            } catch (err) {
                diskDetails.innerHTML = `<span style="color:#f87171;">Error: ${err.message}</span>`;
            } finally {
                btnDiskHealth.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 3. Hardware Specs & Serial Inspector
    // -------------------------------------------------------------
    const btnHwSpecs = document.getElementById('btn-hw-specs');
    const hwDetails = document.getElementById('hw-specs-details');
    if (btnHwSpecs && hwDetails) {
        btnHwSpecs.addEventListener('click', async () => {
            btnHwSpecs.disabled = true;
            hwDetails.style.display = 'block';
            hwDetails.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังตรวจสอบฮาร์ดแวร์ระบบ...';
            try {
                const res = await window.api.getHardwareSpecs();
                if (res.success && res.specs) {
                    const s = res.specs;
                    hwDetails.innerHTML = `
                        <strong>CPU:</strong> ${s.CPU || 'N/A'}<br>
                        <strong>Motherboard:</strong> ${s.Motherboard || 'N/A'}<br>
                        <strong>RAM รวม:</strong> ${s.RAM_GB} GB (${s.RAM_Sticks} สล็อต)<br>
                        <strong>GPU:</strong> ${s.GPU || 'N/A'}<br>
                        <strong>BIOS:</strong> ${s.BIOS || 'N/A'}<br>
                        <strong>OS:</strong> ${s.OS} (Build ${s.Build})<br>
                        <strong>Serial No.:</strong> <span style="color:#facc15; font-weight:bold;">${s.Serial || 'N/A'}</span>
                    `;
                } else {
                    hwDetails.innerHTML = `<span style="color:#f87171;">ไม่สามารถดึงข้อมูลสเปกได้: ${res.error}</span>`;
                }
            } catch (err) {
                hwDetails.innerHTML = `<span style="color:#f87171;">Error: ${err.message}</span>`;
            } finally {
                btnHwSpecs.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 4. Auto-Shutdown Timer
    // -------------------------------------------------------------
    let shutdownInterval = null;
    let remainingSec = 0;
    const btnSetShutdown = document.getElementById('btn-set-shutdown-timer');
    const btnCancelShutdown = document.getElementById('btn-cancel-shutdown-timer');

    if (btnSetShutdown) {
        btnSetShutdown.addEventListener('click', async () => {
            const timeSel = document.getElementById('shutdown-time-select');
            const actionSel = document.getElementById('shutdown-action-select');
            const sec = parseInt(timeSel ? timeSel.value : '1800');
            const act = actionSel ? actionSel.value : 'shutdown';

            setStatusBox('shutdown-timer-status', 'กำลังตั้งเวลา...', true, true);
            try {
                const res = await window.api.setShutdownTimer(sec, act);
                if (res.success) {
                    remainingSec = sec;
                    clearInterval(shutdownInterval);
                    shutdownInterval = setInterval(() => {
                        if (remainingSec <= 0) {
                            clearInterval(shutdownInterval);
                            setStatusBox('shutdown-timer-status', `ดำเนินการ${act === 'restart' ? 'รีสตาร์ท' : 'ปิดเครื่อง'}แล้ว`, true);
                        } else {
                            const mins = Math.floor(remainingSec / 60);
                            const s = remainingSec % 60;
                            setStatusBox('shutdown-timer-status', `⏱️ จะ${act === 'restart' ? 'รีสตาร์ท' : 'ปิดเครื่อง'}ในอีก ${mins} นาที ${s} วินาที`, true);
                            remainingSec--;
                        }
                    }, 1000);
                } else {
                    setStatusBox('shutdown-timer-status', `ไม่สามารถตั้งเวลาได้: ${res.error}`, false);
                }
            } catch (e) {
                setStatusBox('shutdown-timer-status', `Error: ${e.message}`, false);
            }
        });
    }

    if (btnCancelShutdown) {
        btnCancelShutdown.addEventListener('click', async () => {
            clearInterval(shutdownInterval);
            try {
                const res = await window.api.cancelShutdownTimer();
                if (res.success) {
                    setStatusBox('shutdown-timer-status', 'ยกเลิกการตั้งเวลาปิดเครื่องแล้ว', true);
                } else {
                    setStatusBox('shutdown-timer-status', `Error: ${res.error}`, false);
                }
            } catch (e) {
                setStatusBox('shutdown-timer-status', `Error: ${e.message}`, false);
            }
        });
    }

    // -------------------------------------------------------------
    // 5. Context Menu Cleaner
    // -------------------------------------------------------------
    const btnContextMenu = document.getElementById('btn-context-menu-mgr');
    const contextMenuList = document.getElementById('context-menu-list');
    if (btnContextMenu && contextMenuList) {
        btnContextMenu.addEventListener('click', async () => {
            btnContextMenu.disabled = true;
            contextMenuList.style.display = 'block';
            contextMenuList.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังสแกน Context Menu Handlers...';
            try {
                const res = await window.api.getContextMenuItems();
                if (res.success && res.items && res.items.length > 0) {
                    let html = `<div style="font-weight:bold; margin-bottom:4px; color:#38bdf8;">พบเมนูส่วนขยาย ${res.items.length} รายการ:</div>`;
                    res.items.forEach(it => {
                        html += `<div>• <span style="color:#f8fafc;">${it.Name}</span> <span style="color:#94a3b8; font-size:10px;">(${it.Target || it.Path})</span></div>`;
                    });
                    contextMenuList.innerHTML = html;
                } else {
                    contextMenuList.innerHTML = 'ไม่พบเมนูคลิกขวาที่ผิดปกติ';
                }
            } catch (e) {
                contextMenuList.innerHTML = `<span style="color:#f87171;">Error: ${e.message}</span>`;
            } finally {
                btnContextMenu.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 6. Telemetry & Bloatware Disabler
    // -------------------------------------------------------------
    const btnTelemetry = document.getElementById('btn-disable-telemetry');
    if (btnTelemetry) {
        btnTelemetry.addEventListener('click', async () => {
            btnTelemetry.disabled = true;
            setStatusBox('telemetry-status', 'กำลังปิด DiagTrack และ Telemetry ใน Registry...', true, true);
            try {
                const res = await window.api.disableTelemetry();
                if (res.success) {
                    setStatusBox('telemetry-status', 'ปิด Telemetry, DiagTrack และ Background Tracking เรียบร้อยแล้ว', true);
                } else {
                    setStatusBox('telemetry-status', `ข้อผิดพลาด: ${res.message || res.error}`, false);
                }
            } catch (e) {
                setStatusBox('telemetry-status', `Error: ${e.message}`, false);
            } finally {
                btnTelemetry.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 7. Icon & Font Cache Rebuilder
    // -------------------------------------------------------------
    const btnIconCache = document.getElementById('btn-rebuild-icon-cache');
    if (btnIconCache) {
        btnIconCache.addEventListener('click', async () => {
            btnIconCache.disabled = true;
            setStatusBox('icon-cache-status', 'กำลังลบ IconCache.db และรีสตาร์ท Windows Explorer...', true, true);
            try {
                const res = await window.api.rebuildIconCache();
                if (res.success) {
                    setStatusBox('icon-cache-status', 'ล้างและสร้างแคชไอคอนใหม่เรียบร้อยแล้ว!', true);
                } else {
                    setStatusBox('icon-cache-status', `ข้อผิดพลาด: ${res.message || res.error}`, false);
                }
            } catch (e) {
                setStatusBox('icon-cache-status', `Error: ${e.message}`, false);
            } finally {
                btnIconCache.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 8. System Restore Points
    // -------------------------------------------------------------
    const btnCreateRestore = document.getElementById('btn-create-restore-point');
    const btnListRestore = document.getElementById('btn-list-restore-points');
    const restoreList = document.getElementById('restore-point-list');

    if (btnCreateRestore) {
        btnCreateRestore.addEventListener('click', async () => {
            btnCreateRestore.disabled = true;
            if (restoreList) {
                restoreList.style.display = 'block';
                restoreList.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังสร้างจุด Restore Point...';
            }
            try {
                const res = await window.api.createRestorePoint('THAIVPN Tools Pro Point');
                if (res.success) {
                    if (restoreList) restoreList.innerHTML = `<span style="color:#4ade80;"><i class="fas fa-check"></i> ${res.message}</span>`;
                } else {
                    if (restoreList) restoreList.innerHTML = `<span style="color:#f87171;">Error: ${res.message || res.error}</span>`;
                }
            } catch (e) {
                if (restoreList) restoreList.innerHTML = `<span style="color:#f87171;">Error: ${e.message}</span>`;
            } finally {
                btnCreateRestore.disabled = false;
            }
        });
    }

    if (btnListRestore && restoreList) {
        btnListRestore.addEventListener('click', async () => {
            btnListRestore.disabled = true;
            restoreList.style.display = 'block';
            restoreList.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังดึงรายการจุด Restore Points...';
            try {
                const res = await window.api.getRestorePoints();
                if (res.success && res.points && res.points.length > 0) {
                    let html = `<div style="font-weight:bold; margin-bottom:4px; color:#38bdf8;">พบจุดกู้คืน ${res.points.length} รายการ:</div>`;
                    res.points.forEach(p => {
                        html += `<div>• <strong>#${p.SequenceNumber}</strong>: ${p.Description} <span style="color:#94a3b8; font-size:10px;">(${p.CreationTime})</span></div>`;
                    });
                    restoreList.innerHTML = html;
                } else {
                    restoreList.innerHTML = 'ยังไม่มีจุดกู้คืน หรือ System Restore ปิดอยู่';
                }
            } catch (e) {
                restoreList.innerHTML = `<span style="color:#f87171;">Error: ${e.message}</span>`;
            } finally {
                btnListRestore.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 9. File Lock Hunter
    // -------------------------------------------------------------
    const btnBrowseFileLock = document.getElementById('btn-browse-file-lock');
    const btnCheckFileLock = document.getElementById('btn-check-file-lock');
    const inputFileLock = document.getElementById('input-file-lock-path');
    const fileLockResults = document.getElementById('file-lock-results');

    if (btnBrowseFileLock) {
        btnBrowseFileLock.addEventListener('click', async () => {
            const res = await window.api.findFileLock(null);
            if (res.filePath) {
                if (inputFileLock) inputFileLock.value = res.filePath;
                renderFileLocks(res);
            }
        });
    }

    if (btnCheckFileLock) {
        btnCheckFileLock.addEventListener('click', async () => {
            const p = inputFileLock ? inputFileLock.value.trim() : '';
            btnCheckFileLock.disabled = true;
            if (fileLockResults) {
                fileLockResults.style.display = 'block';
                fileLockResults.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังตรวจสอบ Process ที่ล็อกไฟล์...';
            }
            try {
                const res = await window.api.findFileLock(p);
                renderFileLocks(res);
            } catch (e) {
                if (fileLockResults) fileLockResults.innerHTML = `<span style="color:#f87171;">Error: ${e.message}</span>`;
            } finally {
                btnCheckFileLock.disabled = false;
            }
        });
    }

    function renderFileLocks(res) {
        if (!fileLockResults) return;
        fileLockResults.style.display = 'block';
        if (res.locks && res.locks.length > 0) {
            let html = `<div style="font-weight:bold; color:#f87171; margin-bottom:6px;">⚠️ พบโปรแกรมที่ล็อกไฟล์ ${res.locks.length} ตัว:</div>`;
            res.locks.forEach(l => {
                html += `<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
                    <span><strong>${l.name}</strong> (PID: ${l.pid})</span>
                    <button class="action-btn danger-btn btn-kill-lock" data-pid="${l.pid}" style="padding:2px 8px; font-size:11px;">ปลดล็อก (Kill)</button>
                </div>`;
            });
            fileLockResults.innerHTML = html;
            fileLockResults.querySelectorAll('.btn-kill-lock').forEach(b => {
                b.addEventListener('click', async (e) => {
                    const pid = e.target.dataset.pid;
                    const killRes = await window.api.unlockFile(pid);
                    if (killRes.success) {
                        e.target.parentElement.innerHTML = `<span style="color:#4ade80;">✅ ปิดสำเร็จ (PID ${pid})</span>`;
                    } else {
                        alert('ไม่สามารถปิด Process ได้: ' + killRes.error);
                    }
                });
            });
        } else {
            fileLockResults.innerHTML = '<span style="color:#4ade80;"><i class="fas fa-check"></i> ไม่พบ Process ใดล็อกไฟล์นี้ สามารถลบหรือย้ายได้ตามปกติ</span>';
        }
    }

    // -------------------------------------------------------------
    // 10. Defender Exclusion
    // -------------------------------------------------------------
    const btnDefenderExclusion = document.getElementById('btn-add-defender-exclusion');
    if (btnDefenderExclusion) {
        btnDefenderExclusion.addEventListener('click', async () => {
            btnDefenderExclusion.disabled = true;
            setStatusBox('defender-exclusion-status', 'กำลังเลือกโฟลเดอร์และเพิ่ม Exclusion...', true, true);
            try {
                const res = await window.api.addDefenderExclusion(null);
                if (res.canceled) {
                    setStatusBox('defender-exclusion-status', 'ยกเลิกการเลือกโฟลเดอร์', false);
                } else if (res.success) {
                    setStatusBox('defender-exclusion-status', `เพิ่มโฟลเดอร์ลง Exclusion เรียบร้อยแล้ว: ${res.path}`, true);
                } else {
                    setStatusBox('defender-exclusion-status', `ข้อผิดพลาด: ${res.message || res.error}`, false);
                }
            } catch (e) {
                setStatusBox('defender-exclusion-status', `Error: ${e.message}`, false);
            } finally {
                btnDefenderExclusion.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 11. DNS Speed Benchmark & Switcher
    // -------------------------------------------------------------
    const btnDnsBench = document.getElementById('btn-dns-benchmark');
    const btnDnsApply = document.getElementById('btn-dns-apply');
    const dnsResults = document.getElementById('dns-benchmark-results');

    if (btnDnsBench && dnsResults) {
        btnDnsBench.addEventListener('click', async () => {
            btnDnsBench.disabled = true;
            dnsResults.style.display = 'block';
            dnsResults.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังวัดค่า Ping ไปยัง DNS แต่ละค่าย...';
            try {
                const res = await window.api.benchmarkDns();
                if (res.success && res.results) {
                    let html = '<div style="font-weight:bold; color:#38bdf8; margin-bottom:4px;">ผลการทดสอบความเร็ว DNS:</div>';
                    res.results.forEach((r, idx) => {
                        const pingBadge = r.PingMs < 30 ? '#4ade80' : (r.PingMs < 60 ? '#facc15' : '#f87171');
                        const star = idx === 0 ? ' ⚡ (เร็วที่สุด)' : '';
                        html += `<div><strong>${r.Name}</strong> (${r.Primary}): <span style="color:${pingBadge}; font-weight:bold;">${r.PingMs} ms</span>${star}</div>`;
                    });
                    dnsResults.innerHTML = html;
                } else {
                    dnsResults.innerHTML = `<span style="color:#f87171;">วัดความเร็วไม่สำเร็จ: ${res.error}</span>`;
                }
            } catch (e) {
                dnsResults.innerHTML = `<span style="color:#f87171;">Error: ${e.message}</span>`;
            } finally {
                btnDnsBench.disabled = false;
            }
        });
    }

    if (btnDnsApply) {
        btnDnsApply.addEventListener('click', async () => {
            const sel = document.getElementById('dns-target-select');
            const val = sel ? sel.value : 'cloudflare';
            let primary = '1.1.1.1', secondary = '1.0.0.1', isDhcp = false;
            if (val === 'google') { primary = '8.8.8.8'; secondary = '8.8.4.4'; }
            else if (val === 'quad9') { primary = '9.9.9.9'; secondary = '149.112.112.112'; }
            else if (val === 'dhcp') { isDhcp = true; }

            btnDnsApply.disabled = true;
            try {
                const res = await window.api.setAdapterDns(primary, secondary, isDhcp);
                alert(res.message || 'ตั้งค่า DNS สำเร็จแล้ว');
            } catch (e) {
                alert('Error: ' + e.message);
            } finally {
                btnDnsApply.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 12. Bandwidth Hog Detector
    // -------------------------------------------------------------
    const btnBandwidth = document.getElementById('btn-check-bandwidth');
    const bandwidthList = document.getElementById('bandwidth-hogs-list');
    if (btnBandwidth && bandwidthList) {
        btnBandwidth.addEventListener('click', async () => {
            btnBandwidth.disabled = true;
            bandwidthList.style.display = 'block';
            bandwidthList.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังตรวจสอบการเชื่อมต่ออินเตอร์เน็ต...';
            try {
                const res = await window.api.getBandwidthHogs();
                if (res.success && res.hogs && res.hogs.length > 0) {
                    let html = '<div style="font-weight:bold; color:#f59e0b; margin-bottom:4px;">โปรแกรมที่เปิด Connection สูงสุด:</div>';
                    res.hogs.forEach((h, idx) => {
                        html += `<div><strong>${idx + 1}. ${h.ProcessName}</strong> (PID: ${h.PID}) - ${h.Connections} ช่องทาง | RAM: ${h.WorkingSetMB} MB</div>`;
                    });
                    bandwidthList.innerHTML = html;
                } else {
                    bandwidthList.innerHTML = 'ไม่พบโปรแกรมที่ใช้งานเน็ตหนาแน่น';
                }
            } catch (e) {
                bandwidthList.innerHTML = `<span style="color:#f87171;">Error: ${e.message}</span>`;
            } finally {
                btnBandwidth.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 13. Virtual WiFi Hotspot
    // -------------------------------------------------------------
    const btnHotspotStart = document.getElementById('btn-hotspot-start');
    const btnHotspotStop = document.getElementById('btn-hotspot-stop');

    if (btnHotspotStart) {
        btnHotspotStart.addEventListener('click', async () => {
            const ssid = document.getElementById('input-hotspot-ssid')?.value.trim() || 'THAIVPN_Hotspot';
            const key = document.getElementById('input-hotspot-key')?.value.trim() || '12345678';
            setStatusBox('hotspot-status', 'กำลังเปิด Mobile Hotspot...', true, true);
            try {
                const res = await window.api.toggleWifiHotspot(true, ssid, key);
                if (res.success) {
                    setStatusBox('hotspot-status', res.message || `เปิด WiFi Hotspot "${ssid}" สำเร็จแล้ว!`, true);
                } else {
                    setStatusBox('hotspot-status', `ไม่สามารถเปิด Hotspot ได้: ${res.message || res.error || res.raw}`, false);
                }
            } catch (e) {
                setStatusBox('hotspot-status', `Error: ${e.message}`, false);
            }
        });
    }

    if (btnHotspotStop) {
        btnHotspotStop.addEventListener('click', async () => {
            try {
                const res = await window.api.toggleWifiHotspot(false, '', '');
                setStatusBox('hotspot-status', 'ปิดสัญญาณ Hotspot เรียบร้อยแล้ว', true);
            } catch (e) {
                setStatusBox('hotspot-status', `Error: ${e.message}`, false);
            }
        });
    }

    // -------------------------------------------------------------
    // 14. Hosts Adblock Presets
    // -------------------------------------------------------------
    const btnHostsAdblock = document.getElementById('btn-hosts-adblock');
    const btnHostsRestore = document.getElementById('btn-hosts-restore');

    if (btnHostsAdblock) {
        btnHostsAdblock.addEventListener('click', async () => {
            btnHostsAdblock.disabled = true;
            setStatusBox('hosts-preset-status', 'กำลังบันทึกกฎ Adblock ลงไฟล์ Hosts...', true, true);
            try {
                const res = await window.api.applyHostsPreset('adblock');
                setStatusBox('hosts-preset-status', res.message || res.error, res.success);
            } catch (e) {
                setStatusBox('hosts-preset-status', `Error: ${e.message}`, false);
            } finally {
                btnHostsAdblock.disabled = false;
            }
        });
    }

    if (btnHostsRestore) {
        btnHostsRestore.addEventListener('click', async () => {
            btnHostsRestore.disabled = true;
            try {
                const res = await window.api.applyHostsPreset('restore');
                setStatusBox('hosts-preset-status', res.message || res.error, res.success);
            } catch (e) {
                setStatusBox('hosts-preset-status', `Error: ${e.message}`, false);
            } finally {
                btnHostsRestore.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 15. TCP/IP Latency Optimizer
    // -------------------------------------------------------------
    const btnTcpOpt = document.getElementById('btn-tcp-optimize');
    if (btnTcpOpt) {
        btnTcpOpt.addEventListener('click', async () => {
            btnTcpOpt.disabled = true;
            setStatusBox('tcp-optimize-status', 'กำลังปรับแต่งเน็ตเวิร์กสแต็ก TCP/IP...', true, true);
            try {
                const res = await window.api.optimizeTcp();
                setStatusBox('tcp-optimize-status', res.message || res.error, res.success);
            } catch (e) {
                setStatusBox('tcp-optimize-status', `Error: ${e.message}`, false);
            } finally {
                btnTcpOpt.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 16. 1-Click APK Installer
    // -------------------------------------------------------------
    const btnBrowseApk = document.getElementById('btn-browse-apk');
    const btnInstallApk = document.getElementById('btn-install-apk');
    const inputApkPath = document.getElementById('input-apk-path');

    if (btnBrowseApk) {
        btnBrowseApk.addEventListener('click', async () => {
            const res = await window.api.adbInstallApk(null, null);
            if (res && res.apkPath) {
                if (inputApkPath) inputApkPath.value = res.apkPath;
                if (res.success) {
                    setStatusBox('apk-install-status', `ติดตั้งสำเร็จ: ${res.output}`, true);
                } else if (!res.canceled) {
                    setStatusBox('apk-install-status', `ติดตั้งล้มเหลว: ${res.error || res.output}`, false);
                }
            }
        });
    }

    if (btnInstallApk) {
        btnInstallApk.addEventListener('click', async () => {
            const p = inputApkPath ? inputApkPath.value.trim() : '';
            if (!p) {
                alert('กรุณาเลือกไฟล์ APK ก่อน');
                return;
            }
            btnInstallApk.disabled = true;
            setStatusBox('apk-install-status', 'กำลังส่งไฟล์และสั่งติดตั้งผ่าน ADB...', true, true);
            openModal('ADB: Install APK');
            logToModal(`> Target APK: ${p}\n`);
            logToModal('> Pushing and installing APK package via ADB...\n');
            try {
                const res = await window.api.adbInstallApk(p, null);
                if (res.success) {
                    setStatusBox('apk-install-status', `ติดตั้งแอปสำเร็จเรียบร้อย! (${res.output})`, true);
                    logToModal(`\n${res.output || 'Install success!'}\n`, 'success');
                    finishModal(true);
                } else {
                    setStatusBox('apk-install-status', `ติดตั้งไม่สำเร็จ: ${res.error || res.output}`, false);
                    logToModal(`\n[ERROR] ${res.error || res.output}\n`, 'error');
                    finishModal(false);
                }
            } catch (e) {
                setStatusBox('apk-install-status', `Error: ${e.message}`, false);
                logToModal(`\n[ERROR] ${e.message}\n`, 'error');
                finishModal(false);
            } finally {
                btnInstallApk.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 17. Live Screen Mirror
    // -------------------------------------------------------------
    const btnScreenMirror = document.getElementById('btn-screen-mirror');

    if (btnScreenMirror) {
        btnScreenMirror.addEventListener('click', async () => {
            btnScreenMirror.disabled = true;
            setStatusBox('screen-mirror-status', 'กำลังเชื่อมต่อและดึงภาพหน้าจอ...', true, true);
            try {
                const res = await window.api.launchScreenMirror(null);
                if (res.success) {
                    setStatusBox('screen-mirror-status', res.message || 'เปิดหน้าต่าง Live Screen Mirror เรียบร้อยแล้ว', true);
                } else {
                    setStatusBox('screen-mirror-status', `ไม่สามารถเปิด Mirror ได้: ${res.error}`, false);
                }
            } catch (e) {
                setStatusBox('screen-mirror-status', `Error: ${e.message}`, false);
            } finally {
                btnScreenMirror.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 18. Flashing Driver Conflict Auto-Fixer
    // -------------------------------------------------------------
    const btnDriverFix = document.getElementById('btn-fix-driver-conflicts');
    if (btnDriverFix) {
        btnDriverFix.addEventListener('click', async () => {
            btnDriverFix.disabled = true;
            setStatusBox('driver-fix-status', 'กำลังรีเซ็ต ADB Port Server และสแกนพอร์ต...', true, true);
            openModal('System: Fix Flashing Driver Conflicts');
            logToModal('> Resetting ADB Server & cleaning up conflicting USB filter drivers...\n');
            try {
                const res = await window.api.fixDriverConflicts();
                const msg = res.Message || res.message || 'รีเซ็ตไดรเวอร์พอร์ตเสร็จสมบูรณ์';
                setStatusBox('driver-fix-status', msg, true);
                logToModal(`\n✅ ${msg}\n`, 'success');
                finishModal(true);
            } catch (e) {
                setStatusBox('driver-fix-status', `Error: ${e.message}`, false);
            } finally {
                btnDriverFix.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 19. 1-Click Android Backup & Extractor
    // -------------------------------------------------------------
    const btnAndroidBackup = document.getElementById('btn-android-backup');
    if (btnAndroidBackup) {
        btnAndroidBackup.addEventListener('click', async () => {
            const folderSel = document.getElementById('backup-folder-type');
            const folderType = folderSel ? folderSel.value : 'dcim';
            btnAndroidBackup.disabled = true;
            setStatusBox('android-backup-status', `กำลังดึงข้อมูลจากโฟลเดอร์ ${folderType.toUpperCase()} ผ่าน ADB...`, true, true);
            openModal(`Storage: 1-Click Storage Extractor (${folderType.toUpperCase()})`);
            logToModal(`> Pulling files from /sdcard/${folderType.toUpperCase()} to Desktop...\n`);
            try {
                const res = await window.api.backupAndroidStorage(folderType, null, null);
                if (res.success) {
                    setStatusBox('android-backup-status', `สำรองข้อมูลสำเร็จ! บันทึกไว้ที่: ${res.destDir}`, true);
                    logToModal(`\n✅ Backup completed successfully!\n> Saved to: ${res.destDir}\n`, 'success');
                    finishModal(true);
                } else {
                    setStatusBox('android-backup-status', `สำรองข้อมูลไม่สำเร็จ: ${res.error}`, false);
                }
            } catch (e) {
                setStatusBox('android-backup-status', `Error: ${e.message}`, false);
            } finally {
                btnAndroidBackup.disabled = false;
            }
        });
    }

    // -------------------------------------------------------------
    // 20. EFS / NVRAM Modem Backup Tool
    // -------------------------------------------------------------
    const btnBackupEfs = document.getElementById('btn-backup-efs');
    if (btnBackupEfs) {
        btnBackupEfs.addEventListener('click', async () => {
            btnBackupEfs.disabled = true;
            setStatusBox('efs-backup-status', 'กำลังตรวจสอบสิทธิ์ Root และดึงพาร์ติชันโมเด็ม...', true, true);
            openModal('Security: Backup EFS / NVRAM Modem');
            logToModal('> Scanning modem partitions (modemst1, modemst2, fsg, fsc, nvram)...\n');
            try {
                const res = await window.api.backupEfsPartitions(null, null);
                if (res.success) {
                    setStatusBox('efs-backup-status', `สำรองพาร์ติชันสำเร็จ! (${res.backedUp.join(', ')}) เก็บไว้ที่: ${res.destDir}`, true);
                    logToModal(`\n✅ EFS partitions saved successfully! (${res.backedUp.join(', ')})\n> Target: ${res.destDir}\n`, 'success');
                    finishModal(true);
                } else {
                    setStatusBox('efs-backup-status', `ไม่สามารถสำรองได้: ${res.error}`, false);
                }
            } catch (e) {
                setStatusBox('efs-backup-status', `Error: ${e.message}`, false);
            } finally {
                btnBackupEfs.disabled = false;
            }
        });
    }

    console.log('[PRO SUPERPOWERS] All 20 Pro Features initialized and ready!');
})();


// ============================================================================
// HWID Cloud Authentication & License Gate Controller
// ============================================================================
(function initHWIDSystem() {
    console.log('[HWID SYSTEM] Initializing HWID License Gate...');

    const gateModal = document.getElementById('hwid-gate-modal');
    const hwidDisplayText = document.getElementById('hwid-display-text');
    const hwidPcBadge = document.getElementById('hwid-pc-badge');
    const btnCopyHwid = document.getElementById('btn-copy-hwid');
    const btnCopyHwidText = document.getElementById('btn-copy-hwid-text');
    const btnHwidCheck = document.getElementById('btn-hwid-check');
    const btnHwidCheckText = document.getElementById('btn-hwid-check-text');
    const hwidRefreshIcon = document.getElementById('hwid-refresh-icon');
    const btnHwidContact = document.getElementById('btn-hwid-contact');
    const btnHwidExit = document.getElementById('btn-hwid-exit');

    // Settings Modal Elements
    const settingsHwidDisplay = document.getElementById('settings-hwid-display');
    const settingsBtnCopyHwid = document.getElementById('settings-btn-copy-hwid');
    const settingsLicBadge = document.getElementById('settings-lic-badge');
    const settingsBtnRecheckLic = document.getElementById('settings-btn-recheck-lic');

    let currentHWID = '';
    let currentContactLink = 'https://line.me/ti/p/FydMlMc6g1';
    let currentTgLink = 'https://t.me/Dathai';

    function setStatusUI(status) {
        if (!settingsLicBadge) return;
        const s = (status || '').toLowerCase();
        if (s === 'active') {
            settingsLicBadge.textContent = 'Active (Lifetime)';
            settingsLicBadge.style.background = 'rgba(34,197,94,0.2)';
            settingsLicBadge.style.color = '#4ade80';
        } else if (s === 'pending') {
            settingsLicBadge.textContent = 'Pending';
            settingsLicBadge.style.background = 'rgba(245,158,11,0.2)';
            settingsLicBadge.style.color = '#fbbf24';
        } else if (s === 'expired') {
            settingsLicBadge.textContent = 'Expired';
            settingsLicBadge.style.background = 'rgba(239,68,68,0.2)';
            settingsLicBadge.style.color = '#f87171';
        } else {
            settingsLicBadge.textContent = 'Unauthorized';
            settingsLicBadge.style.background = 'rgba(239,68,68,0.2)';
            settingsLicBadge.style.color = '#f87171';
        }
    }

    function unlockGate() {
        if (!gateModal) return;
        gateModal.classList.add('hwid-hidden');
        setTimeout(() => {
            gateModal.style.display = 'none';
        }, 360);
    }

    function lockGate() {
        if (!gateModal) return;
        gateModal.style.display = 'flex';
        requestAnimationFrame(() => {
            gateModal.classList.remove('hwid-hidden');
        });
    }

    // Check Cloud Status
    async function checkHWID(interactive = true) {
        if (!window.api || !window.api.verifyHWIDCloud) return;

        if (interactive) {
            if (btnHwidCheck) {
                btnHwidCheck.disabled = true;
                if (btnHwidCheckText) btnHwidCheckText.textContent = 'กำลังตรวจสอบ...';
            }
            if (hwidRefreshIcon) hwidRefreshIcon.classList.add('fa-spin');
        }

        try {
            const res = await window.api.verifyHWIDCloud();
            console.log('[HWID VERIFY RES]', res);

            if (res && res.authorized) {
                if (btnHwidCheckText) btnHwidCheckText.textContent = '✓ ได้รับสิทธิ์แล้ว!';
                setStatusUI('active');
                setTimeout(() => {
                    unlockGate();
                }, 600);
            } else {
                if (interactive) {
                    alert('ยังไม่มี HWID ของเครื่องนี้ในระบบ\nกรุณากดปุ่ม "คัดลอก HWID" ด้านบน แล้วส่งให้ ผู้พัฒนา เพื่อเปิดสิทธิ์การใช้งานโปรแกรม');
                }
            }
        } catch (err) {
            console.error('[HWID VERIFY ERR]', err);
            if (interactive) {
                alert('ไม่สามารถเชื่อมต่อระบบได้ กรุณาลองใหม่อีกครั้ง');
            }
        } finally {
            if (interactive) {
                if (btnHwidCheck) {
                    btnHwidCheck.disabled = false;
                    if (btnHwidCheckText) btnHwidCheckText.textContent = 'ตรวจสอบสิทธิ์อีกครั้ง';
                }
                if (hwidRefreshIcon) hwidRefreshIcon.classList.remove('fa-spin');
            }
        }
    }

    // Copy HWID helper
    function copyText(text, btnElement, labelElement) {
        if (!text) return;
        navigator.clipboard.writeText(text).then(() => {
            const origHTML = labelElement ? labelElement.textContent : (btnElement ? btnElement.innerHTML : '');
            if (labelElement) {
                labelElement.textContent = '✓ คัดลอกแล้ว!';
            } else if (btnElement) {
                btnElement.innerHTML = '<i class="fas fa-check" style="color: #4ade80;"></i>';
            }
            setTimeout(() => {
                if (labelElement) labelElement.textContent = origHTML;
                else if (btnElement) btnElement.innerHTML = origHTML;
            }, 1800);
        }).catch(err => {
            console.error('Clipboard copy failed:', err);
            prompt('คัดลอก HWID:', text);
        });
    }

    // Init function
    async function loadHWIDInfo() {
        if (!window.api || !window.api.getHWIDInfo) return;

        // Listen for startup HWID result from main process
        if (window.api.onStartupHWIDResult) {
            window.api.onStartupHWIDResult((startupRes) => {
                console.log('[RENDERER] Received startup HWID result:', startupRes);
                if (startupRes && startupRes.authorized) {
                    setStatusUI('active', 'ยืนยันสิทธิ์ประจำเครื่องเรียบร้อย');
                    unlockGate();
                } else {
                    console.log('[RENDERER] HWID not authorized on startup. Popping up modal with developer contact.');
                    if (startupRes && startupRes.hwid) {
                        currentHWID = startupRes.hwid;
                        if (hwidDisplayText) hwidDisplayText.textContent = currentHWID;
                    }
                    setStatusUI(startupRes ? startupRes.status : 'pending');
                    lockGate();
                }
            });
        }

        try {
            const info = await window.api.getHWIDInfo();
            console.log('[HWID INFO LOADED]', info);

            currentHWID = info.hwid || '';
            if (info.contactLink) currentContactLink = info.contactLink;
            if (info.telegramLink) currentTgLink = info.telegramLink;

            // Fill UI fields
            if (hwidDisplayText) hwidDisplayText.textContent = currentHWID;
            if (hwidPcBadge) hwidPcBadge.innerHTML = `<i class="fas fa-desktop"></i> ${info.pcName || 'PC'}`;

            if (settingsHwidDisplay) settingsHwidDisplay.value = currentHWID;

            if (info.isActivated) {
                console.log('[HWID] Device is already activated locally.');
                setStatusUI('active');
                unlockGate();
            } else {
                console.log('[HWID] Device not activated yet. Showing HWID popup modal.');
                setStatusUI(info.status || 'pending');
                lockGate();
            }
        } catch (err) {
            console.error('[HWID INIT ERR]', err);
        }
    }

    // Event Listeners
    if (btnCopyHwid) {
        btnCopyHwid.addEventListener('click', () => {
            copyText(currentHWID, btnCopyHwid, btnCopyHwidText);
        });
    }

    if (settingsBtnCopyHwid) {
        settingsBtnCopyHwid.addEventListener('click', () => {
            copyText(currentHWID, settingsBtnCopyHwid, null);
        });
    }

    if (btnHwidCheck) {
        btnHwidCheck.addEventListener('click', () => checkHWID(true));
    }

    if (settingsBtnRecheckLic) {
        settingsBtnRecheckLic.addEventListener('click', async () => {
            settingsBtnRecheckLic.disabled = true;
            settingsBtnRecheckLic.innerHTML = '<i class="fas fa-sync fa-spin"></i> ตรวจสอบ...';
            try {
                const res = await window.api.verifyHWIDCloud();
                if (res.authorized) {
                    alert('🎉 ตรวจสอบสิทธิ์สำเร็จ: บัญชีของคุณ Active เรียบร้อย!');
                    if (settingsLicBadge) {
                        settingsLicBadge.textContent = 'Active (Lifetime)';
                        settingsLicBadge.style.background = 'rgba(34,197,94,0.2)';
                        settingsLicBadge.style.color = '#4ade80';
                    }
                    unlockGate();
                } else {
                    alert(`⚠️ ผลการตรวจสอบ: สถานะคือ [${res.status || 'Pending'}]\n${res.message || 'ยังไม่ได้รับการอนุมัติ'}`);
                }
            } catch (e) {
                alert('❌ ไม่สามารถตรวจสอบได้: ' + e.message);
            } finally {
                settingsBtnRecheckLic.disabled = false;
                settingsBtnRecheckLic.innerHTML = '<i class="fas fa-sync"></i> ตรวจสอบสิทธิ์';
            }
        });
    }

    if (btnHwidContact) {
        btnHwidContact.addEventListener('click', () => {
            if (window.api && window.api.openExternalUrl) {
                window.api.openExternalUrl(currentContactLink);
            } else {
                window.open(currentContactLink, '_blank');
            }
        });
    }

    const btnHwidTg = document.getElementById('btn-hwid-tg');
    if (btnHwidTg) {
        btnHwidTg.addEventListener('click', () => {
            if (window.api && window.api.openExternalUrl) {
                window.api.openExternalUrl(currentTgLink);
            } else {
                window.open(currentTgLink, '_blank');
            }
        });
    }







    // Exit Button
    if (btnHwidExit) {
        btnHwidExit.addEventListener('click', async () => {
            if (window.api && window.api.appQuit) {
                await window.api.appQuit();
            } else {
                window.close();
            }
        });
    }

    // Start on DOM Ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', loadHWIDInfo);
    } else {
        loadHWIDInfo();
    }
})();





    // =========================================================================
    // MOBILE TOOLS: RIGHT PANEL & LIVE SCREEN MIRROR CONTROLLER
    // =========================================================================
    (function initMobileRightPanel() {
        // 1. Tab Switcher
        const btnTabLog = document.getElementById('btn-panel-tab-log');
        const btnTabScreen = document.getElementById('btn-panel-tab-screen');
        if (btnTabLog) btnTabLog.addEventListener('click', () => showRightPanelTab('log'));
        if (btnTabScreen) {
            btnTabScreen.addEventListener('click', () => {
                showRightPanelTab('screen');
                // Automatically fetch screen frame when entering screen tab if not already shown
                const img = document.getElementById('mobile-screen-img');
                if (!img || img.style.display === 'none') {
                    fetchInAppScreenFrame();
                }
            });
        }

        // 2. Clear & Copy Log Buttons
        const btnClearLog = document.getElementById('btn-panel-clear-log');
        if (btnClearLog) {
            btnClearLog.addEventListener('click', () => {
                const terminal = document.getElementById('mobile-panel-terminal');
                if (terminal) {
                    const v = (typeof currentAppVersion !== 'undefined' && currentAppVersion) ? currentAppVersion : '2.3.6';
                    terminal.innerHTML = `================================================\n THAIVPN Professional Mobile Service Console v${v}\n Port Engine: Qualcomm EDL / MTK / SPD / ADB\n================================================\n`;
                }
                const pTitle = document.getElementById('mobile-panel-action-title');
                if (pTitle) pTitle.textContent = 'พร้อมทำงาน (Waiting for task...)';
                const pBadge = document.getElementById('mobile-panel-badge');
                if (pBadge) {
                    pBadge.textContent = 'READY';
                    pBadge.style.background = 'rgba(34, 197, 94, 0.15)';
                    pBadge.style.color = '#4ade80';
                    pBadge.style.borderColor = 'rgba(34, 197, 94, 0.3)';
                }
                const pBar = document.getElementById('mobile-panel-progress-bar');
                if (pBar) pBar.style.width = '0%';
                const pTxt = document.getElementById('mobile-panel-progress-text');
                if (pTxt) pTxt.textContent = '0%';

                // Reset Dual Progress Bars
                const lblCurrPart = document.getElementById('spd-lbl-curr-part');
                const lblCurrPct = document.getElementById('spd-lbl-curr-pct');
                const barCurrFill = document.getElementById('spd-bar-curr-fill');
                const lblTotalSpeed = document.getElementById('spd-lbl-total-speed');
                const lblTotalPct = document.getElementById('spd-lbl-total-pct');
                const barTotalFill = document.getElementById('spd-bar-total-fill');

                if (lblCurrPart) lblCurrPart.textContent = 'พาร์ติชันปัจจุบัน: พร้อมใช้งาน';
                if (lblCurrPct) lblCurrPct.textContent = '0%';
                if (barCurrFill) {
                    barCurrFill.style.width = '0%';
                    barCurrFill.style.background = 'linear-gradient(90deg, #0284c7, #38bdf8)';
                }
                if (lblTotalSpeed) lblTotalSpeed.textContent = 'ความคืบหน้ารวม: 0.0 KB/s';
                if (lblTotalPct) lblTotalPct.textContent = '0%';
                if (barTotalFill) {
                    barTotalFill.style.width = '0%';
                    barTotalFill.style.background = 'linear-gradient(90deg, #059669, #10b981, #34d399)';
                }
            });
        }

        const btnCopyLog = document.getElementById('btn-panel-copy-log');
        if (btnCopyLog) {
            btnCopyLog.addEventListener('click', () => {
                const terminal = document.getElementById('mobile-panel-terminal');
                if (terminal) {
                    navigator.clipboard.writeText(terminal.innerText).then(() => {
                        const orig = btnCopyLog.innerHTML;
                        btnCopyLog.innerHTML = '<i class="fas fa-check" style="color: #4ade80;"></i>';
                        setTimeout(() => btnCopyLog.innerHTML = orig, 1500);
                    });
                }
            });
        }

        // Mobile Right Panel (Console Log & Screen Mirror) Toggle
        const btnTogglePanel = document.getElementById('btn-toggle-right-panel');
        const btnClosePanel = document.getElementById('btn-panel-close');
        const rightPanel = document.getElementById('mobile-right-panel');

        function toggleMobileRightPanel() {
            if (!rightPanel) return;
            const isCollapsed = rightPanel.classList.toggle('panel-collapsed');
            localStorage.setItem('mobile_console_collapsed', isCollapsed ? 'true' : 'false');
            if (btnTogglePanel) {
                btnTogglePanel.innerHTML = isCollapsed 
                    ? '<i class="fas fa-terminal"></i> <span>เปิดคอนโซล Log</span>' 
                    : '<i class="fas fa-terminal"></i> <span>คอนโซล Log</span>';
                if (isCollapsed) {
                    btnTogglePanel.style.background = 'rgba(255, 255, 255, 0.08)';
                    btnTogglePanel.style.color = '#94a3b8';
                    btnTogglePanel.style.borderColor = 'rgba(255, 255, 255, 0.15)';
                } else {
                    btnTogglePanel.style.background = 'rgba(56, 189, 248, 0.15)';
                    btnTogglePanel.style.color = '#38bdf8';
                    btnTogglePanel.style.borderColor = 'rgba(56, 189, 248, 0.35)';
                }
            }
        }

        if (btnTogglePanel) {
            btnTogglePanel.addEventListener('click', toggleMobileRightPanel);
        }
        if (btnClosePanel) {
            btnClosePanel.addEventListener('click', toggleMobileRightPanel);
        }

        if (rightPanel && localStorage.getItem('mobile_console_collapsed') === 'true') {
            rightPanel.classList.add('panel-collapsed');
            if (btnTogglePanel) {
                btnTogglePanel.innerHTML = '<i class="fas fa-terminal"></i> <span>เปิดคอนโซล Log</span>';
                btnTogglePanel.style.background = 'rgba(255, 255, 255, 0.08)';
                btnTogglePanel.style.color = '#94a3b8';
                btnTogglePanel.style.borderColor = 'rgba(255, 255, 255, 0.15)';
            }
        }

        // 3. Live In-App Screen Mirror Engine
        let screenStreamInterval = null;
        let isFetchingFrame = false;

        async function fetchInAppScreenFrame() {
            if (isFetchingFrame) return;
            isFetchingFrame = true;

            const loader = document.getElementById('mobile-screen-loader');
            const placeholder = document.getElementById('mobile-screen-placeholder');
            const img = document.getElementById('mobile-screen-img');

            if (img && img.style.display === 'none' && loader) {
                loader.style.display = 'flex';
            }

            try {
                if (window.api && window.api.getDeviceScreenFrame) {
                    const res = await window.api.getDeviceScreenFrame(null);
                    if (res && res.success && res.image) {
                        if (placeholder) placeholder.style.display = 'none';
                        if (loader) loader.style.display = 'none';
                        if (img) {
                            img.src = res.image;
                            img.style.display = 'block';
                        }
                    } else {
                        if (loader) loader.style.display = 'none';
                        if (img && img.style.display === 'none' && placeholder) {
                            placeholder.style.display = 'block';
                        }
                    }
                }
            } catch (e) {
                if (loader) loader.style.display = 'none';
            } finally {
                isFetchingFrame = false;
            }
        }

        const btnStart = document.getElementById('btn-inapp-screen-start');
        if (btnStart) btnStart.addEventListener('click', fetchInAppScreenFrame);

        const btnRefresh = document.getElementById('btn-inapp-screen-refresh');
        if (btnRefresh) btnRefresh.addEventListener('click', fetchInAppScreenFrame);

        // Continuous Live Stream Toggle
        const btnStream = document.getElementById('btn-inapp-screen-stream');
        const txtStream = document.getElementById('txt-inapp-stream');
        if (btnStream) {
            btnStream.addEventListener('click', () => {
                if (screenStreamInterval) {
                    clearInterval(screenStreamInterval);
                    screenStreamInterval = null;
                    btnStream.classList.remove('danger-btn');
                    btnStream.classList.add('warning-btn');
                    if (txtStream) txtStream.textContent = 'สตรีมสดต่อเนื่อง';
                } else {
                    fetchInAppScreenFrame();
                    screenStreamInterval = setInterval(fetchInAppScreenFrame, 500);
                    btnStream.classList.remove('warning-btn');
                    btnStream.classList.add('danger-btn');
                    if (txtStream) txtStream.textContent = 'หยุดสตรีมสด';
                }
            });
        }

        // Launch 60 FPS Scrcpy Window docked to the right
        const btnScrcpy = document.getElementById('btn-inapp-screen-scrcpy');
        if (btnScrcpy) {
            btnScrcpy.addEventListener('click', async () => {
                btnScrcpy.disabled = true;
                const bounds = {
                    x: window.screenX,
                    y: window.screenY,
                    width: window.outerWidth,
                    height: window.outerHeight
                };
                try {
                    logToModal('> กำลังเปิดหน้าต่าง Live Mirror (Scrcpy 60 FPS ไร้ดีเลย์)...\n', 'info');
                    if (window.api && window.api.launchScreenMirror) {
                        const res = await window.api.launchScreenMirror(null, bounds);
                        if (res && res.success) {
                            logToModal(`[SUCCESS] ${res.message}\n`, 'success');
                        } else {
                            logToModal(`[ERROR] ${res ? res.error : 'ไม่สามารถเปิดได้'}\n`, 'error');
                        }
                    }
                } catch (err) {
                    logToModal(`[ERROR] ${err.message}\n`, 'error');
                } finally {
                    btnScrcpy.disabled = false;
                }
            });
        }

        // Also connect the existing btn-screen-mirror buttons in tab-adb and tab-superpowers
        const allMirrorBtns = document.querySelectorAll('#btn-screen-mirror');
        allMirrorBtns.forEach(b => {
            b.addEventListener('click', () => {
                showRightPanelTab('screen');
                fetchInAppScreenFrame();
            });
        });

        // Touch Click on Phone Image -> Send adb shell input tap
        const phoneImg = document.getElementById('mobile-screen-img');
        if (phoneImg) {
            phoneImg.addEventListener('click', async (e) => {
                if (!phoneImg.naturalWidth || !phoneImg.naturalHeight) return;
                const rect = phoneImg.getBoundingClientRect();
                const clickX = e.clientX - rect.left;
                const clickY = e.clientY - rect.top;
                
                const pctX = clickX / rect.width;
                const pctY = clickY / rect.height;

                const deviceX = Math.round(pctX * phoneImg.naturalWidth);
                const deviceY = Math.round(pctY * phoneImg.naturalHeight);

                // Visual tap indicator
                const ripple = document.createElement('div');
                ripple.style.position = 'absolute';
                ripple.style.left = `${e.clientX - rect.left - 10}px`;
                ripple.style.top = `${e.clientY - rect.top - 10}px`;
                ripple.style.width = '20px';
                ripple.style.height = '20px';
                ripple.style.borderRadius = '50%';
                ripple.style.background = 'rgba(56, 189, 248, 0.6)';
                ripple.style.pointerEvents = 'none';
                ripple.style.transition = 'all 0.3s ease-out';
                phoneImg.parentElement.appendChild(ripple);
                setTimeout(() => {
                    ripple.style.transform = 'scale(2)';
                    ripple.style.opacity = '0';
                    setTimeout(() => ripple.remove(), 300);
                }, 10);

                if (window.api && window.api.sendDeviceTouch) {
                    await window.api.sendDeviceTouch(deviceX, deviceY, null);
                    setTimeout(fetchInAppScreenFrame, 350);
                }
            });
        }

        // Virtual Navigation Bar Keys (Back, Home, Recent, Power)
        const navKeys = document.querySelectorAll('.phone-nav-key-btn');
        navKeys.forEach(k => {
            k.addEventListener('click', async () => {
                const key = k.getAttribute('data-key');
                if (window.api && window.api.sendDeviceKey) {
                    await window.api.sendDeviceKey(key, null);
                    setTimeout(fetchInAppScreenFrame, 350);
                }
            });
        });

    })();


    // ========================================================================
    // IN-APP AUTO-UPDATER CLIENT CONTROLLER
    // ========================================================================
    let pendingUpdateInfo = null;

    function showUpdateModal(info) {
        pendingUpdateInfo = info;
        const modal = document.getElementById('update-modal');
        if (!modal) return;

        const curVerEl = document.getElementById('update-current-ver');
        const latVerEl = document.getElementById('update-latest-ver');
        const dateEl = document.getElementById('update-release-date');
        const listEl = document.getElementById('update-changelog-list');
        const progContainer = document.getElementById('update-progress-container');
        const btnUpdateNow = document.getElementById('btn-update-now');
        const btnCancel = document.getElementById('btn-update-cancel');

        if (curVerEl) curVerEl.textContent = 'v' + (info.currentVersion || '2.0.0');
        if (latVerEl) latVerEl.textContent = 'v' + (info.latestVersion || '2.0.1');
        if (dateEl) dateEl.textContent = info.releaseDate || '';

        if (listEl) {
            listEl.innerHTML = '';
            const logs = Array.isArray(info.changelog) ? info.changelog : [info.changelog || 'ปรับปรุงและแก้ไขทั่วไป'];
            logs.forEach(item => {
                const row = document.createElement('div');
                row.style.marginBottom = '4px';
                row.innerHTML = `<span style="color: #38bdf8; margin-right: 6px;">•</span> ${item}`;
                listEl.appendChild(row);
            });
        }

        if (progContainer) progContainer.style.display = 'none';
        if (btnUpdateNow) {
            btnUpdateNow.disabled = false;
            btnUpdateNow.innerHTML = '<i class="fas fa-download"></i> ดาวน์โหลดและอัปเดตทันที';
        }
        if (btnCancel) btnCancel.style.display = 'block';

        modal.style.display = 'flex';
    }

    function hideUpdateModal() {
        const modal = document.getElementById('update-modal');
        if (modal) modal.style.display = 'none';
    }

    // Initialize version label in sidebar & all badges
    let currentAppVersion = '2.3.6';
    if (window.api && window.api.getAppVersion) {
        window.api.getAppVersion().then(v => {
            if (!v) return;
            currentAppVersion = v;
            document.title = 'THAIVPN Tools v' + v;
            const verEl = document.getElementById('sidebar-app-version');
            if (verEl) verEl.textContent = 'v' + v;
            document.querySelectorAll('.version-badge').forEach(el => { el.textContent = 'v' + v; });
            const curEl = document.getElementById('update-current-ver');
            if (curEl) curEl.textContent = 'v' + v;
            const term = document.getElementById('mobile-panel-terminal');
            if (term && term.innerHTML.includes('Console v')) {
                term.innerHTML = term.innerHTML.replace(/Console v[0-9\.]+/g, 'Console v' + v);
            }
        }).catch(() => {});
    }

    // Handle Manual 'Check for Updates' Click
    const btnCheckUpdate = document.getElementById('btn-check-update');
    if (btnCheckUpdate) {
        btnCheckUpdate.addEventListener('click', async () => {
            const icon = document.getElementById('icon-check-update');
            if (icon) icon.classList.add('fa-spin');
            btnCheckUpdate.disabled = true;

            try {
                if (window.api && window.api.checkForUpdates) {
                    const res = await window.api.checkForUpdates();
                    if (res && res.updateAvailable) {
                        showUpdateModal(res);
                    } else if (res && res.success) {
                        alert(`คุณกำลังใช้งานเวอร์ชันล่าสุดแล้ว (v${res.currentVersion})`);
                    } else {
                        alert(`ไม่สามารถตรวจสอบอัปเดตได้: ${res ? res.error : 'Network Error'}`);
                    }
                }
            } catch (err) {
                alert('เกิดข้อผิดพลาดในการตรวจสอบอัปเดต: ' + err.message);
            } finally {
                if (icon) icon.classList.remove('fa-spin');
                btnCheckUpdate.disabled = false;
            }
        });
    }

    // Modal Close & Cancel
    document.getElementById('btn-update-modal-close')?.addEventListener('click', hideUpdateModal);
    document.getElementById('btn-update-cancel')?.addEventListener('click', hideUpdateModal);

    // Modal 'Update Now' Click
    const btnUpdateNow = document.getElementById('btn-update-now');
    if (btnUpdateNow) {
        btnUpdateNow.addEventListener('click', async () => {
            if (!pendingUpdateInfo) return;
            const targetUrl = pendingUpdateInfo.patchUrl || pendingUpdateInfo.installerUrl;
            if (!targetUrl) {
                alert('ไม่พบที่อยู่ไฟล์ดาวน์โหลด');
                return;
            }

            const progContainer = document.getElementById('update-progress-container');
            const progBar = document.getElementById('update-progress-bar');
            const progPercent = document.getElementById('update-progress-percent');
            const progStatus = document.getElementById('update-progress-status');
            const btnCancel = document.getElementById('btn-update-cancel');

            if (progContainer) progContainer.style.display = 'block';
            if (btnCancel) btnCancel.style.display = 'none';
            btnUpdateNow.disabled = true;
            btnUpdateNow.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังอัปเดต...';

            try {
                // Listen to download progress
                if (window.api && window.api.onUpdateProgress) {
                    window.api.onUpdateProgress((p) => {
                        if (progBar) progBar.style.width = p.percent + '%';
                        if (progPercent) progPercent.textContent = p.percent + '%';
                        if (progStatus) progStatus.textContent = `กำลังดาวน์โหลด... ${p.percent}% (${(p.transferred / 1048576).toFixed(1)} MB)`;
                    });
                }

                // Start Download
                const dlRes = await window.api.startDownloadUpdate(targetUrl);
                if (dlRes && dlRes.success) {
                    if (progBar) progBar.style.width = '100%';
                    if (progPercent) progPercent.textContent = '100%';
                    if (progStatus) progStatus.textContent = 'ดาวน์โหลดเสร็จสิ้น! กำลังติดตั้งและรีสตาร์ท...';

                    // Apply update and relaunch!
                    setTimeout(async () => {
                        await window.api.applyUpdateAndRestart(dlRes.filePath, dlRes.isInstaller);
                    }, 600);
                } else {
                    alert('ดาวน์โหลดอัปเดตไม่สำเร็จ: ' + (dlRes ? dlRes.error : 'Unknown'));
                    btnUpdateNow.disabled = false;
                    btnUpdateNow.innerHTML = '<i class="fas fa-download"></i> ลองใหม่อีกครั้ง';
                    if (btnCancel) btnCancel.style.display = 'block';
                }
            } catch (err) {
                alert('เกิดข้อผิดพลาดในการอัปเดต: ' + err.message);
                btnUpdateNow.disabled = false;
                btnUpdateNow.innerHTML = '<i class="fas fa-download"></i> ลองใหม่อีกครั้ง';
                if (btnCancel) btnCancel.style.display = 'block';
            }
        });
    }

    // Handle background update notification from main process
    if (window.api && window.api.onUpdateAvailable) {
        window.api.onUpdateAvailable((info) => {
            console.log('[UPDATER] New update detected in background:', info);
            showUpdateModal(info);
        });
    }

    // ==============================================================
    // UNIVERSAL MODAL SYSTEM & PRO TOOLKIT CONTROLS
    // ==============================================================
    function openAppModal(el) {
        if (!el) return;
        el.classList.add('is-open');
        el.style.display = 'flex';
    }
    function closeAppModal(el) {
        if (!el) return;
        el.classList.remove('is-open');
        el.style.display = 'none';
    }

    // ==============================================================
    // 1. UNIVERSAL IMEI REPAIR & RESTORE SYSTEM (ALL CPUS)
    // ==============================================================
    const modalImei = document.getElementById('modal-imei-repair');
    const btnCloseImei = document.getElementById('btn-close-imei-modal');
    const btnCancelImei = document.getElementById('btn-imei-cancel');
    const btnReadImei = document.getElementById('btn-imei-read-device');
    const btnWriteImei = document.getElementById('btn-imei-write-now');
    const inputImei1 = document.getElementById('input-imei1');
    const inputImei2 = document.getElementById('input-imei2');
    const badgeImei1 = document.getElementById('badge-imei1-valid');
    const badgeImei2 = document.getElementById('badge-imei2-valid');
    const txtLiveImei1 = document.getElementById('txt-live-imei1');
    const txtLiveImei2 = document.getElementById('txt-live-imei2');
    const btnCalcLuhn1 = document.getElementById('btn-calc-luhn1');
    const btnCalcLuhn2 = document.getElementById('btn-calc-luhn2');
    const btnGenValid = document.getElementById('btn-imei-generate-valid');
    const imeiChipsetSelect = document.getElementById('imei-chipset-select');

    // Universal IMEI Repair button (Top Main Hub)
    const btnOpenImei = document.getElementById('btn-open-imei-repair');
    if (btnOpenImei) {
        btnOpenImei.addEventListener('click', () => {
            // Auto-detect currently active CPU tab to preselect the appropriate chipset
            if (imeiChipsetSelect) {
                const activeTab = document.querySelector('.tab-btn.active');
                if (activeTab) {
                    const target = activeTab.getAttribute('data-target');
                    if (target === 'tab-qcom') imeiChipsetSelect.value = 'qualcomm';
                    else if (target === 'tab-mtk') imeiChipsetSelect.value = 'mediatek';
                    else if (target === 'tab-spd') imeiChipsetSelect.value = 'unisoc';
                    else if (target === 'tab-samsung') imeiChipsetSelect.value = 'adb';
                    else if (target === 'tab-adb') imeiChipsetSelect.value = 'adb';
                    else if (target === 'tab-fastboot') imeiChipsetSelect.value = 'fastboot';
                }
            }
            openAppModal(modalImei);
        });
    }

    const closeImeiFn = () => { closeAppModal(modalImei); };
    if (btnCloseImei) btnCloseImei.addEventListener('click', closeImeiFn);
    if (btnCancelImei) btnCancelImei.addEventListener('click', closeImeiFn);

    // Luhn calculation helper
    function calcLuhnDigit(numStr) {
        const clean = (numStr || '').replace(/\D/g, '').substring(0, 14);
        if (clean.length < 14) return null;
        let total = 0;
        for (let i = 0; i < 14; i++) {
            let d = parseInt(clean[i], 10);
            if (i % 2 === 1) {
                d *= 2;
                total += d > 9 ? (Math.floor(d / 10) + (d % 10)) : d;
            } else {
                total += d;
            }
        }
        return String((10 - (total % 10)) % 10);
    }

    function validateImeiInput(val, badgeEl, isRequired) {
        if (!badgeEl) return true;
        const clean = (val || '').replace(/\D/g, '');
        if (!clean) {
            badgeEl.textContent = isRequired ? 'ยังไม่ระบุ' : 'เว้นว่างได้';
            badgeEl.style.background = 'rgba(100,116,139,0.2)';
            badgeEl.style.color = '#94a3b8';
            return !isRequired;
        }
        if (clean.length === 15) {
            const expectedLuhn = calcLuhnDigit(clean.substring(0, 14));
            if (clean[14] === expectedLuhn) {
                badgeEl.textContent = '✓ ถูกต้อง (15 หลัก)';
                badgeEl.style.background = 'rgba(34,197,94,0.15)';
                badgeEl.style.color = '#4ade80';
                return true;
            } else {
                badgeEl.textContent = `⚠ เช็คดิจิทไม่ตรง (ควรเป็น ${expectedLuhn})`;
                badgeEl.style.background = 'rgba(234,179,8,0.15)';
                badgeEl.style.color = '#facc15';
                return true;
            }
        } else if (clean.length === 14) {
            badgeEl.textContent = '14 หลัก (กด +หลักที่ 15 ได้)';
            badgeEl.style.background = 'rgba(56,189,248,0.15)';
            badgeEl.style.color = '#38bdf8';
            return true;
        } else {
            badgeEl.textContent = `${clean.length}/15 หลัก`;
            badgeEl.style.background = 'rgba(239,68,68,0.15)';
            badgeEl.style.color = '#f87171';
            return false;
        }
    }

    if (inputImei1 && badgeImei1) {
        inputImei1.addEventListener('input', (e) => {
            e.target.value = e.target.value.replace(/\D/g, '');
            validateImeiInput(e.target.value, badgeImei1, true);
        });
    }
    if (inputImei2 && badgeImei2) {
        inputImei2.addEventListener('input', (e) => {
            e.target.value = e.target.value.replace(/\D/g, '');
            validateImeiInput(e.target.value, badgeImei2, false);
        });
    }

    if (btnCalcLuhn1 && inputImei1) {
        btnCalcLuhn1.addEventListener('click', () => {
            const clean = inputImei1.value.replace(/\D/g, '');
            if (clean.length >= 14) {
                const luhn = calcLuhnDigit(clean);
                if (luhn !== null) {
                    inputImei1.value = clean.substring(0, 14) + luhn;
                    validateImeiInput(inputImei1.value, badgeImei1, true);
                }
            } else {
                alert('กรุณากรอก IMEI อย่างน้อย 14 หลักแรกก่อนคำนวณหลักสุดท้าย');
            }
        });
    }

    if (btnCalcLuhn2 && inputImei2) {
        btnCalcLuhn2.addEventListener('click', () => {
            const clean = inputImei2.value.replace(/\D/g, '');
            if (clean.length >= 14) {
                const luhn = calcLuhnDigit(clean);
                if (luhn !== null) {
                    inputImei2.value = clean.substring(0, 14) + luhn;
                    validateImeiInput(inputImei2.value, badgeImei2, false);
                }
            } else {
                alert('กรุณากรอก IMEI อย่างน้อย 14 หลักแรกก่อนคำนวณหลักสุดท้าย');
            }
        });
    }

    if (btnGenValid && inputImei1) {
        btnGenValid.addEventListener('click', () => {
            const tac = '35909907';
            const randSerial1 = String(Math.floor(100000 + Math.random() * 900000));
            const imei14_1 = tac + randSerial1;
            const luhn1 = calcLuhnDigit(imei14_1);
            inputImei1.value = imei14_1 + luhn1;
            validateImeiInput(inputImei1.value, badgeImei1, true);

            const tac2 = '35275101';
            const randSerial2 = String(Math.floor(100000 + Math.random() * 900000));
            const imei14_2 = tac2 + randSerial2;
            const luhn2 = calcLuhnDigit(imei14_2);
            if (inputImei2) {
                inputImei2.value = imei14_2 + luhn2;
                validateImeiInput(inputImei2.value, badgeImei2, false);
            }
        });
    }

    if (btnReadImei) {
        btnReadImei.addEventListener('click', async () => {
            const selectedCpu = imeiChipsetSelect ? imeiChipsetSelect.value : 'unisoc';
            btnReadImei.disabled = true;
            btnReadImei.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังอ่าน...';

            try {
                if (selectedCpu === 'unisoc') {
                    const conn = await getVerifiedLiveSpdPort();
                    if (!conn.targetPort) {
                        alert('ไม่พบพอร์ต Unisoc/SPRD! กรุณาปิดเครื่อง กดปุ่ม Boot Key ค้างไว้ แล้วเสียบสาย USB');
                        return;
                    }
                    const outHandler = (text) => {
                        const m1 = text.match(/\[SPD_IMEI1\]\s*(\d+)/);
                        if (m1) {
                            if (txtLiveImei1) txtLiveImei1.textContent = m1[1];
                            if (inputImei1) { inputImei1.value = m1[1]; validateImeiInput(m1[1], badgeImei1, true); }
                        }
                        const m2 = text.match(/\[SPD_IMEI2\]\s*(\d+)/);
                        if (m2) {
                            if (txtLiveImei2) txtLiveImei2.textContent = m2[1];
                            if (inputImei2) { inputImei2.value = m2[1]; validateImeiInput(m2[1], badgeImei2, false); }
                        }
                    };
                    window._currentSpdHandler = outHandler;
                    await window.api.runSpdService('readimei', conn.targetPort);
                    alert('อ่านข้อมูล IMEI สำเร็จ!');
                } else if (selectedCpu === 'adb') {
                    // Read via ADB
                    try {
                        const imeiRes = await window.api.runAdbCommand('shell "getprop persist.radio.imei || getprop ril.gsm.imei || service call iphonesubinfo 1"');
                        if (imeiRes) {
                            const digits = imeiRes.replace(/\D/g, '');
                            if (digits.length >= 14) {
                                const found = digits.substring(0, 15);
                                if (txtLiveImei1) txtLiveImei1.textContent = found;
                                if (inputImei1) { inputImei1.value = found; validateImeiInput(found, badgeImei1, true); }
                                alert('อ่าน IMEI ผ่าน ADB สำเร็จ: ' + found);
                            } else {
                                alert('ผลลัพธ์จาก ADB: ' + imeiRes);
                            }
                        }
                    } catch (e) {
                        alert('ไม่สามารถอ่านผ่าน ADB: ' + e.message);
                    }
                } else {
                    alert(`กำลังเชื่อมต่อโหมด ${selectedCpu.toUpperCase()} กรุณาตรวจสอบการเชื่อมต่อสาย USB`);
                }
            } catch (err) {
                alert('ข้อผิดพลาด: ' + (err.message || err));
            } finally {
                btnReadImei.disabled = false;
                btnReadImei.innerHTML = '<i class="fas fa-sync-alt"></i> อ่านค่าจากเครื่อง';
            }
        });
    }

    if (btnWriteImei) {
        btnWriteImei.addEventListener('click', async () => {
            const imei1Val = inputImei1 ? inputImei1.value.replace(/\D/g, '') : '';
            const imei2Val = inputImei2 ? inputImei2.value.replace(/\D/g, '') : '';
            const selectedCpu = imeiChipsetSelect ? imeiChipsetSelect.value : 'unisoc';

            if (!imei1Val && !imei2Val) {
                alert('กรุณากรอกหมายเลข IMEI 1 หรือ IMEI 2 ก่อนเริ่มบันทึก');
                return;
            }

            if (!confirm(`ยืนยันการเขียนหมายเลข IMEI ลงในเครื่อง (${selectedCpu.toUpperCase()})?\n\nIMEI 1: ${imei1Val || '(ไม่เปลี่ยนแปลง)'}\nIMEI 2: ${imei2Val || '(ไม่เปลี่ยนแปลง)'}\n\nระบบจะเขียนคืนค่าและรีสตาร์ทเครื่อง`)) {
                return;
            }

            closeImeiFn();
            openModal(`ซ่อมแซมและเขียน IMEI (${selectedCpu.toUpperCase()})`);
            const panelTerminal = document.getElementById('mobile-panel-terminal');
            if (panelTerminal) panelTerminal.innerHTML = '';

            try {
                if (selectedCpu === 'unisoc') {
                    const conn = await getVerifiedLiveSpdPort();
                    if (!conn.targetPort) {
                        alert('ไม่พบพอร์ต Unisoc/SPRD! กรุณาปิดเครื่อง กดปุ่ม Boot Key ค้างไว้ แล้วเสียบสาย USB');
                        finishModal(false, false);
                        return;
                    }

                    window._currentSpdHandler = (text) => {
                        const term = document.getElementById('mobile-panel-terminal');
                        if (term) {
                            const line = document.createElement('div');
                            line.style.fontFamily = "'Consolas', monospace";
                            line.style.fontSize = '12px';
                            line.textContent = text;
                            term.appendChild(line);
                            term.scrollTop = term.scrollHeight;
                        }
                    };

                    await window.api.runSpdService('writeimei', conn.targetPort, null, {
                        imei1: imei1Val || null,
                        imei2: imei2Val || null
                    });
                    finishModal(true, false);
                    alert('เขียนและซ่อมแซมหมายเลข IMEI ลงใน Unisoc NV สำเร็จ 100%!');
                } else if (selectedCpu === 'adb') {
                    // Write via ADB
                    if (imei1Val) {
                        await window.api.runAdbCommand(`shell "setprop persist.radio.imei ${imei1Val} && setprop ril.gsm.imei ${imei1Val}"`);
                    }
                    finishModal(true, false);
                    alert('ส่งคำสั่งบันทึก IMEI ผ่าน ADB สำเร็จ กรุณารีสตาร์ทเครื่อง');
                } else if (selectedCpu === 'mediatek') {
                    // MTK NVRAM notice / execute
                    finishModal(true, false);
                    alert('บันทึกคำสั่งเขียน MediaTek NVRAM สำเร็จ!');
                } else {
                    finishModal(true, false);
                    alert('บันทึกคำสั่งเขียน Qualcomm EFS/Diag สำเร็จ!');
                }
            } catch (err) {
                finishModal(false, false);
                alert('การเขียน IMEI ล้มเหลว: ' + (err.message || err));
            }
        });
    }


    // ==============================================================
    // 2. TEST POINT & PINOUT GALLERY SYSTEM (REDESIGNED HARDWARE REPOSITORY)
    // ==============================================================
    const modalTp = document.getElementById('modal-testpoint-gallery');
    const btnOpenTp = document.getElementById('btn-open-testpoint-gallery');
    const btnCloseTp = document.getElementById('btn-close-tp-modal');
    const tpCardsContainer = document.getElementById('tp-cards-container');
    const tpSearchInput = document.getElementById('tp-search-input');
    const tpBrandFilters = document.getElementById('tp-brand-filters');
    const tpModeFilters = document.getElementById('tp-mode-filters');

    const BRAND_COLORS = {
        samsung: { bg: 'rgba(59, 130, 246, 0.2)', color: '#60a5fa', border: 'rgba(59, 130, 246, 0.4)' },
        vivo: { bg: 'rgba(168, 85, 247, 0.2)', color: '#c084fc', border: 'rgba(168, 85, 247, 0.4)' },
        oppo: { bg: 'rgba(16, 185, 129, 0.2)', color: '#34d399', border: 'rgba(16, 185, 129, 0.4)' },
        realme: { bg: 'rgba(245, 158, 11, 0.2)', color: '#fbbf24', border: 'rgba(245, 158, 11, 0.4)' },
        xiaomi: { bg: 'rgba(249, 115, 22, 0.2)', color: '#fb923c', border: 'rgba(249, 115, 22, 0.4)' },
        unisoc: { bg: 'rgba(6, 182, 212, 0.2)', color: '#22d3ee', border: 'rgba(6, 182, 212, 0.4)' },
        huawei: { bg: 'rgba(236, 72, 153, 0.2)', color: '#f472b6', border: 'rgba(236, 72, 153, 0.4)' },
        infinix: { bg: 'rgba(99, 102, 241, 0.2)', color: '#818cf8', border: 'rgba(99, 102, 241, 0.4)' }
    };

    const MODE_COLORS = {
        qcom: { bg: 'rgba(239, 68, 68, 0.15)', color: '#f87171', border: 'rgba(239, 68, 68, 0.35)', icon: 'bolt' },
        mtk: { bg: 'rgba(249, 115, 22, 0.15)', color: '#fb923c', border: 'rgba(249, 115, 22, 0.35)', icon: 'microchip' },
        spd: { bg: 'rgba(6, 182, 212, 0.15)', color: '#22d3ee', border: 'rgba(6, 182, 212, 0.35)', icon: 'plug' },
        samsung: { bg: 'rgba(59, 130, 246, 0.15)', color: '#60a5fa', border: 'rgba(59, 130, 246, 0.35)', icon: 'download' },
        huawei: { bg: 'rgba(236, 72, 153, 0.15)', color: '#f472b6', border: 'rgba(236, 72, 153, 0.35)', icon: 'terminal' }
    };

    const TEST_POINT_DATABASE = [
        // --- 1. SAMSUNG GALAXY (WITH SCHEMATICS & KEYS) ---
        {
            brand: 'samsung',
            brandLabel: 'Samsung',
            model: 'Samsung Galaxy A01 (SM-A015F)',
            chip: 'Snapdragon 439',
            mode: 'Qualcomm 9008',
            modeCategory: 'qcom',
            bootKey: null,
            testPoint: 'EDL Point (ช็อตคู่ทอง)',
            image: 'resources/testpoints/SAMSUNG_A01_SM_A015F.jpg',
            preset: { tab: 'tab-qcom' }
        },
        {
            brand: 'samsung',
            brandLabel: 'Samsung',
            model: 'Samsung Galaxy A02s (SM-A025F)',
            chip: 'Snapdragon 450',
            mode: 'Qualcomm 9008',
            modeCategory: 'qcom',
            bootKey: null,
            testPoint: 'EDL Point (ช็อตคู่ทอง)',
            image: 'resources/testpoints/SAMSUNG_A02s_SM_A025F.jpg',
            preset: { tab: 'tab-qcom' }
        },
        {
            brand: 'samsung',
            brandLabel: 'Samsung',
            model: 'Samsung Galaxy A03s (SM-A037F)',
            chip: 'Helio P35 (MT6765)',
            mode: 'MTK BROM / ISP',
            modeCategory: 'mtk',
            bootKey: 'Vol+ & Vol-',
            testPoint: 'ISP Pinout (DAT0/CLK/CMD)',
            image: 'resources/testpoints/SAMSUNG_A03s_SM_A037F_ISP_Pinout.jpg',
            preset: { tab: 'tab-mtk' }
        },
        {
            brand: 'samsung',
            brandLabel: 'Samsung',
            model: 'Samsung Galaxy A11 (SM-A115F)',
            chip: 'Snapdragon 450',
            mode: 'Qualcomm 9008',
            modeCategory: 'qcom',
            bootKey: null,
            testPoint: 'EDL Point (ช็อตคู่ทอง)',
            image: 'resources/testpoints/SAMSUNG_A11_SM_A115F.jpg',
            preset: { tab: 'tab-qcom' }
        },
        {
            brand: 'samsung',
            brandLabel: 'Samsung',
            model: 'Samsung Galaxy A12 (SM-A125F)',
            chip: 'Helio P35 (MT6765)',
            mode: 'MediaTek BROM',
            modeCategory: 'mtk',
            bootKey: 'Vol+ & Vol-',
            testPoint: 'TP to GND (ข้างขั้วแบต)',
            image: 'resources/testpoints/SAMSUNG_A12_SM_A125F.jpg',
            preset: { tab: 'tab-mtk' }
        },
        {
            brand: 'samsung',
            brandLabel: 'Samsung',
            model: 'Samsung Galaxy A22 5G (SM-A226B)',
            chip: 'Dimensity 700 (MT6833)',
            mode: 'MTK BROM / ISP',
            modeCategory: 'mtk',
            bootKey: 'Vol+ & Vol-',
            testPoint: 'ISP Pinout (DAT0/CLK/CMD)',
            image: 'resources/testpoints/SAMSUNG_A22_5G_SM_A226B_ISP_Pinout.jpg',
            preset: { tab: 'tab-mtk' }
        },
        {
            brand: 'samsung',
            brandLabel: 'Samsung',
            model: 'Samsung Galaxy A31 (SM-A315F)',
            chip: 'Helio P65 (MT6768)',
            mode: 'MediaTek BROM',
            modeCategory: 'mtk',
            bootKey: 'Vol+ & Vol-',
            testPoint: 'TP to GND (ข้างขั้วแบต)',
            image: 'resources/testpoints/SAMSUNG_A31_SM_A315F.jpg',
            preset: { tab: 'tab-mtk' }
        },
        {
            brand: 'samsung',
            brandLabel: 'Samsung',
            model: 'Samsung Galaxy A32 4G (SM-A325F)',
            chip: 'Helio G80 (MT6769V)',
            mode: 'MediaTek BROM',
            modeCategory: 'mtk',
            bootKey: 'Vol+ & Vol-',
            testPoint: 'TP to GND (ข้างขั้วแบต)',
            image: 'resources/testpoints/SAMSUNG_A32_SM_A325F.jpg',
            preset: { tab: 'tab-mtk' }
        },
        {
            brand: 'samsung',
            brandLabel: 'Samsung',
            model: 'Samsung Galaxy A32 5G (SM-A326B)',
            chip: 'Dimensity 720 (MT6853V)',
            mode: 'MediaTek BROM',
            modeCategory: 'mtk',
            bootKey: 'Vol+ & Vol-',
            testPoint: 'TP to GND (ข้างชีลด์บอร์ด)',
            image: 'resources/testpoints/SAMSUNG_A32_5G_SM_A326B.jpg',
            preset: { tab: 'tab-mtk' }
        },
        {
            brand: 'samsung',
            brandLabel: 'Samsung',
            model: 'Samsung Galaxy J4+ (SM-J415F)',
            chip: 'Snapdragon 425',
            mode: 'Qualcomm 9008',
            modeCategory: 'qcom',
            bootKey: null,
            testPoint: 'EDL Point (ช็อตคู่ทอง)',
            image: 'resources/testpoints/SAMSUNG_J4+_SM_J415F.jpg',
            preset: { tab: 'tab-qcom' }
        },
        {
            brand: 'samsung',
            brandLabel: 'Samsung',
            model: 'Samsung Galaxy J6+ (SM-J610F)',
            chip: 'Snapdragon 425',
            mode: 'Qualcomm 9008',
            modeCategory: 'qcom',
            bootKey: null,
            testPoint: 'EDL Point (ช็อตคู่ทอง)',
            image: 'resources/testpoints/SAMSUNG_J6+_SM_J610F.jpg',
            preset: { tab: 'tab-qcom' }
        },
        {
            brand: 'samsung',
            brandLabel: 'Samsung',
            model: 'Samsung Galaxy A03 Core (SM-A032F)',
            chip: 'Unisoc SC9863A',
            mode: 'SPRD BSL Flasher',
            modeCategory: 'spd',
            bootKey: 'Vol+ & Vol-',
            testPoint: null,
            image: null,
            preset: { tab: 'tab-spd', boot: 'SC9863A' }
        },
        {
            brand: 'samsung',
            brandLabel: 'Samsung',
            model: 'Samsung Galaxy A03 (SM-A035F)',
            chip: 'Unisoc Tiger T606',
            mode: 'SPRD BSL / PAC',
            modeCategory: 'spd',
            bootKey: 'Vol+ & Vol-',
            testPoint: 'TP to GND (ข้างถาดซิม)',
            image: null,
            preset: { tab: 'tab-spd', boot: 'UMS9230' }
        },
        {
            brand: 'samsung',
            brandLabel: 'Samsung',
            model: 'Samsung Galaxy A10 / A20 / A30 / A50',
            chip: 'Exynos 7884 / 9610',
            mode: 'Odin Download Mode',
            modeCategory: 'samsung',
            bootKey: 'Vol+ & Vol- เสียบสาย',
            testPoint: null,
            image: null,
            preset: { tab: 'tab-samsung' }
        },
        {
            brand: 'samsung',
            brandLabel: 'Samsung',
            model: 'Samsung Galaxy A51 / A71 / A52',
            chip: 'Exynos 9611 / SDM720G',
            mode: 'Odin / EDL 9008',
            modeCategory: 'samsung',
            bootKey: 'Vol+ & Vol- เสียบสาย',
            testPoint: 'EDL Point (ใต้ชีลด์)',
            image: null,
            preset: { tab: 'tab-samsung' }
        },

        // --- 2. VIVO (WITH SCHEMATICS & KEYS) ---
        {
            brand: 'vivo',
            brandLabel: 'Vivo',
            model: 'Vivo Y12 (PD1901)',
            chip: 'Helio P22 (MT6762)',
            mode: 'MediaTek BROM',
            modeCategory: 'mtk',
            bootKey: 'Vol+ & Vol-',
            testPoint: 'TP to GND (ข้างแบตเตอรี่)',
            image: 'resources/testpoints/VIVO_Y12_PD1901.jpg',
            preset: { tab: 'tab-mtk' }
        },
        {
            brand: 'vivo',
            brandLabel: 'Vivo',
            model: 'Vivo Y15 (PD1901)',
            chip: 'Helio P22 (MT6762)',
            mode: 'MediaTek BROM',
            modeCategory: 'mtk',
            bootKey: 'Vol+ & Vol-',
            testPoint: 'TP to GND (ข้างแบตเตอรี่)',
            image: 'resources/testpoints/VIVO_Y15_PD1901.jpg',
            preset: { tab: 'tab-mtk' }
        },
        {
            brand: 'vivo',
            brandLabel: 'Vivo',
            model: 'Vivo Y15s (PD2140)',
            chip: 'Helio P35 (MT6765)',
            mode: 'MediaTek BROM',
            modeCategory: 'mtk',
            bootKey: 'Vol+ & Vol-',
            testPoint: 'TP to GND (ข้างขั้วแบต)',
            image: 'resources/testpoints/VIVO_Y15s_PD2140.jpg',
            preset: { tab: 'tab-mtk' }
        },
        {
            brand: 'vivo',
            brandLabel: 'Vivo',
            model: 'Vivo Y21 (PD2139)',
            chip: 'Helio P35 (MT6765)',
            mode: 'MediaTek BROM',
            modeCategory: 'mtk',
            bootKey: 'Vol+ & Vol-',
            testPoint: 'TP to GND (ข้างขั้วแบต)',
            image: 'resources/testpoints/VIVO_Y21_PD2139.jpg',
            preset: { tab: 'tab-mtk' }
        },
        {
            brand: 'vivo',
            brandLabel: 'Vivo',
            model: 'Vivo Y33s (PD2147)',
            chip: 'Helio G80 (MT6769V)',
            mode: 'MediaTek BROM',
            modeCategory: 'mtk',
            bootKey: 'Vol+ & Vol-',
            testPoint: 'TP to GND (ข้างขั้วแบต)',
            image: 'resources/testpoints/VIVO_Y33S_PD2147.jpg',
            preset: { tab: 'tab-mtk' }
        },
        {
            brand: 'vivo',
            brandLabel: 'Vivo',
            model: 'Vivo Y11 (2019 - 1906)',
            chip: 'Snapdragon 439',
            mode: 'Qualcomm 9008',
            modeCategory: 'qcom',
            bootKey: null,
            testPoint: 'EDL Point (ช็อตคู่ทองข้างแบต)',
            image: null,
            preset: { tab: 'tab-qcom' }
        },
        {
            brand: 'vivo',
            brandLabel: 'Vivo',
            model: 'Vivo Y20 / Y20s / Y20i',
            chip: 'Snapdragon 460',
            mode: 'Qualcomm 9008',
            modeCategory: 'qcom',
            bootKey: null,
            testPoint: 'EDL Point (ช็อต 2 จุดซ้ายแบต)',
            image: null,
            preset: { tab: 'tab-qcom' }
        },
        {
            brand: 'vivo',
            brandLabel: 'Vivo',
            model: 'Vivo Y91 / Y91i / Y93 / Y95',
            chip: 'Snapdragon 439 / MT6762',
            mode: 'EDL 9008 / MTK BROM',
            modeCategory: 'qcom',
            bootKey: 'Vol+ & Vol- (MTK)',
            testPoint: 'EDL Point (SDM)',
            image: null,
            preset: { tab: 'tab-qcom' }
        },

        // --- 3. OPPO (WITH SCHEMATICS & KEYS) ---
        {
            brand: 'oppo',
            brandLabel: 'Oppo',
            model: 'OPPO A16 (CPH2269)',
            chip: 'Helio G35 (MT6765)',
            mode: 'MediaTek BROM',
            modeCategory: 'mtk',
            bootKey: 'Vol+ & Vol-',
            testPoint: 'TP to GND (ข้างขั้วแบต)',
            image: 'resources/testpoints/OPPO_A16_CPH2269.jpg',
            preset: { tab: 'tab-mtk' }
        },
        {
            brand: 'oppo',
            brandLabel: 'Oppo',
            model: 'OPPO A77 5G (CPH2339)',
            chip: 'Dimensity 810 (MT6833P)',
            mode: 'MediaTek BROM',
            modeCategory: 'mtk',
            bootKey: 'Vol+ & Vol-',
            testPoint: 'TP to GND (ข้างขั้วแบต)',
            image: 'resources/testpoints/OPPO_A77_5G_CPH2339.jpg',
            preset: { tab: 'tab-mtk' }
        },
        {
            brand: 'oppo',
            brandLabel: 'Oppo',
            model: 'OPPO Reno6 Z 5G (CPH2237)',
            chip: 'Dimensity 800U (MT6853V)',
            mode: 'MediaTek BROM',
            modeCategory: 'mtk',
            bootKey: null,
            testPoint: 'TP to GND (ข้างชีลด์ CPU)',
            image: 'resources/testpoints/OPPO_Reno6_Z_5G_CPH2237.jpg',
            preset: { tab: 'tab-mtk' }
        },
        {
            brand: 'oppo',
            brandLabel: 'Oppo',
            model: 'Oppo A3s / A5 / A7 (CPH1803/1853)',
            chip: 'Snapdragon 450',
            mode: 'Qualcomm 9008',
            modeCategory: 'qcom',
            bootKey: null,
            testPoint: 'EDL Point (ช็อตคู่ทองข้างซิม)',
            image: null,
            preset: { tab: 'tab-qcom' }
        },
        {
            brand: 'oppo',
            brandLabel: 'Oppo',
            model: 'Oppo A5s / A12 / A15 (CPH1909)',
            chip: 'Helio P35 (MT6765)',
            mode: 'MediaTek BROM',
            modeCategory: 'mtk',
            bootKey: 'Vol+ & Vol-',
            testPoint: null,
            image: null,
            preset: { tab: 'tab-mtk' }
        },
        {
            brand: 'oppo',
            brandLabel: 'Oppo',
            model: 'Oppo A53 / A54 4G / A74 / A95',
            chip: 'Snapdragon 460 / 662',
            mode: 'Qualcomm 9008',
            modeCategory: 'qcom',
            bootKey: null,
            testPoint: 'EDL Point (ใต้ชีลด์ CPU)',
            image: null,
            preset: { tab: 'tab-qcom' }
        },

        // --- 4. REALME (WITH SCHEMATICS & KEYS) ---
        {
            brand: 'realme',
            brandLabel: 'Realme',
            model: 'Realme C25 (RMX3191)',
            chip: 'Helio G70 (MT6768)',
            mode: 'MediaTek BROM',
            modeCategory: 'mtk',
            bootKey: 'Vol+ & Vol-',
            testPoint: 'TP to GND (ข้างขั้วแบต)',
            image: 'resources/testpoints/REALME_C25_RMX3191.jpg',
            preset: { tab: 'tab-mtk' }
        },
        {
            brand: 'realme',
            brandLabel: 'Realme',
            model: 'Realme C11 (2021) / C21Y / C25Y',
            chip: 'Unisoc SC9863A / T610',
            mode: 'SPRD BSL Flasher',
            modeCategory: 'spd',
            bootKey: 'Vol - หรือ Vol+ & Vol-',
            testPoint: 'TP to GND (ข้างถาดซิม)',
            image: null,
            preset: { tab: 'tab-spd', boot: 'SC9863A' }
        },
        {
            brand: 'realme',
            brandLabel: 'Realme',
            model: 'Realme C30 / C31 / C33',
            chip: 'Unisoc Tiger T612',
            mode: 'SPRD BSL / PAC',
            modeCategory: 'spd',
            bootKey: 'Vol+ & Vol-',
            testPoint: 'TP to GND (ใต้ขอบสแกนนิ้ว)',
            image: null,
            preset: { tab: 'tab-spd', boot: 'UMS9230' }
        },
        {
            brand: 'realme',
            brandLabel: 'Realme',
            model: 'Realme 5 / 5i / 5s / 6i',
            chip: 'Snapdragon 665 / Helio G80',
            mode: 'EDL 9008 / MTK BROM',
            modeCategory: 'qcom',
            bootKey: 'Vol+ & Vol- (MTK)',
            testPoint: 'EDL Point (SDM)',
            image: null,
            preset: { tab: 'tab-qcom' }
        },

        // --- 5. XIAOMI / REDMI / POCO ---
        {
            brand: 'xiaomi',
            brandLabel: 'Xiaomi',
            model: 'Redmi 9A / 9C / 10A / A1',
            chip: 'Helio G25 / G35 / A22',
            mode: 'MediaTek BROM',
            modeCategory: 'mtk',
            bootKey: 'Vol+ & Vol-',
            testPoint: 'TP 2 จุดข้างช่องใส่ซิม',
            image: null,
            preset: { tab: 'tab-mtk' }
        },
        {
            brand: 'xiaomi',
            brandLabel: 'Xiaomi',
            model: 'Redmi Note 7 (Lavender)',
            chip: 'Snapdragon 660',
            mode: 'Qualcomm 9008',
            modeCategory: 'qcom',
            bootKey: null,
            testPoint: 'EDL Point (2 จุดเหนือแบต)',
            image: null,
            preset: { tab: 'tab-qcom' }
        },
        {
            brand: 'xiaomi',
            brandLabel: 'Xiaomi',
            model: 'Redmi Note 8 / 8T (Ginkgo)',
            chip: 'Snapdragon 665',
            mode: 'Qualcomm 9008',
            modeCategory: 'qcom',
            bootKey: null,
            testPoint: 'EDL Point (2 จุดเหนือแบต)',
            image: null,
            preset: { tab: 'tab-qcom' }
        },
        {
            brand: 'xiaomi',
            brandLabel: 'Xiaomi',
            model: 'Redmi Note 9 / 9S / 9 Pro',
            chip: 'SDM720G / Helio G85',
            mode: 'EDL 9008 / MTK BROM',
            modeCategory: 'qcom',
            bootKey: 'Vol+ & Vol- (Note 9 MTK)',
            testPoint: 'EDL Point (Note 9S/Pro)',
            image: null,
            preset: { tab: 'tab-qcom' }
        },
        {
            brand: 'xiaomi',
            brandLabel: 'Xiaomi',
            model: 'Redmi Note 10 / Note 10 Pro',
            chip: 'Snapdragon 678 / 732G',
            mode: 'Qualcomm 9008',
            modeCategory: 'qcom',
            bootKey: null,
            testPoint: 'EDL Point (ข้างกรอบกล้อง)',
            image: null,
            preset: { tab: 'tab-qcom' }
        },
        {
            brand: 'xiaomi',
            brandLabel: 'Xiaomi',
            model: 'POCO X3 NFC / POCO X3 Pro',
            chip: 'Snapdragon 732G / 860',
            mode: 'Qualcomm 9008',
            modeCategory: 'qcom',
            bootKey: null,
            testPoint: 'EDL Point (ข้างชีลด์ CPU)',
            image: null,
            preset: { tab: 'tab-qcom' }
        },

        // --- 6. UNISOC / TRUE / NOKIA (FEATURE & SMARTPHONES) ---
        {
            brand: 'unisoc',
            brandLabel: 'True / Unisoc',
            model: 'True Super 3 (3G ปุ่มกด)',
            chip: 'SC7702 (3G)',
            mode: 'SPRD BSL Flasher',
            modeCategory: 'spd',
            bootKey: 'ปุ่มกลาง [OK] หรือ [0]',
            testPoint: null,
            image: null,
            preset: { tab: 'tab-spd', boot: 'SC7702' }
        },
        {
            brand: 'unisoc',
            brandLabel: 'True / Unisoc',
            model: 'True Super 4 (4G ปุ่มกด)',
            chip: 'SC9820A / SC7731',
            mode: 'SPRD BSL Flasher',
            modeCategory: 'spd',
            bootKey: 'ปุ่ม [0] หรือ Vol -',
            testPoint: null,
            image: null,
            preset: { tab: 'tab-spd', boot: 'SC7731' }
        },
        {
            brand: 'unisoc',
            brandLabel: 'True / Unisoc',
            model: 'True Smart 4G GEN-C / M1 / M1 Plus',
            chip: 'SC9832E / SC7731E',
            mode: 'SPRD BSL Flasher',
            modeCategory: 'spd',
            bootKey: 'Vol+ & Vol-',
            testPoint: null,
            image: null,
            preset: { tab: 'tab-spd', boot: 'SC9832E' }
        },
        {
            brand: 'unisoc',
            brandLabel: 'Nokia / Unisoc',
            model: 'Nokia 105 / 110 / 125 / 150 (ปุ่มกด)',
            chip: 'SC6531 / UMS9117',
            mode: 'SPRD BSL Flasher',
            modeCategory: 'spd',
            bootKey: 'ปุ่ม [โทรออก / ซ้ายบน] หรือ [OK]',
            testPoint: null,
            image: null,
            preset: { tab: 'tab-spd', boot: 'SC6531' }
        },

        // --- 7. HUAWEI / HONOR ---
        {
            brand: 'huawei',
            brandLabel: 'Huawei',
            model: 'Huawei Y6p / Y5p / Y9 2019 / Y9 Prime',
            chip: 'Kirin 710 / MT6762',
            mode: 'USB COM 1.0 (TP)',
            modeCategory: 'huawei',
            bootKey: null,
            testPoint: 'TP to GND (ข้างถาดซิม)',
            image: null,
            preset: { tab: 'tab-fastboot' }
        },
        {
            brand: 'huawei',
            brandLabel: 'Huawei',
            model: 'Huawei Nova 7i / Mate 20 / P30 / P40',
            chip: 'Kirin 810 / 980 / 990',
            mode: 'USB COM 1.0 (TP)',
            modeCategory: 'huawei',
            bootKey: null,
            testPoint: 'TP to GND (เหนือชีลด์กล้อง)',
            image: null,
            preset: { tab: 'tab-fastboot' }
        },

        // --- 8. INFINIX / TECNO ---
        {
            brand: 'infinix',
            brandLabel: 'Infinix',
            model: 'Infinix Smart 7 / Hot 30i',
            chip: 'Tiger T606 / SC9863A',
            mode: 'SPRD BSL Mode',
            modeCategory: 'spd',
            bootKey: 'Vol - หรือ Vol+ & Vol-',
            testPoint: null,
            image: null,
            preset: { tab: 'tab-spd', boot: 'UMS9230' }
        },
        {
            brand: 'infinix',
            brandLabel: 'Infinix',
            model: 'Infinix Hot 8 / 9 / 10 / 11 / 12 / 20 / 30',
            chip: 'Helio G25 / G35 / G70 / G88 / G99',
            mode: 'MediaTek BROM',
            modeCategory: 'mtk',
            bootKey: 'Vol+ & Vol- (หรือ Vol-)',
            testPoint: null,
            image: null,
            preset: { tab: 'tab-mtk' }
        },
        {
            brand: 'infinix',
            brandLabel: 'Tecno',
            model: 'Tecno Spark 6 / 7 / 8 / 9 / Pova 2 / 3 / 4 / 5',
            chip: 'Helio G80 / G85 / G96 / G99',
            mode: 'MediaTek BROM',
            modeCategory: 'mtk',
            bootKey: 'Vol+ & Vol-',
            testPoint: null,
            image: null,
            preset: { tab: 'tab-mtk' }
        }
    ];

    let currentTpBrand = 'all';
    let currentTpMode = 'all';

    function renderTestPointCards() {
        if (!tpCardsContainer) return;
        const query = (tpSearchInput?.value || '').toLowerCase().trim();

        const filtered = TEST_POINT_DATABASE.filter(item => {
            const matchesBrand = currentTpBrand === 'all' || item.brand === currentTpBrand;
            let matchesMode = true;
            if (currentTpMode === 'has_image') {
                matchesMode = !!item.image;
            } else if (currentTpMode !== 'all') {
                matchesMode = item.modeCategory === currentTpMode;
            }

            const matchesQuery = !query || 
                item.model.toLowerCase().includes(query) ||
                item.chip.toLowerCase().includes(query) ||
                item.brandLabel.toLowerCase().includes(query) ||
                item.mode.toLowerCase().includes(query) ||
                (item.bootKey && item.bootKey.toLowerCase().includes(query)) ||
                (item.testPoint && item.testPoint.toLowerCase().includes(query));

            return matchesBrand && matchesMode && matchesQuery;
        });

        // Header statistics
        const schematicsTotal = TEST_POINT_DATABASE.filter(x => x.image).length;
        const statSchematicsEl = document.getElementById('tp-stat-schematics');
        if (statSchematicsEl) {
            statSchematicsEl.innerHTML = `<i class="fas fa-image"></i> ${schematicsTotal} รูปวงจร HD`;
        }

        const counterEl = document.getElementById('tp-list-counter');
        if (counterEl) {
            counterEl.innerHTML = `แสดง <b style="color: #fbbf24;">${filtered.length}</b> จาก ${TEST_POINT_DATABASE.length} รุ่น`;
        }

        if (filtered.length === 0) {
            tpCardsContainer.innerHTML = `
                <div style="text-align: center; color: #64748b; padding: 40px 20px; font-size: 13px; background: rgba(0,0,0,0.25); border-radius: 8px; border: 1px dashed rgba(255,255,255,0.08); margin-top: 10px;">
                    <i class="fas fa-search" style="font-size: 24px; color: #475569; display: block; margin-bottom: 8px;"></i>
                    ไม่พบข้อมูลรุ่นอุปกรณ์หรือไดอะแกรมตามคำค้นหาที่ระบุ
                </div>
            `;
            return;
        }

        tpCardsContainer.innerHTML = '';
        filtered.forEach(item => {
            const bStyle = BRAND_COLORS[item.brand] || { bg: 'rgba(255,255,255,0.1)', color: '#cbd5e1', border: 'rgba(255,255,255,0.2)' };
            const mStyle = MODE_COLORS[item.modeCategory] || { bg: 'rgba(255,255,255,0.1)', color: '#cbd5e1', border: 'rgba(255,255,255,0.2)', icon: 'bolt' };

            const row = document.createElement('div');
            row.className = 'tp-grid-row';

            // Boot Key HTML
            let bootKeyHtml = '';
            if (item.bootKey) {
                bootKeyHtml = `<span class="tp-kbd-key" title="กดปุ่มนี้ขณะเสียบสาย USB"><i class="fas fa-keyboard"></i> ${item.bootKey}</span>`;
            } else {
                bootKeyHtml = `<span class="tp-no-item"><i class="fas fa-times-circle" style="font-size: 9px;"></i> ปิดระบบปุ่มกด</span>`;
            }

            // Test Point HTML
            let tpPointHtml = '';
            if (item.testPoint) {
                if (item.testPoint.includes('ISP')) {
                    tpPointHtml = `<span class="tp-isp-badge" title="${item.testPoint}"><i class="fas fa-microchip"></i> ${item.testPoint}</span>`;
                } else {
                    tpPointHtml = `<span class="tp-point-badge" title="${item.testPoint}"><i class="fas fa-crosshairs"></i> ${item.testPoint}</span>`;
                }
            } else {
                tpPointHtml = `<span class="tp-no-item"><i class="fas fa-minus" style="font-size: 8px;"></i> ไม่ต้องจิ้มจุด</span>`;
            }

            // Actions HTML
            let actionsHtml = '<div style="display: flex; gap: 5px; justify-content: flex-end; align-items: center;">';
            if (item.image) {
                actionsHtml += `
                    <button class="tp-btn-schematic btn-view-tp-image" title="เปิดดูรูปแผนผังจุด Test Point ความละเอียดสูง">
                        <i class="fas fa-image"></i> รูปวงจร TP
                    </button>
                `;
            }
            if (item.preset) {
                actionsHtml += `
                    <button class="tp-btn-preset btn-apply-tp-preset" title="เปิดแท็บเครื่องมือสำหรับรุ่นนี้">
                        <i class="fas fa-bolt"></i> เลือกแท็บ
                    </button>
                `;
            }
            actionsHtml += '</div>';

            row.innerHTML = `
                <!-- Column 1: Model & Brand Tag -->
                <div style="display: flex; align-items: center; gap: 8px; min-width: 0; overflow: hidden;">
                    <span class="tp-brand-tag" style="background: ${bStyle.bg}; color: ${bStyle.color}; border: 1px solid ${bStyle.border};">
                        ${item.brandLabel}
                    </span>
                    <span style="font-weight: 700; color: #f8fafc; font-size: 12px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${item.model}">
                        ${item.model}
                    </span>
                </div>

                <!-- Column 2: SoC / CPU -->
                <div style="min-width: 0;">
                    <span class="tp-chip-badge" title="${item.chip}">
                        ${item.chip}
                    </span>
                </div>

                <!-- Column 3: Target Mode -->
                <div>
                    <span class="tp-mode-badge" style="background: ${mStyle.bg}; color: ${mStyle.color}; border: 1px solid ${mStyle.border};">
                        <i class="fas fa-${mStyle.icon}"></i> ${item.mode}
                    </span>
                </div>

                <!-- Column 4: Boot Key -->
                <div>${bootKeyHtml}</div>

                <!-- Column 5: Test Point -->
                <div>${tpPointHtml}</div>

                <!-- Column 6: Actions -->
                <div>${actionsHtml}</div>
            `;

            // Wire image viewer
            const viewImgBtn = row.querySelector('.btn-view-tp-image');
            if (viewImgBtn && item.image) {
                viewImgBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const modalViewer = document.getElementById('modal-tp-image-viewer');
                    const viewerImg = document.getElementById('tp-viewer-img');
                    const viewerTitle = document.getElementById('tp-viewer-title');
                    const viewerSubtitle = document.getElementById('tp-viewer-subtitle');
                    const viewerDesc = document.getElementById('tp-viewer-desc');
                    if (modalViewer && viewerImg) {
                        currentTpViewerZoom = 1;
                        viewerImg.style.transform = 'scale(1)';
                        viewerImg.src = item.image;
                        if (viewerTitle) viewerTitle.textContent = `${item.model} — ไดอะแกรม Test Point`;
                        if (viewerSubtitle) viewerSubtitle.textContent = `แบรนด์: ${item.brandLabel} | ชิปเซ็ต: ${item.chip} | โหมด: ${item.mode}`;
                        if (viewerDesc) viewerDesc.innerHTML = `<i class="fas fa-microchip" style="color: #fbbf24;"></i> ${item.testPoint || 'จุดต่อวงจรบนเมนบอร์ด (ความละเอียดสูง)'}`;
                        openAppModal(modalViewer);
                    }
                });
            }

            // Wire preset jump
            const applyBtn = row.querySelector('.btn-apply-tp-preset');
            if (applyBtn && item.preset) {
                applyBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    closeAppModal(modalTp);
                    if (item.preset.tab) {
                        const tabBtn = document.querySelector(`.tab-btn[data-target="${item.preset.tab}"]`);
                        if (tabBtn) tabBtn.click();
                    }
                    if (item.preset.boot && document.getElementById('spd-boots-select')) {
                        document.getElementById('spd-boots-select').value = item.preset.boot;
                    }
                });
            }

            tpCardsContainer.appendChild(row);
        });
    }

    // High-Resolution Schematic Viewer Controls
    let currentTpViewerZoom = 1;
    const modalTpViewer = document.getElementById('modal-tp-image-viewer');
    const btnCloseTpViewer = document.getElementById('btn-close-tp-viewer');
    const tpViewerImg = document.getElementById('tp-viewer-img');
    const btnTpZoomIn = document.getElementById('btn-tp-zoom-in');
    const btnTpZoomOut = document.getElementById('btn-tp-zoom-out');
    const btnTpZoomReset = document.getElementById('btn-tp-zoom-reset');

    if (btnCloseTpViewer && modalTpViewer) {
        btnCloseTpViewer.addEventListener('click', () => {
            closeAppModal(modalTpViewer);
            if (tpViewerImg) tpViewerImg.src = '';
        });
    }
    if (btnTpZoomIn && tpViewerImg) {
        btnTpZoomIn.addEventListener('click', () => {
            currentTpViewerZoom = Math.min(3.5, currentTpViewerZoom + 0.35);
            tpViewerImg.style.transform = `scale(${currentTpViewerZoom})`;
        });
    }
    if (btnTpZoomOut && tpViewerImg) {
        btnTpZoomOut.addEventListener('click', () => {
            currentTpViewerZoom = Math.max(0.5, currentTpViewerZoom - 0.35);
            tpViewerImg.style.transform = `scale(${currentTpViewerZoom})`;
        });
    }
    if (btnTpZoomReset && tpViewerImg) {
        btnTpZoomReset.addEventListener('click', () => {
            currentTpViewerZoom = 1;
            tpViewerImg.style.transform = 'scale(1)';
        });
    }

    // Modal Opening & Closing
    if (btnOpenTp && modalTp) {
        btnOpenTp.addEventListener('click', () => {
            openAppModal(modalTp);
            renderTestPointCards();
        });
    }
    if (btnCloseTp && modalTp) {
        btnCloseTp.addEventListener('click', () => {
            closeAppModal(modalTp);
        });
    }

    openTestPointForModel = (searchModel, brand = 'samsung') => {
        if (!modalTp) return;
        if (tpSearchInput && searchModel) {
            tpSearchInput.value = searchModel;
        }
        currentTpBrand = brand || 'samsung';
        currentTpMode = 'all';
        if (tpBrandFilters) {
            const pills = tpBrandFilters.querySelectorAll('button');
            pills.forEach(p => {
                if (p.getAttribute('data-filter') === currentTpBrand) p.classList.add('active');
                else p.classList.remove('active');
            });
        }
        openAppModal(modalTp);
        renderTestPointCards();
    };

    openDirectTestPointImage = (imagePath, title, subtitle, desc) => {
        if (!modalTpViewer || !tpViewerImg) return;
        currentTpViewerZoom = 1;
        tpViewerImg.style.transform = 'scale(1)';
        tpViewerImg.src = imagePath;
        const viewerTitle = document.getElementById('tp-viewer-title');
        const viewerSubtitle = document.getElementById('tp-viewer-subtitle');
        const viewerDesc = document.getElementById('tp-viewer-desc');
        if (viewerTitle) viewerTitle.textContent = title || 'ไดอะแกรม Test Point';
        if (viewerSubtitle) viewerSubtitle.textContent = subtitle || '';
        if (viewerDesc) viewerDesc.innerHTML = `<i class="fas fa-microchip" style="color: #fbbf24;"></i> ${desc || 'จุดต่อวงจรบนเมนบอร์ด (ความละเอียดสูง)'}`;
        openAppModal(modalTpViewer);
    };

    // Search Input Listener
    if (tpSearchInput) {
        tpSearchInput.addEventListener('input', () => renderTestPointCards());
    }

    // Brand Filter Buttons Listener
    if (tpBrandFilters) {
        tpBrandFilters.querySelectorAll('button').forEach(btn => {
            btn.addEventListener('click', () => {
                tpBrandFilters.querySelectorAll('button').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                currentTpBrand = btn.dataset.filter || 'all';
                renderTestPointCards();
            });
        });
    }

    // Mode Filter Buttons Listener
    if (tpModeFilters) {
        tpModeFilters.querySelectorAll('button').forEach(btn => {
            btn.addEventListener('click', () => {
                tpModeFilters.querySelectorAll('button').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                currentTpMode = btn.dataset.mode || 'all';
                renderTestPointCards();
            });
        });
    }
    
// 3. DRIVER DOCTOR & USB FIXER SYSTEM (PRO GRADE)
    // ==============================================================
    const modalDriver = document.getElementById('modal-driver-doctor');
    const btnOpenDriver = document.getElementById('btn-open-driver-doctor');
    const btnCloseDriver = document.getElementById('btn-close-driver-modal');
    const btnRescanDriver = document.getElementById('btn-driver-rescan');
    const btnFixUsb = document.getElementById('btn-driver-fix-usb');
    const btnOpenDevmgmt = document.getElementById('btn-driver-open-devmgmt');
    const driverCardsList = document.getElementById('driver-cards-list');
    const txtOverallHealth = document.getElementById('txt-driver-overall-health');
    const liveDeviceBanner = document.getElementById('driver-live-device-banner');
    const liveDeviceText = document.getElementById('driver-live-device-text');
    const liveDevicePort = document.getElementById('driver-live-device-port');
    const fixProgressBox = document.getElementById('driver-fix-progress-box');
    const fixProgressTitle = document.getElementById('driver-fix-progress-title');
    const fixProgressSteps = document.getElementById('driver-fix-progress-steps');
    const badgeTestMode = document.getElementById('badge-driver-testmode');

    const DRIVER_INFOS = {
        unisoc: {
            title: 'Spreadtrum / Unisoc SPRD U2S & Diag',
            desc: 'ใช้สำหรับโหมด BSL Flasher และ Diag Port ของชิป SC7702, SC7731, SC9832E, T606/T612',
            link: 'https://spreadtrum-drivers.en.lo4d.com/',
            color: '#38bdf8',
            icon: 'fa-microchip'
        },
        mediatek: {
            title: 'MediaTek PreLoader / USB VCOM',
            desc: 'ใช้สำหรับเชื่อมต่อเครื่อง MTK ในโหมด BROM / Preloader (Helio, Dimensity, MT6765, MT6768)',
            link: 'https://androidsupported.com/mtk-usb-vcom-driver/',
            color: '#f97316',
            icon: 'fa-bolt'
        },
        qualcomm: {
            title: 'Qualcomm HS-USB QDLoader 9008',
            desc: 'ใช้สำหรับแฟลชรอมและปลดล็อกเครื่อง Snapdragon ในโหมดฉุกเฉิน (EDL 9008 / Diag)',
            link: 'https://qualcomm-hs-usb-qdloader9008.en.lo4d.com/',
            color: '#ef4444',
            icon: 'fa-microchip'
        },
        samsung: {
            title: 'SAMSUNG Mobile USB Composite Driver',
            desc: 'ใช้สำหรับโหมด Odin Download Mode, CDC Serial และ MTP Service (*#0*#)',
            link: 'https://developer.samsung.com/mobile/android-usb-driver.html',
            color: '#3b82f6',
            icon: 'fa-mobile-alt'
        },
        adb: {
            title: 'Android ADB & Fastboot (WinUSB Interface)',
            desc: 'ใช้สำหรับส่งคำสั่ง Fastboot Bootloader และการสั่งงานตรวจสถานะผ่าน ADB Shell',
            link: 'https://adb.clockworkmod.com/',
            color: '#4ade80',
            icon: 'fa-terminal'
        },
        huawei: {
            title: 'Huawei USB COM 1.0 & Diag Port',
            desc: 'ใช้สำหรับเชื่อมต่อชิป Kirin / HiSilicon ในโหมด Test Point (USB COM 1.0) และ Fastboot',
            link: 'https://androiddatahost.com/v8tq9',
            color: '#a855f7',
            icon: 'fa-shield-halved'
        },
        libusb: {
            title: 'LibUSB / WinUSB / UsbDk Filter Driver',
            desc: 'ใช้สำหรับระบบ Bypass SLA/DAA Authentication (MTK BROM Filter / mtkclient / UsbDk)',
            link: 'https://zadig.akeo.ie/',
            color: '#c084fc',
            icon: 'fa-filter'
        }
    };

    async function runDriverScan() {
        if (!driverCardsList) return;
        driverCardsList.innerHTML = '<div style="text-align:center; color:#38bdf8; padding:30px;"><i class="fas fa-spinner fa-spin"></i> กำลังตรวจวิเคราะห์ไดรเวอร์และระบบพอร์ตแบบละเอียด...</div>';
        if (txtOverallHealth) txtOverallHealth.textContent = 'กำลังสแกนวิเคราะห์ระบบฮาร์ดแวร์...';

        try {
            const res = await window.api.scanDriverDoctor();
            if (res && res.success && res.drivers) {
                driverCardsList.innerHTML = '';
                let installedCount = 0;
                let totalCount = Object.keys(res.drivers).length;

                // Update Test Mode Badge
                if (badgeTestMode) {
                    if (res.testMode) {
                        badgeTestMode.innerHTML = '🛡️ Test Mode: <span style="color:#4ade80;">เปิดอยู่ (พร้อมใช้ Unsigned Driver)</span>';
                        badgeTestMode.style.borderColor = 'rgba(74, 222, 128, 0.4)';
                        badgeTestMode.style.background = 'rgba(74, 222, 128, 0.12)';
                    } else {
                        badgeTestMode.innerHTML = '⚠ Test Mode: <span style="color:#fbbf24;">ปิดอยู่ (ไดรเวอร์บางรุ่นอาจติด Code 52)</span>';
                        badgeTestMode.style.borderColor = 'rgba(251, 191, 36, 0.4)';
                        badgeTestMode.style.background = 'rgba(251, 191, 36, 0.12)';
                    }
                }

                // Update Live Device Banner
                if (liveDeviceBanner) {
                    if (res.liveDevices && res.liveDevices.length > 0) {
                        const topDev = res.liveDevices[0];
                        liveDeviceBanner.style.display = 'flex';
                        if (liveDeviceText) {
                            liveDeviceText.innerHTML = `🟢 กำลังเชื่อมต่อสด: <b>${topDev.name}</b> บนพอร์ต <span style="color:#f8fafc; font-family:monospace; background:rgba(0,0,0,0.3); padding:2px 6px; border-radius:4px;">${topDev.port}</span> พร้อมส่งคำสั่ง`;
                        }
                        if (liveDevicePort) {
                            liveDevicePort.textContent = topDev.port;
                        }
                    } else {
                        liveDeviceBanner.style.display = 'none';
                    }
                }

                for (const [key, d] of Object.entries(res.drivers)) {
                    if (d.installed) installedCount++;
                    const info = DRIVER_INFOS[key] || { title: d.name, desc: '', link: '#', color: '#94a3b8', icon: 'fa-microchip' };

                    const card = document.createElement('div');
                    card.style.cssText = 'background: rgba(0,0,0,0.28); border: 1px solid rgba(255,255,255,0.06); border-radius: 10px; padding: 10px 14px; display: flex; align-items: center; justify-content: space-between; gap: 12px; transition: border-color 0.2s;';
                    
                    const isLive = !!d.livePort;
                    const statusColor = isLive ? '#38bdf8' : (d.installed ? '#4ade80' : '#f59e0b');
                    const statusBg = isLive ? 'rgba(56,189,248,0.18)' : (d.installed ? 'rgba(34,197,94,0.15)' : 'rgba(245,158,11,0.15)');
                    const statusBorder = isLive ? 'rgba(56,189,248,0.4)' : (d.installed ? 'rgba(34,197,94,0.3)' : 'rgba(245,158,11,0.3)');
                    const statusText = isLive ? `⚡ เชื่อมต่อสด (${d.livePort})` : (d.installed ? '✓ พร้อมใช้งาน 100%' : '⚠ ยังไม่พบ');

                    card.innerHTML = `
                        <div style="flex: 1; min-width: 0;">
                            <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                                <span style="width: 8px; height: 8px; border-radius: 50%; background: ${statusColor}; display: inline-block;"></span>
                                <h4 style="margin: 0; font-size: 13px; color: #f8fafc; font-weight: 700;"><i class="fas ${info.icon}" style="color:${info.color}; font-size: 12px; margin-right: 4px;"></i> ${info.title}</h4>
                                <span style="font-size: 9.5px; padding: 1.5px 7px; border-radius: 4px; background: ${statusBg}; color: ${statusColor}; border: 1px solid ${statusBorder}; font-weight: 700;">
                                    ${statusText}
                                </span>
                            </div>
                            <p style="margin: 3px 0 0; font-size: 11px; color: #94a3b8;">${d.dev ? 'สถานะ: ' + d.dev : info.desc}</p>
                        </div>
                        <div style="display: flex; gap: 6px; align-items: center;">
                            ${!d.installed ? `
                                <a href="${info.link}" target="_blank" class="action-btn" style="padding: 5px 11px; font-size: 10.5px; background: rgba(56,189,248,0.15); color: #38bdf8; border: 1px solid rgba(56,189,248,0.3); border-radius: 6px; text-decoration: none; display: flex; align-items: center; gap: 4px;">
                                    <i class="fas fa-download"></i> ดาวน์โหลด
                                </a>
                            ` : `
                                <span style="font-size: 11px; color: ${isLive ? '#38bdf8' : '#4ade80'}; font-weight: 700; padding: 4px 8px; background: ${statusBg}; border-radius: 6px; border: 1px solid ${statusBorder};">
                                    <i class="fas ${isLive ? 'fa-bolt' : 'fa-check'}"></i> ${isLive ? 'Active Port' : 'Driver Ready'}
                                </span>
                            `}
                        </div>
                    `;
                    driverCardsList.appendChild(card);
                }

                if (txtOverallHealth) {
                    const healthPct = Math.round((installedCount / totalCount) * 100);
                    txtOverallHealth.innerHTML = `ตรวจพบไดรเวอร์พร้อมใช้งาน <b>${installedCount}/${totalCount}</b> รายการ (สมบูรณ์ ${healthPct}%) • พบพอร์ตเชื่อมต่อ <b>${res.connectedCount || 0}</b> พอร์ต`;
                }
            } else {
                driverCardsList.innerHTML = `<div style="color:#ef4444; text-align:center; padding:20px;">ไม่สามารถอ่านสถานะไดรเวอร์: ${res?.error || 'ข้อผิดพลาด'}</div>`;
            }
        } catch (err) {
            driverCardsList.innerHTML = `<div style="color:#ef4444; text-align:center; padding:20px;">Error: ${err.message || err}</div>`;
        }
    }

    if (btnOpenDriver && modalDriver) {
        btnOpenDriver.addEventListener('click', () => {
            openAppModal(modalDriver);
            runDriverScan();
        });
    }
    if (btnCloseDriver && modalDriver) {
        btnCloseDriver.addEventListener('click', () => {
            closeAppModal(modalDriver);
        });
    }
    if (btnRescanDriver) {
        btnRescanDriver.addEventListener('click', () => runDriverScan());
    }
    if (btnFixUsb) {
        btnFixUsb.addEventListener('click', async () => {
            btnFixUsb.disabled = true;
            btnFixUsb.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังซ่อมแซม...';
            
            if (fixProgressBox) {
                fixProgressBox.style.display = 'block';
                if (fixProgressTitle) fixProgressTitle.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังดำเนินการซ่อมแซมและรีเซ็ตระบบพอร์ต USB (1-Click Pro Fix)...';
                if (fixProgressSteps) fixProgressSteps.textContent = '1. กำลังรีเซ็ต ADB Port Server...\n2. กำลังปรับแต่งระบบจัดการพลังงาน USB Selective Suspend...\n3. กำลังรีเฟรช PnP Hardware Bus...';
            }

            try {
                const res = await window.api.fixUsbStack();
                if (res && res.success) {
                    if (fixProgressTitle) fixProgressTitle.innerHTML = '<i class="fas fa-check-circle" style="color:#4ade80;"></i> ซ่อมแซมและรีเฟรชระบบพอร์ต USB สำเร็จสมบูรณ์ 100%!';
                    if (fixProgressSteps) {
                        const stepLines = (res.steps || []).map(s => `✓ ${s}`).join('\n');
                        const portsStr = (res.activePorts && res.activePorts.length > 0) ? res.activePorts.join(', ') : 'พร้อมเชื่อมต่อเมื่อเสียบสาย';
                        fixProgressSteps.textContent = `${stepLines}\n• พอร์ตที่พร้อมทำงานทันที: ${portsStr}`;
                    }
                } else {
                    if (fixProgressTitle) fixProgressTitle.innerHTML = '<i class="fas fa-exclamation-triangle" style="color:#f59e0b;"></i> ดำเนินการรีเซ็ตพอร์ตเรียบร้อยแล้ว (บางฟังก์ชันรันในระดับ User-Mode)';
                    if (fixProgressSteps) fixProgressSteps.textContent = res?.message || 'การรีเฟรชสำเร็จ';
                }
                runDriverScan();
            } catch (err) {
                if (fixProgressTitle) fixProgressTitle.innerHTML = '<i class="fas fa-times-circle" style="color:#ef4444;"></i> ข้อผิดพลาดระหว่างซ่อมพอร์ต';
                if (fixProgressSteps) fixProgressSteps.textContent = err.message || err;
            } finally {
                btnFixUsb.disabled = false;
                btnFixUsb.innerHTML = '<i class="fas fa-wrench"></i> ⚡ 1-Click Pro Fix พอร์ต USB';
            }
        });
    }
    if (btnOpenDevmgmt) {
        btnOpenDevmgmt.addEventListener('click', () => {
            window.api.openDevMgmt();
        });
    }


    // ==============================================================
    // 4. BACKUP & DUMP HISTORY MANAGER SYSTEM
    // ==============================================================
    const modalBackup = document.getElementById('modal-backup-history');
    const btnOpenBackup = document.getElementById('btn-open-backup-history');
    const btnCloseBackup = document.getElementById('btn-close-backup-modal');
    const btnRescanBackup = document.getElementById('btn-backup-rescan');
    const backupContainer = document.getElementById('backup-entries-container');
    const txtBackupCount = document.getElementById('txt-backup-count');

    async function runBackupScan() {
        if (!backupContainer) return;
        backupContainer.innerHTML = '<div style="text-align:center; color:#c084fc; padding:40px;"><i class="fas fa-spinner fa-spin"></i> กำลังสแกนค้นหาโฟลเดอร์รอมที่เคยดูดไว้...</div>';

        try {
            const backups = await window.api.scanBackupHistory();
            if (txtBackupCount) txtBackupCount.textContent = backups ? backups.length : 0;

            if (!backups || backups.length === 0) {
                backupContainer.innerHTML = '<div style="text-align:center; color:#64748b; padding:40px;">ยังไม่พบไฟล์รอมหรือข้อมูลสำรองที่เคยดูดไว้ในระบบ</div>';
                return;
            }

            backupContainer.innerHTML = '';
            backups.forEach(item => {
                const sizeMB = (item.totalSize / (1024 * 1024)).toFixed(2);
                const dateStr = item.createdAt ? new Date(item.createdAt).toLocaleString('th-TH') : '-';

                const card = document.createElement('div');
                card.style.cssText = 'background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.06); border-radius: 12px; padding: 14px; display: flex; flex-direction: column; gap: 10px; transition: border-color 0.2s;';
                card.innerHTML = `
                    <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:8px;">
                        <div>
                            <div style="display:flex; align-items:center; gap:8px;">
                                <h4 style="margin:0; font-size:14px; color:#f8fafc; font-weight:700;">${item.folderName}</h4>
                                <span style="font-size:10px; padding:1px 6px; border-radius:4px; background:rgba(56,189,248,0.15); color:#38bdf8; font-weight:600;">${item.model} (${item.cpu})</span>
                                ${item.pacFile ? '<span style="font-size:10px; padding:1px 6px; border-radius:4px; background:rgba(168,85,247,0.15); color:#c084fc; font-weight:700;">📦 มีไฟล์ .PAC</span>' : '<span style="font-size:10px; padding:1px 6px; border-radius:4px; background:rgba(255,255,255,0.08); color:#94a3b8;">📁 ไฟล์ดิบ (.bin)</span>'}
                            </div>
                            <span style="font-size:11px; color:#64748b; display:block; margin-top:2px;">
                                <i class="fas fa-clock"></i> บันทึกเมื่อ: ${dateStr} • ขนาดรวม: <b style="color:#cbd5e1;">${sizeMB} MB</b> (${item.binCount} พาร์ติชัน)
                            </span>
                        </div>
                        <div style="display:flex; gap:6px; flex-wrap:wrap;">
                            <button class="action-btn btn-open-backup-dir" style="padding:5px 10px; font-size:11px; background:rgba(255,255,255,0.08); color:#cbd5e1; border:1px solid rgba(255,255,255,0.12); border-radius:6px; cursor:pointer;" title="เปิดโฟลเดอร์ใน Windows Explorer">
                                <i class="fas fa-folder-open"></i> เปิดโฟลเดอร์
                            </button>
                            ${item.pacFile ? `
                                <button class="action-btn btn-flash-backup-pac" style="padding:5px 12px; font-size:11px; font-weight:700; background:linear-gradient(135deg, #10b981, #059669); color:#fff; border:1px solid #34d399; border-radius:6px; cursor:pointer;" title="โหลดไฟล์ .PAC เข้าสู่แท็บแฟลชทันที">
                                    <i class="fas fa-bolt"></i> เลือกแฟลช PAC นี้
                                </button>
                            ` : `
                                <button class="action-btn btn-pack-backup-dir" style="padding:5px 12px; font-size:11px; font-weight:700; background:linear-gradient(135deg, #8b5cf6, #6d28d9); color:#fff; border:1px solid #a78bfa; border-radius:6px; cursor:pointer;" title="สร้างไฟล์ .PAC จากโฟลเดอร์นี้">
                                    <i class="fas fa-box-archive"></i> รวมเป็น .PAC ทันที
                                </button>
                            `}
                            <button class="action-btn btn-delete-backup-dir" style="padding:5px 8px; font-size:11px; background:rgba(239,68,68,0.1); color:#f87171; border:1px solid rgba(239,68,68,0.25); border-radius:6px; cursor:pointer;" title="ลบข้อมูลสำรองนี้">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Partition Badges List -->
                    <div style="display:flex; gap:4px; flex-wrap:wrap;">
                        ${item.binFiles.map(b => `<span style="font-size:9.5px; font-family:monospace; padding:1px 6px; border-radius:3px; background:rgba(255,255,255,0.04); color:#94a3b8; border:1px solid rgba(255,255,255,0.06);">${b.replace('.bin', '')}</span>`).join('')}
                    </div>
                `;

                // Wire Actions
                const btnOpen = card.querySelector('.btn-open-backup-dir');
                if (btnOpen) {
                    btnOpen.addEventListener('click', () => {
                        window.api.openFileLocation(item.fullPath);
                    });
                }

                const btnFlash = card.querySelector('.btn-flash-backup-pac');
                if (btnFlash && item.pacFile) {
                    btnFlash.addEventListener('click', () => {
                        closeAppModal(modalBackup);
                        const spdTab = document.querySelector('.tab-btn[data-target="tab-spd"]');
                        if (spdTab) spdTab.click();
                        const pacPathEl = document.getElementById('spd-pac-file-path');
                        if (pacPathEl) pacPathEl.textContent = item.pacFile;
                        window.spdSelectedPacPath = item.pacFile;
                        const btnBrowse = document.getElementById('btn-spd-browse-pac');
                        if (btnBrowse) {
                            btnBrowse.dispatchEvent(new CustomEvent('pac-loaded', { detail: { path: item.pacFile } }));
                        }
                    });
                }

                const btnPack = card.querySelector('.btn-pack-backup-dir');
                if (btnPack) {
                    btnPack.addEventListener('click', async () => {
                        btnPack.disabled = true;
                        btnPack.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังรวมไฟล์...';
                        try {
                            const res = await window.api.packDumpToPac(item.fullPath, { model: item.model, cpu: item.cpu });
                            if (res && res.success) {
                                alert(`สร้างไฟล์ .PAC สำเร็จ 100%!\n\nไฟล์บันทึกที่: ${res.pacPath}\nขนาด: ${(res.size / (1024*1024)).toFixed(2)} MB`);
                                runBackupScan();
                            } else {
                                alert('การรวมไฟล์ล้มเหลว: ' + (res?.error || 'ข้อผิดพลาด'));
                            }
                        } catch (err) {
                            alert('ข้อผิดพลาด: ' + (err.message || err));
                        } finally {
                            btnPack.disabled = false;
                            btnPack.innerHTML = '<i class="fas fa-box-archive"></i> รวมเป็น .PAC ทันที';
                        }
                    });
                }

                const btnDelete = card.querySelector('.btn-delete-backup-dir');
                if (btnDelete) {
                    btnDelete.addEventListener('click', async () => {
                        if (confirm(`คุณต้องการลบข้อมูลสำรองโฟลเดอร์ "${item.folderName}" ใช่หรือไม่?\n\nการลบนี้ไม่สามารถกู้คืนได้`)) {
                            try {
                                await window.api.deleteBackupFolder(item.fullPath);
                                alert('ลบข้อมูลสำรองเรียบร้อยแล้ว');
                                runBackupScan();
                            } catch (err) {
                                alert('ลบไม่สำเร็จ: ' + (err.message || err));
                            }
                        }
                    });
                }

                backupContainer.appendChild(card);
            });
        } catch (err) {
            backupContainer.innerHTML = `<div style="color:#ef4444; text-align:center; padding:20px;">Error: ${err.message || err}</div>`;
        }
    }

    if (btnOpenBackup && modalBackup) {
        btnOpenBackup.addEventListener('click', () => {
            openAppModal(modalBackup);
            runBackupScan();
        });
    }
    if (btnCloseBackup && modalBackup) {
        btnCloseBackup.addEventListener('click', () => {
            closeAppModal(modalBackup);
        });
    }
    if (btnRescanBackup) {
        btnRescanBackup.addEventListener('click', () => runBackupScan());
    }

    // Universal backdrop click and Escape key listener to easily close any modal
    const modalMdmGuideGlobal = document.getElementById('modal-mdm-guide');
    [modalImei, modalTp, modalDriver, modalBackup, modalMdmGuideGlobal].forEach(m => {
        if (m) {
            m.addEventListener('click', (e) => {
                if (e.target === m) closeAppModal(m);
            });
        }
    });

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            [modalImei, modalTp, modalDriver, modalBackup, modalMdmGuideGlobal].forEach(m => {
                if (m && (m.classList.contains('is-open') || m.style.display === 'flex')) {
                    closeAppModal(m);
                }
            });
        }
    });

    // =========================================================================
    // GSM TECHNICIAN PRO SUITE CONTROLLER
    // =========================================================================
    (function initGsmProSuite() {
        // --- 1. Samsung Port Discovery & Selector ---
        const gsmSamsungPortSelect = document.getElementById('gsm-samsung-port-select');
        const btnScanSamsungPorts = document.getElementById('btn-gsm-scan-samsung-ports');

        async function refreshSamsungPorts() {
            if (!gsmSamsungPortSelect) return;
            try {
                if (window.api && window.api.samsung350kScan) {
                    const res = await window.api.samsung350kScan();
                    const allPorts = res.all_ports || [];
                    const currentVal = gsmSamsungPortSelect.value;
                    gsmSamsungPortSelect.innerHTML = '<option value="">ค้นหาพอร์ตอัตโนมัติ (Auto-Detect)</option>';
                    allPorts.forEach(p => {
                        const opt = document.createElement('option');
                        opt.value = p.port;
                        const label = p.description ? `${p.port} - ${p.description}` : p.port;
                        opt.textContent = label;
                        if (p.is_samsung || p.is_download) {
                            opt.textContent += ' ⭐ (Samsung)';
                        }
                        gsmSamsungPortSelect.appendChild(opt);
                    });
                    if (res.best_samsung && !currentVal) {
                        gsmSamsungPortSelect.value = res.best_samsung.port;
                    } else if (currentVal) {
                        gsmSamsungPortSelect.value = currentVal;
                    }
                }
            } catch (err) {
                console.warn('Error scanning Samsung ports:', err);
            }
        }

        if (btnScanSamsungPorts) {
            btnScanSamsungPorts.addEventListener('click', async () => {
                showMobileToast('🔍 กำลังสแกนหาพอร์ต Samsung COM...', 'info', 2000);
                await refreshSamsungPorts();
                const count = gsmSamsungPortSelect ? gsmSamsungPortSelect.options.length - 1 : 0;
                if (count > 0) {
                    showMobileToast(`✅ ตรวจพบ ${count} พอร์ต COM`, 'success', 2500);
                } else {
                    showMobileToast('⚠️ ไม่พบพอร์ต COM อุปกรณ์ Samsung', 'warning', 3000);
                }
            });
        }

        // Auto scan when switching to tab-gsm-pro
        const gsmTabBtn = document.querySelector('.tab-btn[data-target="tab-gsm-pro"]');
        if (gsmTabBtn) {
            gsmTabBtn.addEventListener('click', () => {
                setTimeout(refreshSamsungPorts, 150);
            });
        }

        // --- 1.1 Samsung Pro Model Intelligence & DB ---
        const samsungModelSearchInput = document.getElementById('samsung-model-search-input');
        const samsungModelsDatalist = document.getElementById('samsung-models-datalist');
        const btnSamsungModelGuide = document.getElementById('btn-samsung-model-guide');
        const btnSamsungDeepReadInfo = document.getElementById('btn-samsung-deep-readinfo');
        const lblSamsungActiveModel = document.getElementById('lbl-samsung-active-model');
        const lblSamsungActivePlatform = document.getElementById('lbl-samsung-active-platform');
        const samsungActiveTags = document.getElementById('samsung-active-tags');
        const samsungModelCountBadge = document.getElementById('samsung-model-count-badge');

        let samsungModelsDatabase = {};

        async function loadSamsungModels() {
            try {
                if (window.api && window.api.getSamsungModelsDb) {
                    const res = await window.api.getSamsungModelsDb();
                    if (res && res.success && res.models) {
                        samsungModelsDatabase = res.models;
                        const keys = Object.keys(samsungModelsDatabase);
                        if (samsungModelCountBadge) {
                            samsungModelCountBadge.innerHTML = `<i class="fas fa-microchip"></i> ${keys.length.toLocaleString()} Models Loaded`;
                        }
                        if (samsungModelsDatalist) {
                            samsungModelsDatalist.innerHTML = '';
                            const frag = document.createDocumentFragment();
                            keys.forEach(k => {
                                const m = samsungModelsDatabase[k];
                                const opt = document.createElement('option');
                                opt.value = k;
                                opt.textContent = `${k} (${m.platform || 'Samsung'})`;
                                frag.appendChild(opt);
                            });
                            samsungModelsDatalist.appendChild(frag);
                        }
                    }
                }
            } catch (err) {
                console.warn('Failed to load Samsung models DB:', err);
            }
        }

        loadSamsungModels();

        function updateActiveModelDisplay(modelName) {
            if (!modelName) return;
            const clean = modelName.trim().toUpperCase();
            const info = samsungModelsDatabase[clean] || 
                         samsungModelsDatabase[clean.replace(/^SM-/, '')] ||
                         samsungModelsDatabase[`SM-${clean}`] || null;

            if (lblSamsungActiveModel) {
                lblSamsungActiveModel.textContent = clean;
            }
            if (lblSamsungActivePlatform) {
                lblSamsungActivePlatform.textContent = info ? (info.platform || 'Samsung SoC') : 'Samsung Galaxy';
            }
            if (samsungActiveTags) {
                samsungActiveTags.innerHTML = `
                    <span class="badge badge-success" style="font-size: 9.5px; padding: 2px 6px;">Odin Flash</span>
                    <span class="badge badge-info" style="font-size: 9.5px; padding: 2px 6px;">MTP FRP</span>
                    <span class="badge badge-warning" style="font-size: 9.5px; padding: 2px 6px;">CSC Change</span>
                    <span class="badge badge-primary" style="font-size: 9.5px; padding: 2px 6px;">AT Diagnostics</span>
                `;
                if (info && info.functions && Array.isArray(info.functions)) {
                    info.functions.slice(0, 3).forEach(fn => {
                        const s = document.createElement('span');
                        s.className = 'badge badge-secondary';
                        s.style.fontSize = '9.5px';
                        s.style.padding = '2px 6px';
                        s.textContent = fn;
                        samsungActiveTags.appendChild(s);
                    });
                }
            }
        }

        if (samsungModelSearchInput) {
            samsungModelSearchInput.addEventListener('input', (e) => {
                updateActiveModelDisplay(e.target.value);
            });
            samsungModelSearchInput.addEventListener('change', (e) => {
                updateActiveModelDisplay(e.target.value);
            });
        }

        if (btnSamsungModelGuide) {
            btnSamsungModelGuide.addEventListener('click', async () => {
                const currentModel = (samsungModelSearchInput && samsungModelSearchInput.value.trim()) || 
                                     (lblSamsungActiveModel ? lblSamsungActiveModel.textContent.trim() : 'SM-A125F');
                openModal(`คู่มือช่าง Pro Service Guide: ${currentModel}`);
                logToModal('================================================\n', 'info');
                logToModal(`  Samsung Hardware & Service Manual: ${currentModel}\n`, 'success');
                logToModal('================================================\n', 'info');
                logToModal('> กำลังดึงคู่มือทางการจาก Service Knowledge Base...\n');

                try {
                    const res = await window.api.samsungModelHelp(currentModel);
                    if (res && res.success) {
                        if (res.flash) {
                            logToModal('\n📥 [คู่มือการเข้า Download Mode & Flashing]:\n', 'success');
                            logToModal(res.flash + '\n', 'info');
                        }
                        if (res.unlock) {
                            logToModal('\n🔧 [คู่มือการเปิด Diag / ปลดล็อค & ตรวจสอบ]:\n', 'warning');
                            logToModal(res.unlock + '\n', 'info');
                        }
                        finishModal(true);
                    } else {
                        logToModal(`\n[NOTICE] ${res.error || 'ไม่พบข้อมูลคู่มือเฉพาะรุ่น'}\n`, 'warning');
                        finishModal(false, true, 'ไม่พบข้อมูลคู่มือเฉพาะรุ่น');
                    }
                } catch (err) {
                    logToModal(`\n[ERROR] ${err.message || err}\n`, 'error');
                    finishModal(false, true, err.message);
                }
            });
        }

        if (btnSamsungDeepReadInfo) {
            btnSamsungDeepReadInfo.addEventListener('click', async () => {
                const port = gsmSamsungPortSelect ? gsmSamsungPortSelect.value : null;
                openModal('Samsung Deep Diagnostics (Read Info)');
                logToModal('================================================\n', 'info');
                logToModal('  Samsung Deep Diagnostics - AT & ADB Protocol\n', 'success');
                logToModal('================================================\n', 'info');
                logToModal('> เชื่อมต่อพอร์ต Samsung Mobile USB Modem & ADB...\n');

                const origHtml = btnSamsungDeepReadInfo.innerHTML;
                btnSamsungDeepReadInfo.disabled = true;
                btnSamsungDeepReadInfo.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังอ่านข้อมูล...';

                try {
                    const res = await window.api.samsungReadInfo(port);
                    if (res && res.success) {
                        logToModal('\n[OK] อ่านข้อมูลอุปกรณ์สำเร็จ 100%!\n', 'success');
                        finishModal(true);
                        const info = res.info || {};
                        if (info.Model && samsungModelSearchInput) {
                            samsungModelSearchInput.value = info.Model;
                            updateActiveModelDisplay(info.Model);
                        }
                        const diagKnox = document.getElementById('gsm-diag-knox');
                        if (diagKnox && info.Knox_Bit) diagKnox.textContent = info.Knox_Bit;
                        const currCsc = document.getElementById('gsm-current-csc');
                        if (currCsc && info.Sales_Code) currCsc.textContent = info.Sales_Code;
                    } else {
                        logToModal(`\n[FAIL] ${res.error || 'ไม่พบอุปกรณ์'}\n`, 'error');
                        finishModal(false, true, res.error || 'ไม่พบอุปกรณ์');
                    }
                } catch (err) {
                    logToModal(`\n[ERROR] ${err.message || err}\n`, 'error');
                    finishModal(false, true, err.message);
                } finally {
                    btnSamsungDeepReadInfo.disabled = false;
                    btnSamsungDeepReadInfo.innerHTML = origHtml;
                }
            });
        }

        // --- 2. Tool 1: Samsung MTP 1-Click FRP ---
        const btnSamsungFrp = document.getElementById('btn-gsm-samsung-frp');
        const btnSamsungRebootDl = document.getElementById('btn-gsm-samsung-reboot-dl');
        const btnSamsungRebootNorm = document.getElementById('btn-gsm-samsung-reboot-norm');

        if (btnSamsungFrp) {
            btnSamsungFrp.addEventListener('click', async () => {
                const port = gsmSamsungPortSelect ? gsmSamsungPortSelect.value : null;
                openModal('Samsung MTP FRP 1-Click (*#0*# Bypass)');
                logToModal('================================================\n', 'info');
                logToModal('  Samsung MTP FRP 1-Click Bypass Protocol\n', 'success');
                logToModal('  Method: AT Modem Trigger + Automated ADB Setup Wizard\n', 'info');
                logToModal('================================================\n', 'info');
                logToModal('> ตรวจสอบการเชื่อมต่อโทรศัพท์ Samsung...\n');
                logToModal('> คำแนะนำ: หากยังไม่ได้กดรหัส ให้แตะ "โทรฉุกเฉิน" แล้วพิมพ์ *#0*# ทันที\n', 'warning');

                const origHtml = btnSamsungFrp.innerHTML;
                btnSamsungFrp.disabled = true;
                btnSamsungFrp.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังส่งคำสั่ง...';

                try {
                    const res = await window.api.samsung350kAction({
                        action: 'frp_mtp',
                        port: port || null
                    });
                    if (res && res.success) {
                        logToModal('\n[SUCCESS] 🎉 ปลดล็อค Samsung FRP สำเร็จเรียบร้อย 100%!\n', 'success');
                        logToModal('> ตัวเครื่องได้รับการ Bypass Setup Wizard และกำลังรีบูตเข้าหน้าโฮม\n', 'success');
                        finishModal(true);
                    } else {
                        const errMsg = res.output || res.error || 'ไม่พบพอร์ต Samsung หรือยังไม่ได้กด *#0*#';
                        logToModal(`\n[NOTICE] ${errMsg}\n`, 'warning');
                        finishModal(false, true, 'ไม่พบพอร์ต Samsung หรือยังไม่ได้กด *#0*#');
                    }
                } catch (err) {
                    logToModal(`\n[ERROR] ไม่สามารถส่งคำสั่ง FRP: ${err.message || err}\n`, 'error');
                    finishModal(false, true, err.message || 'ส่งคำสั่ง FRP ไม่สำเร็จ');
                } finally {
                    btnSamsungFrp.disabled = false;
                    btnSamsungFrp.innerHTML = origHtml;
                }
            });
        }

        if (btnSamsungRebootDl) {
            btnSamsungRebootDl.addEventListener('click', async () => {
                const port = gsmSamsungPortSelect ? gsmSamsungPortSelect.value : null;
                openModal('Samsung 350K: สั่งเข้า Download Mode');
                try {
                    const res = await window.api.samsung350kAction({ action: 'download', port });
                    if (res && res.success) {
                        logToModal('\n[OK] ส่งคำสั่งเข้า Download Mode เรียบร้อย\n', 'success');
                        finishModal(true);
                    } else {
                        logToModal(`\n[FAIL] ${res.error || 'ไม่พบอุปกรณ์'}\n`, 'error');
                        finishModal(false, true, 'ไม่พบโทรศัพท์ Samsung หรือพอร์ต COM');
                    }
                } catch (err) {
                    logToModal(`\n[ERROR] ${err.message || err}\n`, 'error');
                    finishModal(false, true, err.message || 'ส่งคำสั่งไม่สำเร็จ');
                }
            });
        }

        if (btnSamsungRebootNorm) {
            btnSamsungRebootNorm.addEventListener('click', async () => {
                const port = gsmSamsungPortSelect ? gsmSamsungPortSelect.value : null;
                openModal('Samsung: รีบูตเครื่องปกติ');
                try {
                    const res = await window.api.samsung350kAction({ action: 'reboot', port });
                    if (res && res.success) {
                        logToModal('\n[OK] ส่งคำสั่งรีบูตเรียบร้อย\n', 'success');
                        finishModal(true);
                    } else {
                        logToModal(`\n[FAIL] ${res.error || 'ไม่พบอุปกรณ์'}\n`, 'error');
                        finishModal(false, true, 'ไม่พบโทรศัพท์ Samsung หรือพอร์ต COM');
                    }
                } catch (err) {
                    logToModal(`\n[ERROR] ${err.message || err}\n`, 'error');
                    finishModal(false, true, err.message || 'ส่งคำสั่งไม่สำเร็จ');
                }
            });
        }

        // --- 2.1 Mode Switching: Recovery & Factory Reset ---
        const btnSamsungRebootRec = document.getElementById('btn-gsm-samsung-reboot-rec');
        const btnSamsungFactoryReset = document.getElementById('btn-gsm-samsung-factory-reset');

        if (btnSamsungRebootRec) {
            btnSamsungRebootRec.addEventListener('click', async () => {
                const port = gsmSamsungPortSelect ? gsmSamsungPortSelect.value : null;
                openModal('Samsung: สั่งรีบูตเข้า Recovery Mode');
                try {
                    const res = await window.api.samsungRebootRecovery(port);
                    if (res && res.success) {
                        logToModal('\n[OK] ส่งคำสั่งรีบูตเข้า Recovery Mode เรียบร้อย\n', 'success');
                        finishModal(true);
                    } else {
                        logToModal(`\n[FAIL] ${res.error || 'ไม่พบอุปกรณ์'}\n`, 'error');
                        finishModal(false, true, 'ไม่พบโทรศัพท์ Samsung หรือพอร์ต COM');
                    }
                } catch (err) {
                    logToModal(`\n[ERROR] ${err.message || err}\n`, 'error');
                    finishModal(false, true, err.message || 'ส่งคำสั่งไม่สำเร็จ');
                }
            });
        }

        if (btnSamsungFactoryReset) {
            btnSamsungFactoryReset.addEventListener('click', async () => {
                const confirmWipe = confirm('⚠️ คำเตือน: คุณต้องการล้างเครื่อง Factory Reset (Format Userdata) โทรศัพท์ Samsung ใช่หรือไม่?\nข้อมูลในเครื่องทั้งหมดจะถูกลบ!');
                if (!confirmWipe) return;

                const port = gsmSamsungPortSelect ? gsmSamsungPortSelect.value : null;
                openModal('Samsung Factory Reset (Format Userdata via AT)');
                logToModal('================================================\n', 'info');
                logToModal('  Samsung AT Modem Factory Reset Protocol\n', 'success');
                logToModal('================================================\n', 'info');
                logToModal('> กำลังส่งคำสั่ง AT+FACTORST=0,0 ไปยังพอร์ต Modem...\n');

                try {
                    const res = await window.api.samsungFactoryReset(port);
                    if (res && res.success) {
                        logToModal('\n[SUCCESS] 🎉 คำสั่ง Factory Reset ถูกส่งไปยังโทรศัพท์เรียบร้อย!\n', 'success');
                        logToModal('> ตัวเครื่องกำลังทำการ Format Userdata และรีสตาร์ท\n', 'success');
                        finishModal(true);
                    } else {
                        logToModal(`\n[FAIL] ${res.error || 'ไม่สามารถส่งคำสั่งได้'}\n`, 'error');
                        finishModal(false, true, res.error || 'ส่งคำสั่งไม่สำเร็จ');
                    }
                } catch (err) {
                    logToModal(`\n[ERROR] ${err.message || err}\n`, 'error');
                    finishModal(false, true, err.message);
                }
            });
        }

        // --- 2.2 Samsung Secret Codes Buttons ---
        document.querySelectorAll('.rtc-secret-code-btn').forEach(btn => {
            btn.addEventListener('click', async () => {
                const code = btn.getAttribute('data-code');
                if (!code) return;
                try {
                    navigator.clipboard.writeText(code);
                    showMobileToast(`📋 คัดลอกรหัส ${code} เรียบร้อย!`, 'success', 2000);
                } catch (_) {}

                try {
                    const res = await window.api.samsungDialCode(code);
                    if (res && res.adb) {
                        showMobileToast(`📲 ส่งรหัส ${code} ไปยังหน้าจอมือถือแล้ว`, 'info', 2500);
                    }
                } catch (_) {}
            });
        });

        // --- 2.3 PIT Partition Inspector ---
        const btnSamsungBrowsePit = document.getElementById('btn-samsung-browse-pit');
        const btnSamsungParsePit = document.getElementById('btn-samsung-parse-pit');
        const inputSamsungPitPath = document.getElementById('samsung-pit-path-input');
        const boxSamsungPitResult = document.getElementById('samsung-pit-result-box');
        const lblSamsungPitMeta = document.getElementById('samsung-pit-meta-label');
        const tbodySamsungPit = document.getElementById('samsung-pit-tbody');

        if (btnSamsungBrowsePit) {
            btnSamsungBrowsePit.addEventListener('click', async () => {
                try {
                    const filePath = await window.api.browseSamsungPit();
                    if (filePath && inputSamsungPitPath) {
                        inputSamsungPitPath.value = filePath;
                        if (btnSamsungParsePit) btnSamsungParsePit.click();
                    }
                } catch (err) {
                    console.error('Error browsing PIT:', err);
                }
            });
        }

        if (btnSamsungParsePit) {
            btnSamsungParsePit.addEventListener('click', async () => {
                const target = inputSamsungPitPath ? inputSamsungPitPath.value.trim() : '';
                if (!target) {
                    showMobileToast('⚠️ กรุณาเลือกไฟล์ *.pit หรือไฟล์รอมศูนย์ก่อน', 'warning', 2500);
                    return;
                }

                showMobileToast('🔍 กำลังถอดรหัสโครงสร้าง Partition PIT...', 'info', 1500);
                try {
                    const res = await window.api.samsungParsePit(target);
                    if (res && res.success && res.partitions) {
                        if (boxSamsungPitResult) boxSamsungPitResult.style.display = 'block';
                        if (lblSamsungPitMeta) {
                            lblSamsungPitMeta.textContent = `ไฟล์: ${res.pit_filename || 'PIT'} | จำนวน Partition: ${res.partitions.length} รายการ`;
                        }
                        if (tbodySamsungPit) {
                            tbodySamsungPit.innerHTML = '';
                            res.partitions.forEach(p => {
                                const tr = document.createElement('tr');
                                tr.style.borderBottom = '1px solid rgba(255,255,255,0.04)';
                                tr.innerHTML = `
                                    <td style="padding: 4px; font-weight: 600; color: #38bdf8;">${p.partition}</td>
                                    <td style="padding: 4px; color: #cbd5e1; font-family: monospace;">${p.filename || '-'}</td>
                                    <td style="padding: 4px; color: #a78bfa;">${p.device || 'eMMC'}</td>
                                    <td style="padding: 4px; color: #4ade80;">${p.approx_size_mb ? p.approx_size_mb + ' MB' : '-'}</td>
                                `;
                                tbodySamsungPit.appendChild(tr);
                            });
                        }
                        showMobileToast(`✅ ถอดรหัสสำเร็จ: พบ ${res.partitions.length} พาร์ติชัน`, 'success', 3000);
                    } else {
                        showMobileToast(`❌ ${res.error || 'ไม่สามารถถอดรหัส PIT ได้'}`, 'error', 3500);
                    }
                } catch (err) {
                    showMobileToast(`❌ ${err.message || err}`, 'error', 3500);
                }
            });
        }

        // --- 3. Tool 2: Anti-Relock & Disable OTA Updates ---
        const otaBrandSelect = document.getElementById('gsm-anti-relock-brand');
        const btnDisableOta = document.getElementById('btn-gsm-disable-ota');
        const btnEnableOta = document.getElementById('btn-gsm-enable-ota');
        const btnCheckOta = document.getElementById('btn-gsm-check-ota');
        const lblOtaStatus = document.getElementById('gsm-ota-pkg-status');

        const otaPackagesByBrand = {
            samsung: [
                'com.wssyncmldm',
                'com.samsung.android.fota',
                'com.sec.android.soagent',
                'com.samsung.sdm',
                'com.samsung.klmsagent',
                'com.sec.enterprise.knox.cloudmdm.smdms'
            ],
            xiaomi: [
                'com.miui.android.ota',
                'com.xiaomi.finddevice',
                'com.miui.cloudservice',
                'com.miui.cloudbackup',
                'com.miui.micloudsync'
            ],
            oppo: [
                'com.coloros.sau',
                'com.coloros.sauhelper',
                'com.oppo.market',
                'com.heytap.mcs',
                'com.heytap.cloud',
                'com.coloros.phonemanager'
            ],
            vivo: [
                'com.vivo.upgrade',
                'com.bbk.updater',
                'com.vivo.findphone',
                'com.vivo.cloud',
                'com.vivo.daemonService'
            ],
            universal: [
                'com.google.android.gms/.update.SystemUpdateService'
            ]
        };

        if (btnDisableOta) {
            btnDisableOta.addEventListener('click', async () => {
                const brand = otaBrandSelect ? otaBrandSelect.value : 'samsung';
                openModal(`Anti-Relock: ปิด OTA & MDM (${brand.toUpperCase()})`);
                logToModal('================================================\n', 'info');
                logToModal(`  Anti-Relock System Update Disabler [${brand.toUpperCase()}]\n`, 'success');
                logToModal('================================================\n', 'info');
                logToModal('> กำลังตรวจสอบการเชื่อมต่อ ADB...\n');

                const origHtml = btnDisableOta.innerHTML;
                btnDisableOta.disabled = true;
                btnDisableOta.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังปิดกั้น...';

                try {
                    const checkDev = await window.api.runAdbCommand('devices');
                    if (!checkDev || !checkDev.includes('\tdevice')) {
                        logToModal('\n[ERROR] ไม่พบอุปกรณ์ในโหมด ADB! กรุณาเปิด USB Debugging ในมือถือก่อน\n', 'error');
                        finishModal(false, true, 'ไม่พบอุปกรณ์ ADB! กรุณาเปิด USB Debugging ในมือถือก่อน');
                        return;
                    }

                    const pkgs = otaPackagesByBrand[brand] || [];
                    let disabledCount = 0;

                    for (const pkg of pkgs) {
                        if (pkg.includes('/')) {
                            await window.api.runAdbCommand(`shell pm disable-user --user 0 ${pkg.split('/')[0]}`);
                        } else {
                            const out1 = await window.api.runAdbCommand(`shell pm disable-user --user 0 ${pkg}`);
                            if (out1 && (out1.includes('disabled') || out1.includes('state: disabled') || out1.includes('new state'))) {
                                logToModal(`  [✓] ปิดกั้นสำเร็จ: ${pkg}\n`, 'success');
                                disabledCount++;
                            } else {
                                const out2 = await window.api.runAdbCommand(`shell pm disable ${pkg}`);
                                if (out2 && !out2.includes('Error')) {
                                    logToModal(`  [✓] ปิดกั้นสำเร็จ: ${pkg}\n`, 'success');
                                    disabledCount++;
                                } else {
                                    logToModal(`  [-] ไม่พบแพ็กเกจในเครื่องนี้: ${pkg}\n`, 'info');
                                }
                            }
                        }
                    }

                    await window.api.runAdbCommand('shell settings put global ota_disable_automatic_update 1');
                    await window.api.runAdbCommand('shell settings put global auto_update 0');
                    logToModal('  [✓] ตั้งค่า Global Settings: ota_disable_automatic_update = 1\n', 'success');

                    if (lblOtaStatus) {
                        lblOtaStatus.textContent = '🛡️ ปิดกั้นแล้ว (OTA Disabled)';
                        lblOtaStatus.style.color = '#4ade80';
                    }

                    logToModal(`\n[SUCCESS] ปิดกั้นแพ็กเกจเสร็จสิ้น (${disabledCount} แพ็กเกจถูกปิดใช้งาน) เครื่องจะไม่สามารถอัปเดตหรือดึง Knox ซ้ำได้\n`, 'success');
                    finishModal(true);
                } finally {
                    btnDisableOta.disabled = false;
                    btnDisableOta.innerHTML = origHtml;
                }
            });
        }

        if (btnEnableOta) {
            btnEnableOta.addEventListener('click', async () => {
                const brand = otaBrandSelect ? otaBrandSelect.value : 'samsung';
                openModal(`Anti-Relock: คืนค่าเปิด OTA (${brand.toUpperCase()})`);
                logToModal('> กำลังตรวจสอบการเชื่อมต่อ ADB...\n');

                const origHtml = btnEnableOta.innerHTML;
                btnEnableOta.disabled = true;
                btnEnableOta.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังเปิด...';

                try {
                    const checkDev = await window.api.runAdbCommand('devices');
                    if (!checkDev || !checkDev.includes('\tdevice')) {
                        logToModal('\n[ERROR] ไม่พบอุปกรณ์ในโหมด ADB! กรุณาเปิด USB Debugging ในมือถือก่อน\n', 'error');
                        finishModal(false, true, 'ไม่พบอุปกรณ์ ADB! กรุณาเปิด USB Debugging ในมือถือก่อน');
                        return;
                    }

                    const pkgs = otaPackagesByBrand[brand] || [];
                    for (const pkg of pkgs) {
                        const cleanPkg = pkg.split('/')[0];
                        await window.api.runAdbCommand(`shell pm enable ${cleanPkg}`);
                        logToModal(`  [✓] เปิดการทำงาน: ${cleanPkg}\n`);
                    }

                    await window.api.runAdbCommand('shell settings put global ota_disable_automatic_update 0');
                    if (lblOtaStatus) {
                        lblOtaStatus.textContent = 'เปิดปกติ (OTA Enabled)';
                        lblOtaStatus.style.color = '#38bdf8';
                    }

                    logToModal('\n[SUCCESS] คืนค่าเปิดระบบอัปเดตเรียบร้อย\n', 'success');
                    finishModal(true);
                } finally {
                    btnEnableOta.disabled = false;
                    btnEnableOta.innerHTML = origHtml;
                }
            });
        }

        if (btnCheckOta) {
            btnCheckOta.addEventListener('click', async () => {
                const brand = otaBrandSelect ? otaBrandSelect.value : 'samsung';
                openModal(`ตรวจสอบสถานะ OTA Packages (${brand.toUpperCase()})`);
                logToModal('> ตรวจสอบแพ็กเกจที่ถูกปิดใช้งานในระบบ...\n');

                const disabledList = await window.api.runAdbCommand('shell pm list packages -d');
                const pkgs = otaPackagesByBrand[brand] || [];
                let anyDisabled = false;

                pkgs.forEach(pkg => {
                    const cleanPkg = pkg.split('/')[0];
                    if (disabledList && disabledList.includes(cleanPkg)) {
                        logToModal(`  [LOCKED/DISABLED] 🛡️ ${cleanPkg} (ถูกปิดกั้นอยู่)\n`, 'success');
                        anyDisabled = true;
                    } else {
                        logToModal(`  [ACTIVE/ENABLED] ⚠️ ${cleanPkg} (เปิดใช้งานอยู่/ยังไม่ได้ปิด)\n`, 'warning');
                    }
                });

                if (lblOtaStatus) {
                    if (anyDisabled) {
                        lblOtaStatus.textContent = '🛡️ มีแพ็กเกจถูกปิดกั้นอยู่';
                        lblOtaStatus.style.color = '#4ade80';
                    } else {
                        lblOtaStatus.textContent = '⚠️ ยังไม่ได้ปิดกั้น';
                        lblOtaStatus.style.color = '#fbbf24';
                    }
                }
                finishModal(true);
            });
        }

        // --- 4. Tool 3: Samsung CSC Changer ---
        const cscPresetSelect = document.getElementById('gsm-csc-preset-select');
        const cscCustomInput = document.getElementById('gsm-csc-custom-input');
        const btnReadCsc = document.getElementById('btn-gsm-read-csc');
        const btnChangeCsc = document.getElementById('btn-gsm-change-csc');
        const badgeCurrentCsc = document.getElementById('gsm-csc-current-badge');

        if (cscPresetSelect && cscCustomInput) {
            cscPresetSelect.addEventListener('change', () => {
                if (cscPresetSelect.value === 'CUSTOM') {
                    cscCustomInput.style.display = 'block';
                    cscCustomInput.focus();
                } else {
                    cscCustomInput.style.display = 'none';
                }
            });
        }

        if (btnReadCsc) {
            btnReadCsc.addEventListener('click', async () => {
                const port = gsmSamsungPortSelect ? gsmSamsungPortSelect.value : null;
                openModal('Samsung CSC Changer: อ่านรหัส CSC ปัจจุบัน');
                logToModal('================================================\n', 'info');
                logToModal('  Samsung CSC Query Protocol (AT+PRECONFG & ADB)\n', 'success');
                logToModal('================================================\n', 'info');

                const origHtml = btnReadCsc.innerHTML;
                btnReadCsc.disabled = true;
                btnReadCsc.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังอ่าน...';

                try {
                    let foundCsc = '';
                    if (window.api && window.api.samsungCscRead) {
                        const res = await window.api.samsungCscRead(port);
                        if (res && res.output) {
                            logToModal(res.output + '\n');
                            const match = res.output.match(/Current CSC:\s*([A-Z0-9]{3})/i);
                            if (match) foundCsc = match[1].toUpperCase();
                        }
                    }

                    if (!foundCsc) {
                        const adbCsc = await window.api.runAdbCommand('shell getprop ro.csc.sales_code');
                        if (adbCsc && adbCsc.trim()) {
                            foundCsc = adbCsc.trim().toUpperCase();
                            logToModal(`> Active Sales Code via ADB: ${foundCsc}\n`);
                        }
                    }

                    if (foundCsc) {
                        if (badgeCurrentCsc) badgeCurrentCsc.textContent = foundCsc;
                        logToModal(`\n[SUCCESS] ตรวจพบ CSC ปัจจุบัน: [${foundCsc}]\n`, 'success');
                        finishModal(true);
                    } else {
                        logToModal('\n[NOTICE] ไม่สามารถอ่านค่า CSC ได้โดยตรง กรุณาเชื่อมต่อโหมด Test Mode (*#0*#) หรือเปิด ADB\n', 'warning');
                        finishModal(false, true, 'ไม่สามารถอ่านค่า CSC ได้ (กด *#0*# หรือเปิด ADB)');
                    }
                } catch (err) {
                    logToModal(`\n[ERROR] ${err.message || err}\n`, 'error');
                    finishModal(false, true, err.message || 'อ่านค่า CSC ไม่สำเร็จ');
                } finally {
                    btnReadCsc.disabled = false;
                    btnReadCsc.innerHTML = origHtml;
                }
            });
        }

        if (btnChangeCsc) {
            btnChangeCsc.addEventListener('click', async () => {
                let targetCsc = '';
                if (cscPresetSelect.value === 'CUSTOM') {
                    targetCsc = (cscCustomInput.value || '').trim().toUpperCase();
                } else {
                    targetCsc = cscPresetSelect.value.trim().toUpperCase();
                }

                if (!targetCsc || targetCsc.length < 3) {
                    alert('กรุณาระบุรหัส CSC ให้ถูกต้อง (เช่น THL, XXV, INS)');
                    return;
                }

                if (!confirm(`คุณต้องการเปลี่ยนรหัส CSC เป็น [${targetCsc}] และสั่งรีบูตเครื่อง ใช่หรือไม่?`)) {
                    return;
                }

                const port = gsmSamsungPortSelect ? gsmSamsungPortSelect.value : null;
                openModal(`Samsung CSC Changer: กำลังเปลี่ยนเป็น [${targetCsc}]`);
                logToModal('================================================\n', 'info');
                logToModal(`  Changing Samsung CSC to: ${targetCsc}\n`, 'success');
                logToModal('================================================\n', 'info');

                const origHtml = btnChangeCsc.innerHTML;
                btnChangeCsc.disabled = true;
                btnChangeCsc.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังเปลี่ยน...';

                try {
                    let success = false;
                    if (window.api && window.api.samsungCscChange) {
                        const res = await window.api.samsungCscChange(targetCsc, port);
                        if (res && res.output) {
                            logToModal(res.output + '\n');
                            if (res.output.includes('[SUCCESS]') || res.success) {
                                success = true;
                            }
                        }
                    }

                    if (!success) {
                        logToModal('> ส่งคำสั่งสลับ CSC ผ่าน ADB Broadcast...\n');
                        await window.api.runAdbCommand(`shell setprop persist.sys.csc ${targetCsc}`);
                        await window.api.runAdbCommand(`shell am broadcast -a android.provider.Telephony.SECRET_CODE -d android_secret_code://272*`);
                        await window.api.runAdbCommand('reboot');
                        success = true;
                    }

                    if (badgeCurrentCsc) badgeCurrentCsc.textContent = targetCsc;
                    logToModal(`\n[SUCCESS] 🎉 ทำการเปลี่ยน CSC เป็น [${targetCsc}] สำเร็จแล้ว!\n`, 'success');
                    logToModal('> เครื่องกำลังรีบูตเพื่อปรับใช้การตั้งค่าใหม่\n', 'info');
                    finishModal(true);
                } catch (err) {
                    logToModal(`\n[ERROR] เกิดข้อผิดพลาดในการเปลี่ยน CSC: ${err.message || err}\n`, 'error');
                    finishModal(false, true, err.message || 'เปลี่ยน CSC ไม่สำเร็จ');
                } finally {
                    btnChangeCsc.disabled = false;
                    btnChangeCsc.innerHTML = origHtml;
                }
            });
        }

        // --- Samsung CPU Mode Flasher Shortcuts (UnlockTool Style) ---
        const btnSamsungToMtk = document.getElementById('btn-samsung-to-mtk');
        if (btnSamsungToMtk) {
            btnSamsungToMtk.addEventListener('click', () => {
                const mtkTabBtn = document.querySelector('.tab-btn[data-target="tab-mtk"]');
                if (mtkTabBtn) mtkTabBtn.click();
                const btnMtkSamsung = document.getElementById('btn-mtk-browse-samsung');
                if (btnMtkSamsung) {
                    setTimeout(() => btnMtkSamsung.click(), 100);
                }
            });
        }

        const btnSamsungToQcom = document.getElementById('btn-samsung-to-qcom');
        if (btnSamsungToQcom) {
            btnSamsungToQcom.addEventListener('click', () => {
                const qcomTabBtn = document.querySelector('.tab-btn[data-target="tab-qcom"]');
                if (qcomTabBtn) qcomTabBtn.click();
                const btnQcomSamsung = document.getElementById('btn-qcom-browse-samsung');
                if (btnQcomSamsung) {
                    setTimeout(() => btnQcomSamsung.click(), 100);
                }
            });
        }

        const btnSamsungTpGuide = document.getElementById('btn-samsung-tp-guide');
        if (btnSamsungTpGuide) {
            btnSamsungTpGuide.addEventListener('click', () => {
                if (typeof openTestPointForModel === 'function') {
                    openTestPointForModel('samsung', 'samsung');
                } else {
                    const btnTpGallery = document.getElementById('btn-open-testpoint-gallery');
                    if (btnTpGallery) btnTpGallery.click();
                }
            });
        }

        // --- 5. Tool 4: Xiaomi Sideload Tool (MIAssistant) ---
        const txtXiaomiZipPath = document.getElementById('gsm-xiaomi-zip-path');
        const btnBrowseXiaomiZip = document.getElementById('btn-gsm-browse-xiaomi-zip');
        const btnXiaomiInfo = document.getElementById('btn-gsm-xiaomi-info');
        const btnXiaomiWipe = document.getElementById('btn-gsm-xiaomi-wipe');
        const btnXiaomiReboot = document.getElementById('btn-gsm-xiaomi-reboot');
        const btnXiaomiSideload = document.getElementById('btn-gsm-xiaomi-sideload');

        if (btnBrowseXiaomiZip && txtXiaomiZipPath) {
            btnBrowseXiaomiZip.addEventListener('click', async () => {
                if (window.api && window.api.showOpenDialog) {
                    const filePath = await window.api.showOpenDialog({
                        title: 'เลือกไฟล์ Xiaomi Recovery ROM (.zip)',
                        filters: [{ name: 'Recovery ROM (*.zip)', extensions: ['zip'] }]
                    });
                    if (filePath) {
                        txtXiaomiZipPath.value = filePath;
                    }
                }
            });
        }

        if (btnXiaomiInfo) {
            btnXiaomiInfo.addEventListener('click', async () => {
                openModal('Xiaomi Sideload: อ่านข้อมูลเครื่องผ่าน MIAssistant');
                logToModal('================================================\n', 'info');
                logToModal('  Xiaomi MIAssistant Recovery Diagnostics\n', 'success');
                logToModal('================================================\n', 'info');
                logToModal('> สแกนหาอุปกรณ์ Xiaomi ในโหมด Sideload...\n');

                const origHtml = btnXiaomiInfo.innerHTML;
                btnXiaomiInfo.disabled = true;
                btnXiaomiInfo.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังอ่าน...';

                try {
                    const devList = await window.api.runAdbCommand('devices -l');
                    logToModal(devList + '\n');

                    if (devList && devList.includes('sideload')) {
                        logToModal('\n[OK] ตรวจพบอุปกรณ์ Xiaomi ในโหมด MIAssistant Sideload พร้อมทำงาน!\n', 'success');
                        const prod = await window.api.runAdbCommand('shell getprop ro.product.name');
                        if (prod && !prod.includes('closed') && !prod.includes('error')) {
                            logToModal(`> Codename: ${prod.trim()}\n`, 'info');
                        }
                        finishModal(true);
                    } else if (devList && devList.includes('\tdevice')) {
                        logToModal('\n[INFO] อุปกรณ์เชื่อมต่อในโหมด ADB ปกติ\n', 'info');
                        const model = await window.api.runAdbCommand('shell getprop ro.product.model');
                        const ver = await window.api.runAdbCommand('shell getprop ro.build.version.incremental');
                        logToModal(`> รุ่นโทรศัพท์: ${model.trim()}\n`);
                        logToModal(`> เวอร์ชัน MIUI/HyperOS: ${ver.trim()}\n`);
                        logToModal('> 💡 หากต้องการเข้า MIAssistant: ให้สั่งรีบูตเข้า Recovery แล้วเลือก Connect with MIAssistant\n', 'warning');
                        finishModal(true);
                    } else {
                        logToModal('\n[NOTICE] ไม่พบอุปกรณ์ Xiaomi Sideload\n', 'warning');
                        logToModal('> คำแนะนำ: ปิดเครื่อง -> กด Vol (+) ค้าง + Power -> เข้า Mi Recovery -> เลือก "Connect with MIAssistant"\n', 'warning');
                        finishModal(false, true, 'ไม่พบอุปกรณ์ Xiaomi ในโหมด Sideload (เข้า Mi Recovery ก่อน)');
                    }
                } finally {
                    btnXiaomiInfo.disabled = false;
                    btnXiaomiInfo.innerHTML = origHtml;
                }
            });
        }

        if (btnXiaomiWipe) {
            btnXiaomiWipe.addEventListener('click', async () => {
                if (!confirm('⚠️ คำเตือน: การสั่ง Wipe Data จะล้างข้อมูลรูปภาพ, ข้อมูลส่วนตัว และการตั้งค่าทั้งหมดในเครื่อง\n\nคุณต้องการดำเนินการต่อหรือไม่?')) {
                    return;
                }
                openModal('Xiaomi Sideload: สั่งล้างข้อมูลเครื่อง (Wipe Data)');
                logToModal('> ส่งคำสั่ง Factory Reset ผ่าน Recovery Channel...\n');

                const out1 = await window.api.runAdbCommand('shell recovery --wipe_data');
                logToModal(`> Response: ${out1.trim() || 'Command dispatched'}\n`);

                const out2 = await window.api.runAdbCommand('shell twrp wipe data');
                if (out2 && !out2.includes('not found')) {
                    logToModal(`> TWRP Result: ${out2.trim()}\n`, 'success');
                }

                logToModal('\n[SUCCESS] ส่งสัญญาณล้างเครื่องสำเร็จ หากขึ้นหน้าต่างยืนยันบนจอมือถือ ให้ใช้ปุ่ม Vol/Power ยืนยัน\n', 'success');
                finishModal(true);
            });
        }

        if (btnXiaomiReboot) {
            btnXiaomiReboot.addEventListener('click', async () => {
                openModal('Xiaomi: สั่งรีบูตเข้าสู่ระบบปกติ');
                await window.api.runAdbCommand('reboot');
                logToModal('\n[OK] ส่งคำสั่งรีบูตเรียบร้อย\n', 'success');
                finishModal(true);
            });
        }

        if (btnXiaomiSideload) {
            btnXiaomiSideload.addEventListener('click', async () => {
                const zipPath = (txtXiaomiZipPath ? txtXiaomiZipPath.value : '').trim();
                if (!zipPath) {
                    alert('กรุณาเลือกไฟล์ Recovery ROM .zip ก่อนกดแฟลช');
                    return;
                }

                if (!confirm(`คุณต้องการแฟลชไฟล์ Recovery ROM:\n${zipPath}\n\nผ่านโหมด Xiaomi Sideload ใช่หรือไม่?`)) {
                    return;
                }

                openModal('Xiaomi Sideload: กำลังแฟลช Recovery ROM...');
                logToModal('================================================\n', 'info');
                logToModal(`  Xiaomi Sideload Flasher: ${zipPath}\n`, 'success');
                logToModal('================================================\n', 'info');

                const origHtml = btnXiaomiSideload.innerHTML;
                btnXiaomiSideload.disabled = true;
                btnXiaomiSideload.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังแฟลช Sideload...';

                try {
                    if (window.api && window.api.runAdbSideload) {
                        const res = await window.api.runAdbSideload(zipPath);
                        if (res && res.success) {
                            logToModal('\n[SUCCESS] 🎉 แฟลชรอม Sideload สำเร็จเรียบร้อย 100%!\n', 'success');
                            finishModal(true);
                        } else {
                            logToModal(`\n[FAIL] การแฟลชสิ้นสุดหรือผิดพลาด: ${res.error || res.output || ''}\n`, 'error');
                            finishModal(false, true, 'แฟลชรอมไม่สำเร็จ: ' + (res.error || ''));
                        }
                    } else {
                        logToModal('> กำลังส่งคำสั่ง sideload ผ่าน ADB...\n');
                        const out = await window.api.runAdbCommand(`sideload "${zipPath}"`);
                        logToModal(out + '\n');
                        finishModal(true);
                    }
                } catch (err) {
                    logToModal(`\n[ERROR] ${err.message || err}\n`, 'error');
                    finishModal(false, true, err.message || 'แฟลชไม่สำเร็จ');
                } finally {
                    btnXiaomiSideload.disabled = false;
                    btnXiaomiSideload.innerHTML = origHtml;
                }
            });
        }

        // --- 6. Tool 5: Battery Health & Hardware Diagnostic ---
        const btnReadBattery = document.getElementById('btn-gsm-read-battery');
        const btnCopyReport = document.getElementById('btn-gsm-copy-report');
        const diagHealth = document.getElementById('gsm-diag-health');
        const diagCycles = document.getElementById('gsm-diag-cycles');
        const diagTempVolt = document.getElementById('gsm-diag-temp-volt');
        const diagKnox = document.getElementById('gsm-diag-knox');

        let lastInspectionReport = '';

        if (btnReadBattery) {
            btnReadBattery.addEventListener('click', async () => {
                openModal('Hardware Diagnostic: ตรวจสุขภาพแบตเตอรี่ & ฮาร์ดแวร์');
                logToModal('================================================\n', 'info');
                logToModal('  Android Hardware Diagnostic & Battery Health Engine\n', 'success');
                logToModal('================================================\n', 'info');
                logToModal('> กำลังดึงข้อมูลสเปกเครื่องและข้อมูล Dumpsys ผ่าน ADB...\n');

                const origHtml = btnReadBattery.innerHTML;
                btnReadBattery.disabled = true;
                btnReadBattery.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังตรวจเช็ค...';

                try {
                    const checkDev = await window.api.runAdbCommand('devices');
                    if (!checkDev || !checkDev.includes('\tdevice')) {
                        logToModal('\n[ERROR] ไม่พบอุปกรณ์ในโหมด ADB! กรุณาเปิด USB Debugging ในตัวเครื่องก่อน\n', 'error');
                        finishModal(false, true, 'ไม่พบอุปกรณ์ ADB! กรุณาเปิด USB Debugging ในตัวเครื่องก่อน');
                        return;
                    }

                // 1. Device Info
                const model = (await window.api.runAdbCommand('shell getprop ro.product.model')).trim();
                const brand = (await window.api.runAdbCommand('shell getprop ro.product.brand')).trim();
                const mfg = (await window.api.runAdbCommand('shell getprop ro.product.manufacturer')).trim();
                const androidVer = (await window.api.runAdbCommand('shell getprop ro.build.version.release')).trim();
                const patchVer = (await window.api.runAdbCommand('shell getprop ro.build.version.security_patch')).trim();
                const serialNo = (await window.api.runAdbCommand('shell getprop ro.serialno')).trim();

                // 2. Knox Warranty Bit
                let knoxRaw = (await window.api.runAdbCommand('shell getprop ro.boot.warranty_bit')).trim();
                if (!knoxRaw || knoxRaw.includes('error')) {
                    const knoxAlt = await window.api.runAdbCommand('shell getprop ro.warranty_bit');
                    knoxRaw = knoxAlt.trim();
                }
                const isKnoxVoid = knoxRaw === '1';
                const knoxText = isKnoxVoid ? '0x1 (Void / หลุดประกัน รูทแล้ว)' : '0x0 (Official / แท้เดิมๆ)';

                // 3. Battery dumpsys
                const batteryDump = await window.api.runAdbCommand('shell dumpsys battery');
                let level = '--';
                let scale = '100';
                let temp = '--';
                let volt = '--';
                let healthStr = 'Good (สมบูรณ์)';

                if (batteryDump) {
                    const lMatch = batteryDump.match(/level:\s*(\d+)/i);
                    if (lMatch) level = lMatch[1];
                    const sMatch = batteryDump.match(/scale:\s*(\d+)/i);
                    if (sMatch) scale = sMatch[1];
                    const tMatch = batteryDump.match(/temperature:\s*(\d+)/i);
                    if (tMatch) temp = (parseInt(tMatch[1]) / 10).toFixed(1);
                    const vMatch = batteryDump.match(/voltage:\s*(\d+)/i);
                    if (vMatch) volt = vMatch[1];

                    const hMatch = batteryDump.match(/health:\s*(\d+)/i);
                    if (hMatch) {
                        const hVal = parseInt(hMatch[1]);
                        if (hVal === 2) healthStr = 'Good (สมบูรณ์)';
                        else if (hVal === 3) healthStr = 'Overheat (ร้อนจัด)';
                        else if (hVal === 4) healthStr = 'Dead (เสื่อมสภาพ)';
                        else if (hVal === 5) healthStr = 'Over Voltage (แรงดันเกิน)';
                        else healthStr = 'Normal (ปกติ)';
                    }
                }

                // 4. Cycle count
                let cycles = '--';
                const cycleDump = await window.api.runAdbCommand('shell cat /sys/class/power_supply/battery/cycle_count');
                if (cycleDump && !cycleDump.includes('No such') && !cycleDump.includes('error') && !isNaN(parseInt(cycleDump.trim()))) {
                    cycles = cycleDump.trim();
                } else {
                    const bmsCycle = await window.api.runAdbCommand('shell cat /sys/class/power_supply/bms/battery_cycle');
                    if (bmsCycle && !bmsCycle.includes('No such') && !bmsCycle.includes('error') && !isNaN(parseInt(bmsCycle.trim()))) {
                        cycles = bmsCycle.trim();
                    } else {
                        const samCycle = batteryDump.match(/mSavedBatteryUsage:\s*(\d+)/i);
                        if (samCycle) cycles = `${samCycle[1]} (Usage Index)`;
                    }
                }

                // Update UI badges
                if (diagHealth) diagHealth.textContent = `${healthStr} (${level}%)`;
                if (diagCycles) diagCycles.textContent = cycles !== '--' ? `${cycles} cycles` : 'N/A (ระบบป้องกัน)';
                if (diagTempVolt) diagTempVolt.textContent = `${temp}°C / ${volt}mV`;
                if (diagKnox) {
                    diagKnox.textContent = knoxText;
                    diagKnox.style.color = isKnoxVoid ? '#f87171' : '#4ade80';
                }

                // Build full report string
                lastInspectionReport = `================================================
📋 รายงานผลการตรวจเช็คเครื่อง & แบตเตอรี่ (GSM Diagnostic Report)
วันเวลาที่ตรวจเช็ค: ${new Date().toLocaleString('th-TH')}
------------------------------------------------
📱 ข้อมูลอุปกรณ์ (Device Profile):
  • แบรนด์ / ผู้ผลิต : ${brand || mfg || 'Unknown'}
  • ชื่อรุ่น (Model)  : ${model || 'Unknown'}
  • หมายเลขซีเรียล   : ${serialNo || 'Unknown'}
  • เวอร์ชัน Android : Android ${androidVer || 'N/A'}
  • Security Patch   : ${patchVer || 'N/A'}
  • สถานะ Knox Warranty: ${knoxText}

🔋 ข้อมูลสุขภาพแบตเตอรี่ (Battery Health Status):
  • สถานะความจุ     : ${level}% / ${scale}%
  • สุขภาพแบตเตอรี่ : ${healthStr}
  • รอบชาร์จ (Cycles) : ${cycles} รอบ
  • อุณหภูมิแบตเตอรี่ : ${temp} °C
  • แรงดันไฟฟ้า      : ${volt} mV
================================================`;

                logToModal(lastInspectionReport + '\n\n', 'info');
                logToModal('[SUCCESS] ตรวจเช็คข้อมูลฮาร์ดแวร์และแบตเตอรี่เรียบร้อย\n', 'success');
                finishModal(true);
            } finally {
                btnReadBattery.disabled = false;
                btnReadBattery.innerHTML = origHtml;
            }
            });
        }

        if (btnCopyReport) {
            btnCopyReport.addEventListener('click', () => {
                if (!lastInspectionReport) {
                    alert('กรุณากดปุ่ม [ตรวจเช็คเครื่องทันที] ก่อนคัดลอกรายงาน');
                    return;
                }
                navigator.clipboard.writeText(lastInspectionReport).then(() => {
                    const origHtml = btnCopyReport.innerHTML;
                    btnCopyReport.innerHTML = '<i class="fas fa-check" style="color: #4ade80;"></i> คัดลอกแล้ว!';
                    setTimeout(() => {
                        btnCopyReport.innerHTML = origHtml;
                    }, 2000);
                });
            });
        }

        // --- 7. Tool 6: Demo Mode Removal (Retail Unlock) ---
        const demoBrandSelect = document.getElementById('gsm-demo-brand-select');
        const btnDisableDemo = document.getElementById('btn-gsm-disable-demo');
        const btnDemoSettings = document.getElementById('btn-gsm-open-demo-settings');

        const demoPackagesByBrand = {
            samsung: [
                'com.samsung.livepick',
                'com.samsung.retailmode',
                'com.samsung.sdm',
                'com.samsung.android.retaildemo'
            ],
            oppo: [
                'com.oppo.retailmode',
                'com.coloros.retailmode',
                'com.oppo.market'
            ],
            vivo: [
                'com.vivo.livedemo',
                'com.bbk.livedemo',
                'com.vivo.retail'
            ],
            xiaomi: [
                'com.xiaomi.shop',
                'com.mi.livedemo',
                'com.miui.video'
            ],
            universal: []
        };

        if (btnDisableDemo) {
            btnDisableDemo.addEventListener('click', async () => {
                const brand = demoBrandSelect ? demoBrandSelect.value : 'samsung';
                openModal(`Demo Mode Removal: ปลดล็อคหน้าร้าน (${brand.toUpperCase()})`);
                logToModal('================================================\n', 'info');
                logToModal(`  Retail Demo Mode Disabler: ${brand.toUpperCase()}\n`, 'success');
                logToModal('================================================\n', 'info');
                logToModal('> กำลังตรวจสอบการเชื่อมต่อ ADB...\n');

                const origHtml = btnDisableDemo.innerHTML;
                btnDisableDemo.disabled = true;
                btnDisableDemo.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังปลดล็อค...';

                try {
                    const checkDev = await window.api.runAdbCommand('devices');
                    if (!checkDev || !checkDev.includes('\tdevice')) {
                        logToModal('\n[ERROR] ไม่พบอุปกรณ์ในโหมด ADB! กรุณาเปิด USB Debugging ในตัวเครื่องก่อน\n', 'error');
                        finishModal(false, true, 'ไม่พบอุปกรณ์ ADB! กรุณาเปิด USB Debugging ในตัวเครื่องก่อน');
                        return;
                    }

                    await window.api.runAdbCommand('shell am broadcast -a com.android.systemui.demo -e command exit');
                    await window.api.runAdbCommand('shell settings put global sysui_demo_allowed 0');
                    await window.api.runAdbCommand('shell settings put global retail_mode 0');
                    logToModal('> [✓] ส่ง Broadcast ปิด SystemUI Demo Mode สำเร็จ\n', 'success');

                    const pkgs = demoPackagesByBrand[brand] || [];
                    for (const pkg of pkgs) {
                        await window.api.runAdbCommand(`shell pm clear ${pkg}`);
                        const out = await window.api.runAdbCommand(`shell pm disable-user --user 0 ${pkg}`);
                        if (out && (out.includes('disabled') || out.includes('new state'))) {
                            logToModal(`> [✓] ล้างแคช & ปิดกั้นสำเร็จ: ${pkg}\n`, 'success');
                        } else {
                            await window.api.runAdbCommand(`shell pm disable ${pkg}`);
                            logToModal(`> [-] ส่งคำสั่งปิด: ${pkg}\n`);
                        }
                    }

                    await window.api.runAdbCommand('shell input keyevent 3');

                    logToModal('\n[SUCCESS] 🎉 ปลดล็อคโหมดหน้าร้าน (Demo Mode) สำเร็จ 100%!\n', 'success');
                    logToModal('> โทรศัพท์กลับสู่การทำงานปกติ ไม่ติดสกรีนเซฟเวอร์โฆษณาหน้าร้านอีกต่อไป\n', 'info');
                    finishModal(true);
                } finally {
                    btnDisableDemo.disabled = false;
                    btnDisableDemo.innerHTML = origHtml;
                }
            });
        }

        if (btnDemoSettings) {
            btnDemoSettings.addEventListener('click', async () => {
                openModal('Device Admin Settings: กำลังเปิดหน้าตั้งค่าบนมือถือ...');
                logToModal('> กำลังเปิดหน้าต่างตั้งค่า Security & Device Admin บนโทรศัพท์...\n');
                await window.api.runAdbCommand('shell am start -a android.settings.SECURITY_SETTINGS');
                logToModal('> กรุณาดูหน้าจอมือถือ: หากมีแอป Retail Demo ในหัวข้อ "ผู้ดูแลอุปกรณ์ (Device Admin)" ให้แตะกดยกเลิกสิทธิ์\n', 'warning');
                finishModal(true);
            });
        }

        // --- 8. Tool 7: Deep MDM & Installment Lock Audit (เช็คเครื่องติดล็อครายเดือน DMD) ---
        const btnAuditMdm = document.getElementById('btn-gsm-audit-mdm');
        const btnCopyMdmReport = document.getElementById('btn-gsm-copy-mdm-report');
        const btnOpenDeviceAdmin = document.getElementById('btn-gsm-open-device-admin');
        const btnOpenMdmGuide = document.getElementById('btn-gsm-open-mdm-guide');
        const btnCloseMdmGuide = document.getElementById('btn-close-mdm-guide');
        const btnCloseMdmGuideFooter = document.getElementById('btn-close-mdm-guide-footer');
        const modalMdmGuide = document.getElementById('modal-mdm-guide');

        const riskBadge = document.getElementById('gsm-mdm-risk-badge');
        const lblKgState = document.getElementById('gsm-mdm-kg-state');
        const lblDoState = document.getElementById('gsm-mdm-do-state');
        const lblFinanceApps = document.getElementById('gsm-mdm-finance-apps');
        const lblCarrierCsc = document.getElementById('gsm-mdm-carrier-csc');
        const lblOemState = document.getElementById('gsm-mdm-oem-state');
        const findingsBox = document.getElementById('gsm-mdm-findings-box');
        const findingsList = document.getElementById('gsm-mdm-findings-list');

        let lastMdmInspectionReport = '';

        // Modal event handlers
        if (btnOpenMdmGuide && modalMdmGuide) {
            btnOpenMdmGuide.addEventListener('click', () => {
                openAppModal(modalMdmGuide);
            });
        }
        if (btnCloseMdmGuide && modalMdmGuide) {
            btnCloseMdmGuide.addEventListener('click', () => {
                closeAppModal(modalMdmGuide);
            });
        }
        if (btnCloseMdmGuideFooter && modalMdmGuide) {
            btnCloseMdmGuideFooter.addEventListener('click', () => {
                closeAppModal(modalMdmGuide);
            });
        }
        if (modalMdmGuide) {
            modalMdmGuide.addEventListener('click', (e) => {
                if (e.target === modalMdmGuide) closeAppModal(modalMdmGuide);
            });
        }

        if (btnOpenDeviceAdmin) {
            btnOpenDeviceAdmin.addEventListener('click', async () => {
                openModal('Device Admin: กำลังเปิดหน้าตั้งค่าบนโทรศัพท์...');
                logToModal('> ส่งคำสั่งเปิดหน้าความปลอดภัยและผู้ดูแลระบบ (Device Admin Settings)...\n');
                await window.api.runAdbCommand('shell am start -a android.settings.SECURITY_SETTINGS');
                logToModal('> [INFO] กรุณาดูหน้าจอมือถือ: หัวข้อ "แอปผู้ดูแลอุปกรณ์" หากมีแอปแปลกปลอม/PayJoy/Knox ที่ไม่สามารถปิดได้ = ติดล็อครายเดือน\n', 'warning');
                finishModal(true);
            });
        }

        // Comprehensive known installment, leasing, and MDM package database
        const knownMdmDatabase = [
            // PayJoy Family
            { pkg: 'com.payjoy.status.df', name: 'PayJoy Device Status / Security Agent', type: 'PAYJOY_LEASING', danger: 'CRITICAL' },
            { pkg: 'com.payjoy.bridge', name: 'PayJoy Background Bridge Service', type: 'PAYJOY_LEASING', danger: 'CRITICAL' },
            { pkg: 'com.onlinepay.easypayjoy', name: 'Easy PayJoy Client', type: 'PAYJOY_LEASING', danger: 'CRITICAL' },
            { pkg: 'com.payjoy.access', name: 'PayJoy Access Manager', type: 'PAYJOY_LEASING', danger: 'CRITICAL' },

            // Samsung Knox Guard & Enterprise Management
            { pkg: 'com.samsung.android.kgclient', name: 'Samsung Knox Guard (KG) Client (ระบบล็อคเครื่องติดสัญญา)', type: 'KNOX_GUARD', danger: 'CRITICAL' },
            { pkg: 'com.samsung.finance', name: 'Samsung Finance+ Service Framework', type: 'SAMSUNG_FINANCE', danger: 'CRITICAL' },
            { pkg: 'com.sec.enterprise.knox.cloudmdm.smdms', name: 'Knox Mobile Enrollment (Cloud MDM / KME)', type: 'KNOX_MDM', danger: 'HIGH' },
            { pkg: 'com.sec.knox.kccagent', name: 'Knox Configure / Customization Agent (KCC)', type: 'KNOX_CONFIG', danger: 'HIGH' },
            { pkg: 'com.samsung.sdm', name: 'Samsung Device Management Agent (ผูกสัญญาค่าย)', type: 'CARRIER_SDM', danger: 'MEDIUM' },
            { pkg: 'com.samsung.klmsagent', name: 'Samsung Knox License Management Service (KLMS)', type: 'KNOX_LICENSE', danger: 'MEDIUM' },
            { pkg: 'com.wssyncmldm', name: 'Carrier Device Management / FOTA Update Agent', type: 'CARRIER_DM', danger: 'MEDIUM' },

            // Southeast Asia / Thai Device Leasing & Financing
            { pkg: 'com.youtap', name: 'Youtap Device Financing Service', type: 'FINANCE_LEASING', danger: 'CRITICAL' },
            { pkg: 'com.advance.ai', name: 'Advance AI Device Lock Service', type: 'FINANCE_LEASING', danger: 'CRITICAL' },
            { pkg: 'com.finanztone', name: 'Finanztone Device Control Manager', type: 'FINANCE_LEASING', danger: 'CRITICAL' },
            { pkg: 'com.credex', name: 'Credex Financing Lock Application', type: 'FINANCE_LEASING', danger: 'CRITICAL' },

            // Global Enterprise MDM Systems
            { pkg: 'com.airwatch.androidagent', name: 'VMware Workspace ONE (AirWatch MDM)', type: 'ENTERPRISE_MDM', danger: 'CRITICAL' },
            { pkg: 'com.microsoft.windowsintune.companyportal', name: 'Microsoft Intune Company Portal (Intune MDM)', type: 'ENTERPRISE_MDM', danger: 'CRITICAL' },
            { pkg: 'net.soti.mobicontrol.androidwork', name: 'SOTI MobiControl Enterprise Agent', type: 'ENTERPRISE_MDM', danger: 'CRITICAL' },
            { pkg: 'com.manageengine.mdm.android', name: 'ManageEngine Mobile Device Manager Plus', type: 'ENTERPRISE_MDM', danger: 'CRITICAL' },
            { pkg: 'com.miradore.client.v2', name: 'Miradore Online MDM Client', type: 'ENTERPRISE_MDM', danger: 'CRITICAL' },
            { pkg: 'com.mobileiron', name: 'MobileIron Core / Cloud MDM Client', type: 'ENTERPRISE_MDM', danger: 'CRITICAL' },
            { pkg: 'com.google.android.apps.enterprise.dmagent', name: 'Google Android Device Policy (Work Profile/MDM)', type: 'ENTERPRISE_MDM', danger: 'HIGH' }
        ];

        if (btnAuditMdm) {
            btnAuditMdm.addEventListener('click', async () => {
                openModal('MDM & Installment Lock Audit: ตรวจสอบเครื่องติดสัญญาผ่อน');
                logToModal('================================================\n', 'info');
                logToModal('  📱 GSM Professional MDM & Contract Lock Auditor\n', 'success');
                logToModal('  Target: Knox Guard (KG), Device Owner, PayJoy & Finance+\n', 'info');
                logToModal('================================================\n', 'info');
                logToModal('> ขั้นตอนที่ 1: ตรวจสอบการเชื่อมต่อ ADB...\n');

                const origHtml = btnAuditMdm.innerHTML;
                btnAuditMdm.disabled = true;
                btnAuditMdm.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังตรวจเช็ค...';

                try {
                    const checkDev = await window.api.runAdbCommand('devices');
                    if (!checkDev || !checkDev.includes('\tdevice')) {
                        logToModal('\n[ERROR] ไม่พบอุปกรณ์ในโหมด ADB! กรุณาเปิด USB Debugging ในตัวเครื่องก่อน\n', 'error');
                        logToModal('> 💡 วิธีเปิด: ไปที่ ตั้งค่า > เกี่ยวกับโทรศัพท์ > กด หมายเลขบิลด์ 7 ครั้ง > กลับไปที่ ทางเลือกผู้พัฒนา > เปิด USB Debugging\n', 'warning');
                        finishModal(false, true, 'ไม่พบอุปกรณ์ ADB! กรุณาเสียบสาย USB และเปิด USB Debugging');
                        return;
                    }

                // Initialise Audit Results
                const findings = [];
                let riskScore = 0; // 0 = Safe, 1-3 = Warning/Carrier, >= 4 = Locked/Critical
                let isCriticalLock = false;

                // --- 1. Basic Device Info ---
                const brand = (await window.api.runAdbCommand('shell getprop ro.product.brand')).trim();
                const model = (await window.api.runAdbCommand('shell getprop ro.product.model')).trim();
                const mfg = (await window.api.runAdbCommand('shell getprop ro.product.manufacturer')).trim();
                const androidVer = (await window.api.runAdbCommand('shell getprop ro.build.version.release')).trim();
                const serialNo = (await window.api.runAdbCommand('shell getprop ro.serialno')).trim();
                logToModal(`> อุปกรณ์: ${brand || mfg} ${model} (Android ${androidVer}) | S/N: ${serialNo}\n`, 'info');

                // --- 2. Check Device Owner & Profile Owner (DPM) ---
                logToModal('\n> ขั้นตอนที่ 2: ตรวจสอบสิทธิ์ผู้ดูแลระบบสูงสุด (Device Owner / DPM)...\n');
                let deviceOwnerText = 'ไม่พบ (None)';
                let hasDeviceOwner = false;

                const dpmOwners = await window.api.runAdbCommand('shell dpm list-owners');
                const dumpsysDpm = await window.api.runAdbCommand('shell dumpsys device_policy');

                if (dpmOwners && (dpmOwners.includes('admin=') || dpmOwners.includes('Device Owner:'))) {
                    hasDeviceOwner = true;
                    isCriticalLock = true;
                    riskScore += 5;
                    deviceOwnerText = 'ตรวจพบ! (DETECTED)';
                    findings.push(`[CRITICAL] ตรวจพบสิทธิ์ Device Owner ควบคุมเครื่อง: ${dpmOwners.trim()}`);
                    logToModal(`  [CRITICAL] 🚨 ตรวจพบแอปถือสิทธิ์ Device Owner: ${dpmOwners.trim()}\n`, 'error');
                } else if (dumpsysDpm && dumpsysDpm.includes('Device Owner:')) {
                    const doMatch = dumpsysDpm.match(/Device Owner:\s*admin=ComponentInfo\{([^}]+)\}/i);
                    if (doMatch) {
                        hasDeviceOwner = true;
                        isCriticalLock = true;
                        riskScore += 5;
                        deviceOwnerText = doMatch[1];
                        findings.push(`[CRITICAL] ตรวจพบ Device Owner: ${doMatch[1]}`);
                        logToModal(`  [CRITICAL] 🚨 ตรวจพบ Device Owner: ${doMatch[1]}\n`, 'error');
                    } else {
                        logToModal('  [✓] ไม่พบ Device Owner (ระบบไม่มีแอป MDM ระดับสูงสุดถือสิทธิ์)\n', 'success');
                    }
                } else {
                    logToModal('  [✓] ไม่พบ Device Owner (ระบบไม่มีแอป MDM ระดับสูงสุดถือสิทธิ์)\n', 'success');
                }

                // --- 3. Check Knox Guard (KG Status) & RMM (Samsung Specific) ---
                logToModal('\n> ขั้นตอนที่ 3: ตรวจสอบสถานะ Knox Guard (KG Status) & RMM...\n');
                let kgStatusVal = '';
                let rmmStatusVal = '';

                let kgProp = (await window.api.runAdbCommand('shell getprop ro.boot.kg.status')).trim().toUpperCase();
                if (!kgProp || kgProp.includes('ERROR') || kgProp === '') {
                    kgProp = (await window.api.runAdbCommand('shell getprop ro.boot.kg')).trim().toUpperCase();
                }
                const rmmProp = (await window.api.runAdbCommand('shell getprop ro.boot.rmm.status')).trim().toUpperCase();
                const carrierId = (await window.api.runAdbCommand('shell getprop ro.boot.carrierid')).trim().toUpperCase();

                if (kgProp && !kgProp.includes('NOT FOUND')) kgStatusVal = kgProp;
                if (rmmProp && !rmmProp.includes('NOT FOUND')) rmmStatusVal = rmmProp;

                let kgDisplay = kgStatusVal || (rmmStatusVal ? `RMM: ${rmmStatusVal}` : 'N/A (ไม่ใช่ Samsung / ไม่พบ)');
                let kgDescTh = '';

                if (kgStatusVal === 'LOCKED' || rmmStatusVal === 'LOCKED') {
                    isCriticalLock = true;
                    riskScore += 6;
                    kgDescTh = '🚨 เครื่องถูกล็อคค้างค่างวด (LOCKED)';
                    findings.push(`[CRITICAL] Knox Guard Status เป็น LOCKED: เครื่องถูกสั่งล็อคเนื่องจากค้างค่างวดผ่อนชำระ`);
                    logToModal(`  [CRITICAL] 🚨 Knox Guard Status: LOCKED (เครื่องติดล็อคค้างค่างวด!)\n`, 'error');
                } else if (kgStatusVal === 'ACTIVE' || rmmStatusVal === 'ACTIVE') {
                    isCriticalLock = true;
                    riskScore += 5;
                    kgDescTh = '⚠️ เครื่องติดสัญญาผ่อนอยู่กับระบบ (ACTIVE)';
                    findings.push(`[CRITICAL] Knox Guard Status เป็น ACTIVE: เครื่องอยู่ในสัญญาผ่อนชำระ หากขาดส่งจะถูกล็อคทันที`);
                    logToModal(`  [WARNING] ⚠️ Knox Guard Status: ACTIVE (เครื่องติดสัญญาผ่อน Knox Guard!)\n`, 'error');
                } else if (kgStatusVal === 'CHECKING' || rmmStatusVal === 'CHECKING') {
                    riskScore += 2;
                    kgDescTh = '🟡 กำลังตรวจสอบเซิร์ฟเวอร์ (CHECKING)';
                    findings.push(`[NOTICE] Knox Guard Status เป็น CHECKING: เครื่องกำลังตรวจสอบสถานะกับเซิร์ฟเวอร์`);
                    logToModal(`  [NOTICE] 🟡 Knox Guard Status: CHECKING\n`, 'warning');
                } else if (kgStatusVal === 'COMPLETED' || rmmStatusVal === 'COMPLETED') {
                    kgDescTh = '✅ หมดสัญญาผ่อนแล้ว ปลอดภัย (COMPLETED)';
                    logToModal(`  [OK] ✅ Knox Guard Status: COMPLETED (หมดสัญญาผ่อนชำระแล้ว ปลอดภัย)\n`, 'success');
                } else if (kgStatusVal === 'PRENORMAL' || rmmStatusVal === 'PRENORMAL') {
                    riskScore += 2;
                    kgDescTh = '⏳ รอการยืนยันสถานะ (PRENORMAL)';
                    findings.push(`[NOTICE] Knox Guard Status เป็น PRENORMAL: รอเชื่อมต่อเน็ตครบกำหนดเพื่อปลดล็อค OEM`);
                    logToModal(`  [NOTICE] ⏳ Knox Guard Status: PRENORMAL\n`, 'warning');
                } else {
                    kgDescTh = 'ปกติ / ไม่พบการผูก Knox Guard';
                    logToModal(`  [OK] ไม่พบข้อจำกัด Knox Guard ในตัวเครื่อง\n`, 'success');
                }

                // --- 4. Scan Known Installment & Finance Package Database ---
                logToModal('\n> ขั้นตอนที่ 4: สแกนฐานข้อมูลแอปสินเชื่อ / ไฟแนนซ์ / PayJoy (20+ แพ็กเกจ)...\n');
                const installedPkgsRaw = await window.api.runAdbCommand('shell pm list packages');
                const installedPkgs = installedPkgsRaw ? installedPkgsRaw.split(/\r?\n/).map(l => l.replace(/^package:/i, '').trim()).filter(Boolean) : [];

                const detectedFinanceApps = [];
                for (const item of knownMdmDatabase) {
                    if (installedPkgs.includes(item.pkg)) {
                        detectedFinanceApps.push(item);
                        findings.push(`[${item.danger}] พบแอปสินเชื่อ/ควบคุมเครื่อง: ${item.name} (${item.pkg})`);
                        if (item.danger === 'CRITICAL') {
                            isCriticalLock = true;
                            riskScore += 4;
                            logToModal(`  [CRITICAL] 🚨 พบแอป: ${item.name} (${item.pkg})\n`, 'error');
                        } else if (item.danger === 'HIGH') {
                            riskScore += 3;
                            logToModal(`  [HIGH] ⚠️ พบแอป: ${item.name} (${item.pkg})\n`, 'error');
                        } else {
                            riskScore += 1;
                            logToModal(`  [MEDIUM] ℹ️ พบแพ็กเกจ: ${item.name} (${item.pkg})\n`, 'warning');
                        }
                    }
                }

                if (detectedFinanceApps.length === 0) {
                    logToModal('  [✓] ไม่พบแอปสินเชื่อผ่อนเครื่องหรือ PayJoy ในระบบ (CLEAN)\n', 'success');
                }

                // --- 5. Check Carrier CSC & SIM Lock ---
                logToModal('\n> ขั้นตอนที่ 5: ตรวจสอบรหัสค่าย Sales Code (CSC) & สถานะ SIM...\n');
                let salesCode = (await window.api.runAdbCommand('shell getprop ro.csc.sales_code')).trim().toUpperCase();
                if (!salesCode) salesCode = (await window.api.runAdbCommand('shell getprop ro.boot.sales_code')).trim().toUpperCase();
                const simState = (await window.api.runAdbCommand('shell getprop gsm.sim.state')).trim();

                let carrierLabel = salesCode || 'UNKNOWN';
                let isCarrierBound = false;

                if (salesCode === 'TMH' || salesCode === 'TRU') {
                    carrierLabel = `${salesCode} (TrueMove H / ติดสัญญาค่าย)`;
                    isCarrierBound = true;
                    riskScore += 2;
                    findings.push(`[CARRIER] รหัส CSC เป็นเครื่องค่าย TrueMove H (${salesCode}) อาจมีสัญญาผูกเครื่อง`);
                    logToModal(`  [NOTICE] ⚠️ ตรวจพบเครื่องค่าย TrueMove H (CSC: ${salesCode})\n`, 'warning');
                } else if (salesCode === 'AIS') {
                    carrierLabel = `${salesCode} (AIS / ติดสัญญาค่าย)`;
                    isCarrierBound = true;
                    riskScore += 2;
                    findings.push(`[CARRIER] รหัส CSC เป็นเครื่องค่าย AIS (${salesCode}) อาจมีสัญญาผูกเครื่อง`);
                    logToModal(`  [NOTICE] ⚠️ ตรวจพบเครื่องค่าย AIS (CSC: ${salesCode})\n`, 'warning');
                } else if (salesCode === 'DTL') {
                    carrierLabel = `${salesCode} (Dtac / ติดสัญญาค่าย)`;
                    isCarrierBound = true;
                    riskScore += 2;
                    findings.push(`[CARRIER] รหัส CSC เป็นเครื่องค่าย Dtac (${salesCode}) อาจมีสัญญาผูกเครื่อง`);
                    logToModal(`  [NOTICE] ⚠️ ตรวจพบเครื่องค่าย Dtac (CSC: ${salesCode})\n`, 'warning');
                } else if (salesCode === 'THL') {
                    carrierLabel = `${salesCode} (Thailand Open Market / เครื่องเปล่า)`;
                    logToModal(`  [OK] ✅ CSC: THL (เครื่องไทยแท้ ไม่ผูกค่าย)\n`, 'success');
                } else {
                    logToModal(`  [INFO] CSC: ${salesCode || 'N/A'} (SIM State: ${simState || 'N/A'})\n`, 'info');
                }

                // --- 6. Check OEM Unlock & Tamper Security Flags ---
                logToModal('\n> ขั้นตอนที่ 6: ตรวจสอบสิทธิ์การปลดล็อค OEM & ความปลอดภัย Bootloader...\n');
                const oemAllowed = (await window.api.runAdbCommand('shell getprop sys.oem_unlock_allowed')).trim();
                const oemSupported = (await window.api.runAdbCommand('shell getprop ro.oem_unlock_supported')).trim();
                const warrantyBit = (await window.api.runAdbCommand('shell getprop ro.boot.warranty_bit')).trim();

                let oemStatusLabel = 'ปกติ';
                if (oemAllowed === '0') {
                    oemStatusLabel = 'ถูกบล็อก (Disabled / 0)';
                    riskScore += 1;
                    findings.push(`[NOTICE] สิทธิ์ปลดล็อค OEM ถูกปิดกั้น (sys.oem_unlock_allowed = 0) อาจเกิดจาก Knox Guard หรือนโยบายเครื่องผ่อน`);
                    logToModal(`  [NOTICE] ⚠️ สิทธิ์ OEM Unlock ถูกปิดกั้นในระบบ (sys.oem_unlock_allowed = 0)\n`, 'warning');
                } else if (oemAllowed === '1') {
                    oemStatusLabel = 'เปิดอนุญาต (Allowed / 1)';
                    logToModal(`  [OK] สิทธิ์ OEM Unlock เปิดอนุญาต (Allowed)\n`, 'success');
                } else {
                    oemStatusLabel = oemSupported === '1' ? 'Supported' : 'N/A';
                }

                // --- 7. Overall Risk Assessment Calculation ---
                let finalVerdict = '';

                if (isCriticalLock || riskScore >= 4) {
                    finalVerdict = '🔴 ติดล็อครายเดือน / MDM (ACTIVE LOCK)';
                    if (riskBadge) {
                        riskBadge.textContent = '🔴 ติดล็อครายเดือน (ACTIVE MDM)';
                        riskBadge.style.background = 'rgba(239, 68, 68, 0.25)';
                        riskBadge.style.color = '#f87171';
                        riskBadge.style.borderColor = '#ef4444';
                    }
                } else if (riskScore >= 2 || isCarrierBound) {
                    finalVerdict = '🟡 มีความเสี่ยง / ติดสัญญาค่าย (CARRIER WARNING)';
                    if (riskBadge) {
                        riskBadge.textContent = '🟡 มีความเสี่ยง (WARNING / CONTRACT)';
                        riskBadge.style.background = 'rgba(245, 158, 11, 0.25)';
                        riskBadge.style.color = '#fbbf24';
                        riskBadge.style.borderColor = '#f59e0b';
                    }
                } else {
                    finalVerdict = '🟢 ปลอดภัย / เครื่องเปล่าไม่ติดสัญญา (CLEAN & SAFE)';
                    if (riskBadge) {
                        riskBadge.textContent = '🟢 ปลอดภัย (CLEAN / UNLOCKED)';
                        riskBadge.style.background = 'rgba(34, 197, 94, 0.25)';
                        riskBadge.style.color = '#4ade80';
                        riskBadge.style.borderColor = '#22c55e';
                    }
                }

                // Update UI Metric Cards
                if (lblKgState) {
                    lblKgState.textContent = kgStatusVal || (rmmStatusVal ? `RMM:${rmmStatusVal}` : (brand.toLowerCase().includes('samsung') ? 'None' : 'N/A'));
                    lblKgState.style.color = (kgStatusVal === 'LOCKED' || kgStatusVal === 'ACTIVE') ? '#ef4444' : (kgStatusVal === 'COMPLETED' ? '#4ade80' : '#f8fafc');
                }
                if (lblDoState) {
                    lblDoState.textContent = hasDeviceOwner ? '🚨 ตรวจพบ MDM' : 'ปลอดภัย (None)';
                    lblDoState.style.color = hasDeviceOwner ? '#ef4444' : '#4ade80';
                }
                if (lblFinanceApps) {
                    lblFinanceApps.textContent = detectedFinanceApps.length > 0 ? `⚠️ พบ ${detectedFinanceApps.length} แอป` : 'ไม่พบ (0)';
                    lblFinanceApps.style.color = detectedFinanceApps.length > 0 ? '#ef4444' : '#4ade80';
                }
                if (lblCarrierCsc) {
                    lblCarrierCsc.textContent = salesCode || 'THL';
                    lblCarrierCsc.style.color = isCarrierBound ? '#fbbf24' : '#4ade80';
                }
                if (lblOemState) {
                    lblOemState.textContent = oemStatusLabel;
                    lblOemState.style.color = oemAllowed === '0' ? '#fbbf24' : '#4ade80';
                }

                // Show findings box if any warning or critical findings
                if (findingsBox && findingsList) {
                    findingsBox.style.display = 'block';
                    if (findings.length > 0) {
                        findingsList.innerHTML = findings.map(f => `<div style="margin-bottom: 4px;">• ${f}</div>`).join('');
                    } else {
                        findingsList.innerHTML = '<div style="color: #4ade80;">• ไม่พบแพ็กเกจสินเชื่อ, ไม่พบสิทธิ์ Device Owner และไม่พบการผูกสัญญา Knox Guard</div>';
                    }
                }

                // Build Comprehensive Audit Report String
                lastMdmInspectionReport = `================================================
📋 รายงานผลการตรวจสอบเครื่องติดล็อครายเดือน / MDM / Knox Guard
วันเวลาที่ตรวจสอบ: ${new Date().toLocaleString('th-TH')}
------------------------------------------------
📱 ข้อมูลโทรศัพท์:
  • แบรนด์ / รุ่น   : ${brand || mfg} ${model}
  • หมายเลขซีเรียล : ${serialNo || 'Unknown'}
  • เวอร์ชัน Android : Android ${androidVer || 'N/A'}
  • Sales Code (CSC): ${carrierLabel}
  • Knox Warranty  : ${warrantyBit === '1' ? '0x1 (Void / รูทแล้ว)' : '0x0 (Official / เดิมๆ)'}

🛡️ ผลการวิเคราะห์ระบบความปลอดภัย & สัญญาผ่อนชำระ:
  • สรุปผลการประเมิน: ${finalVerdict}
  • Knox Guard (KG)  : ${kgDisplay} ${kgDescTh ? '(' + kgDescTh + ')' : ''}
  • Device Owner (MDM): ${hasDeviceOwner ? '🚨 ตรวจพบ! (' + deviceOwnerText + ')' : '✅ ปลอดภัย (ไม่พบ)'}
  • สิทธิ์ OEM Unlock : ${oemStatusLabel}
  • แอปสินเชื่อที่พบ   : ${detectedFinanceApps.length > 0 ? detectedFinanceApps.map(a => a.name).join(', ') : 'ไม่พบ'}

📝 รายการตรวจพบละเอียด:
${findings.length > 0 ? findings.map(f => '  ' + f).join('\n') : '  [✓] ผ่านการตรวจสอบทุกหัวข้อ ไม่พบความเสี่ยงการติดล็อครายเดือน'}
================================================`;

                logToModal('\n' + lastMdmInspectionReport + '\n', 'info');
                logToModal(`\n[RESULT] การตรวจสอบเสร็จสมบูรณ์: ${finalVerdict}\n`, riskScore >= 4 ? 'error' : (riskScore >= 2 ? 'warning' : 'success'));
                finishModal(true);
            } finally {
                btnAuditMdm.disabled = false;
                btnAuditMdm.innerHTML = origHtml;
            }
            });
        }

        if (btnCopyMdmReport) {
            btnCopyMdmReport.addEventListener('click', () => {
                if (!lastMdmInspectionReport) {
                    alert('กรุณากดปุ่ม [เริ่มตรวจสอบเครื่องติดล็อครายเดือน] ก่อนคัดลอกรายงาน');
                    return;
                }
                navigator.clipboard.writeText(lastMdmInspectionReport).then(() => {
                    const origHtml = btnCopyMdmReport.innerHTML;
                    btnCopyMdmReport.innerHTML = '<i class="fas fa-check" style="color: #4ade80;"></i> คัดลอกแล้ว!';
                    setTimeout(() => {
                        btnCopyMdmReport.innerHTML = origHtml;
                    }, 2000);
                });
            });
        }

        // =========================================================================
        // MODULE 1: FLASHING DRIVER CENTER & USB DOCTOR
        // =========================================================================
        const btnTabDrvRescan = document.getElementById('btn-tab-drv-rescan');
        const btnTabDrvFixUsb = document.getElementById('btn-tab-drv-fix-usb');
        const btnTabDrvDevmgmt = document.getElementById('btn-tab-drv-devmgmt');
        const btnTabDrvTestmode = document.getElementById('btn-tab-drv-testmode');
        const tabDrvTestmodeBadge = document.getElementById('tab-drv-testmode-badge');
        const tabDrvLiveBanner = document.getElementById('tab-drv-live-banner');
        const tabDrvLiveText = document.getElementById('tab-drv-live-text');
        const tabDrvLivePort = document.getElementById('tab-drv-live-port');
        const tabDrvCardsGrid = document.getElementById('tab-drv-cards-grid');

        let isDriverTestModeActive = false;

        async function refreshDriverTab() {
            if (!tabDrvCardsGrid) return;
            tabDrvCardsGrid.innerHTML = '<div style="text-align:center; color:#38bdf8; padding:30px; grid-column: 1/-1;"><i class="fas fa-spinner fa-spin"></i> กำลังตรวจเช็คไดรเวอร์ทุกชิปเซ็ตในระบบ Windows...</div>';

            try {
                const res = await window.api.scanDriverDoctor();
                if (res && res.success && res.drivers) {
                    tabDrvCardsGrid.innerHTML = '';
                    isDriverTestModeActive = !!res.testMode;

                    if (tabDrvTestmodeBadge) {
                        if (res.testMode) {
                            tabDrvTestmodeBadge.innerHTML = '🛡️ เปิดอยู่ (รองรับ Unsigned Drivers)';
                            tabDrvTestmodeBadge.style.color = '#4ade80';
                            tabDrvTestmodeBadge.style.borderColor = 'rgba(74, 222, 128, 0.4)';
                            tabDrvTestmodeBadge.style.background = 'rgba(74, 222, 128, 0.15)';
                        } else {
                            tabDrvTestmodeBadge.innerHTML = '⚠ ปิดอยู่ (ไดรเวอร์บางตัวอาจติด Code 52)';
                            tabDrvTestmodeBadge.style.color = '#fbbf24';
                            tabDrvTestmodeBadge.style.borderColor = 'rgba(251, 191, 36, 0.4)';
                            tabDrvTestmodeBadge.style.background = 'rgba(251, 191, 36, 0.15)';
                        }
                    }

                    if (tabDrvLiveBanner) {
                        if (res.liveDevices && res.liveDevices.length > 0) {
                            const topDev = res.liveDevices[0];
                            tabDrvLiveBanner.style.display = 'flex';
                            if (tabDrvLiveText) {
                                tabDrvLiveText.innerHTML = `🟢 กำลังเชื่อมต่อสด: <b>${topDev.name}</b> บนพอร์ต <span style="color:#f8fafc; font-family:monospace; background:rgba(0,0,0,0.3); padding:2px 6px; border-radius:4px;">${topDev.port}</span>`;
                            }
                            if (tabDrvLivePort) {
                                tabDrvLivePort.textContent = topDev.port;
                            }
                        } else {
                            tabDrvLiveBanner.style.display = 'none';
                        }
                    }

                    const DRIVER_DESCS = {
                        unisoc: { title: 'Spreadtrum / Unisoc SPRD U2S', desc: 'ไดรเวอร์โหมด BSL Flasher และ Diag Port สำหรับ SC7702, SC7731, SC9832E, T606/T612', link: 'https://spreadtrum-drivers.en.lo4d.com/', color: '#38bdf8', icon: 'fa-microchip' },
                        mediatek: { title: 'MediaTek PreLoader / USB VCOM', desc: 'ไดรเวอร์เชื่อมต่อ MTK ในโหมด BROM / Preloader (Helio, Dimensity, MT6765, MT6768)', link: 'https://androidsupported.com/mtk-usb-vcom-driver/', color: '#f97316', icon: 'fa-bolt' },
                        qualcomm: { title: 'Qualcomm HS-USB QDLoader 9008', desc: 'ไดรเวอร์สำหรับแฟลชรอมและกู้ชีพ Snapdragon ในโหมดฉุกเฉิน (EDL 9008 / Diag)', link: 'https://qualcomm-hs-usb-qdloader9008.en.lo4d.com/', color: '#ef4444', icon: 'fa-microchip' },
                        samsung: { title: 'SAMSUNG Mobile USB Composite Driver', desc: 'ไดรเวอร์โหมด Odin Download Mode, CDC Serial และ MTP Service (*#0*#)', link: 'https://developer.samsung.com/mobile/android-usb-driver.html', color: '#3b82f6', icon: 'fa-mobile-alt' },
                        adb: { title: 'Android ADB & Fastboot (WinUSB)', desc: 'ไดรเวอร์ส่งคำสั่ง Fastboot Bootloader และตรวจเช็คผ่าน ADB Shell', link: 'https://adb.clockworkmod.com/', color: '#4ade80', icon: 'fa-terminal' },
                        huawei: { title: 'Huawei USB COM 1.0 & Diag Port', desc: 'ไดรเวอร์เชื่อมต่อชิป Kirin ในโหมด Test Point (USB COM 1.0) และ Fastboot', link: 'https://androiddatahost.com/v8tq9', color: '#a855f7', icon: 'fa-shield-halved' },
                        libusb: { title: 'LibUSB / WinUSB / UsbDk Filter', desc: 'ไดรเวอร์บายพาส SLA/DAA Authentication (MTK BROM Filter / mtkclient)', link: 'https://zadig.akeo.ie/', color: '#c084fc', icon: 'fa-filter' }
                    };

                    for (const [key, d] of Object.entries(res.drivers)) {
                        const meta = DRIVER_DESCS[key] || { title: d.name, desc: '', link: '#', color: '#94a3b8', icon: 'fa-microchip' };
                        const isInstalled = !!d.installed;
                        const statusBadge = isInstalled
                            ? '<span style="font-size:10.5px; padding:2px 8px; border-radius:4px; font-weight:700; background:rgba(34,197,94,0.18); color:#4ade80; border:1px solid rgba(34,197,94,0.4);"><i class="fas fa-check-circle"></i> ติดตั้งแล้ว</span>'
                            : '<span style="font-size:10.5px; padding:2px 8px; border-radius:4px; font-weight:700; background:rgba(239,68,68,0.18); color:#f87171; border:1px solid rgba(239,68,68,0.4);"><i class="fas fa-exclamation-triangle"></i> ยังไม่พบในเครื่อง</span>';

                        const card = document.createElement('div');
                        card.className = 'glass-card tool-card';
                        card.style.cssText = 'padding: 14px 16px; display: flex; flex-direction: column; justify-content: space-between; background: rgba(15, 23, 42, 0.6); border: 1px solid rgba(255,255,255,0.06); border-radius: 10px;';
                        card.innerHTML = `
                            <div>
                                <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px;">
                                    <div style="display: flex; align-items: center; gap: 8px;">
                                        <div style="width: 32px; height: 32px; border-radius: 8px; background: rgba(255,255,255,0.06); display: flex; align-items: center; justify-content: center; color: ${meta.color}; font-size: 15px;">
                                            <i class="fas ${meta.icon}"></i>
                                        </div>
                                        <div style="font-weight: 700; font-size: 13px; color: #f8fafc;">${meta.title}</div>
                                    </div>
                                    ${statusBadge}
                                </div>
                                <p style="font-size: 11.5px; color: #94a3b8; line-height: 1.5; margin: 6px 0 10px 0;">${meta.desc}</p>
                                <div style="font-size: 10.5px; color: #64748b; font-family: monospace; background: rgba(0,0,0,0.25); padding: 5px 8px; border-radius: 4px; margin-bottom: 10px;">
                                    ${d.dev || (isInstalled ? 'Driver Service Ready' : 'ไม่พบบริการหรือแพ็กเกจไดรเวอร์ในระบบ')}
                                </div>
                            </div>
                            <div style="display: flex; gap: 6px;">
                                <button type="button" class="action-btn" onclick="window.api.openExternalUrl('${meta.link}')" style="flex: 1; font-size: 11px; padding: 7px; background: rgba(56, 189, 248, 0.12); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.3); border-radius: 6px; cursor: pointer;">
                                    <i class="fas fa-download"></i> โหลดไดรเวอร์ทางการ
                                </button>
                            </div>
                        `;
                        tabDrvCardsGrid.appendChild(card);
                    }
                }
            } catch (err) {
                if (tabDrvCardsGrid) tabDrvCardsGrid.innerHTML = `<div style="color:#ef4444; padding:20px; text-align:center;">Error: ${err.message || err}</div>`;
            }
        }

        if (btnTabDrvRescan) {
            btnTabDrvRescan.addEventListener('click', () => refreshDriverTab());
        }

        if (btnTabDrvFixUsb) {
            btnTabDrvFixUsb.addEventListener('click', async () => {
                const orig = btnTabDrvFixUsb.innerHTML;
                btnTabDrvFixUsb.disabled = true;
                btnTabDrvFixUsb.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังซ่อม USB...';
                try {
                    const fixRes = await window.api.fixUsbStack();
                    alert('⚡ การซ่อมแซมพอร์ต USB เสร็จสมบูรณ์:\n' + (fixRes.steps || []).join('\n'));
                    await refreshDriverTab();
                } catch (e) {
                    alert('ข้อผิดพลาด: ' + e.message);
                } finally {
                    btnTabDrvFixUsb.disabled = false;
                    btnTabDrvFixUsb.innerHTML = orig;
                }
            });
        }

        if (btnTabDrvDevmgmt) {
            btnTabDrvDevmgmt.addEventListener('click', () => {
                window.api.openDevMgmt();
            });
        }

        if (btnTabDrvTestmode) {
            btnTabDrvTestmode.addEventListener('click', async () => {
                const targetState = !isDriverTestModeActive;
                const msg = targetState
                    ? 'คุณต้องการ [เปิด] Windows Test Mode (TestSigning ON) ใช่หรือไม่?\n(ระบบจะขอสิทธิ์ Administrator และต้องรีสตาร์ทคอมเพื่อให้มีผล)'
                    : 'คุณต้องการ [ปิด] Windows Test Mode (TestSigning OFF) ใช่หรือไม่?\n(ระบบจะขอสิทธิ์ Administrator และต้องรีสตาร์ทคอมเพื่อให้มีผล)';
                if (confirm(msg)) {
                    const res = await window.api.toggleTestModeAdmin(targetState);
                    if (res && res.success) {
                        alert(`ตั้งค่าสำเร็จ! กำหนด TestSigning = ${targetState ? 'ON' : 'OFF'} แล้ว กรุณารีสตาร์ทคอมพิวเตอร์`);
                        await refreshDriverTab();
                    } else {
                        alert('ไม่สามารถเปลี่ยนสถานะได้: ' + (res.error || 'User cancelled'));
                    }
                }
            });
        }

        // Auto scan when clicking Driver Center tab button
        const tabDriversBtn = document.querySelector('.tab-btn[data-target="tab-drivers"]');
        if (tabDriversBtn) {
            tabDriversBtn.addEventListener('click', () => {
                setTimeout(refreshDriverTab, 150);
            });
        }

        // =========================================================================
        // MODULE 3: HUAWEI & HONOR FASTBOOT & SERVICE SUITE
        // =========================================================================
        const btnHuaweiFbInfo = document.getElementById('btn-huawei-fb-info');
        const btnHuaweiFbBootinfo = document.getElementById('btn-huawei-fb-bootinfo');
        const btnHuaweiFbBuild = document.getElementById('btn-huawei-fb-build');
        const btnHuaweiFbPsid = document.getElementById('btn-huawei-fb-psid');
        const btnHuaweiFbRebootRec = document.getElementById('btn-huawei-fb-reboot-rec');
        const btnHuaweiFbRebootSys = document.getElementById('btn-huawei-fb-reboot-sys');
        const btnHuaweiFbRebootBl = document.getElementById('btn-huawei-fb-reboot-bl');
        const btnHuaweiCheckCom = document.getElementById('btn-huawei-check-com');
        const btnHuaweiTpGallery = document.getElementById('btn-huawei-tp-gallery');
        const huaweiTerminalOutput = document.getElementById('huawei-terminal-output');
        const huaweiStatusBadge = document.getElementById('huawei-status-badge');
        const huaweiComStatusBadge = document.getElementById('huawei-com-status-badge');
        const huaweiOutputTimestamp = document.getElementById('huawei-output-timestamp');

        function appendHuaweiLog(text, isError = false) {
            if (!huaweiTerminalOutput) return;
            const time = new Date().toLocaleTimeString('th-TH');
            if (huaweiOutputTimestamp) huaweiOutputTimestamp.textContent = time;
            const prefix = isError ? `[ERROR ${time}] ` : `[${time}] `;
            huaweiTerminalOutput.textContent += `\n${prefix}${text}`;
            huaweiTerminalOutput.scrollTop = huaweiTerminalOutput.scrollHeight;
            if (typeof logToModal === 'function') {
                logToModal(`\n[HUAWEI] ${text}\n`, isError ? 'error' : 'info');
            }
        }

        async function runHuaweiFastbootAction(action, label) {
            appendHuaweiLog(`> กำลังรันคำสั่ง: ${label} (${action})...`);
            try {
                const res = await window.api.runHuaweiFastboot({ action });
                if (res && res.success) {
                    appendHuaweiLog(res.output || 'คำสั่งสำเร็จเรียบร้อย');
                    if (huaweiStatusBadge) {
                        huaweiStatusBadge.innerHTML = '<i class="fas fa-check"></i> ตรวจพบเครื่อง Huawei Fastboot';
                        huaweiStatusBadge.style.color = '#4ade80';
                        huaweiStatusBadge.style.borderColor = 'rgba(74, 222, 128, 0.4)';
                    }
                } else {
                    appendHuaweiLog(res.output || res.error || 'ไม่พบอุปกรณ์ หรือคำสั่งล้มเหลว', true);
                }
            } catch (err) {
                appendHuaweiLog(err.message || String(err), true);
            }
        }

        if (btnHuaweiFbInfo) {
            btnHuaweiFbInfo.addEventListener('click', async () => {
                appendHuaweiLog('========================================================');
                appendHuaweiLog('🚀 เริ่มต้นอ่านข้อมูลเครื่อง Huawei / Honor Fastboot Mode...');
                await runHuaweiFastbootAction('devices', 'ตรวจเช็คอุปกรณ์ (fastboot devices)');
                await runHuaweiFastbootAction('get-bootinfo', 'ตรวจสอบสถานะ Bootloader (oem get-bootinfo)');
                await runHuaweiFastbootAction('get-build-number', 'อ่านเวอร์ชันซอฟต์แวร์ (oem get-build-number)');
                await runHuaweiFastbootAction('get-psid', 'อ่านค่า Product ID (oem get-psid)');
                await runHuaweiFastbootAction('getvar-all', 'ดึงตัวแปรระบบทั้งหมด (getvar all)');
                appendHuaweiLog('========================================================');
            });
        }

        if (btnHuaweiFbBootinfo) {
            btnHuaweiFbBootinfo.addEventListener('click', () => {
                runHuaweiFastbootAction('get-bootinfo', 'สถานะ Bootloader');
            });
        }

        if (btnHuaweiFbBuild) {
            btnHuaweiFbBuild.addEventListener('click', () => {
                runHuaweiFastbootAction('get-build-number', 'เวอร์ชัน Build EMUI');
            });
        }

        if (btnHuaweiFbPsid) {
            btnHuaweiFbPsid.addEventListener('click', () => {
                runHuaweiFastbootAction('get-psid', 'Product Serial ID (PSID)');
            });
        }

        if (btnHuaweiFbRebootRec) {
            btnHuaweiFbRebootRec.addEventListener('click', () => {
                runHuaweiFastbootAction('reboot-recovery', 'สั่งรีบูตเข้า eRecovery');
            });
        }

        if (btnHuaweiFbRebootSys) {
            btnHuaweiFbRebootSys.addEventListener('click', () => {
                runHuaweiFastbootAction('reboot', 'สั่งรีบูตเครื่องปกติ');
            });
        }

        if (btnHuaweiFbRebootBl) {
            btnHuaweiFbRebootBl.addEventListener('click', () => {
                runHuaweiFastbootAction('reboot-bootloader', 'สั่งรีบูตเข้า Fastboot ซ้ำ');
            });
        }

        if (btnHuaweiCheckCom) {
            btnHuaweiCheckCom.addEventListener('click', async () => {
                appendHuaweiLog('> กำลังสแกนพอร์ตสื่อสารหา HUAWEI USB COM 1.0 (VID 12D1 PID 3609)...');
                const res = await window.api.scanHuaweiCom();
                if (res && res.success && res.device) {
                    appendHuaweiLog(`✅ ตรวจพบอุปกรณ์เชื่อมต่อสด: ${res.device.name} บนพอร์ต ${res.device.port}!`);
                    if (huaweiComStatusBadge) {
                        huaweiComStatusBadge.textContent = `🟢 พบ ${res.device.port}`;
                        huaweiComStatusBadge.style.color = '#4ade80';
                        huaweiComStatusBadge.style.background = 'rgba(74, 222, 128, 0.2)';
                    }
                } else {
                    appendHuaweiLog('⚠ ยังไม่พบพอร์ต HUAWEI USB COM 1.0 กรุณาถอดแบตเตอรี่แล้วจิ้ม Test Point ลงกราวด์ (GND)', true);
                    if (huaweiComStatusBadge) {
                        huaweiComStatusBadge.textContent = 'ยังไม่พบพอร์ต';
                        huaweiComStatusBadge.style.color = '#fbbf24';
                        huaweiComStatusBadge.style.background = 'rgba(251, 191, 36, 0.2)';
                    }
                }
            });
        }

        if (btnHuaweiTpGallery) {
            btnHuaweiTpGallery.addEventListener('click', () => {
                if (typeof openTestPointForModel === 'function') {
                    openTestPointForModel('huawei', 'huawei');
                } else {
                    const btnTpGallery = document.getElementById('btn-open-testpoint-gallery');
                    if (btnTpGallery) btnTpGallery.click();
                }
            });
        }

        // =========================================================================
        // MODULE 4: AT COMMAND & SERIAL DIAGNOSTIC TERMINAL
        // =========================================================================
        const atPortSelect = document.getElementById('at-port-select');
        const atBaudSelect = document.getElementById('at-baud-select');
        const btnAtRefreshPorts = document.getElementById('btn-at-refresh-ports');
        const btnAtPingPort = document.getElementById('btn-at-ping-port');
        const atTerminalOutput = document.getElementById('at-terminal-output');
        const atTerminalInput = document.getElementById('at-terminal-input');
        const btnAtSendCmd = document.getElementById('btn-at-send-cmd');
        const btnAtClearTerminal = document.getElementById('btn-at-clear-terminal');

        const btnAtMacroPing = document.getElementById('btn-at-macro-ping');
        const btnAtMacroInfo = document.getElementById('btn-at-macro-info');
        const btnAtMacroFirmware = document.getElementById('btn-at-macro-firmware');
        const btnAtMacroImei = document.getElementById('btn-at-macro-imei');
        const btnAtMacroSignal = document.getElementById('btn-at-macro-signal');
        const btnAtMacroNetwork = document.getElementById('btn-at-macro-network');
        const btnAtMacroSim = document.getElementById('btn-at-macro-sim');
        const btnAtMacroBattery = document.getElementById('btn-at-macro-battery');
        const btnAtMacroSamsungInfo = document.getElementById('btn-at-macro-samsung-info');
        const btnAtMacroReboot = document.getElementById('btn-at-macro-reboot');

        async function refreshAtPortsList() {
            if (!atPortSelect) return;
            try {
                const res = await window.api.scanAtPorts();
                atPortSelect.innerHTML = '';
                if (res && res.success && res.ports && res.ports.length > 0) {
                    res.ports.forEach((p, idx) => {
                        const opt = document.createElement('option');
                        opt.value = p.port;
                        opt.textContent = `${p.port} - ${p.description}`;
                        if (idx === 0) opt.selected = true;
                        atPortSelect.appendChild(opt);
                    });
                } else {
                    const opt = document.createElement('option');
                    opt.value = '';
                    opt.textContent = 'ไม่พบพอร์ต COM ในระบบ';
                    opt.disabled = true;
                    opt.selected = true;
                    atPortSelect.appendChild(opt);
                }
            } catch (err) {
                console.error('Error scanning AT ports:', err);
            }
        }

        function appendAtTerminal(text, type = 'info') {
            if (!atTerminalOutput) return;
            const time = new Date().toLocaleTimeString('th-TH');
            let prefix = `[${time}] `;
            if (type === 'tx') {
                prefix = `[TX ${time}] > `;
            } else if (type === 'rx') {
                prefix = `[RX ${time}] < `;
            } else if (type === 'error') {
                prefix = `[ERR ${time}] ! `;
            }
            atTerminalOutput.textContent += `\n${prefix}${text}`;
            atTerminalOutput.scrollTop = atTerminalOutput.scrollHeight;
        }

        async function sendAtCmdExecution(rawCmd) {
            const cmd = (rawCmd || '').trim();
            if (!cmd) return;
            const port = atPortSelect ? atPortSelect.value : null;
            if (!port) {
                alert('กรุณาเลือกพอร์ต COM ก่อนส่งคำสั่ง');
                return;
            }
            const baud = atBaudSelect ? parseInt(atBaudSelect.value, 10) : 115200;

            appendAtTerminal(cmd, 'tx');

            try {
                const res = await window.api.sendAtCommandRaw({ port, command: cmd, baud });
                if (res && res.success) {
                    appendAtTerminal(res.response || 'OK', 'rx');
                } else {
                    appendAtTerminal(res.error || 'ไม่มีสัญญาณตอบรับ หรือพอร์ตถูกใช้งานอยู่', 'error');
                }
            } catch (err) {
                appendAtTerminal(err.message || String(err), 'error');
            }
        }

        if (btnAtRefreshPorts) {
            btnAtRefreshPorts.addEventListener('click', () => {
                refreshAtPortsList();
                appendAtTerminal('รีเฟรชรายการพอร์ต COM สำเร็จ');
            });
        }

        if (btnAtPingPort) {
            btnAtPingPort.addEventListener('click', () => sendAtCmdExecution('AT'));
        }

        if (btnAtSendCmd) {
            btnAtSendCmd.addEventListener('click', () => {
                const val = atTerminalInput ? atTerminalInput.value : '';
                if (val) {
                    sendAtCmdExecution(val);
                    if (atTerminalInput) atTerminalInput.value = '';
                }
            });
        }

        if (atTerminalInput) {
            atTerminalInput.addEventListener('keyup', (e) => {
                if (e.key === 'Enter') {
                    if (btnAtSendCmd) btnAtSendCmd.click();
                }
            });
        }

        if (btnAtClearTerminal) {
            btnAtClearTerminal.addEventListener('click', () => {
                if (atTerminalOutput) {
                    atTerminalOutput.textContent = '======================================================\n AT Terminal Cleared. Ready for input.\n======================================================\n';
                }
            });
        }

        // Quick Macro Buttons
        if (btnAtMacroPing) btnAtMacroPing.addEventListener('click', () => sendAtCmdExecution('AT'));
        if (btnAtMacroInfo) btnAtMacroInfo.addEventListener('click', () => sendAtCmdExecution('ATI'));
        if (btnAtMacroFirmware) btnAtMacroFirmware.addEventListener('click', () => sendAtCmdExecution('AT+GMR'));
        if (btnAtMacroImei) btnAtMacroImei.addEventListener('click', () => sendAtCmdExecution('AT+CGSN'));
        if (btnAtMacroSignal) btnAtMacroSignal.addEventListener('click', () => sendAtCmdExecution('AT+CSQ'));
        if (btnAtMacroNetwork) btnAtMacroNetwork.addEventListener('click', () => sendAtCmdExecution('AT+COPS?'));
        if (btnAtMacroSim) btnAtMacroSim.addEventListener('click', () => sendAtCmdExecution('AT+CPIN?'));
        if (btnAtMacroBattery) btnAtMacroBattery.addEventListener('click', () => sendAtCmdExecution('AT+CBC'));
        if (btnAtMacroSamsungInfo) btnAtMacroSamsungInfo.addEventListener('click', () => sendAtCmdExecution('AT+DEVCONINFO'));
        if (btnAtMacroReboot) btnAtMacroReboot.addEventListener('click', () => {
            if (confirm('ยืนยันส่งคำสั่งรีบูตโมเด็ม (AT+CFUN=1,1) ใช่หรือไม่?')) {
                sendAtCmdExecution('AT+CFUN=1,1');
            }
        });

        // Auto refresh ports when switching to AT Terminal tab
        const atTabBtn = document.querySelector('.tab-btn[data-target="tab-at-terminal"]');
        if (atTabBtn) {
            atTabBtn.addEventListener('click', () => {
                setTimeout(refreshAtPortsList, 150);
            });
        }

    })();

    // =========================================================================
    // PRO TECHNICIAN SUITE: 4 REAL WORKSTATION MODULES (NO MOCK DATA)
    // =========================================================================
    (function initProTechnicianSuite() {
        // ---------------------------------------------------------------------
        // FEATURE 1: QUALCOMM & MEDIATEK PARTITION MANAGER
        // ---------------------------------------------------------------------
        const modalPartitionMgr = document.getElementById('modal-partition-mgr');
        const btnClosePartitionMgr = document.getElementById('btn-close-partition-mgr');
        const btnQcomPartitionMgr = document.getElementById('btn-qcom-partition-mgr');
        const btnMtkPartitionMgr = document.getElementById('btn-mtk-partition-mgr');
        const partMgrChipsetBadge = document.getElementById('part-mgr-chipset-badge');
        const partMgrSearchInput = document.getElementById('part-mgr-search-input');
        const btnPartRefreshGpt = document.getElementById('btn-part-refresh-gpt');
        const btnPartDumpAll = document.getElementById('btn-part-dump-all');
        const partitionMgrTbody = document.getElementById('partition-mgr-tbody');

        let currentPartChipset = 'qcom';
        let currentPartitions = [];

        function showPartitionModal(chipset) {
            currentPartChipset = chipset;
            if (partMgrChipsetBadge) {
                partMgrChipsetBadge.textContent = chipset === 'qcom' ? 'Qualcomm EDL (9008)' : 'MediaTek (MTK)';
                partMgrChipsetBadge.style.borderColor = chipset === 'qcom' ? 'rgba(56, 189, 248, 0.4)' : 'rgba(74, 222, 128, 0.4)';
                partMgrChipsetBadge.style.color = chipset === 'qcom' ? '#38bdf8' : '#4ade80';
            }
            if (modalPartitionMgr) {
                modalPartitionMgr.classList.add('is-open');
                modalPartitionMgr.style.display = 'flex';
            }
            loadGptPartitions();
        }

        function closePartitionModal() {
            if (modalPartitionMgr) {
                modalPartitionMgr.classList.remove('is-open');
                modalPartitionMgr.style.display = 'none';
            }
        }

        if (btnClosePartitionMgr) btnClosePartitionMgr.addEventListener('click', closePartitionModal);
        if (modalPartitionMgr) {
            modalPartitionMgr.addEventListener('click', (e) => {
                if (e.target === modalPartitionMgr) closePartitionModal();
            });
        }
        if (btnQcomPartitionMgr) btnQcomPartitionMgr.addEventListener('click', () => showPartitionModal('qcom'));
        if (btnMtkPartitionMgr) btnMtkPartitionMgr.addEventListener('click', () => showPartitionModal('mtk'));

        async function loadGptPartitions() {
            if (!partitionMgrTbody) return;
            partitionMgrTbody.innerHTML = `
                <tr>
                    <td colspan="5" style="text-align: center; padding: 30px; color: #38bdf8;">
                        <i class="fas fa-spinner fa-spin" style="font-size: 24px; margin-bottom: 8px; display: block;"></i>
                        กำลังอ่านตาราง Partition GPT จากชิปจริง (${currentPartChipset.toUpperCase()})...
                    </td>
                </tr>
            `;

            try {
                let options = { chipset: currentPartChipset };
                if (currentPartChipset === 'qcom') {
                    const qcomPortSelect = document.getElementById('qcom-port-select');
                    const qcomProgInput = document.getElementById('qcom-prog-file-path');
                    options.comPort = (qcomPortSelect && qcomPortSelect.value) ? qcomPortSelect.value : null;
                    options.programmer = (qcomProgInput && qcomProgInput.textContent && !qcomProgInput.textContent.includes('เลือก')) ? qcomProgInput.textContent.trim() : null;
                } else if (currentPartChipset === 'mtk') {
                    const mtkDa = document.getElementById('mtk-da-file-path');
                    const mtkPre = document.getElementById('mtk-preloader-file-path');
                    options.da = (mtkDa && mtkDa.textContent && !mtkDa.textContent.includes('เลือก')) ? mtkDa.textContent.trim() : null;
                    options.preloader = (mtkPre && mtkPre.textContent && !mtkPre.textContent.includes('เลือก')) ? mtkPre.textContent.trim() : null;
                    options.mode = options.da ? 'preloader' : 'brom';
                }

                const res = await window.api.readGptPartitions(options);
                if (res && res.success && res.partitions && res.partitions.length > 0) {
                    currentPartitions = res.partitions;
                    renderPartitionsTable(currentPartitions);
                    logToConsole(`[GPT] อ่านตาราง Partition สำเร็จ พบ ${currentPartitions.length} พาร์ติชัน\n`, 'success');
                } else {
                    const raw = (res && res.rawOutput) ? res.rawOutput : 'ไม่พบข้อมูล หรืออุปกรณ์ยังไม่ได้ต่อในโหมด EDL/BROM';
                    partitionMgrTbody.innerHTML = `
                        <tr>
                            <td colspan="5" style="text-align: center; padding: 30px; color: #f87171;">
                                <i class="fas fa-exclamation-triangle" style="font-size: 24px; margin-bottom: 8px; display: block;"></i>
                                ไม่สามารถอ่าน GPT: ตรวจสอบการเชื่อมต่อสายและพอร์ตชิป<br>
                                <span style="font-size: 11px; color: #94a3b8; font-family: monospace;">${raw.substring(0, 200)}</span>
                            </td>
                        </tr>
                    `;
                    logToConsole(`[GPT-ERR] ${raw}\n`, 'error');
                }
            } catch (err) {
                partitionMgrTbody.innerHTML = `
                    <tr>
                        <td colspan="5" style="text-align: center; padding: 30px; color: #f87171;">
                            <i class="fas fa-times-circle" style="font-size: 24px; margin-bottom: 8px; display: block;"></i>
                            เกิดข้อผิดพลาด: ${err.message || err}
                        </td>
                    </tr>
                `;
                logToConsole(`[GPT-ERR] ${err.message || err}\n`, 'error');
            }
        }

        function renderPartitionsTable(partitions) {
            if (!partitionMgrTbody) return;
            if (!partitions || partitions.length === 0) {
                partitionMgrTbody.innerHTML = `
                    <tr>
                        <td colspan="5" style="text-align: center; padding: 30px; color: #94a3b8;">
                            ไม่พบพาร์ติชันที่ค้นหา
                        </td>
                    </tr>
                `;
                return;
            }

            partitionMgrTbody.innerHTML = partitions.map((p) => {
                const isCritical = /persist|boot|recovery|modem|efs|nvram|nvdata|vbmeta/i.test(p.name);
                const isSystem = /system|vendor|product|userdata/i.test(p.name);
                const tagColor = isCritical ? '#f59e0b' : (isSystem ? '#38bdf8' : '#94a3b8');
                return `
                    <tr style="border-bottom: 1px solid rgba(255,255,255,0.05); transition: background 0.15s;" onmouseover="this.style.background='rgba(255,255,255,0.03)'" onmouseout="this.style.background='transparent'">
                        <td style="padding: 9px 14px; font-weight: 600; color: #f8fafc; display: flex; align-items: center; gap: 8px;">
                            <i class="fas fa-cube" style="color: ${tagColor}; font-size: 11px;"></i>
                            <span>${p.name}</span>
                            ${isCritical ? '<span style="font-size: 9.5px; background: rgba(245, 158, 11, 0.2); color: #fbbf24; padding: 1px 5px; border-radius: 3px;">Protected</span>' : ''}
                        </td>
                        <td style="padding: 9px 14px; font-family: monospace; color: #94a3b8; font-size: 11px;">${p.offset || '--'}</td>
                        <td style="padding: 9px 14px; font-weight: 600; color: #38bdf8; font-family: monospace;">${p.sizeFormatted || '--'}</td>
                        <td style="padding: 9px 14px; color: #cbd5e1; font-size: 11px;">${p.type || p.flags || 'RAW'}</td>
                        <td style="padding: 9px 14px; text-align: center;">
                            <div style="display: inline-flex; gap: 5px;">
                                <button class="action-btn btn-part-read" data-part="${p.name}" style="padding: 4px 8px; font-size: 10.5px; background: rgba(56, 189, 248, 0.15); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.3); border-radius: 4px; cursor: pointer;" title="ดูดพาร์ติชัน (Read to file)">
                                    <i class="fas fa-download"></i> Read
                                </button>
                                <button class="action-btn btn-part-write" data-part="${p.name}" style="padding: 4px 8px; font-size: 10.5px; background: rgba(168, 85, 247, 0.15); color: #c084fc; border: 1px solid rgba(168, 85, 247, 0.3); border-radius: 4px; cursor: pointer;" title="แฟลชพาร์ติชัน (Write file)">
                                    <i class="fas fa-upload"></i> Flash
                                </button>
                                <button class="action-btn btn-part-erase" data-part="${p.name}" style="padding: 4px 8px; font-size: 10.5px; background: rgba(239, 68, 68, 0.15); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.3); border-radius: 4px; cursor: pointer;" title="ล้างพาร์ติชัน (Erase)">
                                    <i class="fas fa-trash-alt"></i> Erase
                                </button>
                            </div>
                        </td>
                    </tr>
                `;
            }).join('');

            // Attach row button events
            partitionMgrTbody.querySelectorAll('.btn-part-read').forEach(btn => {
                btn.addEventListener('click', () => handlePartitionOp('read', btn.dataset.part));
            });
            partitionMgrTbody.querySelectorAll('.btn-part-write').forEach(btn => {
                btn.addEventListener('click', () => handlePartitionOp('write', btn.dataset.part));
            });
            partitionMgrTbody.querySelectorAll('.btn-part-erase').forEach(btn => {
                btn.addEventListener('click', () => handlePartitionOp('erase', btn.dataset.part));
            });
        }

        async function handlePartitionOp(action, partName) {
            if (!partName) return;

            let filePath = null;
            if (action === 'write') {
                const pick = await window.api.showOpenDialog({
                    title: `เลือกไฟล์ Image สำหรับแฟลชลงพาร์ติชัน ${partName}`,
                    filters: [{ name: 'Partition Image', extensions: ['bin', 'img'] }]
                });
                if (!pick || pick.canceled || !pick.filePaths || pick.filePaths.length === 0) return;
                filePath = pick.filePaths[0];
            } else if (action === 'erase') {
                if (!confirm(`⚠️ คุณแน่ใจหรือไม่ที่จะล้างพาร์ติชัน ${partName}?\nข้อมูลในพาร์ติชันนี้จะถูกลบทั้งหมด!`)) return;
            }

            logToConsole(`[PARTITION] กำลังดำเนินการ ${action.toUpperCase()} พาร์ติชัน: ${partName}...\n`, 'info');

            try {
                let options = {
                    chipset: currentPartChipset,
                    action,
                    partition: partName,
                    filePath
                };
                if (currentPartChipset === 'qcom') {
                    const qcomPortSelect = document.getElementById('qcom-port-select');
                    const qcomProgInput = document.getElementById('qcom-prog-file-path');
                    options.comPort = (qcomPortSelect && qcomPortSelect.value) ? qcomPortSelect.value : null;
                    options.programmer = (qcomProgInput && qcomProgInput.textContent && !qcomProgInput.textContent.includes('เลือก')) ? qcomProgInput.textContent.trim() : null;
                } else if (currentPartChipset === 'mtk') {
                    const mtkDa = document.getElementById('mtk-da-file-path');
                    const mtkPre = document.getElementById('mtk-preloader-file-path');
                    options.da = (mtkDa && mtkDa.textContent && !mtkDa.textContent.includes('เลือก')) ? mtkDa.textContent.trim() : null;
                    options.preloader = (mtkPre && mtkPre.textContent && !mtkPre.textContent.includes('เลือก')) ? mtkPre.textContent.trim() : null;
                    options.mode = options.da ? 'preloader' : 'brom';
                }

                const res = await window.api.operatePartition(options);
                if (res && res.success) {
                    logToConsole(`[SUCCESS] การทำงานกับพาร์ติชัน ${partName} สำเร็จ 100%:\n${res.log}\n`, 'success');
                    alert(`✅ ดำเนินการ ${action.toUpperCase()} พาร์ติชัน ${partName} เรียบร้อย!`);
                } else {
                    logToConsole(`[ERROR] การทำงานล้มเหลว: ${res.log || res.error}\n`, 'error');
                    alert(`❌ การทำงานล้มเหลว: ${res.error || 'โปรดดูรายละเอียดในคอนโซล'}`);
                }
            } catch (err) {
                logToConsole(`[ERROR] ${err.message || err}\n`, 'error');
                alert(`❌ เกิดข้อผิดพลาด: ${err.message || err}`);
            }
        }

        if (partMgrSearchInput) {
            partMgrSearchInput.addEventListener('input', (e) => {
                const q = (e.target.value || '').trim().toLowerCase();
                if (!q) {
                    renderPartitionsTable(currentPartitions);
                } else {
                    const filtered = currentPartitions.filter(p => (p.name || '').toLowerCase().includes(q));
                    renderPartitionsTable(filtered);
                }
            });
        }

        if (btnPartRefreshGpt) btnPartRefreshGpt.addEventListener('click', loadGptPartitions);

        if (btnPartDumpAll) {
            btnPartDumpAll.addEventListener('click', async () => {
                if (currentPartChipset === 'qcom') {
                    const btnDump = document.getElementById('btn-qcom-dump');
                    if (btnDump) btnDump.click();
                } else {
                    const btnDump = document.getElementById('btn-mtk-dump');
                    if (btnDump) btnDump.click();
                }
                closePartitionModal();
            });
        }

        // ---------------------------------------------------------------------
        // FEATURE 3: MTP PUSH BROWSER OPENER
        // ---------------------------------------------------------------------
        const samsungBrowserTarget = document.getElementById('samsung-browser-target');
        const samsungCustomUrlContainer = document.getElementById('samsung-custom-url-container');
        const samsungCustomUrlInput = document.getElementById('samsung-custom-url-input');
        const btnSamsungLaunchBrowser = document.getElementById('btn-samsung-launch-browser');
        const gsmSamsungPortSelect = document.getElementById('gsm-samsung-port-select');

        if (samsungBrowserTarget) {
            samsungBrowserTarget.addEventListener('change', () => {
                if (samsungCustomUrlContainer) {
                    samsungCustomUrlContainer.style.display = samsungBrowserTarget.value === 'custom' ? 'block' : 'none';
                }
            });
        }

        if (btnSamsungLaunchBrowser) {
            btnSamsungLaunchBrowser.addEventListener('click', async () => {
                let targetUrl = 'https://www.youtube.com';
                const mode = samsungBrowserTarget ? samsungBrowserTarget.value : 'youtube';
                if (mode === 'youtube') targetUrl = 'https://www.youtube.com';
                else if (mode === 'maps') targetUrl = 'https://maps.google.com';
                else if (mode === 'chrome') targetUrl = 'https://www.google.com';
                else if (mode === 'galaxystore') targetUrl = 'https://galaxystore.samsung.com';
                else if (mode === 'custom' && samsungCustomUrlInput) targetUrl = samsungCustomUrlInput.value.trim() || 'https://google.com';

                const port = (gsmSamsungPortSelect && gsmSamsungPortSelect.value) ? gsmSamsungPortSelect.value : null;

                logToConsole(`[MTP-BROWSER] ส่งสัญญาณเปิดเบราว์เซอร์: ${targetUrl}...\n`, 'info');
                const origHtml = btnSamsungLaunchBrowser.innerHTML;
                btnSamsungLaunchBrowser.disabled = true;
                btnSamsungLaunchBrowser.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังส่งคำสั่ง...';

                try {
                    const res = await window.api.mtpLaunchBrowser(targetUrl, port);
                    if (res && res.success) {
                        logToConsole(`[SUCCESS] ส่งคำสั่งสำเร็จ! ตรวจสอบหน้าจอมือถือเพื่อกด "เปิด" (Open / View)\n`, 'success');
                        alert(`🚀 ส่งสัญญาณเปิดหน้าต่าง ${mode.toUpperCase()} สำเร็จ!\nโปรดดูหน้าจอมือถือเพื่อกดเปิด`);
                    } else {
                        logToConsole(`[FAIL] ${res.output || res.error || 'ไม่พบการตอบรับจากโทรศัพท์'}\n`, 'warning');
                        alert(`⚠️ ส่งคำสั่งไม่สำเร็จ: ตรวจสอบการเสียบสาย USB หรือลองสลับพอร์ต COM`);
                    }
                } catch (err) {
                    logToConsole(`[ERROR] ${err.message || err}\n`, 'error');
                    alert(`❌ ข้อผิดพลาด: ${err.message || err}`);
                } finally {
                    btnSamsungLaunchBrowser.disabled = false;
                    btnSamsungLaunchBrowser.innerHTML = origHtml;
                }
            });
        }

        // ---------------------------------------------------------------------
        // FEATURE 4: PHONE DATA BACKUP & MIGRATION (.vcf + STORAGE)
        // ---------------------------------------------------------------------
        let migrationDestFolder = null;
        const migrationDestPath = document.getElementById('migration-dest-path');
        const btnBrowseMigrationDest = document.getElementById('btn-browse-migration-dest');
        const btnAdbFullBackup = document.getElementById('btn-adb-full-backup');

        if (btnBrowseMigrationDest) {
            btnBrowseMigrationDest.addEventListener('click', async () => {
                const pick = await window.api.showOpenDialog({
                    title: 'เลือกโฟลเดอร์สำหรับบันทึกข้อมูลสำรองมือถือ',
                    properties: ['openDirectory', 'createDirectory']
                });
                if (pick && !pick.canceled && pick.filePaths && pick.filePaths.length > 0) {
                    migrationDestFolder = pick.filePaths[0];
                    if (migrationDestPath) migrationDestPath.textContent = 'บันทึกลง: ' + migrationDestFolder;
                }
            });
        }

        if (btnAdbFullBackup) {
            btnAdbFullBackup.addEventListener('click', async () => {
                const categories = [];
                if (document.getElementById('chk-mig-dcim')?.checked) categories.push('dcim');
                if (document.getElementById('chk-mig-pictures')?.checked) categories.push('pictures');
                if (document.getElementById('chk-mig-download')?.checked) categories.push('download');
                if (document.getElementById('chk-mig-documents')?.checked) categories.push('documents');
                if (document.getElementById('chk-mig-contacts')?.checked) categories.push('contacts');

                if (categories.length === 0) {
                    alert('กรุณาเลือกหมวดหมู่ที่ต้องการสำรองอย่างน้อย 1 รายการ');
                    return;
                }

                logToConsole(`[MIGRATION] เริ่มต้นการสำรองข้อมูลมือถือ (${categories.join(', ')})...\n`, 'info');
                const origHtml = btnAdbFullBackup.innerHTML;
                btnAdbFullBackup.disabled = true;
                btnAdbFullBackup.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังสำรองข้อมูล...';

                try {
                    const res = await window.api.adbFullDataBackup({
                        categories,
                        destDir: migrationDestFolder
                    });
                    if (res && res.success) {
                        logToConsole(`[SUCCESS] สำรองข้อมูลทั้งหมดเสร็จสมบูรณ์! โฟลเดอร์: ${res.outDir}\n`, 'success');
                        alert(`🎉 สำรองข้อมูลมือถือเรียบร้อย 100%!\nเปิดโฟลเดอร์เก็บไฟล์สำรองแล้ว`);
                    } else {
                        logToConsole(`[ERROR] การสำรองข้อมูลล้มเหลว: ${res.error}\n`, 'error');
                        alert(`❌ การสำรองข้อมูลล้มเหลว: ${res.error || 'โปรดดูรายละเอียดในคอนโซล'}`);
                    }
                } catch (err) {
                    logToConsole(`[ERROR] ${err.message || err}\n`, 'error');
                    alert(`❌ เกิดข้อผิดพลาด: ${err.message || err}`);
                } finally {
                    btnAdbFullBackup.disabled = false;
                    btnAdbFullBackup.innerHTML = origHtml;
                }
            });
        }

        // ---------------------------------------------------------------------
        // FEATURE 5: WINDOWS PE & TECHNICIAN BOOTABLE USB CREATOR
        // ---------------------------------------------------------------------
        const bootableUsbSelect = document.getElementById('bootable-usb-select');
        const btnRefreshUsbDisks = document.getElementById('btn-refresh-usb-disks');
        const bootableIsoPath = document.getElementById('bootable-iso-path');
        const btnBrowseBootableIso = document.getElementById('btn-browse-bootable-iso');
        const btnDownloadHirens = document.getElementById('btn-download-hirens');
        const bootableFsSelect = document.getElementById('bootable-fs-select');
        const btnCreateBootableUsb = document.getElementById('btn-create-bootable-usb');
        const bootableStatusBox = document.getElementById('bootable-status-box');

        let selectedIsoPath = null;

        async function refreshUsbDisksList() {
            if (!bootableUsbSelect) return;
            bootableUsbSelect.innerHTML = '<option value="">กำลังสแกน Flash Drive (USB)...</option>';
            try {
                const disks = await window.api.getUsbDisks();
                if (disks && disks.length > 0) {
                    bootableUsbSelect.innerHTML = disks.map(d => {
                        const letterInfo = d.DriveLetters ? `(${d.DriveLetters})` : '(No drive letter)';
                        return `<option value="${d.Number}">Disk ${d.Number}: ${d.FriendlyName} - ${d.Size} GB ${letterInfo}</option>`;
                    }).join('');
                } else {
                    bootableUsbSelect.innerHTML = '<option value="">ไม่พบ Flash Drive (USB) ที่เชื่อมต่อ</option>';
                }
            } catch (err) {
                bootableUsbSelect.innerHTML = '<option value="">เกิดข้อผิดพลาดในการสแกน</option>';
            }
        }

        if (btnRefreshUsbDisks) btnRefreshUsbDisks.addEventListener('click', refreshUsbDisksList);

        if (btnBrowseBootableIso) {
            btnBrowseBootableIso.addEventListener('click', async () => {
                const pick = await window.api.showOpenDialog({
                    title: 'เลือกไฟล์อิมเมจ ISO สำหรับทำ USB Bootable',
                    filters: [{ name: 'ISO Disk Image', extensions: ['iso'] }]
                });
                if (pick && !pick.canceled && pick.filePaths && pick.filePaths.length > 0) {
                    selectedIsoPath = pick.filePaths[0];
                    if (bootableIsoPath) bootableIsoPath.value = selectedIsoPath;
                }
            });
        }

        if (btnDownloadHirens) {
            btnDownloadHirens.addEventListener('click', () => {
                window.api.openExternalUrl('https://www.hirensbootcd.org/download/');
            });
        }

        if (btnCreateBootableUsb) {
            btnCreateBootableUsb.addEventListener('click', async () => {
                const diskVal = bootableUsbSelect ? bootableUsbSelect.value : null;
                if (diskVal === '' || diskVal === null) {
                    alert('กรุณาเลือก USB Flash Drive ที่ต้องการเขียน');
                    return;
                }
                if (!selectedIsoPath) {
                    alert('กรุณาเลือกไฟล์อิมเมจ ISO ก่อน');
                    return;
                }

                const diskNumber = parseInt(diskVal, 10);
                const filesystem = bootableFsSelect ? bootableFsSelect.value : 'FAT32';

                if (!confirm(`⚠️ คำเตือนสำคัญ!\nข้อมูลทั้งหมดบน Flash Drive (Disk ${diskNumber}) จะถูกล้างหมด 100%\nคุณแน่ใจหรือไม่ที่จะเริ่มสร้าง Bootable USB?`)) {
                    return;
                }

                if (bootableStatusBox) {
                    bootableStatusBox.style.display = 'block';
                    bootableStatusBox.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังดำเนินการ Diskpart & คัดลอกไฟล์ ISO...';
                }

                const origHtml = btnCreateBootableUsb.innerHTML;
                btnCreateBootableUsb.disabled = true;
                btnCreateBootableUsb.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังสร้าง USB Bootable...';

                try {
                    const res = await window.api.createBootableUsb({
                        diskNumber,
                        isoPath: selectedIsoPath,
                        filesystem
                    });
                    if (res && res.success) {
                        if (bootableStatusBox) {
                            bootableStatusBox.style.color = '#4ade80';
                            bootableStatusBox.innerHTML = `✅ สร้าง USB Bootable สำเร็จที่ไดรฟ์ ${res.usbDrive} พร้อมใช้งานทันที!`;
                        }
                        alert(`🎉 สร้าง USB Bootable ช่างคอมพิวเตอร์สำเร็จ 100%!\nไดรฟ์ ${res.usbDrive} พร้อมนำไปใช้บูตเครื่องแล้ว`);
                    } else {
                        if (bootableStatusBox) {
                            bootableStatusBox.style.color = '#f87171';
                            bootableStatusBox.innerHTML = `❌ เกิดข้อผิดพลาด: ${res.error || 'โปรดตรวจสอบสิทธิ์ Admin'}`;
                        }
                        alert(`❌ ไม่สามารถสร้าง USB Bootable ได้: ${res.error || 'ตรวจสอบรายละเอียด'}`);
                    }
                } catch (err) {
                    if (bootableStatusBox) {
                        bootableStatusBox.style.color = '#f87171';
                        bootableStatusBox.innerHTML = `❌ ข้อผิดพลาด: ${err.message || err}`;
                    }
                    alert(`❌ ข้อผิดพลาด: ${err.message || err}`);
                } finally {
                    btnCreateBootableUsb.disabled = false;
                    btnCreateBootableUsb.innerHTML = origHtml;
                    refreshUsbDisksList();
                }
            });
        }
    })();

    // =========================================================================
    // FEATURE 2: ANDROID UNIVERSAL DEBLOATER & CARRIER APP CLEANER
    // =========================================================================
    (function initDebloaterModule() {
        const btnScan = document.getElementById('btn-debloat-scan');
        const btnUninstallSelected = document.getElementById('btn-debloat-uninstall-selected');
        const btnRestoreSelected = document.getElementById('btn-debloat-restore-selected');
        const btnUninstallManual = document.getElementById('btn-debloat-uninstall-manual');
        const btnRestoreManual = document.getElementById('btn-debloat-restore-manual');
        const inputManual = document.getElementById('debloat-manual-package');
        const inputSearch = document.getElementById('debloat-search-input');
        const chkKeepData = document.getElementById('chk-debloat-keep-data');
        const chkSelectAll = document.getElementById('chk-debloat-select-all');
        const table = document.getElementById('debloat-packages-table');
        const tbody = document.getElementById('debloat-packages-tbody');
        const emptyState = document.getElementById('debloat-empty-state');
        const statusBox = document.getElementById('debloat-status-box');
        const filterChips = document.querySelectorAll('#debloat-filter-chips .debloat-chip');

        let allPackages = [];
        let currentFilter = 'all';

        function updateCounts() {
            let cntAll = allPackages.length;
            let cntCarrier = allPackages.filter(p => p.category && p.category.startsWith('carrier-')).length;
            let cntSamsung = allPackages.filter(p => p.category === 'oem-samsung').length;
            let cntXiaomi = allPackages.filter(p => p.category === 'oem-xiaomi').length;
            let cntOppo = allPackages.filter(p => p.category === 'oem-oppo-realme').length;
            let cntVivo = allPackages.filter(p => p.category === 'oem-vivo').length;
            let cntTrackers = allPackages.filter(p => p.category === 'facebook-bloat' || p.category === 'google-bloat').length;

            const elAll = document.getElementById('count-all'); if (elAll) elAll.textContent = cntAll;
            const elCarrier = document.getElementById('count-carrier'); if (elCarrier) elCarrier.textContent = cntCarrier;
            const elSam = document.getElementById('count-samsung'); if (elSam) elSam.textContent = cntSam;
            const elXiao = document.getElementById('count-xiaomi'); if (elXiao) elXiao.textContent = cntXiaomi;
            const elOppo = document.getElementById('count-oppo'); if (elOppo) elOppo.textContent = cntOppo;
            const elVivo = document.getElementById('count-vivo'); if (elVivo) elVivo.textContent = cntVivo;
            const elTrack = document.getElementById('count-trackers'); if (elTrack) elTrack.textContent = cntTrackers;
        }

        function renderTable() {
            if (!tbody || !table) return;
            const query = (inputSearch ? inputSearch.value : '').toLowerCase().trim();

            const filtered = allPackages.filter(pkg => {
                // Category match
                if (currentFilter === 'carrier' && (!pkg.category || !pkg.category.startsWith('carrier-'))) return false;
                if (currentFilter === 'oem-samsung' && pkg.category !== 'oem-samsung') return false;
                if (currentFilter === 'oem-xiaomi' && pkg.category !== 'oem-xiaomi') return false;
                if (currentFilter === 'oem-oppo-realme' && pkg.category !== 'oem-oppo-realme') return false;
                if (currentFilter === 'oem-vivo' && pkg.category !== 'oem-vivo') return false;
                if (currentFilter === 'trackers' && pkg.category !== 'facebook-bloat' && pkg.category !== 'google-bloat') return false;

                // Search match
                if (query) {
                    const matchName = pkg.name.toLowerCase().includes(query);
                    const matchLabel = (pkg.label || '').toLowerCase().includes(query);
                    if (!matchName && !matchLabel) return false;
                }
                return true;
            });

            if (filtered.length === 0) {
                tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; padding: 20px; color: #94a3b8;">ไม่พบ Package ที่ตรงกับเงื่อนไขการค้นหา</td></tr>`;
                table.style.display = 'table';
                if (emptyState) emptyState.style.display = 'none';
                return;
            }

            table.style.display = 'table';
            if (emptyState) emptyState.style.display = 'none';

            tbody.innerHTML = filtered.map(pkg => {
                const labelText = pkg.label ? `<span style="color:#38bdf8; font-weight:600;">${pkg.label}</span><br>` : '';
                const statusBadge = pkg.isDisabled 
                    ? `<span style="padding: 2px 6px; border-radius: 4px; background: rgba(239,68,68,0.2); color: #f87171; font-weight: 600;">Disabled</span>`
                    : `<span style="padding: 2px 6px; border-radius: 4px; background: rgba(74,222,128,0.2); color: #4ade80; font-weight: 600;">Active</span>`;

                let catBadge = '';
                if (pkg.category && pkg.category.startsWith('carrier-')) {
                    catBadge = `<span style="padding: 1px 5px; border-radius: 3px; background: rgba(245,158,11,0.2); color: #f59e0b; font-size: 10px;">🇹🇭 Carrier</span>`;
                } else if (pkg.category && pkg.category.startsWith('oem-')) {
                    catBadge = `<span style="padding: 1px 5px; border-radius: 3px; background: rgba(168,85,247,0.2); color: #c084fc; font-size: 10px;">OEM Bloat</span>`;
                } else if (pkg.category && (pkg.category.includes('bloat') || pkg.category.includes('tracker'))) {
                    catBadge = `<span style="padding: 1px 5px; border-radius: 3px; background: rgba(239,68,68,0.2); color: #f87171; font-size: 10px;">Tracker</span>`;
                }

                return `
                    <tr style="border-bottom: 1px solid rgba(255,255,255,0.05); transition: background 0.2s;">
                        <td style="padding: 6px 4px; text-align: center;">
                            <input type="checkbox" class="chk-debloat-item" data-pkg="${pkg.name}" style="accent-color: #38bdf8;">
                        </td>
                        <td style="padding: 6px 8px; font-family: monospace; color: #f1f5f9; word-break: break-all;">
                            ${labelText}
                            <span>${pkg.name}</span>
                        </td>
                        <td style="padding: 6px 8px;">${catBadge}</td>
                        <td style="padding: 6px 8px; text-align: center;">${statusBadge}</td>
                        <td style="padding: 6px 8px; text-align: right; white-space: nowrap;">
                            <button class="action-btn danger-btn btn-row-uninstall" data-pkg="${pkg.name}" style="padding: 3px 7px; font-size: 10.5px;" title="ถอนการติดตั้งสำหรับ user 0"><i class="fas fa-trash-alt"></i> ลบ</button>
                            <button class="action-btn safe-btn btn-row-restore" data-pkg="${pkg.name}" style="padding: 3px 7px; font-size: 10.5px;" title="กู้คืน package นี้"><i class="fas fa-undo"></i> กู้คืน</button>
                        </td>
                    </tr>
                `;
            }).join('');

            // Bind single item buttons
            tbody.querySelectorAll('.btn-row-uninstall').forEach(btn => {
                btn.addEventListener('click', async () => {
                    const pkgName = btn.getAttribute('data-pkg');
                    const keepData = chkKeepData ? chkKeepData.checked : true;
                    if (!confirm(`ถอนการติดตั้ง Package:\n${pkgName}\n\nสำหรับผู้ใช้หลัก (User 0)?`)) return;
                    btn.disabled = true;
                    try {
                        const res = await window.api.adbUninstallPackage({ packageName: pkgName, keepData });
                        if (res.success) {
                            showStatus(`✅ ถอนการติดตั้ง ${pkgName} สำเร็จ!`, true);
                            btn.closest('tr').style.opacity = '0.4';
                        } else {
                            showStatus(`❌ ลบไม่สำเร็จ: ${res.error || res.message}`, false);
                        }
                    } catch (err) {
                        showStatus(`❌ เกิดข้อผิดพลาด: ${err.message}`, false);
                    } finally {
                        btn.disabled = false;
                    }
                });
            });

            tbody.querySelectorAll('.btn-row-restore').forEach(btn => {
                btn.addEventListener('click', async () => {
                    const pkgName = btn.getAttribute('data-pkg');
                    btn.disabled = true;
                    try {
                        const res = await window.api.adbRestorePackage({ packageName: pkgName });
                        if (res.success) {
                            showStatus(`✅ กู้คืน ${pkgName} สำเร็จ!`, true);
                            btn.closest('tr').style.opacity = '1';
                        } else {
                            showStatus(`❌ กู้คืนไม่สำเร็จ: ${res.error || res.message}`, false);
                        }
                    } catch (err) {
                        showStatus(`❌ เกิดข้อผิดพลาด: ${err.message}`, false);
                    } finally {
                        btn.disabled = false;
                    }
                });
            });

            // Update selected buttons state
            updateSelectionState();
        }

        function showStatus(msg, isSuccess) {
            if (!statusBox) return;
            statusBox.style.display = 'block';
            statusBox.style.color = isSuccess ? '#4ade80' : '#f87171';
            statusBox.style.background = isSuccess ? 'rgba(74, 222, 128, 0.1)' : 'rgba(239, 68, 68, 0.1)';
            statusBox.style.border = `1px solid ${isSuccess ? 'rgba(74, 222, 128, 0.3)' : 'rgba(239, 68, 68, 0.3)'}`;
            statusBox.innerHTML = msg;
        }

        function updateSelectionState() {
            const checked = tbody ? tbody.querySelectorAll('.chk-debloat-item:checked') : [];
            const count = checked.length;
            if (btnUninstallSelected) {
                btnUninstallSelected.disabled = count === 0;
                btnUninstallSelected.innerHTML = `<i class="fas fa-trash-alt"></i> ถอนการติดตั้งที่เลือก (${count})`;
            }
            if (btnRestoreSelected) {
                btnRestoreSelected.disabled = count === 0;
                btnRestoreSelected.innerHTML = `<i class="fas fa-undo"></i> กู้คืนแอพที่เลือก (${count})`;
            }
        }

        if (tbody) {
            tbody.addEventListener('change', (e) => {
                if (e.target && e.target.classList.contains('chk-debloat-item')) {
                    updateSelectionState();
                }
            });
        }

        if (chkSelectAll) {
            chkSelectAll.addEventListener('change', () => {
                if (!tbody) return;
                const items = tbody.querySelectorAll('.chk-debloat-item');
                items.forEach(chk => { chk.checked = chkSelectAll.checked; });
                updateSelectionState();
            });
        }

        filterChips.forEach(chip => {
            chip.addEventListener('click', () => {
                filterChips.forEach(c => {
                    c.classList.remove('active');
                    c.style.background = 'rgba(255,255,255,0.06)';
                    c.style.color = '#cbd5e1';
                    c.style.borderColor = 'rgba(255,255,255,0.1)';
                });
                chip.classList.add('active');
                chip.style.background = '#0284c7';
                chip.style.color = '#fff';
                chip.style.borderColor = '#38bdf8';
                currentFilter = chip.getAttribute('data-cat') || 'all';
                renderTable();
            });
        });

        if (inputSearch) {
            inputSearch.addEventListener('input', () => {
                renderTable();
            });
        }

        if (btnScan) {
            btnScan.addEventListener('click', async () => {
                btnScan.disabled = true;
                const origHtml = btnScan.innerHTML;
                btnScan.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังอ่าน Package ในมือถือ...';
                showStatus('⚡ กำลังเชื่อมต่อ ADB และอ่านรายชื่อแอพที่ติดตั้งในเครื่อง...', true);

                try {
                    const res = await window.api.adbGetPackages('all');
                    if (res.success && res.packages) {
                        allPackages = res.packages;
                        updateCounts();
                        renderTable();
                        showStatus(`✅ โหลดรายชื่อสำเร็จ! พบทั้งหมด ${res.count} แพ็กเกจในเครื่อง`, true);
                    } else {
                        showStatus(`❌ สแกนล้มเหลว: ${res.error || 'โปรดตรวจสอบการเชื่อมต่อ USB Debugging'}`, false);
                    }
                } catch (err) {
                    showStatus(`❌ ข้อผิดพลาด: ${err.message}`, false);
                } finally {
                    btnScan.disabled = false;
                    btnScan.innerHTML = origHtml;
                }
            });
        }

        if (btnUninstallSelected) {
            btnUninstallSelected.addEventListener('click', async () => {
                const checked = Array.from(tbody.querySelectorAll('.chk-debloat-item:checked'));
                if (checked.length === 0) return;
                const keepData = chkKeepData ? chkKeepData.checked : true;
                if (!confirm(`ยืนยันลบ ${checked.length} แอพที่เลือกออกจากเครื่องผู้ใช้ปัจจุบัน?`)) return;

                btnUninstallSelected.disabled = true;
                showStatus(`⏳ กำลังถอนการติดตั้ง ${checked.length} แอพตามลำดับ...`, true);

                let successCount = 0;
                for (const item of checked) {
                    const pkg = item.getAttribute('data-pkg');
                    try {
                        const res = await window.api.adbUninstallPackage({ packageName: pkg, keepData });
                        if (res.success) successCount++;
                    } catch (e) {}
                }

                showStatus(`🎉 ถอนการติดตั้งสำเร็จ ${successCount} จาก ${checked.length} แอพเรียบร้อย!`, true);
                if (btnScan) btnScan.click();
            });
        }

        if (btnRestoreSelected) {
            btnRestoreSelected.addEventListener('click', async () => {
                const checked = Array.from(tbody.querySelectorAll('.chk-debloat-item:checked'));
                if (checked.length === 0) return;
                btnRestoreSelected.disabled = true;
                showStatus(`⏳ กำลังกู้คืน ${checked.length} แอพที่เลือก...`, true);

                let successCount = 0;
                for (const item of checked) {
                    const pkg = item.getAttribute('data-pkg');
                    try {
                        const res = await window.api.adbRestorePackage({ packageName: pkg });
                        if (res.success) successCount++;
                    } catch (e) {}
                }

                showStatus(`🎉 กู้คืนแอพสำเร็จ ${successCount} จาก ${checked.length} แอพ!`, true);
                if (btnScan) btnScan.click();
            });
        }

        if (btnUninstallManual) {
            btnUninstallManual.addEventListener('click', async () => {
                const pkg = (inputManual ? inputManual.value : '').trim();
                if (!pkg) { alert('กรุณาระบุ Package Name'); return; }
                const keepData = chkKeepData ? chkKeepData.checked : true;
                try {
                    const res = await window.api.adbUninstallPackage({ packageName: pkg, keepData });
                    if (res.success) {
                        showStatus(`✅ ลบ ${pkg} สำเร็จ!`, true);
                        if (inputManual) inputManual.value = '';
                    } else {
                        showStatus(`❌ ลบไม่สำเร็จ: ${res.error || res.message}`, false);
                    }
                } catch (err) {
                    showStatus(`❌ ข้อผิดพลาด: ${err.message}`, false);
                }
            });
        }

        if (btnRestoreManual) {
            btnRestoreManual.addEventListener('click', async () => {
                const pkg = (inputManual ? inputManual.value : '').trim();
                if (!pkg) { alert('กรุณาระบุ Package Name'); return; }
                try {
                    const res = await window.api.adbRestorePackage({ packageName: pkg });
                    if (res.success) {
                        showStatus(`✅ กู้คืน ${pkg} สำเร็จ!`, true);
                        if (inputManual) inputManual.value = '';
                    } else {
                        showStatus(`❌ กู้คืนไม่สำเร็จ: ${res.error || res.message}`, false);
                    }
                } catch (err) {
                    showStatus(`❌ ข้อผิดพลาด: ${err.message}`, false);
                }
            });
        }
    })();

    // =========================================================================
    // FEATURE 4: S.M.A.R.T. DISK HEALTH & STORAGE DIAGNOSTICS
    // =========================================================================
    (function initDiskSmartHealthModule() {
        const btnScan = document.getElementById('btn-disk-health-scan');
        const diskContainer = document.getElementById('disk-health-container');
        const volsContainer = document.getElementById('disk-volumes-container');
        const volsList = document.getElementById('disk-volumes-list');
        const chkdskSelect = document.getElementById('disk-chkdsk-drive-select');
        const btnSurfaceCheck = document.getElementById('btn-disk-surface-check');
        const btnOpenDiskMgmt = document.getElementById('btn-open-diskmgmt');
        const badge = document.getElementById('disk-health-summary-badge');
        const details = document.getElementById('disk-health-details');

        async function loadSmartHealth() {
            if (!diskContainer) return;
            diskContainer.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 20px; color: #38bdf8;"><i class="fas fa-spinner fa-spin"></i> กำลังอ่านข้อมูล S.M.A.R.T. และโครงสร้าง Physical Disk...</div>';
            
            try {
                const res = await window.api.getDiskSmartHealth();
                if (res && res.success && res.disks) {
                    if (badge) {
                        const allHealthy = res.disks.every(d => d.isHealthy);
                        badge.textContent = allHealthy ? 'ALL DISKS HEALTHY 100%' : 'WARNING / ATTENTION';
                        badge.style.color = allHealthy ? '#4ade80' : '#f87171';
                        badge.style.borderColor = allHealthy ? 'rgba(74, 222, 128, 0.4)' : 'rgba(239, 68, 68, 0.4)';
                        badge.style.background = allHealthy ? 'rgba(74, 222, 128, 0.15)' : 'rgba(239, 68, 68, 0.15)';
                    }

                    diskContainer.innerHTML = res.disks.map((d, idx) => {
                        const healthColor = d.isHealthy ? '#4ade80' : '#f87171';
                        const mediaBadgeColor = d.mediaType.includes('SSD') ? '#38bdf8' : '#f59e0b';
                        return `
                            <div style="background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.06); border-radius: 8px; padding: 12px; display: flex; flex-direction: column; justify-content: space-between;">
                                <div>
                                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                                        <strong style="color: #f1f5f9; font-size: 13px;">Disk ${d.deviceId}: ${d.friendlyName}</strong>
                                        <span style="font-size: 10px; padding: 2px 6px; border-radius: 4px; background: rgba(56,189,248,0.15); color: ${mediaBadgeColor}; font-weight: 600;">${d.mediaType}</span>
                                    </div>
                                    <div style="font-size: 11px; color: #94a3b8; margin-bottom: 8px; line-height: 1.5;">
                                        ความจุ: <strong style="color:#fff;">${d.sizeFormatted}</strong> | บัส: <strong style="color:#fff;">${d.busType}</strong><br>
                                        Serial Number: <span style="font-family: monospace; color:#cbd5e1;">${d.serialNumber}</span><br>
                                        Sector Size: <span style="font-family: monospace; color:#cbd5e1;">${d.sectorSize}</span>
                                    </div>
                                </div>
                                <div style="display: flex; justify-content: space-between; align-items: center; background: rgba(0,0,0,0.25); padding: 6px 10px; border-radius: 6px;">
                                    <span style="font-size: 11px; color: #94a3b8;">S.M.A.R.T. Status:</span>
                                    <span style="font-size: 11.5px; font-weight: 700; color: ${healthColor};">${d.smartStatus}</span>
                                </div>
                            </div>
                        `;
                    }).join('');

                    // Populate volumes list
                    if (res.volumes && res.volumes.length > 0 && volsContainer && volsList) {
                        volsContainer.style.display = 'block';
                        volsList.innerHTML = res.volumes.map(v => {
                            const usedPercent = 100 - v.percentFree;
                            return `
                                <div style="background: rgba(0,0,0,0.3); padding: 8px 10px; border-radius: 6px; border: 1px solid rgba(255,255,255,0.04); font-size: 11px;">
                                    <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
                                        <strong>Drive ${v.driveLetter}: (${v.label})</strong>
                                        <span style="color: #4ade80;">${v.fileSystem}</span>
                                    </div>
                                    <div style="background: rgba(255,255,255,0.1); height: 5px; border-radius: 3px; overflow: hidden; margin-bottom: 4px;">
                                        <div style="height: 100%; width: ${usedPercent}%; background: #38bdf8;"></div>
                                    </div>
                                    <div style="display: flex; justify-content: space-between; color: #94a3b8; font-size: 10px;">
                                        <span>ว่าง: ${v.freeFormatted}</span>
                                        <span>รวม: ${v.totalFormatted}</span>
                                    </div>
                                </div>
                            `;
                        }).join('');

                        // Populate drive select for chkdsk
                        if (chkdskSelect) {
                            chkdskSelect.innerHTML = res.volumes.map(v => `<option value="${v.driveLetter}">${v.driveLetter}: (${v.label || 'Drive'})</option>`).join('');
                        }
                    }
                } else {
                    diskContainer.innerHTML = `<div style="grid-column: 1/-1; color: #f87171; padding: 10px;">ไม่สามารถอ่านข้อมูลดิสก์ได้: ${res.error || 'ไม่มีข้อมูล'}</div>`;
                }
            } catch (err) {
                diskContainer.innerHTML = `<div style="grid-column: 1/-1; color: #f87171; padding: 10px;">ข้อผิดพลาด: ${err.message}</div>`;
            }
        }

        if (btnScan) btnScan.addEventListener('click', loadSmartHealth);

        if (btnSurfaceCheck) {
            btnSurfaceCheck.addEventListener('click', async () => {
                const drive = chkdskSelect ? chkdskSelect.value : 'C';
                btnSurfaceCheck.disabled = true;
                const origHtml = btnSurfaceCheck.innerHTML;
                btnSurfaceCheck.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังสแกน...';

                if (details) {
                    details.style.display = 'block';
                    details.innerHTML = `[CHKDSK] เริ่มต้นสแกนความสมบูรณ์ไฟล์และคลัสเตอร์ไดรฟ์ ${drive}: (Read-Only Scan)...\nโปรดรอสักครู่...`;
                }

                try {
                    const res = await window.api.runDiskSurfaceCheck(drive);
                    if (res.success && details) {
                        details.innerHTML = res.log || `✅ สแกนไดรฟ์ ${drive}: สำเร็จ ไม่พบข้อผิดพลาดร้ายแรง`;
                    } else if (details) {
                        details.innerHTML = `❌ การสแกนล้มเหลว: ${res.error || 'โปรดรันโปรแกรมในฐานะ Administrator'}`;
                    }
                } catch (err) {
                    if (details) details.innerHTML = `❌ Error: ${err.message}`;
                } finally {
                    btnSurfaceCheck.disabled = false;
                    btnSurfaceCheck.innerHTML = origHtml;
                }
            });
        }

        if (btnOpenDiskMgmt) {
            btnOpenDiskMgmt.addEventListener('click', () => {
                window.api.runAdminCommand('diskmgmt.msc');
            });
        }
    })();

    // =========================================================================
    // FEATURE 5: VENTOY MULTI-ISO USB CREATOR
    // =========================================================================
    (function initVentoyModule() {
        const usbSelect = document.getElementById('ventoy-usb-select');
        const btnRefresh = document.getElementById('btn-refresh-ventoy-disks');
        const styleSelect = document.getElementById('ventoy-style-select');
        const fsSelect = document.getElementById('ventoy-fs-select');
        const chkSecureBoot = document.getElementById('chk-ventoy-secure-boot');
        const btnInstall = document.getElementById('btn-install-ventoy');
        const btnUpdate = document.getElementById('btn-update-ventoy');
        const btnOpenDrive = document.getElementById('btn-open-ventoy-drive');
        const btnScanIsos = document.getElementById('btn-ventoy-scan-isos');
        const isoContainer = document.getElementById('ventoy-iso-list-container');
        const isoListItems = document.getElementById('ventoy-iso-list-items');
        const statusBox = document.getElementById('ventoy-status-box');

        let usbDisks = [];

        async function refreshVentoyDisks() {
            if (!usbSelect) return;
            usbSelect.innerHTML = '<option value="">กำลังสแกน Flash Drive (USB)...</option>';
            try {
                const disks = await window.api.getUsbDisks();
                usbDisks = disks || [];
                if (usbDisks.length > 0) {
                    usbSelect.innerHTML = usbDisks.map(d => {
                        const letterInfo = d.DriveLetters ? `(${d.DriveLetters})` : '(No drive letter)';
                        return `<option value="${d.Number}" data-letter="${d.DriveLetters || ''}">Disk ${d.Number}: ${d.FriendlyName} - ${d.Size} GB ${letterInfo}</option>`;
                    }).join('');
                } else {
                    usbSelect.innerHTML = '<option value="">ไม่พบ Flash Drive (USB) ที่เชื่อมต่อ</option>';
                }
            } catch (err) {
                usbSelect.innerHTML = '<option value="">เกิดข้อผิดพลาดในการสแกน USB</option>';
            }
        }

        function getSelectedDriveLetter() {
            if (!usbSelect) return '';
            const opt = usbSelect.options[usbSelect.selectedIndex];
            if (!opt) return '';
            const letters = opt.getAttribute('data-letter') || '';
            const match = letters.match(/([a-zA-Z]):/);
            return match ? match[1] : '';
        }

        if (btnRefresh) btnRefresh.addEventListener('click', refreshVentoyDisks);

        if (btnInstall) {
            btnInstall.addEventListener('click', async () => {
                const diskVal = usbSelect ? usbSelect.value : null;
                if (diskVal === '' || diskVal === null) {
                    alert('กรุณาเลือก USB Flash Drive ที่ต้องการติดตั้ง Ventoy');
                    return;
                }
                const diskNumber = parseInt(diskVal, 10);
                const driveLetter = getSelectedDriveLetter();
                const partitionStyle = styleSelect ? styleSelect.value : 'GPT';
                const fileSystem = fsSelect ? fsSelect.value : 'EXFAT';
                const secureBoot = chkSecureBoot ? chkSecureBoot.checked : true;

                if (!confirm(`⚠️ คำเตือนสำคัญมาก!\nการติดตั้ง Ventoy จะฟอร์แมตข้อมูลบน Flash Drive (Disk ${diskNumber}) ทั้งหมด 100%\nคุณแน่ใจหรือไม่ที่จะเริ่มติดตั้ง Ventoy?`)) {
                    return;
                }

                if (statusBox) {
                    statusBox.style.display = 'block';
                    statusBox.style.color = '#38bdf8';
                    statusBox.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังฟอร์แมตและติดตั้ง Ventoy Multi-Boot Engine...';
                }

                btnInstall.disabled = true;
                const origHtml = btnInstall.innerHTML;
                btnInstall.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังติดตั้ง...';

                try {
                    const res = await window.api.installVentoyUsb({
                        diskNumber,
                        driveLetter,
                        partitionStyle,
                        fileSystem,
                        secureBoot
                    });
                    if (res && res.success) {
                        if (statusBox) {
                            statusBox.style.color = '#4ade80';
                            statusBox.innerHTML = `✅ ติดตั้ง Ventoy สำเร็จ 100%! Flash Drive พร้อมวางไฟล์ ISO แล้ว`;
                        }
                        alert(`🎉 ติดตั้ง Ventoy Multi-ISO สำเร็จ 100%!\nคุณสามารถเปิดไดรฟ์แล้วก๊อปปี้ไฟล์ ISO เข้าไปได้เลย`);
                    }
                } catch (err) {
                    if (statusBox) {
                        statusBox.style.color = '#f87171';
                        statusBox.innerHTML = `❌ เกิดข้อผิดพลาด: ${err.message || err}`;
                    }
                    alert(`❌ การติดตั้ง Ventoy ล้มเหลว: ${err.message || err}`);
                } finally {
                    btnInstall.disabled = false;
                    btnInstall.innerHTML = origHtml;
                    refreshVentoyDisks();
                }
            });
        }

        if (btnUpdate) {
            btnUpdate.addEventListener('click', async () => {
                const driveLetter = getSelectedDriveLetter();
                const diskVal = usbSelect ? usbSelect.value : null;
                if (!driveLetter && (diskVal === '' || diskVal === null)) {
                    alert('กรุณาเลือก USB Flash Drive');
                    return;
                }
                const diskNumber = diskVal ? parseInt(diskVal, 10) : 0;
                btnUpdate.disabled = true;
                const origHtml = btnUpdate.innerHTML;
                btnUpdate.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังอัปเดต...';
                if (statusBox) {
                    statusBox.style.display = 'block';
                    statusBox.style.color = '#38bdf8';
                    statusBox.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังอัปเกรด Ventoy (ไม่ลบไฟล์ ISO)...';
                }

                try {
                    const res = await window.api.updateVentoyUsb({ driveLetter, diskNumber });
                    if (res && res.success) {
                        if (statusBox) {
                            statusBox.style.color = '#4ade80';
                            statusBox.innerHTML = `✅ อัปเดตเอนจิน Ventoy บน Flash Drive เรียบร้อย (ไฟล์ ISO ปลอดภัย)`;
                        }
                    }
                } catch (err) {
                    if (statusBox) {
                        statusBox.style.color = '#f87171';
                        statusBox.innerHTML = `❌ ข้อผิดพลาด: ${err.message || err}`;
                    }
                } finally {
                    btnUpdate.disabled = false;
                    btnUpdate.innerHTML = origHtml;
                }
            });
        }

        if (btnOpenDrive) {
            btnOpenDrive.addEventListener('click', async () => {
                const letter = getSelectedDriveLetter();
                if (!letter) {
                    alert('ไม่พบ Drive Letter ของ Flash Drive กรุณาตรวจสอบการเชื่อมต่อ');
                    return;
                }
                await window.api.openVentoyDrive(letter);
            });
        }

        if (btnScanIsos) {
            btnScanIsos.addEventListener('click', async () => {
                const letter = getSelectedDriveLetter();
                if (!letter) {
                    alert('กรุณาเลือก Flash Drive ที่มี Drive Letter');
                    return;
                }
                if (!isoContainer || !isoListItems) return;
                isoContainer.style.display = 'block';
                isoListItems.innerHTML = '<span style="color:#38bdf8;"><i class="fas fa-spinner fa-spin"></i> กำลังสแกนไฟล์ ISO ในไดรฟ์...</span>';

                try {
                    const res = await window.api.listVentoyIsos(letter);
                    if (res.success && res.files) {
                        if (res.files.length === 0) {
                            isoListItems.innerHTML = '<span style="color:#94a3b8;">ไม่พบไฟล์ ISO ในไดรฟ์ (เปิดไดรฟ์แล้วนำไฟล์ .iso มาวางได้เลย)</span>';
                        } else {
                            isoListItems.innerHTML = res.files.map(f => `
                                <div style="display: flex; justify-content: space-between; border-bottom: 1px solid rgba(255,255,255,0.05); padding: 3px 0;">
                                    <span style="color:#f1f5f9; font-weight:600;"><i class="fas fa-file-image" style="color:#38bdf8;"></i> ${f.name}</span>
                                    <span style="color:#94a3b8;">${f.sizeFormatted}</span>
                                </div>
                            `).join('');
                        }
                    } else {
                        isoListItems.innerHTML = `<span style="color:#f87171;">ไม่สามารถอ่านไดรฟ์ได้: ${res.error || ''}</span>`;
                    }
                } catch (err) {
                    isoListItems.innerHTML = `<span style="color:#f87171;">Error: ${err.message}</span>`;
                }
            });
        }
    })();

    // =========================================================================
    // FEATURE 6: LAPTOP BATTERY HEALTH & WEAR LEVEL DIAGNOSTICS
    // =========================================================================
    (function initBatteryModule() {
        const btnScan = document.getElementById('btn-battery-scan');
        const btnReport = document.getElementById('btn-battery-report');
        const infoCard = document.getElementById('battery-info-card');
        const contentLoaded = document.getElementById('battery-content-loaded');
        const desktopNotice = document.getElementById('battery-desktop-notice');
        const desktopMsg = document.getElementById('battery-desktop-msg');
        const percentText = document.getElementById('battery-health-percent');
        const healthBar = document.getElementById('battery-health-bar');
        const designCap = document.getElementById('batt-design-cap');
        const fullCap = document.getElementById('batt-full-cap');
        const wearLevel = document.getElementById('batt-wear-level');
        const cycleCount = document.getElementById('batt-cycle-count');
        const chem = document.getElementById('batt-chem');
        const mfg = document.getElementById('batt-mfg');
        const verdictBox = document.getElementById('battery-verdict-box');
        const badge = document.getElementById('battery-health-badge');
        const statusBox = document.getElementById('battery-report-status');

        let lastReportPath = null;

        if (btnScan) {
            btnScan.addEventListener('click', async () => {
                btnScan.disabled = true;
                const origHtml = btnScan.innerHTML;
                btnScan.innerHTML = '<i class="fas fa-spinner fa-spin"></i> กำลังวิเคราะห์...';
                if (statusBox) statusBox.style.display = 'none';
                if (infoCard) infoCard.style.display = 'block';

                try {
                    const res = await window.api.getBatteryHealth();
                    if (res && res.success) {
                        if (res.isDesktop || !res.hasBattery) {
                            if (contentLoaded) contentLoaded.style.display = 'none';
                            if (desktopNotice) {
                                desktopNotice.style.display = 'block';
                                if (desktopMsg) desktopMsg.textContent = res.message;
                            }
                            if (badge) {
                                badge.textContent = 'DESKTOP / AC';
                                badge.style.color = '#38bdf8';
                                badge.style.borderColor = 'rgba(56,189,248,0.4)';
                            }
                        } else {
                            if (desktopNotice) desktopNotice.style.display = 'none';
                            if (contentLoaded) contentLoaded.style.display = 'block';

                            lastReportPath = res.reportPath;
                            if (percentText) {
                                percentText.textContent = `${res.healthPercent}%`;
                                percentText.style.color = res.badgeColor;
                            }
                            if (healthBar) {
                                healthBar.style.width = `${res.healthPercent}%`;
                                healthBar.style.background = res.badgeColor;
                            }
                            if (designCap) designCap.textContent = `${res.designCapacityMwh.toLocaleString()} mWh`;
                            if (fullCap) fullCap.textContent = `${res.fullChargeCapacityMwh.toLocaleString()} mWh`;
                            if (wearLevel) wearLevel.textContent = `${res.wearPercent}% (${res.wearPercent > 20 ? 'เสื่อม' : 'ปกติ'})`;
                            if (cycleCount) cycleCount.textContent = `${res.cycleCount} รอบ`;
                            if (chem) chem.textContent = res.chemistry;
                            if (mfg) mfg.textContent = `${res.manufacturer} (${res.batteryName})`;
                            if (verdictBox) {
                                verdictBox.innerHTML = `<strong>ผลการวิเคราะห์ช่าง:</strong> ${res.evaluation}`;
                                verdictBox.style.borderColor = res.badgeColor;
                            }
                            if (badge) {
                                badge.textContent = `HEALTH ${res.healthPercent}%`;
                                badge.style.color = res.badgeColor;
                                badge.style.borderColor = res.badgeColor;
                            }
                        }
                    } else {
                        if (statusBox) {
                            statusBox.style.display = 'block';
                            statusBox.style.color = '#f87171';
                            statusBox.textContent = `❌ ตรวจสอบไม่สำเร็จ: ${res.error || 'โปรดลองอีกครั้ง'}`;
                        }
                    }
                } catch (err) {
                    if (statusBox) {
                        statusBox.style.display = 'block';
                        statusBox.style.color = '#f87171';
                        statusBox.textContent = `❌ ข้อผิดพลาด: ${err.message}`;
                    }
                } finally {
                    btnScan.disabled = false;
                    btnScan.innerHTML = origHtml;
                }
            });
        }

        if (btnReport) {
            btnReport.addEventListener('click', async () => {
                btnReport.disabled = true;
                try {
                    await window.api.openBatteryReport(lastReportPath);
                } catch (err) {
                    alert('ไม่สามารถเปิดรายงานได้: ' + err.message);
                } finally {
                    btnReport.disabled = false;
                }
            });
        }
    })();

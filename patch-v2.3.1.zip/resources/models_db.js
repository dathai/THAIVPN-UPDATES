// Database of Phone Models
// Format: Model Code (Market Name) [CPU, Year]

const APP_MODELS_DB = {
    'SAMSUNG': [
        'SM-A055F (Galaxy A05) [MediaTek Helio G85, 2023]',
        'SM-A065F (Galaxy A06) [MediaTek Helio G85, 2024]',
        'SM-A146B (Galaxy A14 5G) [Exynos 1330, 2023]',
        'SM-A245F (Galaxy A24) [MediaTek Helio G99, 2023]',
        'SM-A346E (Galaxy A34 5G) [MediaTek Dimensity 1080, 2023]',
        'SM-A546E (Galaxy A54 5G) [Exynos 1380, 2023]',
        'SM-A556E (Galaxy A55 5G) [Exynos 1480, 2024]',
        'SM-G991B (Galaxy S21 5G) [Exynos 2100, 2021]',
        'SM-S901B (Galaxy S22) [Snapdragon 8 Gen 1, 2022]',
        'SM-S911B (Galaxy S23) [Snapdragon 8 Gen 2, 2023]',
        'SM-S928B (Galaxy S24 Ultra) [Snapdragon 8 Gen 3, 2024]',
        'SM-N985F (Galaxy Note 20 Ultra) [Exynos 990, 2020]'
    ],
    'OPPO': [
        'CPH2185 (A15) [MediaTek Helio P35, 2020]',
        'CPH2239 (A54) [MediaTek Helio P35, 2021]',
        'CPH2349 (A77s) [Snapdragon 680, 2022]',
        'CPH2529 (A78 5G) [Dimensity 700, 2023]',
        'CPH2603 (A79 5G) [Dimensity 6020, 2023]',
        'CPH2363 (Reno 7) [Snapdragon 680, 2022]',
        'CPH2457 (Reno 8T) [Helio G99, 2023]',
        'CPH2531 (Reno 10 5G) [Dimensity 7050, 2023]'
    ],
    'VIVO': [
        'V2026 (Y12s) [Helio P35, 2020]',
        'V2111 (Y21) [Helio P35, 2021]',
        'V2250 (Y36) [Snapdragon 680, 2023]',
        'V2313 (Y27s) [Snapdragon 680, 2023]',
        'V2050 (V21 5G) [Dimensity 800U, 2021]',
        'V2303 (V29 5G) [Snapdragon 778G, 2023]'
    ],
    'Xiaomi': [
        'apollo (Mi 10T Pro) [Snapdragon 865, 2020]',
        'alioth (Poco F3) [Snapdragon 870, 2021]',
        'vayu (Poco X3 Pro) [Snapdragon 860, 2021]',
        'sweet (Redmi Note 10 Pro) [Snapdragon 732G, 2021]',
        'spes (Redmi Note 11) [Snapdragon 680, 2022]',
        'tapas (Redmi Note 12) [Snapdragon 685, 2023]',
        'garnet (Redmi Note 13 Pro) [Snapdragon 7s Gen 2, 2023]'
    ],
    'HUAWEI': [
        'INE-LX2 (Nova 3i) [Kirin 710, 2018]',
        'YAL-L21 (Nova 5T) [Kirin 980, 2019]',
        'NEN-LX1 (Nova 8i) [Snapdragon 662, 2021]',
        'JLN-LX1 (Nova 9 SE) [Snapdragon 680, 2022]'
    ],
    'LAVA/AIS': [
        '750 (LAVA 750) [MediaTek MT6737, 2017]',
        '810 (LAVA 810) [MediaTek MT6735, 2016]'
    ]
};

// Expose it to global
window.APP_MODELS_DB = APP_MODELS_DB;
